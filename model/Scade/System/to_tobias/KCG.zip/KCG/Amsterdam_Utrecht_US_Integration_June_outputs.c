/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config C:/GITHUB/modeling/model/Scade/System/TracksideDynamicModel/TestTracks/UtrechtAmsterdam_oETCS/KCG\kcg_s2c_config.txt
** Generation date: 2015-07-21T17:56:59
*************************************************************$ */
#include "Amsterdam_Utrecht_US_Integration_June.h"

/* US_Integration_June::Amsterdam_Utrecht::Balise_Packets */
CompressedPackets_T_Common_Types_Pkg Balise_Packets;
/* US_Integration_June::Amsterdam_Utrecht::Balise_Header */
TelegramHeader_T_BG_Types_Pkg Balise_Header;
/* US_Integration_June::Amsterdam_Utrecht::RadioTrackTrainHeader_out */
Radio_TrackTrain_Header_T_Radio_Types_Pkg RadioTrackTrainHeader_out;
/* US_Integration_June::Amsterdam_Utrecht::Compressed_Packets_out */
CompressedPackets_T_Common_Types_Pkg Compressed_Packets_out;
/* US_Integration_June::Amsterdam_Utrecht::Compressed_Radio_Message_out */
CompressedRadioMessage_TM Compressed_Radio_Message_out;

/* $*************** KCG Version 6.1.3 (build i6) ****************
** Amsterdam_Utrecht_US_Integration_June_outputs.c
** Generation date: 2015-07-21T17:56:59
*************************************************************$ */

