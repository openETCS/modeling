/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config C:/GITHUB/modeling/model/Scade/System/TracksideDynamicModel/TestTracks/UtrechtAmsterdam_oETCS/KCG\kcg_s2c_config.txt
** Generation date: 2015-07-21T17:56:59
*************************************************************$ */
#include "Amsterdam_Utrecht_US_Integration_June.h"

/* US_Integration_June::Amsterdam_Utrecht::TrainPos */
kcg_real TrainPos;
/* US_Integration_June::Amsterdam_Utrecht::Trigger_in */
kcg_int Trigger_in;

/* $*************** KCG Version 6.1.3 (build i6) ****************
** Amsterdam_Utrecht_US_Integration_June_inputs.c
** Generation date: 2015-07-21T17:56:59
*************************************************************$ */

