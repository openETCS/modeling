/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _genPassedBG_itr_ctp_t_pck_t_engine_H_
#define _genPassedBG_itr_ctp_t_pck_t_engine_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG_itr::cont */ cont;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG */ passedBG;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::genPassedBG_itr::_L1 */ _L1;
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG_itr::_L2 */ _L2;
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG_itr::_L3 */ _L3;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genPassedBG_itr::_L4 */ _L4;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genPassedBG_itr::_L5 */ _L5;
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG_itr::_L6 */ _L6;
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG_itr::_L7 */ _L7;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG_itr::_L8 */ _L8;
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG_itr::_L9 */ _L9;
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::genPassedBG_itr::_L10 */ _L10;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG_itr::_L11 */ _L11;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG_itr::_L12 */ _L12;
} outC_genPassedBG_itr_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::genPassedBG_itr */
extern void genPassedBG_itr_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG_itr::accPassedBG */passedBG_T_BG_Types_Pkg *accPassedBG,
  /* ctp_t_pck::t_engine::genPassedBG_itr::trueLocation */L_internal_Type_Obu_BasicTypes_Pkg trueLocation,
  /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG_in */genPassedBG_T_ctp_t_pck_t_engine *passedBG_in,
  outC_genPassedBG_itr_ctp_t_pck_t_engine *outC);

extern void genPassedBG_itr_reset_ctp_t_pck_t_engine(
  outC_genPassedBG_itr_ctp_t_pck_t_engine *outC);

#endif /* _genPassedBG_itr_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_itr_ctp_t_pck_t_engine.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

