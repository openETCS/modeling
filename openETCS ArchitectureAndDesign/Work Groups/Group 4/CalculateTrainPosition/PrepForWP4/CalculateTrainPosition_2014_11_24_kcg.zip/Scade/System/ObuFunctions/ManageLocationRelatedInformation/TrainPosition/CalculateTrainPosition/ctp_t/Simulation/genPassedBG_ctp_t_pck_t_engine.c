/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genPassedBG_ctp_t_pck_t_engine.h"

void genPassedBG_reset_ctp_t_pck_t_engine(
  outC_genPassedBG_ctp_t_pck_t_engine *outC)
{
  kcg_int i;
  
  for (i = 0; i < 10; i++) {
    /* 1 */ genPassedBG_itr_reset_ctp_t_pck_t_engine(&outC->Context_1[i]);
  }
}

/* ctp_t_pck::t_engine::genPassedBG */
void genPassedBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG::trueLocation */L_internal_Type_Obu_BasicTypes_Pkg trueLocation,
  /* ctp_t_pck::t_engine::genPassedBG::odometry */odometry_T_Obu_BasicTypes_Pkg *odometry,
  /* ctp_t_pck::t_engine::genPassedBG::passedBGs */genPassedBGs_T_ctp_t_pck_t_engine *passedBGs,
  outC_genPassedBG_ctp_t_pck_t_engine *outC)
{
  kcg_int i1;
  passedBG_T_BG_Types_Pkg tmp;
  kcg_int i;
  kcg_int noname;
  
  kcg_copy_passedBG_T_BG_Types_Pkg(
    &outC->_L6,
    (passedBG_T_BG_Types_Pkg *) &cNoPassedBG_CalculateTrainPosition_Pkg);
  outC->_L1 = trueLocation;
  for (i1 = 0; i1 < 10; i1++) {
    outC->_L7[i1] = outC->_L1;
  }
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&outC->_L2, passedBGs);
  outC->_L8 = kcg_true;
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L3, &outC->_L6);
  if (outC->_L8) {
    for (i = 0; i < 10; i++) {
      kcg_copy_passedBG_T_BG_Types_Pkg(&tmp, &outC->_L3);
      /* 1 */
      genPassedBG_itr_ctp_t_pck_t_engine(
        &tmp,
        outC->_L7[i],
        &outC->_L2[i],
        &outC->Context_1[i]);
      kcg_copy_passedBG_T_BG_Types_Pkg(
        &outC->_L3,
        &outC->Context_1[i].passedBG);
      outC->_L5 = i + 1;
      if (!outC->Context_1[i].cont) {
        break;
      }
    }
  }
  else {
    outC->_L5 = 0;
  }
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L10, odometry);
  kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(&outC->_L11, &outC->_L10.odo);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L9, &outC->_L3);
  if (kcg_true) {
    kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
      &outC->_L9.odometrystamp,
      &outC->_L11);
  }
  outC->_L12 = outC->_L10.timestamp;
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L13, &outC->_L9);
  if (kcg_true) {
    outC->_L13.timestamp = outC->_L12;
  }
  noname = outC->_L5;
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->passedBG, &outC->_L13);
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_ctp_t_pck_t_engine.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

