/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.h"

void runningDirectionVsRef_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  /* 1 */
  trainMovementSensor_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
    &outC->Context_1);
}

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef */
void runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refTrainRunningDirection */Q_DIRTRAIN refTrainRunningDirection,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refSpeed */Speed_T_Obu_BasicTypes_Pkg refSpeed,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else */
  static kcg_bool else_clock_IfBlock2;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2 */
  static kcg_bool IfBlock2_clock;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refDir */
  static trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg refDir;
  
  /* 1 */
  trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(
    currentOdometry,
    &outC->Context_1);
  else_clock_IfBlock2 = refSpeed > 0;
  if (else_clock_IfBlock2) {
    refDir = trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg;
  }
  else {
    IfBlock2_clock = refSpeed < 0;
    if (IfBlock2_clock) {
      refDir = trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg;
    }
    else {
      refDir = trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg;
    }
  }
  IfBlock2_clock = outC->Context_1.direction == refDir;
  if (IfBlock2_clock) {
    outC->trainRunningDirection = refTrainRunningDirection;
  }
  else {
    else_clock_IfBlock2 = (outC->Context_1.direction ==
        trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg) | (refDir ==
        trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg);
    if (else_clock_IfBlock2) {
      outC->trainRunningDirection = Q_DIRTRAIN_Unknown;
    }
    else if (refTrainRunningDirection == Q_DIRTRAIN_Nominal) {
      outC->trainRunningDirection = Q_DIRTRAIN_Reverse;
    }
    else {
      outC->trainRunningDirection = Q_DIRTRAIN_Nominal;
    }
  }
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.c
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

