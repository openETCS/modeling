/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateTrainPositionInfo_CalculateTrainPosition_Pkg.h"

void calculateTrainPositionInfo_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg *outC)
{
  outC->init = kcg_true;
}

/* CalculateTrainPosition_Pkg::calculateTrainPositionInfo */
void calculateTrainPositionInfo_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::BGs */positionedBGs_T_TrainPosition_Types_Pck *BGs,
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::recalculateBGs */kcg_bool recalculateBGs,
  outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg *outC)
{
  static kcg_bool tmp1;
  static kcg_bool tmp2;
  static kcg_bool tmp;
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::_L7 */
  static LocWithInAcc_T_Obu_BasicTypes_Pkg _L7;
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::_L8 */
  static LocWithInAcc_T_Obu_BasicTypes_Pkg _L8;
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::_L10 */
  static LocWithInAcc_T_Obu_BasicTypes_Pkg _L10;
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::_L11 */
  static kcg_bool _L11;
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::_L20 */
  static positionedBG_T_TrainPosition_Types_Pck _L20;
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::_L22 */
  static positionedBG_T_TrainPosition_Types_Pck _L22;
  
  outC->trainPositionInfo.timestamp = (*currentOdometry).timestamp;
  outC->trainPositionInfo.speed = (*currentOdometry).speed;
  if (recalculateBGs) {
    /* 1 */
    indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
      kcg_true,
      BGs,
      recalculateBGs,
      &outC->_L17,
      &tmp2,
      &tmp1);
    /* 2 */
    indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
      kcg_false,
      BGs,
      recalculateBGs,
      &outC->_L23,
      &tmp,
      &_L11);
  }
  else if (outC->init) {
    outC->_L23 = cNoValidIndex_CalculateTrainPosition_Pkg;
    outC->_L17 = cNoValidIndex_CalculateTrainPosition_Pkg;
  }
  if ((0 <= outC->_L23) & (outC->_L23 < 8)) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&_L22, &(*BGs)[outC->_L23]);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &_L22,
      (positionedBG_T_TrainPosition_Types_Pck *)
        &cNoPositionedBG_CalculateTrainPosition_Pkg);
  }
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo.lastPassedUnlinkedBG,
    &_L22);
  outC->init = kcg_false;
  if ((0 <= outC->_L17) & (outC->_L17 < 8)) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&_L20, &(*BGs)[outC->_L17]);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &_L20,
      (positionedBG_T_TrainPosition_Types_Pck *)
        &cNoPositionedBG_CalculateTrainPosition_Pkg);
  }
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo.lastPassedLinkedBG,
    &_L20);
  /* 1 */
  positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &(*currentOdometry).odo,
    &_L20,
    &_L7);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->trainPositionInfo.trainPositionDerivedFromLastLinkedBG,
    &_L7);
  /* 2 */
  positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &(*currentOdometry).odo,
    &_L22,
    &_L8);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->trainPositionInfo.trainPositionDerivedFromLastUnlinkedBG,
    &_L8);
  /* 1 */
  overlapOf_2_Locations_BasicLocationFunctions_Pkg(&_L7, &_L8, &_L10, &_L11);
  outC->trainPositionInfo.valid = _L11;
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->trainPositionInfo.trainPosition,
    &_L10);
  outC->positionCalculationNotConsistent = !_L11;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainPositionInfo_CalculateTrainPosition_Pkg.c
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

