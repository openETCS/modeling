/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateTrainPosition_CalculateTrainPosition_Pkg.h"

void calculateTrainPosition_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainPosition_CalculateTrainPosition_Pkg *outC)
{
  outC->init = kcg_true;
  /* 1 */
  calculateTrainpositionAttributes_reset_CalculateTrainPosition_Pkg(
    &outC->_3_Context_1);
  /* 1 */
  calculateTrainPositionInfo_reset_CalculateTrainPosition_Pkg(
    &outC->_2_Context_1);
  /* 1 */
  delDispensableBGs_reset_CalculateTrainPosition_Pkg(&outC->_1_Context_1);
  /* 1 */
  calculateBGLocations_reset_CalculateTrainPosition_Pkg(&outC->Context_1);
}

/* CalculateTrainPosition_Pkg::calculateTrainPosition */
void calculateTrainPosition_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::passedBG */passedBG_T_BG_Types_Pkg *passedBG,
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::LRBG */positionedBG_T_TrainPosition_Types_Pck *LRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::prevLRBG */positionedBG_T_TrainPosition_Types_Pck *prevLRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::reset */kcg_bool reset,
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  outC_calculateTrainPosition_CalculateTrainPosition_Pkg *outC)
{
  positionErrors_T_TrainPosition_Types_Pck tmp2;
  positionedBGs_T_TrainPosition_Types_Pck tmp1;
  positionedBGs_T_TrainPosition_Types_Pck tmp;
  positionedBGs_T_TrainPosition_Types_Pck tmp3;
  positionErrors_T_TrainPosition_Types_Pck tmp4;
  positionedBGs_T_TrainPosition_Types_Pck tmp5;
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::BGs_loc */ positionedBGs_T_TrainPosition_Types_Pck last_BGs_loc;
  
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L202, passedBG);
  outC->_L217 = outC->_L202.valid;
  outC->_L203 = reset;
  outC->_L229 = outC->_L217 | outC->_L203;
  outC->tmp4 = outC->_L229;
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
    &outC->_L227,
    (positionedBGs_T_TrainPosition_Types_Pck *)
      &cNoPositionedBGs_CalculateTrainPosition_Pkg);
  if (outC->init) {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &last_BGs_loc,
      (positionedBGs_T_TrainPosition_Types_Pck *)
        &cNoPositionedBGs_CalculateTrainPosition_Pkg);
  }
  else {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &last_BGs_loc,
      &outC->BGs_loc);
  }
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L210, &last_BGs_loc);
  if (outC->_L203) {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &outC->_L228,
      &outC->_L227);
  }
  else {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &outC->_L228,
      &outC->_L210);
  }
  kcg_copy_trainProperties_T_TrainPosition_Types_Pck(
    &outC->_L234,
    trainProperties);
  if (outC->tmp4) {
    /* 1 */
    calculateBGLocations_CalculateTrainPosition_Pkg(
      &outC->_L202,
      &outC->_L228,
      outC->_L203,
      &outC->_L234,
      &outC->Context_1);
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &tmp5,
      &outC->Context_1.BGs);
    kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
      &tmp4,
      &outC->Context_1.errors);
  }
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
    &outC->_L231,
    (positionErrors_T_TrainPosition_Types_Pck *)
      &cNoPositionErrors_CalculateTrainPosition_Pkg);
  if (outC->tmp4) {
    kcg_copy_positionErrors_T_TrainPosition_Types_Pck(&outC->_L199, &tmp4);
  }
  else {
    if (outC->init) {
      kcg_copy_positionErrors_T_TrainPosition_Types_Pck(&tmp2, &outC->_L231);
    }
    else {
      kcg_copy_positionErrors_T_TrainPosition_Types_Pck(&tmp2, &outC->_L199);
    }
    kcg_copy_positionErrors_T_TrainPosition_Types_Pck(&outC->_L199, &tmp2);
  }
  outC->tmp = outC->_L229;
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
    &outC->_L230,
    (positionedBGs_T_TrainPosition_Types_Pck *)
      &cNoPositionedBGs_CalculateTrainPosition_Pkg);
  if (outC->tmp4) {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L198, &tmp5);
  }
  else {
    if (outC->init) {
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&tmp1, &outC->_L230);
    }
    else {
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&tmp1, &outC->_L198);
    }
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L198, &tmp1);
  }
  if (outC->tmp) {
    /* 1 */
    delDispensableBGs_CalculateTrainPosition_Pkg(
      &outC->_L198,
      outC->_L229,
      &outC->_1_Context_1);
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &tmp3,
      &outC->_1_Context_1.BGs_out);
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L233, &tmp3);
  }
  else {
    if (outC->init) {
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&tmp, &outC->_L230);
    }
    else {
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&tmp, &outC->_L233);
    }
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L233, &tmp);
  }
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L201, currentOdometry);
  /* 1 */
  calculateTrainPositionInfo_CalculateTrainPosition_Pkg(
    &outC->_L201,
    &outC->_L233,
    outC->_L229,
    &outC->_2_Context_1);
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->_L215,
    &outC->_2_Context_1.trainPositionInfo);
  outC->_L216 = outC->_2_Context_1.positionCalculationNotConsistent;
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(&outC->_L232, &outC->_L199);
  if (kcg_true) {
    outC->_L232.positionCalculation_inconsistent = outC->_L216;
  }
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
    &outC->BGs_loc,
    &outC->_L233);
  kcg_copy_trainProperties_T_TrainPosition_Types_Pck(
    &outC->_L207,
    trainProperties);
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo,
    &outC->_L215);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L204, LRBG);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L205, prevLRBG);
  /* 1 */
  calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(
    &outC->_L204,
    &outC->_L205,
    &outC->_L215,
    &outC->_L201,
    &outC->_L207,
    &outC->_3_Context_1);
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->_L200,
    &outC->_3_Context_1.trainPosition);
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->trainPosition,
    &outC->_L200);
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
    &outC->errors,
    &outC->_L232);
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->BGs, &outC->_L233);
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainPosition_CalculateTrainPosition_Pkg.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

