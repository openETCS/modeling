/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genOdometry_ctp_t_pck_t_engine.h"

void genOdometry_reset_ctp_t_pck_t_engine(
  outC_genOdometry_ctp_t_pck_t_engine *outC)
{
  outC->init = kcg_true;
}

/* ctp_t_pck::t_engine::genOdometry */
void genOdometry_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genOdometry::trueLocation */L_internal_Type_Obu_BasicTypes_Pkg trueLocation,
  /* ctp_t_pck::t_engine::genOdometry::time */T_internal_Type_Obu_BasicTypes_Pkg time,
  /* ctp_t_pck::t_engine::genOdometry::odometryProperties */odometryFactors_T_ctp_t_pck_t_engine *odometryProperties,
  outC_genOdometry_ctp_t_pck_t_engine *outC)
{
  outC->_L32 = 1;
  outC->I2_1 = outC->_L32;
  kcg_copy_odometryFactors_T_ctp_t_pck_t_engine(
    &outC->_L33,
    odometryProperties);
  outC->_L15 = outC->_L33.o_max;
  outC->_L14 = outC->_L33.o_min;
  outC->_L31 = 36;
  if (outC->init) {
    outC->_L29 = 100;
  }
  else {
    outC->_L29 = outC->_L27;
  }
  outC->_L27 = time;
  outC->_L28 = outC->_L27 - outC->_L29;
  outC->I1_1 = outC->_L28;
  outC->_L1_1 = outC->I1_1;
  outC->_L2_1 = outC->I2_1;
  outC->_L3_1 = outC->_L1_1 >= outC->_L2_1;
  if (outC->_L3_1) {
    outC->_L4_1 = outC->_L1_1;
  }
  else {
    outC->_L4_1 = outC->_L2_1;
  }
  outC->Ma_Output_1 = outC->_L4_1;
  outC->_L30 = outC->Ma_Output_1;
  if (outC->init) {
    outC->_L25 = 0;
  }
  else {
    outC->_L25 = outC->_L17;
  }
  outC->_L13 = outC->_L33.o_nominal;
  outC->_L1 = trueLocation;
  outC->_L16 = (kcg_real) outC->_L1;
  outC->_L20 = outC->_L13 * outC->_L16;
  outC->_L17 = (kcg_int) outC->_L20;
  outC->_L24 = outC->_L17 - outC->_L25;
  outC->_L23 = outC->_L24 * outC->_L31;
  outC->_L26 = outC->_L23 / outC->_L30;
  outC->_L22 = outC->_L15 * outC->_L16;
  outC->_L21 = outC->_L14 * outC->_L16;
  outC->_L19 = (kcg_int) outC->_L22;
  outC->_L18 = (kcg_int) outC->_L21;
  outC->_L8.o_nominal = outC->_L17;
  outC->_L8.o_min = outC->_L18;
  outC->_L8.o_max = outC->_L19;
  outC->_L4 = time;
  outC->_L3 = kcg_true;
  outC->_L2.valid = outC->_L3;
  outC->_L2.timestamp = outC->_L4;
  kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(&outC->_L2.odo, &outC->_L8);
  outC->_L2.speed = outC->_L26;
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->odometry, &outC->_L2);
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genOdometry_ctp_t_pck_t_engine.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

