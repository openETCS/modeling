#include <stdlib.h>
#include <stddef.h>
#include "NewSmuTypes.h"
#include "kcg_types.h"
#include "ctp_t_newtype.h"
#include "kcg_conv.h"

char* strDefaultRealFormat="%.5g"; /*(from .etp)*/

#define skip_whitespace(str) while(*str == ' ' || *str == '\t') str++

/****************************************************************
 ** utility functions 
 ****************************************************************/

static int string_to_VTable(const char *str, const struct SimTypeVTable *pVTable, void *pValue, char **endptr)
{
    int nRet;
    if (pVTable != NULL && pVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
        nRet = pVTable->m_pfnFromType(SptString, (const void*)&str, pValue);
        if (nRet != 0) {
            *endptr = (char*)str+strlen(str);
        }
        return nRet;
    };
    return 0;
}

static int is_VTable_double_convertion_allowed(const struct SimTypeVTable *pVTable)
{
    if (pVTable != NULL) {
        int nConvertionAllowed = 0;
        nConvertionAllowed |= pVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
        nConvertionAllowed |= pVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
        nConvertionAllowed |= pVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
        nConvertionAllowed |= pVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
        return nConvertionAllowed;
    }
    return 1;
}

int VTable_to_double(const void *pValue, const struct SimTypeVTable *pVTable, double *nRetValue)
{
    if (pVTable != NULL) {
        if (pVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
            *nRetValue = (*(double*)pVTable->m_pfnToType(SptDouble, pValue));
        else if (pVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
            *nRetValue = (double)(*(float*)pVTable->m_pfnToType(SptFloat, pValue));
        else if (pVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
            *nRetValue = (double)(*(long*)pVTable->m_pfnToType(SptLong, pValue));
        else if (pVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
            *nRetValue = (double)(*(int*)pVTable->m_pfnToType(SptShort, pValue));
        else
            return 0;
    }
    return 1;
}

static int get_enum_signature(const SimEnumValUtils *pEnumVals, int nSize, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    int i;
    pfnStrAppend("E", pData);
    for(i=0; i<nSize; i++) {
        pfnStrAppend("|", pData);
        pfnStrAppend(pEnumVals[i].m_name, pData);
    }
    return 1;
}

static int get_structure_signature(const SimFieldUtils *pFields, int nSize, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for(i=0; i<nSize; i++) {
        if (i > 0)
            pfnStrAppend(",", pData);
        pFields[i].m_pTypeUtils->m_pfnGetSignature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

/****************************************************************
 ** SSM_ST_SM1 
 ****************************************************************/

struct SimTypeVTable *pSimSSM_ST_SM1VTable;

static SimEnumValUtils SSM_ST_SM1_values[] = {
    { "Unknown", SSM_st_Unknown_SM1},
    { "Unknown", SSM_st_Unknown_SM1},
    { "Decreasing", SSM_st_Decreasing_SM1},
    { "Decreasing", SSM_st_Decreasing_SM1},
    { "Increasing", SSM_st_Increasing_SM1},
    { "Increasing", SSM_st_Increasing_SM1},
    { "Standstill", SSM_st_Standstill_SM1},
    { "Standstill", SSM_st_Standstill_SM1},
};

int SSM_ST_SM1_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimSSM_ST_SM1VTable != NULL
        && pSimSSM_ST_SM1VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimSSM_ST_SM1VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(SSM_ST_SM1*)pValue, SSM_ST_SM1_values, 8, pfnStrAppend, pData);
}

int string_to_SSM_ST_SM1(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimSSM_ST_SM1VTable != NULL) {
        nRet=string_to_VTable(str, pSimSSM_ST_SM1VTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, SSM_ST_SM1_values, 8, endptr);
        if (pValue != NULL && nRet != 0)
            *(SSM_ST_SM1*)pValue = nTemp;
    }
    return nRet;
}

int is_SSM_ST_SM1_double_convertion_allowed()
{
    if (pSimSSM_ST_SM1VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimSSM_ST_SM1VTable);
    }
    return 1;
}

void compare_SSM_ST_SM1(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimSSM_ST_SM1VTable != NULL
        && pSimSSM_ST_SM1VTable->m_version >= Scv612
        && pSimSSM_ST_SM1VTable->m_pfnCompare != NULL) {
        if (pSimSSM_ST_SM1VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimSSM_ST_SM1VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimSSM_ST_SM1VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(SSM_ST_SM1*)pValue1), (int)(*(SSM_ST_SM1*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int SSM_ST_SM1_to_double(const void *pValue, double *nRetValue)
{
    if (pSimSSM_ST_SM1VTable != NULL) {
        return VTable_to_double(pValue, pSimSSM_ST_SM1VTable, nRetValue);
    }
    *nRetValue = (double)*((SSM_ST_SM1*)pValue);
    return 1;
}

int get_SSM_ST_SM1_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(SSM_ST_SM1_values, 8, pfnStrAppend, pData);
}

int set_SSM_ST_SM1_default_value(void *pValue)
{
    *(SSM_ST_SM1*)pValue = SSM_st_Unknown_SM1;
    return 1;
}

int check_SSM_ST_SM1_string(const char *str, char **endptr)
{
    static SSM_ST_SM1 rTemp;
    return string_to_SSM_ST_SM1(str, &rTemp, endptr);
}

SimTypeUtils _Type_SSM_ST_SM1_Utils = {
    SSM_ST_SM1_to_string,
    check_SSM_ST_SM1_string,
    string_to_SSM_ST_SM1,
    is_SSM_ST_SM1_double_convertion_allowed,
    SSM_ST_SM1_to_double,
    compare_SSM_ST_SM1,
    get_SSM_ST_SM1_signature,
    set_SSM_ST_SM1_default_value,
    sizeof(SSM_ST_SM1)
};

/****************************************************************
 ** SSM_TR_SM1 
 ****************************************************************/

struct SimTypeVTable *pSimSSM_TR_SM1VTable;

static SimEnumValUtils SSM_TR_SM1_values[] = {
    { "SSM_TR_SM1_no_trans", 0},
    { "SSM_TR_SM1_no_trans", 0},
    { "Unknown:<1>", SSM_TR_Unknown_1_SM1},
    { "Unknown:<1>", SSM_TR_Unknown_1_SM1},
    { "Unknown:<2>", SSM_TR_Unknown_2_SM1},
    { "Unknown:<2>", SSM_TR_Unknown_2_SM1},
    { "Unknown:<3>", SSM_TR_Unknown_3_SM1},
    { "Unknown:<3>", SSM_TR_Unknown_3_SM1},
    { "Decreasing:<1>", SSM_TR_Decreasing_1_SM1},
    { "Decreasing:<1>", SSM_TR_Decreasing_1_SM1},
    { "Decreasing:<2>", SSM_TR_Decreasing_2_SM1},
    { "Decreasing:<2>", SSM_TR_Decreasing_2_SM1},
    { "Increasing:<1>", SSM_TR_Increasing_1_SM1},
    { "Increasing:<1>", SSM_TR_Increasing_1_SM1},
    { "Increasing:<2>", SSM_TR_Increasing_2_SM1},
    { "Increasing:<2>", SSM_TR_Increasing_2_SM1},
    { "Standstill:<1>", SSM_TR_Standstill_1_SM1},
    { "Standstill:<1>", SSM_TR_Standstill_1_SM1},
    { "Standstill:<2>", SSM_TR_Standstill_2_SM1},
    { "Standstill:<2>", SSM_TR_Standstill_2_SM1},
};

int SSM_TR_SM1_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimSSM_TR_SM1VTable != NULL
        && pSimSSM_TR_SM1VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimSSM_TR_SM1VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(SSM_TR_SM1*)pValue, SSM_TR_SM1_values, 20, pfnStrAppend, pData);
}

int string_to_SSM_TR_SM1(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimSSM_TR_SM1VTable != NULL) {
        nRet=string_to_VTable(str, pSimSSM_TR_SM1VTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, SSM_TR_SM1_values, 20, endptr);
        if (pValue != NULL && nRet != 0)
            *(SSM_TR_SM1*)pValue = nTemp;
    }
    return nRet;
}

int is_SSM_TR_SM1_double_convertion_allowed()
{
    if (pSimSSM_TR_SM1VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimSSM_TR_SM1VTable);
    }
    return 1;
}

void compare_SSM_TR_SM1(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimSSM_TR_SM1VTable != NULL
        && pSimSSM_TR_SM1VTable->m_version >= Scv612
        && pSimSSM_TR_SM1VTable->m_pfnCompare != NULL) {
        if (pSimSSM_TR_SM1VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimSSM_TR_SM1VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimSSM_TR_SM1VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(SSM_TR_SM1*)pValue1), (int)(*(SSM_TR_SM1*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int SSM_TR_SM1_to_double(const void *pValue, double *nRetValue)
{
    if (pSimSSM_TR_SM1VTable != NULL) {
        return VTable_to_double(pValue, pSimSSM_TR_SM1VTable, nRetValue);
    }
    *nRetValue = (double)*((SSM_TR_SM1*)pValue);
    return 1;
}

int get_SSM_TR_SM1_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(SSM_TR_SM1_values, 20, pfnStrAppend, pData);
}

int set_SSM_TR_SM1_default_value(void *pValue)
{
    *(SSM_TR_SM1*)pValue = 0;
    return 1;
}

int check_SSM_TR_SM1_string(const char *str, char **endptr)
{
    static SSM_TR_SM1 rTemp;
    return string_to_SSM_TR_SM1(str, &rTemp, endptr);
}

SimTypeUtils _Type_SSM_TR_SM1_Utils = {
    SSM_TR_SM1_to_string,
    check_SSM_TR_SM1_string,
    string_to_SSM_TR_SM1,
    is_SSM_TR_SM1_double_convertion_allowed,
    SSM_TR_SM1_to_double,
    compare_SSM_TR_SM1,
    get_SSM_TR_SM1_signature,
    set_SSM_TR_SM1_default_value,
    sizeof(SSM_TR_SM1)
};

/****************************************************************
 ** kcg_real 
 ****************************************************************/

struct SimTypeVTable *pSimDoubleVTable;

int kcg_real_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimDoubleVTable != NULL
        && pSimDoubleVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
        if (pSimDoubleVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> variable to VTable function: */
            return pfnStrAppend(*(char**)pSimDoubleVTable->m_pfnToType(SptString, pValue), pData);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            double value = (double)(*(const kcg_real*)pValue);
            return pfnStrAppend(*(char**)pSimDoubleVTable->m_pfnToType(SptString, &value), pData);
        }
    }
    return predef_kcg_real_to_string(*((kcg_real*)pValue), pConverter->m_RealFormat, pfnStrAppend, pData);
}

int string_to_kcg_real(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    static double rTemp;
    skip_whitespace(str);
    if (pSimDoubleVTable != NULL) {
        if (pSimDoubleVTable->m_version >= Scv65) {
            /*R15 and higher: VTable funtion must return a kcg_<type> *variable: */
            nRet=string_to_VTable(str, pSimDoubleVTable, pValue, endptr);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            nRet=string_to_VTable(str, pSimDoubleVTable, &rTemp, endptr);
            if (nRet!=0) {
                *(kcg_real*)pValue = (kcg_real)rTemp;
            }
        }
    }
    if (nRet==0) {
        nRet = predef_string_to_kcg_real(str, (kcg_real*)pValue, endptr);
    }
    return nRet;
}

int is_kcg_real_double_convertion_allowed()
{
    if (pSimDoubleVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimDoubleVTable);
    }
    return 1;
}

void compare_kcg_real(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    if (pSimDoubleVTable != NULL && pData!=NULL && pSimDoubleVTable->m_version >= Scv65 && pSimDoubleVTable->m_pfnCompareWithTol != NULL ) {
        /*Customized comparison with tolerance (R15 and higher): */
        unitResult = pSimDoubleVTable->m_pfnCompareWithTol(pResult, pValue1, pValue2, pData);
    } else if (pSimDoubleVTable != NULL && pData==NULL && pSimDoubleVTable->m_version >= Scv612 && pSimDoubleVTable->m_pfnCompare != NULL) {
        /*Customized comparison without tolerance: */
        if (pSimDoubleVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            unitResult = pSimDoubleVTable->m_pfnCompare(pResult, pValue1, pValue2);
         } else {
             /*Before R15: VTable funtion returns a standard C typed *variable: */
             double value1 = (double)(*(const kcg_real*)pValue1);
             double value2 = (double)(*(const kcg_real*)pValue2);
             pSimDoubleVTable->m_pfnCompare(&unitResult, &value1, &value2);
             updateCompareResult(unitResult, pResult);
         }
    } else {
        /*Predefined comparison (with/without tolerance): */
        unitResult = predef_compare_kcg_real(pResult, *((kcg_real*)pValue1), *((kcg_real*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int kcg_real_to_double(const void *pValue, double *nRetValue)
{
    if (pSimDoubleVTable != NULL) {
        if (pSimDoubleVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            return VTable_to_double(pValue, pSimDoubleVTable, nRetValue);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            double value = (double)(*(const kcg_real*)pValue);
            return VTable_to_double(&value, pSimDoubleVTable, nRetValue);
        }
    }
    *nRetValue = (double)*((kcg_real*)pValue);
    return 1;
}

int get_kcg_real_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return pfnStrAppend("R", pData);
}

int set_kcg_real_default_value(void *pValue)
{
    *(kcg_real*)pValue = 0.0;
    return 1;
}

int check_kcg_real_string(const char *str, char **endptr)
{
    static kcg_real rTemp;
    return string_to_kcg_real(str, &rTemp, endptr);
}

SimTypeUtils _Type_kcg_real_Utils = {
    kcg_real_to_string,
    check_kcg_real_string,
    string_to_kcg_real,
    is_kcg_real_double_convertion_allowed,
    kcg_real_to_double,
    compare_kcg_real,
    get_kcg_real_signature,
    set_kcg_real_default_value,
    sizeof(kcg_real)
};

/****************************************************************
 ** kcg_bool 
 ****************************************************************/

struct SimTypeVTable *pSimBoolVTable;

int kcg_bool_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimBoolVTable != NULL
        && pSimBoolVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
        if (pSimBoolVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> variable to VTable function: */
            return pfnStrAppend(*(char**)pSimBoolVTable->m_pfnToType(SptString, pValue), pData);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            SimBool value = (*((const kcg_bool*)pValue) == kcg_true)? SbTrue : SbFalse;
            return pfnStrAppend(*(char**)pSimBoolVTable->m_pfnToType(SptString, &value), pData);
        }
    }
    return predef_kcg_bool_to_string(*((kcg_bool*)pValue), pfnStrAppend, pData);
}

int string_to_kcg_bool(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    static SimBool rTemp;
    skip_whitespace(str);
    if (pSimBoolVTable != NULL) {
        if (pSimBoolVTable->m_version >= Scv65) {
            /*R15 and higher: VTable funtion must return a kcg_<type> *variable: */
            nRet=string_to_VTable(str, pSimBoolVTable, pValue, endptr);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            nRet=string_to_VTable(str, pSimBoolVTable, &rTemp, endptr);
            if (nRet!=0) {
                *(kcg_bool*)pValue = (rTemp == SbTrue)? kcg_true : kcg_false;
            }
        }
    }
    if (nRet==0) {
        nRet = predef_string_to_kcg_bool(str, (kcg_bool*)pValue, endptr);
    }
    return nRet;
}

int is_kcg_bool_double_convertion_allowed()
{
    if (pSimBoolVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimBoolVTable);
    }
    return 1;
}

void compare_kcg_bool(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimBoolVTable != NULL
        && pSimBoolVTable->m_version >= Scv612
        && pSimBoolVTable->m_pfnCompare != NULL) {
        if (pSimBoolVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            unitResult = pSimBoolVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            SimBool value1 = (*((const kcg_bool*)pValue1) == kcg_true)? SbTrue : SbFalse;
            SimBool value2 = (*((const kcg_bool*)pValue2) == kcg_true)? SbTrue : SbFalse;
            pSimBoolVTable->m_pfnCompare(&unitResult, &value1, &value2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_kcg_bool(pResult, *((kcg_bool*)pValue1), *((kcg_bool*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int kcg_bool_to_double(const void *pValue, double *nRetValue)
{
    if (pSimBoolVTable != NULL) {
        if (pSimBoolVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            return VTable_to_double(pValue, pSimBoolVTable, nRetValue);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            SimBool value = (*((const kcg_bool*)pValue) == kcg_true)? SbTrue : SbFalse;
            return VTable_to_double(&value, pSimBoolVTable, nRetValue);
        }
    }
    *nRetValue = *((kcg_bool*)pValue) == kcg_true ? 1.0 : 0.0;
    return 1;
}

int get_kcg_bool_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return pfnStrAppend("B", pData);
}

int set_kcg_bool_default_value(void *pValue)
{
    *(kcg_bool*)pValue = kcg_false;
    return 1;
}

int check_kcg_bool_string(const char *str, char **endptr)
{
    static kcg_bool rTemp;
    return string_to_kcg_bool(str, &rTemp, endptr);
}

SimTypeUtils _Type_kcg_bool_Utils = {
    kcg_bool_to_string,
    check_kcg_bool_string,
    string_to_kcg_bool,
    is_kcg_bool_double_convertion_allowed,
    kcg_bool_to_double,
    compare_kcg_bool,
    get_kcg_bool_signature,
    set_kcg_bool_default_value,
    sizeof(kcg_bool)
};

/****************************************************************
 ** kcg_char 
 ****************************************************************/

struct SimTypeVTable *pSimCharVTable;

int kcg_char_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimCharVTable != NULL
        && pSimCharVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
        if (pSimCharVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> variable to VTable function: */
            return pfnStrAppend(*(char**)pSimCharVTable->m_pfnToType(SptString, pValue), pData);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            char value = (char)(*(const kcg_char*)pValue);
            return pfnStrAppend(*(char**)pSimCharVTable->m_pfnToType(SptString, &value), pData);
        }
    }
    return predef_kcg_char_to_string(*((kcg_char*)pValue), pfnStrAppend, pData);
}

int string_to_kcg_char(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    static char rTemp;
    skip_whitespace(str);
    if (pSimCharVTable != NULL) {
        if (pSimCharVTable->m_version >= Scv65) {
            /*R15 and higher: VTable funtion must return a kcg_<type> *variable: */
            nRet=string_to_VTable(str, pSimCharVTable, pValue, endptr);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            nRet=string_to_VTable(str, pSimCharVTable, &rTemp, endptr);
            if (nRet!=0) {
                *(kcg_char*)pValue = (kcg_char)rTemp;
            }
        }
    }
    if (nRet==0) {
        nRet = predef_string_to_kcg_char(str, (kcg_char*)pValue, endptr);
    }
    return nRet;
}

int is_kcg_char_double_convertion_allowed()
{
    if (pSimCharVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimCharVTable);
    }
    return 1;
}

void compare_kcg_char(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimCharVTable != NULL
        && pSimCharVTable->m_version >= Scv612
        && pSimCharVTable->m_pfnCompare != NULL) {
        if (pSimCharVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            unitResult = pSimCharVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            char value1 = (char)(*(const kcg_char*)pValue1);
            char value2 = (char)(*(const kcg_char*)pValue2);
            pSimCharVTable->m_pfnCompare(&unitResult, &value1, &value2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_kcg_char(pResult, *((kcg_char*)pValue1), *((kcg_char*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int kcg_char_to_double(const void *pValue, double *nRetValue)
{
    if (pSimCharVTable != NULL) {
        if (pSimCharVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            return VTable_to_double(pValue, pSimCharVTable, nRetValue);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            char value = (char)(*(const kcg_char*)pValue);
            return VTable_to_double(&value, pSimCharVTable, nRetValue);
        }
    }
    *nRetValue = (double)*((kcg_char*)pValue);
    return 1;
}

int get_kcg_char_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return pfnStrAppend("C", pData);
}

int set_kcg_char_default_value(void *pValue)
{
    *(kcg_char*)pValue = 0;
    return 1;
}

int check_kcg_char_string(const char *str, char **endptr)
{
    static kcg_char rTemp;
    return string_to_kcg_char(str, &rTemp, endptr);
}

SimTypeUtils _Type_kcg_char_Utils = {
    kcg_char_to_string,
    check_kcg_char_string,
    string_to_kcg_char,
    is_kcg_char_double_convertion_allowed,
    kcg_char_to_double,
    compare_kcg_char,
    get_kcg_char_signature,
    set_kcg_char_default_value,
    sizeof(kcg_char)
};

/****************************************************************
 ** kcg_int 
 ****************************************************************/

struct SimTypeVTable *pSimLongVTable;

int kcg_int_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimLongVTable != NULL
        && pSimLongVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
        if (pSimLongVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> variable to VTable function: */
            return pfnStrAppend(*(char**)pSimLongVTable->m_pfnToType(SptString, pValue), pData);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            long value = (long)(*(const kcg_int*)pValue);
            return pfnStrAppend(*(char**)pSimLongVTable->m_pfnToType(SptString, &value), pData);
        }
    }
    return predef_kcg_int_to_string(*((kcg_int*)pValue), pfnStrAppend, pData);
}

int string_to_kcg_int(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    static long rTemp;
    skip_whitespace(str);
    if (pSimLongVTable != NULL) {
        if (pSimLongVTable->m_version >= Scv65) {
            /*R15 and higher: VTable funtion must return a kcg_<type> *variable: */
            nRet=string_to_VTable(str, pSimLongVTable, pValue, endptr);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            nRet=string_to_VTable(str, pSimLongVTable, &rTemp, endptr);
            if (nRet!=0) {
                *(kcg_int*)pValue = (kcg_int)rTemp;
            }
        }
    }
    if (nRet==0) {
        nRet = predef_string_to_kcg_int(str, (kcg_int*)pValue, endptr);
    }
    return nRet;
}

int is_kcg_int_double_convertion_allowed()
{
    if (pSimLongVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimLongVTable);
    }
    return 1;
}

void compare_kcg_int(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimLongVTable != NULL
        && pSimLongVTable->m_version >= Scv612
        && pSimLongVTable->m_pfnCompare != NULL) {
        if (pSimLongVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            unitResult = pSimLongVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            long value1 = (long)(*(const kcg_int*)pValue1);
            long value2 = (long)(*(const kcg_int*)pValue2);
            pSimLongVTable->m_pfnCompare(&unitResult, &value1, &value2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_kcg_int(pResult, *((kcg_int*)pValue1), *((kcg_int*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int kcg_int_to_double(const void *pValue, double *nRetValue)
{
    if (pSimLongVTable != NULL) {
        if (pSimLongVTable->m_version >= Scv65) {
            /*R15 and higher: pass kcg_<type> * to VTable funtion: */
            return VTable_to_double(pValue, pSimLongVTable, nRetValue);
        } else {
            /*Before R15: pass a standard C typed variable to VTable function: */
            long value = (long)(*(const kcg_int*)pValue);
            return VTable_to_double(&value, pSimLongVTable, nRetValue);
        }
    }
    *nRetValue = (double)*((kcg_int*)pValue);
    return 1;
}

int get_kcg_int_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return pfnStrAppend("I", pData);
}

int set_kcg_int_default_value(void *pValue)
{
    *(kcg_int*)pValue = 0;
    return 1;
}

int check_kcg_int_string(const char *str, char **endptr)
{
    static kcg_int rTemp;
    return string_to_kcg_int(str, &rTemp, endptr);
}

SimTypeUtils _Type_kcg_int_Utils = {
    kcg_int_to_string,
    check_kcg_int_string,
    string_to_kcg_int,
    is_kcg_int_double_convertion_allowed,
    kcg_int_to_double,
    compare_kcg_int,
    get_kcg_int_signature,
    set_kcg_int_default_value,
    sizeof(kcg_int)
};

/****************************************************************
 ** struct__5578 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5578VTable;

static SimFieldUtils struct__5578_fields[] = {
    {"nominal", offsetof(struct__5578,nominal), &_Type_kcg_int_Utils},
    {"d_min", offsetof(struct__5578,d_min), &_Type_kcg_int_Utils},
    {"d_max", offsetof(struct__5578,d_max), &_Type_kcg_int_Utils},
};

int struct__5578_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5578VTable != NULL
        && pSimstruct__5578VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5578VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5578_fields, 3, pfnStrAppend, pData);
}

int string_to_struct__5578(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5578VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5578VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5578_fields, 3, endptr);
    }
    return nRet;
}

int is_struct__5578_double_convertion_allowed()
{
    if (pSimstruct__5578VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5578VTable);
    }
    return 0;
}

void compare_struct__5578(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5578VTable != NULL
        && pSimstruct__5578VTable->m_version >= Scv612
        && pSimstruct__5578VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5578VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5578VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5578VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5578_fields, 3, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5578_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5578VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5578VTable, nRetValue);
    }
    return 0;
}

int get_struct__5578_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5578_fields, 3, pfnStrAppend, pData);
}

int set_struct__5578_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5578*)pValue)->nominal));
    set_kcg_int_default_value(&(((struct__5578*)pValue)->d_min));
    set_kcg_int_default_value(&(((struct__5578*)pValue)->d_max));
    return 1;
}

int check_struct__5578_string(const char *str, char **endptr)
{
    static struct__5578 rTemp;
    return string_to_struct__5578(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5578_Utils = {
    struct__5578_to_string,
    check_struct__5578_string,
    string_to_struct__5578,
    is_struct__5578_double_convertion_allowed,
    struct__5578_to_double,
    compare_struct__5578,
    get_struct__5578_signature,
    set_struct__5578_default_value,
    sizeof(struct__5578)
};

/****************************************************************
 ** struct__5584 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5584VTable;

static SimFieldUtils struct__5584_fields[] = {
    {"valid", offsetof(struct__5584,valid), &_Type_kcg_bool_Utils},
    {"nid_LRBG", offsetof(struct__5584,nid_LRBG), &_Type_kcg_int_Utils},
    {"nid_packet", offsetof(struct__5584,nid_packet), &_Type_kcg_int_Utils},
    {"q_dir", offsetof(struct__5584,q_dir), &_Type_Q_DIR_Utils},
    {"l_packet", offsetof(struct__5584,l_packet), &_Type_kcg_int_Utils},
    {"q_scale", offsetof(struct__5584,q_scale), &_Type_Q_SCALE_Utils},
    {"d_link", offsetof(struct__5584,d_link), &_Type_kcg_int_Utils},
    {"q_newcountry", offsetof(struct__5584,q_newcountry), &_Type_Q_NEWCOUNTRY_Utils},
    {"nid_c", offsetof(struct__5584,nid_c), &_Type_kcg_int_Utils},
    {"nid_bg", offsetof(struct__5584,nid_bg), &_Type_kcg_int_Utils},
    {"q_linkorientation", offsetof(struct__5584,q_linkorientation), &_Type_Q_LINKORIENTATION_Utils},
    {"q_linkreaction", offsetof(struct__5584,q_linkreaction), &_Type_Q_LINKREACTION_Utils},
    {"q_locacc", offsetof(struct__5584,q_locacc), &_Type_kcg_int_Utils},
};

int struct__5584_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5584VTable != NULL
        && pSimstruct__5584VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5584VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5584_fields, 13, pfnStrAppend, pData);
}

int string_to_struct__5584(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5584VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5584VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5584_fields, 13, endptr);
    }
    return nRet;
}

int is_struct__5584_double_convertion_allowed()
{
    if (pSimstruct__5584VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5584VTable);
    }
    return 0;
}

void compare_struct__5584(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5584VTable != NULL
        && pSimstruct__5584VTable->m_version >= Scv612
        && pSimstruct__5584VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5584VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5584VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5584VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5584_fields, 13, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5584_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5584VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5584VTable, nRetValue);
    }
    return 0;
}

int get_struct__5584_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5584_fields, 13, pfnStrAppend, pData);
}

int set_struct__5584_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5584*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->nid_LRBG));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->nid_packet));
    set_Q_DIR_default_value(&(((struct__5584*)pValue)->q_dir));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->l_packet));
    set_Q_SCALE_default_value(&(((struct__5584*)pValue)->q_scale));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->d_link));
    set_Q_NEWCOUNTRY_default_value(&(((struct__5584*)pValue)->q_newcountry));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->nid_c));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->nid_bg));
    set_Q_LINKORIENTATION_default_value(&(((struct__5584*)pValue)->q_linkorientation));
    set_Q_LINKREACTION_default_value(&(((struct__5584*)pValue)->q_linkreaction));
    set_kcg_int_default_value(&(((struct__5584*)pValue)->q_locacc));
    return 1;
}

int check_struct__5584_string(const char *str, char **endptr)
{
    static struct__5584 rTemp;
    return string_to_struct__5584(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5584_Utils = {
    struct__5584_to_string,
    check_struct__5584_string,
    string_to_struct__5584,
    is_struct__5584_double_convertion_allowed,
    struct__5584_to_double,
    compare_struct__5584,
    get_struct__5584_signature,
    set_struct__5584_default_value,
    sizeof(struct__5584)
};

/****************************************************************
 ** struct__5600 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5600VTable;

static SimFieldUtils struct__5600_fields[] = {
    {"valid", offsetof(struct__5600,valid), &_Type_kcg_bool_Utils},
    {"nid_bg_fromLinkingBG", offsetof(struct__5600,nid_bg_fromLinkingBG), &_Type_kcg_int_Utils},
    {"nid_c_fromLinkingBG", offsetof(struct__5600,nid_c_fromLinkingBG), &_Type_kcg_int_Utils},
    {"expectedLocation", offsetof(struct__5600,expectedLocation), &_Type_struct__5578_Utils},
    {"d_link", offsetof(struct__5600,d_link), &_Type_struct__5578_Utils},
    {"linkingInfo", offsetof(struct__5600,linkingInfo), &_Type_struct__5584_Utils},
};

int struct__5600_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5600VTable != NULL
        && pSimstruct__5600VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5600VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5600_fields, 6, pfnStrAppend, pData);
}

int string_to_struct__5600(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5600VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5600VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5600_fields, 6, endptr);
    }
    return nRet;
}

int is_struct__5600_double_convertion_allowed()
{
    if (pSimstruct__5600VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5600VTable);
    }
    return 0;
}

void compare_struct__5600(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5600VTable != NULL
        && pSimstruct__5600VTable->m_version >= Scv612
        && pSimstruct__5600VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5600VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5600VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5600VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5600_fields, 6, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5600_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5600VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5600VTable, nRetValue);
    }
    return 0;
}

int get_struct__5600_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5600_fields, 6, pfnStrAppend, pData);
}

int set_struct__5600_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5600*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5600*)pValue)->nid_bg_fromLinkingBG));
    set_kcg_int_default_value(&(((struct__5600*)pValue)->nid_c_fromLinkingBG));
    set_struct__5578_default_value(&(((struct__5600*)pValue)->expectedLocation));
    set_struct__5578_default_value(&(((struct__5600*)pValue)->d_link));
    set_struct__5584_default_value(&(((struct__5600*)pValue)->linkingInfo));
    return 1;
}

int check_struct__5600_string(const char *str, char **endptr)
{
    static struct__5600 rTemp;
    return string_to_struct__5600(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5600_Utils = {
    struct__5600_to_string,
    check_struct__5600_string,
    string_to_struct__5600,
    is_struct__5600_double_convertion_allowed,
    struct__5600_to_double,
    compare_struct__5600,
    get_struct__5600_signature,
    set_struct__5600_default_value,
    sizeof(struct__5600)
};

/****************************************************************
 ** struct__5609 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5609VTable;

static SimFieldUtils struct__5609_fields[] = {
    {"o_nominal", offsetof(struct__5609,o_nominal), &_Type_kcg_int_Utils},
    {"o_min", offsetof(struct__5609,o_min), &_Type_kcg_int_Utils},
    {"o_max", offsetof(struct__5609,o_max), &_Type_kcg_int_Utils},
};

int struct__5609_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5609VTable != NULL
        && pSimstruct__5609VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5609VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5609_fields, 3, pfnStrAppend, pData);
}

int string_to_struct__5609(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5609VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5609VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5609_fields, 3, endptr);
    }
    return nRet;
}

int is_struct__5609_double_convertion_allowed()
{
    if (pSimstruct__5609VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5609VTable);
    }
    return 0;
}

void compare_struct__5609(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5609VTable != NULL
        && pSimstruct__5609VTable->m_version >= Scv612
        && pSimstruct__5609VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5609VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5609VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5609VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5609_fields, 3, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5609_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5609VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5609VTable, nRetValue);
    }
    return 0;
}

int get_struct__5609_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5609_fields, 3, pfnStrAppend, pData);
}

int set_struct__5609_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5609*)pValue)->o_nominal));
    set_kcg_int_default_value(&(((struct__5609*)pValue)->o_min));
    set_kcg_int_default_value(&(((struct__5609*)pValue)->o_max));
    return 1;
}

int check_struct__5609_string(const char *str, char **endptr)
{
    static struct__5609 rTemp;
    return string_to_struct__5609(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5609_Utils = {
    struct__5609_to_string,
    check_struct__5609_string,
    string_to_struct__5609,
    is_struct__5609_double_convertion_allowed,
    struct__5609_to_double,
    compare_struct__5609,
    get_struct__5609_signature,
    set_struct__5609_default_value,
    sizeof(struct__5609)
};

/****************************************************************
 ** array__5615 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5615VTable;

int array__5615_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5615VTable != NULL
        && pSimarray__5615VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5615VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5584_to_string, 4, sizeof(struct__5584), pfnStrAppend, pData);
}

int string_to_array__5615(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5615VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5615VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5584_Utils, 4, sizeof(struct__5584), endptr);
    }
    return nRet;
}

int is_array__5615_double_convertion_allowed()
{
    if (pSimarray__5615VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5615VTable);
    }
    return 0;
}

void compare_array__5615(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5615VTable != NULL
        && pSimarray__5615VTable->m_version >= Scv612
        && pSimarray__5615VTable->m_pfnCompare != NULL) {
        if (pSimarray__5615VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5615VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5615VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5584, 4, sizeof(struct__5584), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5615_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5615VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5615VTable, nRetValue);
    }
    return 0;
}

int get_array__5615_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 4; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5584_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5615_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 4; i++)
        set_struct__5584_default_value(&((struct__5584*)pValue)[i]);
    return 1;
}

int check_array__5615_string(const char *str, char **endptr)
{
    static array__5615 rTemp;
    return string_to_array__5615(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5615_Utils = {
    array__5615_to_string,
    check_array__5615_string,
    string_to_array__5615,
    is_array__5615_double_convertion_allowed,
    array__5615_to_double,
    compare_array__5615,
    get_array__5615_signature,
    set_array__5615_default_value,
    sizeof(array__5615)
};

/****************************************************************
 ** struct__5618 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5618VTable;

static SimFieldUtils struct__5618_fields[] = {
    {"q_updown", offsetof(struct__5618,q_updown), &_Type_Q_UPDOWN_Utils},
    {"m_version", offsetof(struct__5618,m_version), &_Type_M_VERSION_Utils},
    {"q_media", offsetof(struct__5618,q_media), &_Type_Q_MEDIA_Utils},
    {"n_total", offsetof(struct__5618,n_total), &_Type_N_TOTAL_Utils},
    {"m_mcount", offsetof(struct__5618,m_mcount), &_Type_kcg_int_Utils},
    {"nid_c", offsetof(struct__5618,nid_c), &_Type_kcg_int_Utils},
    {"nid_bg", offsetof(struct__5618,nid_bg), &_Type_kcg_int_Utils},
    {"q_link", offsetof(struct__5618,q_link), &_Type_Q_LINK_Utils},
};

int struct__5618_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5618VTable != NULL
        && pSimstruct__5618VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5618VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5618_fields, 8, pfnStrAppend, pData);
}

int string_to_struct__5618(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5618VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5618VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5618_fields, 8, endptr);
    }
    return nRet;
}

int is_struct__5618_double_convertion_allowed()
{
    if (pSimstruct__5618VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5618VTable);
    }
    return 0;
}

void compare_struct__5618(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5618VTable != NULL
        && pSimstruct__5618VTable->m_version >= Scv612
        && pSimstruct__5618VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5618VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5618VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5618VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5618_fields, 8, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5618_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5618VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5618VTable, nRetValue);
    }
    return 0;
}

int get_struct__5618_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5618_fields, 8, pfnStrAppend, pData);
}

int set_struct__5618_default_value(void *pValue)
{
    set_Q_UPDOWN_default_value(&(((struct__5618*)pValue)->q_updown));
    set_M_VERSION_default_value(&(((struct__5618*)pValue)->m_version));
    set_Q_MEDIA_default_value(&(((struct__5618*)pValue)->q_media));
    set_N_TOTAL_default_value(&(((struct__5618*)pValue)->n_total));
    set_kcg_int_default_value(&(((struct__5618*)pValue)->m_mcount));
    set_kcg_int_default_value(&(((struct__5618*)pValue)->nid_c));
    set_kcg_int_default_value(&(((struct__5618*)pValue)->nid_bg));
    set_Q_LINK_default_value(&(((struct__5618*)pValue)->q_link));
    return 1;
}

int check_struct__5618_string(const char *str, char **endptr)
{
    static struct__5618 rTemp;
    return string_to_struct__5618(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5618_Utils = {
    struct__5618_to_string,
    check_struct__5618_string,
    string_to_struct__5618,
    is_struct__5618_double_convertion_allowed,
    struct__5618_to_double,
    compare_struct__5618,
    get_struct__5618_signature,
    set_struct__5618_default_value,
    sizeof(struct__5618)
};

/****************************************************************
 ** struct__5629 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5629VTable;

static SimFieldUtils struct__5629_fields[] = {
    {"valid", offsetof(struct__5629,valid), &_Type_kcg_bool_Utils},
    {"timestamp", offsetof(struct__5629,timestamp), &_Type_kcg_int_Utils},
    {"odometrystamp", offsetof(struct__5629,odometrystamp), &_Type_struct__5609_Utils},
    {"BG_centerDetectionInaccuraccuracies", offsetof(struct__5629,BG_centerDetectionInaccuraccuracies), &_Type_struct__5578_Utils},
    {"BG_Header", offsetof(struct__5629,BG_Header), &_Type_struct__5618_Utils},
    {"linkedBGs", offsetof(struct__5629,linkedBGs), &_Type_array__5615_Utils},
    {"noCoordinateSystemHasBeenAssigned", offsetof(struct__5629,noCoordinateSystemHasBeenAssigned), &_Type_kcg_bool_Utils},
    {"trainOrientationToBG", offsetof(struct__5629,trainOrientationToBG), &_Type_Q_DIRLRBG_Utils},
    {"trainRunningDirectionToBG", offsetof(struct__5629,trainRunningDirectionToBG), &_Type_Q_DIRTRAIN_Utils},
    {"passingSpeed", offsetof(struct__5629,passingSpeed), &_Type_kcg_int_Utils},
};

int struct__5629_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5629VTable != NULL
        && pSimstruct__5629VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5629VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5629_fields, 10, pfnStrAppend, pData);
}

int string_to_struct__5629(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5629VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5629VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5629_fields, 10, endptr);
    }
    return nRet;
}

int is_struct__5629_double_convertion_allowed()
{
    if (pSimstruct__5629VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5629VTable);
    }
    return 0;
}

void compare_struct__5629(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5629VTable != NULL
        && pSimstruct__5629VTable->m_version >= Scv612
        && pSimstruct__5629VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5629VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5629VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5629VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5629_fields, 10, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5629_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5629VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5629VTable, nRetValue);
    }
    return 0;
}

int get_struct__5629_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5629_fields, 10, pfnStrAppend, pData);
}

int set_struct__5629_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5629*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5629*)pValue)->timestamp));
    set_struct__5609_default_value(&(((struct__5629*)pValue)->odometrystamp));
    set_struct__5578_default_value(&(((struct__5629*)pValue)->BG_centerDetectionInaccuraccuracies));
    set_struct__5618_default_value(&(((struct__5629*)pValue)->BG_Header));
    set_array__5615_default_value(&(((struct__5629*)pValue)->linkedBGs));
    set_kcg_bool_default_value(&(((struct__5629*)pValue)->noCoordinateSystemHasBeenAssigned));
    set_Q_DIRLRBG_default_value(&(((struct__5629*)pValue)->trainOrientationToBG));
    set_Q_DIRTRAIN_default_value(&(((struct__5629*)pValue)->trainRunningDirectionToBG));
    set_kcg_int_default_value(&(((struct__5629*)pValue)->passingSpeed));
    return 1;
}

int check_struct__5629_string(const char *str, char **endptr)
{
    static struct__5629 rTemp;
    return string_to_struct__5629(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5629_Utils = {
    struct__5629_to_string,
    check_struct__5629_string,
    string_to_struct__5629,
    is_struct__5629_double_convertion_allowed,
    struct__5629_to_double,
    compare_struct__5629,
    get_struct__5629_signature,
    set_struct__5629_default_value,
    sizeof(struct__5629)
};

/****************************************************************
 ** struct__5642 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5642VTable;

static SimFieldUtils struct__5642_fields[] = {
    {"valid", offsetof(struct__5642,valid), &_Type_kcg_bool_Utils},
    {"nid_c", offsetof(struct__5642,nid_c), &_Type_kcg_int_Utils},
    {"nid_bg", offsetof(struct__5642,nid_bg), &_Type_kcg_int_Utils},
    {"q_link", offsetof(struct__5642,q_link), &_Type_Q_LINK_Utils},
    {"location", offsetof(struct__5642,location), &_Type_struct__5578_Utils},
    {"seqNoOnTrack", offsetof(struct__5642,seqNoOnTrack), &_Type_kcg_int_Utils},
    {"infoFromLinking", offsetof(struct__5642,infoFromLinking), &_Type_struct__5600_Utils},
    {"infoFromPassing", offsetof(struct__5642,infoFromPassing), &_Type_struct__5629_Utils},
};

int struct__5642_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5642VTable != NULL
        && pSimstruct__5642VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5642VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5642_fields, 8, pfnStrAppend, pData);
}

int string_to_struct__5642(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5642VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5642VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5642_fields, 8, endptr);
    }
    return nRet;
}

int is_struct__5642_double_convertion_allowed()
{
    if (pSimstruct__5642VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5642VTable);
    }
    return 0;
}

void compare_struct__5642(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5642VTable != NULL
        && pSimstruct__5642VTable->m_version >= Scv612
        && pSimstruct__5642VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5642VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5642VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5642VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5642_fields, 8, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5642_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5642VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5642VTable, nRetValue);
    }
    return 0;
}

int get_struct__5642_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5642_fields, 8, pfnStrAppend, pData);
}

int set_struct__5642_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5642*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5642*)pValue)->nid_c));
    set_kcg_int_default_value(&(((struct__5642*)pValue)->nid_bg));
    set_Q_LINK_default_value(&(((struct__5642*)pValue)->q_link));
    set_struct__5578_default_value(&(((struct__5642*)pValue)->location));
    set_kcg_int_default_value(&(((struct__5642*)pValue)->seqNoOnTrack));
    set_struct__5600_default_value(&(((struct__5642*)pValue)->infoFromLinking));
    set_struct__5629_default_value(&(((struct__5642*)pValue)->infoFromPassing));
    return 1;
}

int check_struct__5642_string(const char *str, char **endptr)
{
    static struct__5642 rTemp;
    return string_to_struct__5642(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5642_Utils = {
    struct__5642_to_string,
    check_struct__5642_string,
    string_to_struct__5642,
    is_struct__5642_double_convertion_allowed,
    struct__5642_to_double,
    compare_struct__5642,
    get_struct__5642_signature,
    set_struct__5642_default_value,
    sizeof(struct__5642)
};

/****************************************************************
 ** struct__5653 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5653VTable;

static SimFieldUtils struct__5653_fields[] = {
    {"valid", offsetof(struct__5653,valid), &_Type_kcg_bool_Utils},
    {"timestamp", offsetof(struct__5653,timestamp), &_Type_kcg_int_Utils},
    {"trainPosition", offsetof(struct__5653,trainPosition), &_Type_struct__5578_Utils},
    {"trainPositionDerivedFromLastLinkedBG", offsetof(struct__5653,trainPositionDerivedFromLastLinkedBG), &_Type_struct__5578_Utils},
    {"trainPositionDerivedFromLastUnlinkedBG", offsetof(struct__5653,trainPositionDerivedFromLastUnlinkedBG), &_Type_struct__5578_Utils},
    {"lastPassedLinkedBG", offsetof(struct__5653,lastPassedLinkedBG), &_Type_struct__5642_Utils},
    {"lastPassedUnlinkedBG", offsetof(struct__5653,lastPassedUnlinkedBG), &_Type_struct__5642_Utils},
    {"speed", offsetof(struct__5653,speed), &_Type_kcg_int_Utils},
};

int struct__5653_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5653VTable != NULL
        && pSimstruct__5653VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5653VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5653_fields, 8, pfnStrAppend, pData);
}

int string_to_struct__5653(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5653VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5653VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5653_fields, 8, endptr);
    }
    return nRet;
}

int is_struct__5653_double_convertion_allowed()
{
    if (pSimstruct__5653VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5653VTable);
    }
    return 0;
}

void compare_struct__5653(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5653VTable != NULL
        && pSimstruct__5653VTable->m_version >= Scv612
        && pSimstruct__5653VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5653VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5653VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5653VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5653_fields, 8, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5653_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5653VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5653VTable, nRetValue);
    }
    return 0;
}

int get_struct__5653_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5653_fields, 8, pfnStrAppend, pData);
}

int set_struct__5653_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5653*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5653*)pValue)->timestamp));
    set_struct__5578_default_value(&(((struct__5653*)pValue)->trainPosition));
    set_struct__5578_default_value(&(((struct__5653*)pValue)->trainPositionDerivedFromLastLinkedBG));
    set_struct__5578_default_value(&(((struct__5653*)pValue)->trainPositionDerivedFromLastUnlinkedBG));
    set_struct__5642_default_value(&(((struct__5653*)pValue)->lastPassedLinkedBG));
    set_struct__5642_default_value(&(((struct__5653*)pValue)->lastPassedUnlinkedBG));
    set_kcg_int_default_value(&(((struct__5653*)pValue)->speed));
    return 1;
}

int check_struct__5653_string(const char *str, char **endptr)
{
    static struct__5653 rTemp;
    return string_to_struct__5653(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5653_Utils = {
    struct__5653_to_string,
    check_struct__5653_string,
    string_to_struct__5653,
    is_struct__5653_double_convertion_allowed,
    struct__5653_to_double,
    compare_struct__5653,
    get_struct__5653_signature,
    set_struct__5653_default_value,
    sizeof(struct__5653)
};

/****************************************************************
 ** struct__5664 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5664VTable;

static SimFieldUtils struct__5664_fields[] = {
    {"valid", offsetof(struct__5664,valid), &_Type_kcg_bool_Utils},
    {"timestamp", offsetof(struct__5664,timestamp), &_Type_kcg_int_Utils},
    {"trainPositionIsUnknown", offsetof(struct__5664,trainPositionIsUnknown), &_Type_kcg_bool_Utils},
    {"noCoordinateSystemHasBeenAssigned", offsetof(struct__5664,noCoordinateSystemHasBeenAssigned), &_Type_kcg_bool_Utils},
    {"trainPosition", offsetof(struct__5664,trainPosition), &_Type_struct__5578_Utils},
    {"estimatedFrontEndPosition", offsetof(struct__5664,estimatedFrontEndPosition), &_Type_kcg_int_Utils},
    {"minSafeFrontEndPosition", offsetof(struct__5664,minSafeFrontEndPosition), &_Type_kcg_int_Utils},
    {"maxSafeFrontEndPostion", offsetof(struct__5664,maxSafeFrontEndPostion), &_Type_kcg_int_Utils},
    {"nid_LRBG", offsetof(struct__5664,nid_LRBG), &_Type_kcg_int_Utils},
    {"nid_PrvLRB", offsetof(struct__5664,nid_PrvLRB), &_Type_kcg_int_Utils},
    {"nominalOrReverseToLRBG", offsetof(struct__5664,nominalOrReverseToLRBG), &_Type_Q_DLRBG_Utils},
    {"trainOrientationToLRBG", offsetof(struct__5664,trainOrientationToLRBG), &_Type_Q_DIRLRBG_Utils},
    {"trainRunningDirectionToLRBG", offsetof(struct__5664,trainRunningDirectionToLRBG), &_Type_Q_DIRTRAIN_Utils},
    {"speed", offsetof(struct__5664,speed), &_Type_kcg_int_Utils},
};

int struct__5664_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5664VTable != NULL
        && pSimstruct__5664VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5664VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5664_fields, 14, pfnStrAppend, pData);
}

int string_to_struct__5664(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5664VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5664VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5664_fields, 14, endptr);
    }
    return nRet;
}

int is_struct__5664_double_convertion_allowed()
{
    if (pSimstruct__5664VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5664VTable);
    }
    return 0;
}

void compare_struct__5664(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5664VTable != NULL
        && pSimstruct__5664VTable->m_version >= Scv612
        && pSimstruct__5664VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5664VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5664VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5664VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5664_fields, 14, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5664_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5664VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5664VTable, nRetValue);
    }
    return 0;
}

int get_struct__5664_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5664_fields, 14, pfnStrAppend, pData);
}

int set_struct__5664_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5664*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->timestamp));
    set_kcg_bool_default_value(&(((struct__5664*)pValue)->trainPositionIsUnknown));
    set_kcg_bool_default_value(&(((struct__5664*)pValue)->noCoordinateSystemHasBeenAssigned));
    set_struct__5578_default_value(&(((struct__5664*)pValue)->trainPosition));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->estimatedFrontEndPosition));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->minSafeFrontEndPosition));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->maxSafeFrontEndPostion));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->nid_LRBG));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->nid_PrvLRB));
    set_Q_DLRBG_default_value(&(((struct__5664*)pValue)->nominalOrReverseToLRBG));
    set_Q_DIRLRBG_default_value(&(((struct__5664*)pValue)->trainOrientationToLRBG));
    set_Q_DIRTRAIN_default_value(&(((struct__5664*)pValue)->trainRunningDirectionToLRBG));
    set_kcg_int_default_value(&(((struct__5664*)pValue)->speed));
    return 1;
}

int check_struct__5664_string(const char *str, char **endptr)
{
    static struct__5664 rTemp;
    return string_to_struct__5664(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5664_Utils = {
    struct__5664_to_string,
    check_struct__5664_string,
    string_to_struct__5664,
    is_struct__5664_double_convertion_allowed,
    struct__5664_to_double,
    compare_struct__5664,
    get_struct__5664_signature,
    set_struct__5664_default_value,
    sizeof(struct__5664)
};

/****************************************************************
 ** struct__5681 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5681VTable;

static SimFieldUtils struct__5681_fields[] = {
    {"outOfMemSpace", offsetof(struct__5681,outOfMemSpace), &_Type_kcg_bool_Utils},
    {"passedBG_notFoundWhereExpected", offsetof(struct__5681,passedBG_notFoundWhereExpected), &_Type_kcg_bool_Utils},
    {"positionCalculation_inconsistent", offsetof(struct__5681,positionCalculation_inconsistent), &_Type_kcg_bool_Utils},
};

int struct__5681_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5681VTable != NULL
        && pSimstruct__5681VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5681VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5681_fields, 3, pfnStrAppend, pData);
}

int string_to_struct__5681(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5681VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5681VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5681_fields, 3, endptr);
    }
    return nRet;
}

int is_struct__5681_double_convertion_allowed()
{
    if (pSimstruct__5681VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5681VTable);
    }
    return 0;
}

void compare_struct__5681(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5681VTable != NULL
        && pSimstruct__5681VTable->m_version >= Scv612
        && pSimstruct__5681VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5681VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5681VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5681VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5681_fields, 3, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5681_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5681VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5681VTable, nRetValue);
    }
    return 0;
}

int get_struct__5681_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5681_fields, 3, pfnStrAppend, pData);
}

int set_struct__5681_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5681*)pValue)->outOfMemSpace));
    set_kcg_bool_default_value(&(((struct__5681*)pValue)->passedBG_notFoundWhereExpected));
    set_kcg_bool_default_value(&(((struct__5681*)pValue)->positionCalculation_inconsistent));
    return 1;
}

int check_struct__5681_string(const char *str, char **endptr)
{
    static struct__5681 rTemp;
    return string_to_struct__5681(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5681_Utils = {
    struct__5681_to_string,
    check_struct__5681_string,
    string_to_struct__5681,
    is_struct__5681_double_convertion_allowed,
    struct__5681_to_double,
    compare_struct__5681,
    get_struct__5681_signature,
    set_struct__5681_default_value,
    sizeof(struct__5681)
};

/****************************************************************
 ** array__5687 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5687VTable;

int array__5687_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5687VTable != NULL
        && pSimarray__5687VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5687VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5642_to_string, 8, sizeof(struct__5642), pfnStrAppend, pData);
}

int string_to_array__5687(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5687VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5687VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5642_Utils, 8, sizeof(struct__5642), endptr);
    }
    return nRet;
}

int is_array__5687_double_convertion_allowed()
{
    if (pSimarray__5687VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5687VTable);
    }
    return 0;
}

void compare_array__5687(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5687VTable != NULL
        && pSimarray__5687VTable->m_version >= Scv612
        && pSimarray__5687VTable->m_pfnCompare != NULL) {
        if (pSimarray__5687VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5687VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5687VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5642, 8, sizeof(struct__5642), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5687_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5687VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5687VTable, nRetValue);
    }
    return 0;
}

int get_array__5687_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 8; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5642_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5687_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 8; i++)
        set_struct__5642_default_value(&((struct__5642*)pValue)[i]);
    return 1;
}

int check_array__5687_string(const char *str, char **endptr)
{
    static array__5687 rTemp;
    return string_to_array__5687(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5687_Utils = {
    array__5687_to_string,
    check_array__5687_string,
    string_to_array__5687,
    is_array__5687_double_convertion_allowed,
    array__5687_to_double,
    compare_array__5687,
    get_array__5687_signature,
    set_array__5687_default_value,
    sizeof(array__5687)
};

/****************************************************************
 ** struct__5690 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5690VTable;

static SimFieldUtils struct__5690_fields[] = {
    {"nid_engine", offsetof(struct__5690,nid_engine), &_Type_kcg_int_Utils},
    {"nid_operational", offsetof(struct__5690,nid_operational), &_Type_kcg_int_Utils},
    {"l_train", offsetof(struct__5690,l_train), &_Type_kcg_int_Utils},
    {"d_baliseAntenna_2_frontend", offsetof(struct__5690,d_baliseAntenna_2_frontend), &_Type_struct__5578_Utils},
    {"d_frontend_2_rearend", offsetof(struct__5690,d_frontend_2_rearend), &_Type_struct__5578_Utils},
    {"locationAccuracy_NationalValue", offsetof(struct__5690,locationAccuracy_NationalValue), &_Type_kcg_int_Utils},
    {"locationAccuracy_DefaultValue", offsetof(struct__5690,locationAccuracy_DefaultValue), &_Type_struct__5578_Utils},
    {"centerDetectionAcc_DefaultValue", offsetof(struct__5690,centerDetectionAcc_DefaultValue), &_Type_struct__5578_Utils},
};

int struct__5690_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5690VTable != NULL
        && pSimstruct__5690VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5690VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5690_fields, 8, pfnStrAppend, pData);
}

int string_to_struct__5690(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5690VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5690VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5690_fields, 8, endptr);
    }
    return nRet;
}

int is_struct__5690_double_convertion_allowed()
{
    if (pSimstruct__5690VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5690VTable);
    }
    return 0;
}

void compare_struct__5690(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5690VTable != NULL
        && pSimstruct__5690VTable->m_version >= Scv612
        && pSimstruct__5690VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5690VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5690VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5690VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5690_fields, 8, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5690_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5690VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5690VTable, nRetValue);
    }
    return 0;
}

int get_struct__5690_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5690_fields, 8, pfnStrAppend, pData);
}

int set_struct__5690_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5690*)pValue)->nid_engine));
    set_kcg_int_default_value(&(((struct__5690*)pValue)->nid_operational));
    set_kcg_int_default_value(&(((struct__5690*)pValue)->l_train));
    set_struct__5578_default_value(&(((struct__5690*)pValue)->d_baliseAntenna_2_frontend));
    set_struct__5578_default_value(&(((struct__5690*)pValue)->d_frontend_2_rearend));
    set_kcg_int_default_value(&(((struct__5690*)pValue)->locationAccuracy_NationalValue));
    set_struct__5578_default_value(&(((struct__5690*)pValue)->locationAccuracy_DefaultValue));
    set_struct__5578_default_value(&(((struct__5690*)pValue)->centerDetectionAcc_DefaultValue));
    return 1;
}

int check_struct__5690_string(const char *str, char **endptr)
{
    static struct__5690 rTemp;
    return string_to_struct__5690(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5690_Utils = {
    struct__5690_to_string,
    check_struct__5690_string,
    string_to_struct__5690,
    is_struct__5690_double_convertion_allowed,
    struct__5690_to_double,
    compare_struct__5690,
    get_struct__5690_signature,
    set_struct__5690_default_value,
    sizeof(struct__5690)
};

/****************************************************************
 ** struct__5701 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5701VTable;

static SimFieldUtils struct__5701_fields[] = {
    {"valid", offsetof(struct__5701,valid), &_Type_kcg_bool_Utils},
    {"timestamp", offsetof(struct__5701,timestamp), &_Type_kcg_int_Utils},
    {"odo", offsetof(struct__5701,odo), &_Type_struct__5609_Utils},
    {"speed", offsetof(struct__5701,speed), &_Type_kcg_int_Utils},
};

int struct__5701_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5701VTable != NULL
        && pSimstruct__5701VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5701VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5701_fields, 4, pfnStrAppend, pData);
}

int string_to_struct__5701(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5701VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5701VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5701_fields, 4, endptr);
    }
    return nRet;
}

int is_struct__5701_double_convertion_allowed()
{
    if (pSimstruct__5701VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5701VTable);
    }
    return 0;
}

void compare_struct__5701(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5701VTable != NULL
        && pSimstruct__5701VTable->m_version >= Scv612
        && pSimstruct__5701VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5701VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5701VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5701VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5701_fields, 4, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5701_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5701VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5701VTable, nRetValue);
    }
    return 0;
}

int get_struct__5701_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5701_fields, 4, pfnStrAppend, pData);
}

int set_struct__5701_default_value(void *pValue)
{
    set_kcg_bool_default_value(&(((struct__5701*)pValue)->valid));
    set_kcg_int_default_value(&(((struct__5701*)pValue)->timestamp));
    set_struct__5609_default_value(&(((struct__5701*)pValue)->odo));
    set_kcg_int_default_value(&(((struct__5701*)pValue)->speed));
    return 1;
}

int check_struct__5701_string(const char *str, char **endptr)
{
    static struct__5701 rTemp;
    return string_to_struct__5701(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5701_Utils = {
    struct__5701_to_string,
    check_struct__5701_string,
    string_to_struct__5701,
    is_struct__5701_double_convertion_allowed,
    struct__5701_to_double,
    compare_struct__5701,
    get_struct__5701_signature,
    set_struct__5701_default_value,
    sizeof(struct__5701)
};

/****************************************************************
 ** struct__5708 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5708VTable;

static SimFieldUtils struct__5708_fields[] = {
    {"index", offsetof(struct__5708,index), &_Type_kcg_int_Utils},
    {"noOfFoundBGs", offsetof(struct__5708,noOfFoundBGs), &_Type_kcg_int_Utils},
    {"BGFound", offsetof(struct__5708,BGFound), &_Type_kcg_bool_Utils},
};

int struct__5708_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5708VTable != NULL
        && pSimstruct__5708VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5708VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5708_fields, 3, pfnStrAppend, pData);
}

int string_to_struct__5708(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5708VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5708VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5708_fields, 3, endptr);
    }
    return nRet;
}

int is_struct__5708_double_convertion_allowed()
{
    if (pSimstruct__5708VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5708VTable);
    }
    return 0;
}

void compare_struct__5708(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5708VTable != NULL
        && pSimstruct__5708VTable->m_version >= Scv612
        && pSimstruct__5708VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5708VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5708VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5708VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5708_fields, 3, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5708_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5708VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5708VTable, nRetValue);
    }
    return 0;
}

int get_struct__5708_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5708_fields, 3, pfnStrAppend, pData);
}

int set_struct__5708_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5708*)pValue)->index));
    set_kcg_int_default_value(&(((struct__5708*)pValue)->noOfFoundBGs));
    set_kcg_bool_default_value(&(((struct__5708*)pValue)->BGFound));
    return 1;
}

int check_struct__5708_string(const char *str, char **endptr)
{
    static struct__5708 rTemp;
    return string_to_struct__5708(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5708_Utils = {
    struct__5708_to_string,
    check_struct__5708_string,
    string_to_struct__5708,
    is_struct__5708_double_convertion_allowed,
    struct__5708_to_double,
    compare_struct__5708,
    get_struct__5708_signature,
    set_struct__5708_default_value,
    sizeof(struct__5708)
};

/****************************************************************
 ** struct__5714 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5714VTable;

static SimFieldUtils struct__5714_fields[] = {
    {"unlinkedBGsCount", offsetof(struct__5714,unlinkedBGsCount), &_Type_kcg_int_Utils},
    {"linkedBGsCount", offsetof(struct__5714,linkedBGsCount), &_Type_kcg_int_Utils},
    {"totalBGsCount", offsetof(struct__5714,totalBGsCount), &_Type_kcg_int_Utils},
    {"passedUnlinkedBGsCount", offsetof(struct__5714,passedUnlinkedBGsCount), &_Type_kcg_int_Utils},
    {"passedLinkedBGsCount", offsetof(struct__5714,passedLinkedBGsCount), &_Type_kcg_int_Utils},
    {"passedTotalBGsCount", offsetof(struct__5714,passedTotalBGsCount), &_Type_kcg_int_Utils},
};

int struct__5714_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5714VTable != NULL
        && pSimstruct__5714VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5714VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5714_fields, 6, pfnStrAppend, pData);
}

int string_to_struct__5714(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5714VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5714VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5714_fields, 6, endptr);
    }
    return nRet;
}

int is_struct__5714_double_convertion_allowed()
{
    if (pSimstruct__5714VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5714VTable);
    }
    return 0;
}

void compare_struct__5714(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5714VTable != NULL
        && pSimstruct__5714VTable->m_version >= Scv612
        && pSimstruct__5714VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5714VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5714VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5714VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5714_fields, 6, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5714_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5714VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5714VTable, nRetValue);
    }
    return 0;
}

int get_struct__5714_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5714_fields, 6, pfnStrAppend, pData);
}

int set_struct__5714_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5714*)pValue)->unlinkedBGsCount));
    set_kcg_int_default_value(&(((struct__5714*)pValue)->linkedBGsCount));
    set_kcg_int_default_value(&(((struct__5714*)pValue)->totalBGsCount));
    set_kcg_int_default_value(&(((struct__5714*)pValue)->passedUnlinkedBGsCount));
    set_kcg_int_default_value(&(((struct__5714*)pValue)->passedLinkedBGsCount));
    set_kcg_int_default_value(&(((struct__5714*)pValue)->passedTotalBGsCount));
    return 1;
}

int check_struct__5714_string(const char *str, char **endptr)
{
    static struct__5714 rTemp;
    return string_to_struct__5714(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5714_Utils = {
    struct__5714_to_string,
    check_struct__5714_string,
    string_to_struct__5714,
    is_struct__5714_double_convertion_allowed,
    struct__5714_to_double,
    compare_struct__5714,
    get_struct__5714_signature,
    set_struct__5714_default_value,
    sizeof(struct__5714)
};

/****************************************************************
 ** struct__5723 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5723VTable;

static SimFieldUtils struct__5723_fields[] = {
    {"previousLinkedBG_idx", offsetof(struct__5723,previousLinkedBG_idx), &_Type_kcg_int_Utils},
    {"currentIndex", offsetof(struct__5723,currentIndex), &_Type_kcg_int_Utils},
    {"subsequentLinkedBG_idx", offsetof(struct__5723,subsequentLinkedBG_idx), &_Type_kcg_int_Utils},
};

int struct__5723_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5723VTable != NULL
        && pSimstruct__5723VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5723VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5723_fields, 3, pfnStrAppend, pData);
}

int string_to_struct__5723(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5723VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5723VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5723_fields, 3, endptr);
    }
    return nRet;
}

int is_struct__5723_double_convertion_allowed()
{
    if (pSimstruct__5723VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5723VTable);
    }
    return 0;
}

void compare_struct__5723(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5723VTable != NULL
        && pSimstruct__5723VTable->m_version >= Scv612
        && pSimstruct__5723VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5723VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5723VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5723VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5723_fields, 3, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5723_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5723VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5723VTable, nRetValue);
    }
    return 0;
}

int get_struct__5723_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5723_fields, 3, pfnStrAppend, pData);
}

int set_struct__5723_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5723*)pValue)->previousLinkedBG_idx));
    set_kcg_int_default_value(&(((struct__5723*)pValue)->currentIndex));
    set_kcg_int_default_value(&(((struct__5723*)pValue)->subsequentLinkedBG_idx));
    return 1;
}

int check_struct__5723_string(const char *str, char **endptr)
{
    static struct__5723 rTemp;
    return string_to_struct__5723(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5723_Utils = {
    struct__5723_to_string,
    check_struct__5723_string,
    string_to_struct__5723,
    is_struct__5723_double_convertion_allowed,
    struct__5723_to_double,
    compare_struct__5723,
    get_struct__5723_signature,
    set_struct__5723_default_value,
    sizeof(struct__5723)
};

/****************************************************************
 ** array__5729 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5729VTable;

int array__5729_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5729VTable != NULL
        && pSimarray__5729VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5729VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5723_to_string, 8, sizeof(struct__5723), pfnStrAppend, pData);
}

int string_to_array__5729(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5729VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5729VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5723_Utils, 8, sizeof(struct__5723), endptr);
    }
    return nRet;
}

int is_array__5729_double_convertion_allowed()
{
    if (pSimarray__5729VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5729VTable);
    }
    return 0;
}

void compare_array__5729(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5729VTable != NULL
        && pSimarray__5729VTable->m_version >= Scv612
        && pSimarray__5729VTable->m_pfnCompare != NULL) {
        if (pSimarray__5729VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5729VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5729VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5723, 8, sizeof(struct__5723), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5729_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5729VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5729VTable, nRetValue);
    }
    return 0;
}

int get_array__5729_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 8; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5723_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5729_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 8; i++)
        set_struct__5723_default_value(&((struct__5723*)pValue)[i]);
    return 1;
}

int check_array__5729_string(const char *str, char **endptr)
{
    static array__5729 rTemp;
    return string_to_array__5729(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5729_Utils = {
    array__5729_to_string,
    check_array__5729_string,
    string_to_array__5729,
    is_array__5729_double_convertion_allowed,
    array__5729_to_double,
    compare_array__5729,
    get_array__5729_signature,
    set_array__5729_default_value,
    sizeof(array__5729)
};

/****************************************************************
 ** struct__5732 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5732VTable;

static SimFieldUtils struct__5732_fields[] = {
    {"refBG", offsetof(struct__5732,refBG), &_Type_struct__5642_Utils},
    {"prevLinkedBG", offsetof(struct__5732,prevLinkedBG), &_Type_struct__5642_Utils},
    {"prevUnlinkedBG", offsetof(struct__5732,prevUnlinkedBG), &_Type_struct__5642_Utils},
    {"recalculate", offsetof(struct__5732,recalculate), &_Type_kcg_bool_Utils},
    {"sumOfBestDistances", offsetof(struct__5732,sumOfBestDistances), &_Type_struct__5578_Utils},
};

int struct__5732_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5732VTable != NULL
        && pSimstruct__5732VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5732VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5732_fields, 5, pfnStrAppend, pData);
}

int string_to_struct__5732(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5732VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5732VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5732_fields, 5, endptr);
    }
    return nRet;
}

int is_struct__5732_double_convertion_allowed()
{
    if (pSimstruct__5732VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5732VTable);
    }
    return 0;
}

void compare_struct__5732(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5732VTable != NULL
        && pSimstruct__5732VTable->m_version >= Scv612
        && pSimstruct__5732VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5732VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5732VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5732VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5732_fields, 5, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5732_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5732VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5732VTable, nRetValue);
    }
    return 0;
}

int get_struct__5732_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5732_fields, 5, pfnStrAppend, pData);
}

int set_struct__5732_default_value(void *pValue)
{
    set_struct__5642_default_value(&(((struct__5732*)pValue)->refBG));
    set_struct__5642_default_value(&(((struct__5732*)pValue)->prevLinkedBG));
    set_struct__5642_default_value(&(((struct__5732*)pValue)->prevUnlinkedBG));
    set_kcg_bool_default_value(&(((struct__5732*)pValue)->recalculate));
    set_struct__5578_default_value(&(((struct__5732*)pValue)->sumOfBestDistances));
    return 1;
}

int check_struct__5732_string(const char *str, char **endptr)
{
    static struct__5732 rTemp;
    return string_to_struct__5732(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5732_Utils = {
    struct__5732_to_string,
    check_struct__5732_string,
    string_to_struct__5732,
    is_struct__5732_double_convertion_allowed,
    struct__5732_to_double,
    compare_struct__5732,
    get_struct__5732_signature,
    set_struct__5732_default_value,
    sizeof(struct__5732)
};

/****************************************************************
 ** array__5740 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5740VTable;

int array__5740_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5740VTable != NULL
        && pSimarray__5740VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5740VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5642_to_string, 4, sizeof(struct__5642), pfnStrAppend, pData);
}

int string_to_array__5740(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5740VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5740VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5642_Utils, 4, sizeof(struct__5642), endptr);
    }
    return nRet;
}

int is_array__5740_double_convertion_allowed()
{
    if (pSimarray__5740VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5740VTable);
    }
    return 0;
}

void compare_array__5740(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5740VTable != NULL
        && pSimarray__5740VTable->m_version >= Scv612
        && pSimarray__5740VTable->m_pfnCompare != NULL) {
        if (pSimarray__5740VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5740VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5740VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5642, 4, sizeof(struct__5642), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5740_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5740VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5740VTable, nRetValue);
    }
    return 0;
}

int get_array__5740_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 4; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5642_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5740_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 4; i++)
        set_struct__5642_default_value(&((struct__5642*)pValue)[i]);
    return 1;
}

int check_array__5740_string(const char *str, char **endptr)
{
    static array__5740 rTemp;
    return string_to_array__5740(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5740_Utils = {
    array__5740_to_string,
    check_array__5740_string,
    string_to_array__5740,
    is_array__5740_double_convertion_allowed,
    array__5740_to_double,
    compare_array__5740,
    get_array__5740_signature,
    set_array__5740_default_value,
    sizeof(array__5740)
};

/****************************************************************
 ** struct__5743 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5743VTable;

static SimFieldUtils struct__5743_fields[] = {
    {"BGs", offsetof(struct__5743,BGs), &_Type_array__5687_Utils},
    {"overrun", offsetof(struct__5743,overrun), &_Type_kcg_bool_Utils},
};

int struct__5743_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5743VTable != NULL
        && pSimstruct__5743VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5743VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5743_fields, 2, pfnStrAppend, pData);
}

int string_to_struct__5743(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5743VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5743VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5743_fields, 2, endptr);
    }
    return nRet;
}

int is_struct__5743_double_convertion_allowed()
{
    if (pSimstruct__5743VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5743VTable);
    }
    return 0;
}

void compare_struct__5743(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5743VTable != NULL
        && pSimstruct__5743VTable->m_version >= Scv612
        && pSimstruct__5743VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5743VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5743VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5743VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5743_fields, 2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5743_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5743VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5743VTable, nRetValue);
    }
    return 0;
}

int get_struct__5743_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5743_fields, 2, pfnStrAppend, pData);
}

int set_struct__5743_default_value(void *pValue)
{
    set_array__5687_default_value(&(((struct__5743*)pValue)->BGs));
    set_kcg_bool_default_value(&(((struct__5743*)pValue)->overrun));
    return 1;
}

int check_struct__5743_string(const char *str, char **endptr)
{
    static struct__5743 rTemp;
    return string_to_struct__5743(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5743_Utils = {
    struct__5743_to_string,
    check_struct__5743_string,
    string_to_struct__5743,
    is_struct__5743_double_convertion_allowed,
    struct__5743_to_double,
    compare_struct__5743,
    get_struct__5743_signature,
    set_struct__5743_default_value,
    sizeof(struct__5743)
};

/****************************************************************
 ** struct__5748 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5748VTable;

static SimFieldUtils struct__5748_fields[] = {
    {"trueLocation", offsetof(struct__5748,trueLocation), &_Type_kcg_int_Utils},
    {"passedBG", offsetof(struct__5748,passedBG), &_Type_struct__5629_Utils},
};

int struct__5748_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5748VTable != NULL
        && pSimstruct__5748VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5748VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5748_fields, 2, pfnStrAppend, pData);
}

int string_to_struct__5748(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5748VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5748VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5748_fields, 2, endptr);
    }
    return nRet;
}

int is_struct__5748_double_convertion_allowed()
{
    if (pSimstruct__5748VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5748VTable);
    }
    return 0;
}

void compare_struct__5748(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5748VTable != NULL
        && pSimstruct__5748VTable->m_version >= Scv612
        && pSimstruct__5748VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5748VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5748VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5748VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5748_fields, 2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5748_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5748VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5748VTable, nRetValue);
    }
    return 0;
}

int get_struct__5748_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5748_fields, 2, pfnStrAppend, pData);
}

int set_struct__5748_default_value(void *pValue)
{
    set_kcg_int_default_value(&(((struct__5748*)pValue)->trueLocation));
    set_struct__5629_default_value(&(((struct__5748*)pValue)->passedBG));
    return 1;
}

int check_struct__5748_string(const char *str, char **endptr)
{
    static struct__5748 rTemp;
    return string_to_struct__5748(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5748_Utils = {
    struct__5748_to_string,
    check_struct__5748_string,
    string_to_struct__5748,
    is_struct__5748_double_convertion_allowed,
    struct__5748_to_double,
    compare_struct__5748,
    get_struct__5748_signature,
    set_struct__5748_default_value,
    sizeof(struct__5748)
};

/****************************************************************
 ** array__5753 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5753VTable;

int array__5753_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5753VTable != NULL
        && pSimarray__5753VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5753VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5748_to_string, 10, sizeof(struct__5748), pfnStrAppend, pData);
}

int string_to_array__5753(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5753VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5753VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5748_Utils, 10, sizeof(struct__5748), endptr);
    }
    return nRet;
}

int is_array__5753_double_convertion_allowed()
{
    if (pSimarray__5753VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5753VTable);
    }
    return 0;
}

void compare_array__5753(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5753VTable != NULL
        && pSimarray__5753VTable->m_version >= Scv612
        && pSimarray__5753VTable->m_pfnCompare != NULL) {
        if (pSimarray__5753VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5753VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5753VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5748, 10, sizeof(struct__5748), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5753_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5753VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5753VTable, nRetValue);
    }
    return 0;
}

int get_array__5753_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 10; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5748_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5753_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 10; i++)
        set_struct__5748_default_value(&((struct__5748*)pValue)[i]);
    return 1;
}

int check_array__5753_string(const char *str, char **endptr)
{
    static array__5753 rTemp;
    return string_to_array__5753(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5753_Utils = {
    array__5753_to_string,
    check_array__5753_string,
    string_to_array__5753,
    is_array__5753_double_convertion_allowed,
    array__5753_to_double,
    compare_array__5753,
    get_array__5753_signature,
    set_array__5753_default_value,
    sizeof(array__5753)
};

/****************************************************************
 ** struct__5756 
 ****************************************************************/

struct SimTypeVTable *pSimstruct__5756VTable;

static SimFieldUtils struct__5756_fields[] = {
    {"o_nominal", offsetof(struct__5756,o_nominal), &_Type_kcg_real_Utils},
    {"o_min", offsetof(struct__5756,o_min), &_Type_kcg_real_Utils},
    {"o_max", offsetof(struct__5756,o_max), &_Type_kcg_real_Utils},
};

int struct__5756_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimstruct__5756VTable != NULL
        && pSimstruct__5756VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimstruct__5756VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnStructureToString(pValue, struct__5756_fields, 3, pfnStrAppend, pData);
}

int string_to_struct__5756(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimstruct__5756VTable != NULL) {
        nRet=string_to_VTable(str, pSimstruct__5756VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet=pConverter->m_pfnStringToStructure(str, pValue, struct__5756_fields, 3, endptr);
    }
    return nRet;
}

int is_struct__5756_double_convertion_allowed()
{
    if (pSimstruct__5756VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimstruct__5756VTable);
    }
    return 0;
}

void compare_struct__5756(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimstruct__5756VTable != NULL
        && pSimstruct__5756VTable->m_version >= Scv612
        && pSimstruct__5756VTable->m_pfnCompare != NULL) {
        if (pSimstruct__5756VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimstruct__5756VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimstruct__5756VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnStructureComparison(pResult, pValue1, pValue2, struct__5756_fields, 3, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int struct__5756_to_double(const void *pValue, double *nRetValue)
{
    if (pSimstruct__5756VTable != NULL) {
        return VTable_to_double(pValue, pSimstruct__5756VTable, nRetValue);
    }
    return 0;
}

int get_struct__5756_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_structure_signature(struct__5756_fields, 3, pfnStrAppend, pData);
}

int set_struct__5756_default_value(void *pValue)
{
    set_kcg_real_default_value(&(((struct__5756*)pValue)->o_nominal));
    set_kcg_real_default_value(&(((struct__5756*)pValue)->o_min));
    set_kcg_real_default_value(&(((struct__5756*)pValue)->o_max));
    return 1;
}

int check_struct__5756_string(const char *str, char **endptr)
{
    static struct__5756 rTemp;
    return string_to_struct__5756(str, &rTemp, endptr);
}

SimTypeUtils _Type_struct__5756_Utils = {
    struct__5756_to_string,
    check_struct__5756_string,
    string_to_struct__5756,
    is_struct__5756_double_convertion_allowed,
    struct__5756_to_double,
    compare_struct__5756,
    get_struct__5756_signature,
    set_struct__5756_default_value,
    sizeof(struct__5756)
};

/****************************************************************
 ** array__5762 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5762VTable;

int array__5762_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5762VTable != NULL
        && pSimarray__5762VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5762VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5690_to_string, 4, sizeof(struct__5690), pfnStrAppend, pData);
}

int string_to_array__5762(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5762VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5762VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5690_Utils, 4, sizeof(struct__5690), endptr);
    }
    return nRet;
}

int is_array__5762_double_convertion_allowed()
{
    if (pSimarray__5762VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5762VTable);
    }
    return 0;
}

void compare_array__5762(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5762VTable != NULL
        && pSimarray__5762VTable->m_version >= Scv612
        && pSimarray__5762VTable->m_pfnCompare != NULL) {
        if (pSimarray__5762VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5762VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5762VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5690, 4, sizeof(struct__5690), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5762_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5762VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5762VTable, nRetValue);
    }
    return 0;
}

int get_array__5762_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 4; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5690_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5762_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 4; i++)
        set_struct__5690_default_value(&((struct__5690*)pValue)[i]);
    return 1;
}

int check_array__5762_string(const char *str, char **endptr)
{
    static array__5762 rTemp;
    return string_to_array__5762(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5762_Utils = {
    array__5762_to_string,
    check_array__5762_string,
    string_to_array__5762,
    is_array__5762_double_convertion_allowed,
    array__5762_to_double,
    compare_array__5762,
    get_array__5762_signature,
    set_array__5762_default_value,
    sizeof(array__5762)
};

/****************************************************************
 ** array_int_8 
 ****************************************************************/

struct SimTypeVTable *pSimarray_int_8VTable;

int array_int_8_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray_int_8VTable != NULL
        && pSimarray_int_8VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray_int_8VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, kcg_int_to_string, 8, sizeof(kcg_int), pfnStrAppend, pData);
}

int string_to_array_int_8(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray_int_8VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray_int_8VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_kcg_int_Utils, 8, sizeof(kcg_int), endptr);
    }
    return nRet;
}

int is_array_int_8_double_convertion_allowed()
{
    if (pSimarray_int_8VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray_int_8VTable);
    }
    return 0;
}

void compare_array_int_8(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray_int_8VTable != NULL
        && pSimarray_int_8VTable->m_version >= Scv612
        && pSimarray_int_8VTable->m_pfnCompare != NULL) {
        if (pSimarray_int_8VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray_int_8VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray_int_8VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_kcg_int, 8, sizeof(kcg_int), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array_int_8_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray_int_8VTable != NULL) {
        return VTable_to_double(pValue, pSimarray_int_8VTable, nRetValue);
    }
    return 0;
}

int get_array_int_8_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 8; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_kcg_int_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array_int_8_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 8; i++)
        set_kcg_int_default_value(&((kcg_int*)pValue)[i]);
    return 1;
}

int check_array_int_8_string(const char *str, char **endptr)
{
    static array_int_8 rTemp;
    return string_to_array_int_8(str, &rTemp, endptr);
}

SimTypeUtils _Type_array_int_8_Utils = {
    array_int_8_to_string,
    check_array_int_8_string,
    string_to_array_int_8,
    is_array_int_8_double_convertion_allowed,
    array_int_8_to_double,
    compare_array_int_8,
    get_array_int_8_signature,
    set_array_int_8_default_value,
    sizeof(array_int_8)
};

/****************************************************************
 ** array__5768 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5768VTable;

int array__5768_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5768VTable != NULL
        && pSimarray__5768VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5768VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5642_to_string, 7, sizeof(struct__5642), pfnStrAppend, pData);
}

int string_to_array__5768(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5768VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5768VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5642_Utils, 7, sizeof(struct__5642), endptr);
    }
    return nRet;
}

int is_array__5768_double_convertion_allowed()
{
    if (pSimarray__5768VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5768VTable);
    }
    return 0;
}

void compare_array__5768(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5768VTable != NULL
        && pSimarray__5768VTable->m_version >= Scv612
        && pSimarray__5768VTable->m_pfnCompare != NULL) {
        if (pSimarray__5768VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5768VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5768VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5642, 7, sizeof(struct__5642), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5768_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5768VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5768VTable, nRetValue);
    }
    return 0;
}

int get_array__5768_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 7; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5642_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5768_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 7; i++)
        set_struct__5642_default_value(&((struct__5642*)pValue)[i]);
    return 1;
}

int check_array__5768_string(const char *str, char **endptr)
{
    static array__5768 rTemp;
    return string_to_array__5768(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5768_Utils = {
    array__5768_to_string,
    check_array__5768_string,
    string_to_array__5768,
    is_array__5768_double_convertion_allowed,
    array__5768_to_double,
    compare_array__5768,
    get_array__5768_signature,
    set_array__5768_default_value,
    sizeof(array__5768)
};

/****************************************************************
 ** array__5771 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5771VTable;

int array__5771_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5771VTable != NULL
        && pSimarray__5771VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5771VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5642_to_string, 1, sizeof(struct__5642), pfnStrAppend, pData);
}

int string_to_array__5771(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5771VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5771VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5642_Utils, 1, sizeof(struct__5642), endptr);
    }
    return nRet;
}

int is_array__5771_double_convertion_allowed()
{
    if (pSimarray__5771VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5771VTable);
    }
    return 0;
}

void compare_array__5771(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5771VTable != NULL
        && pSimarray__5771VTable->m_version >= Scv612
        && pSimarray__5771VTable->m_pfnCompare != NULL) {
        if (pSimarray__5771VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5771VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5771VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5642, 1, sizeof(struct__5642), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5771_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5771VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5771VTable, nRetValue);
    }
    return 0;
}

int get_array__5771_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 1; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5642_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5771_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 1; i++)
        set_struct__5642_default_value(&((struct__5642*)pValue)[i]);
    return 1;
}

int check_array__5771_string(const char *str, char **endptr)
{
    static array__5771 rTemp;
    return string_to_array__5771(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5771_Utils = {
    array__5771_to_string,
    check_array__5771_string,
    string_to_array__5771,
    is_array__5771_double_convertion_allowed,
    array__5771_to_double,
    compare_array__5771,
    get_array__5771_signature,
    set_array__5771_default_value,
    sizeof(array__5771)
};

/****************************************************************
 ** array_bool_8 
 ****************************************************************/

struct SimTypeVTable *pSimarray_bool_8VTable;

int array_bool_8_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray_bool_8VTable != NULL
        && pSimarray_bool_8VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray_bool_8VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, kcg_bool_to_string, 8, sizeof(kcg_bool), pfnStrAppend, pData);
}

int string_to_array_bool_8(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray_bool_8VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray_bool_8VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_kcg_bool_Utils, 8, sizeof(kcg_bool), endptr);
    }
    return nRet;
}

int is_array_bool_8_double_convertion_allowed()
{
    if (pSimarray_bool_8VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray_bool_8VTable);
    }
    return 0;
}

void compare_array_bool_8(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray_bool_8VTable != NULL
        && pSimarray_bool_8VTable->m_version >= Scv612
        && pSimarray_bool_8VTable->m_pfnCompare != NULL) {
        if (pSimarray_bool_8VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray_bool_8VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray_bool_8VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_kcg_bool, 8, sizeof(kcg_bool), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array_bool_8_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray_bool_8VTable != NULL) {
        return VTable_to_double(pValue, pSimarray_bool_8VTable, nRetValue);
    }
    return 0;
}

int get_array_bool_8_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 8; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_kcg_bool_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array_bool_8_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 8; i++)
        set_kcg_bool_default_value(&((kcg_bool*)pValue)[i]);
    return 1;
}

int check_array_bool_8_string(const char *str, char **endptr)
{
    static array_bool_8 rTemp;
    return string_to_array_bool_8(str, &rTemp, endptr);
}

SimTypeUtils _Type_array_bool_8_Utils = {
    array_bool_8_to_string,
    check_array_bool_8_string,
    string_to_array_bool_8,
    is_array_bool_8_double_convertion_allowed,
    array_bool_8_to_double,
    compare_array_bool_8,
    get_array_bool_8_signature,
    set_array_bool_8_default_value,
    sizeof(array_bool_8)
};

/****************************************************************
 ** array__5777 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5777VTable;

int array__5777_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5777VTable != NULL
        && pSimarray__5777VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5777VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, struct__5690_to_string, 8, sizeof(struct__5690), pfnStrAppend, pData);
}

int string_to_array__5777(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5777VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5777VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_struct__5690_Utils, 8, sizeof(struct__5690), endptr);
    }
    return nRet;
}

int is_array__5777_double_convertion_allowed()
{
    if (pSimarray__5777VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5777VTable);
    }
    return 0;
}

void compare_array__5777(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5777VTable != NULL
        && pSimarray__5777VTable->m_version >= Scv612
        && pSimarray__5777VTable->m_pfnCompare != NULL) {
        if (pSimarray__5777VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5777VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5777VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_struct__5690, 8, sizeof(struct__5690), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5777_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5777VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5777VTable, nRetValue);
    }
    return 0;
}

int get_array__5777_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 8; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_struct__5690_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5777_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 8; i++)
        set_struct__5690_default_value(&((struct__5690*)pValue)[i]);
    return 1;
}

int check_array__5777_string(const char *str, char **endptr)
{
    static array__5777 rTemp;
    return string_to_array__5777(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5777_Utils = {
    array__5777_to_string,
    check_array__5777_string,
    string_to_array__5777,
    is_array__5777_double_convertion_allowed,
    array__5777_to_double,
    compare_array__5777,
    get_array__5777_signature,
    set_array__5777_default_value,
    sizeof(array__5777)
};

/****************************************************************
 ** array__5780 
 ****************************************************************/

struct SimTypeVTable *pSimarray__5780VTable;

int array__5780_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray__5780VTable != NULL
        && pSimarray__5780VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray__5780VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, array__5687_to_string, 8, sizeof(array__5687), pfnStrAppend, pData);
}

int string_to_array__5780(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray__5780VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray__5780VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_array__5687_Utils, 8, sizeof(array__5687), endptr);
    }
    return nRet;
}

int is_array__5780_double_convertion_allowed()
{
    if (pSimarray__5780VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray__5780VTable);
    }
    return 0;
}

void compare_array__5780(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray__5780VTable != NULL
        && pSimarray__5780VTable->m_version >= Scv612
        && pSimarray__5780VTable->m_pfnCompare != NULL) {
        if (pSimarray__5780VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray__5780VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray__5780VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_array__5687, 8, sizeof(array__5687), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array__5780_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray__5780VTable != NULL) {
        return VTable_to_double(pValue, pSimarray__5780VTable, nRetValue);
    }
    return 0;
}

int get_array__5780_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 8; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_array__5687_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array__5780_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 8; i++)
        set_array__5687_default_value(&((array__5687*)pValue)[i]);
    return 1;
}

int check_array__5780_string(const char *str, char **endptr)
{
    static array__5780 rTemp;
    return string_to_array__5780(str, &rTemp, endptr);
}

SimTypeUtils _Type_array__5780_Utils = {
    array__5780_to_string,
    check_array__5780_string,
    string_to_array__5780,
    is_array__5780_double_convertion_allowed,
    array__5780_to_double,
    compare_array__5780,
    get_array__5780_signature,
    set_array__5780_default_value,
    sizeof(array__5780)
};

/****************************************************************
 ** array_int_10 
 ****************************************************************/

struct SimTypeVTable *pSimarray_int_10VTable;

int array_int_10_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimarray_int_10VTable != NULL
        && pSimarray_int_10VTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimarray_int_10VTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnArrayToString(pValue, kcg_int_to_string, 10, sizeof(kcg_int), pfnStrAppend, pData);
}

int string_to_array_int_10(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimarray_int_10VTable != NULL) {
        nRet=string_to_VTable(str, pSimarray_int_10VTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = pConverter->m_pfnStringToArray(str, pValue, &_Type_kcg_int_Utils, 10, sizeof(kcg_int), endptr);
    }
    return nRet;
}

int is_array_int_10_double_convertion_allowed()
{
    if (pSimarray_int_10VTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimarray_int_10VTable);
    }
    return 0;
}

void compare_array_int_10(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimarray_int_10VTable != NULL
        && pSimarray_int_10VTable->m_version >= Scv612
        && pSimarray_int_10VTable->m_pfnCompare != NULL) {
        if (pSimarray_int_10VTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimarray_int_10VTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimarray_int_10VTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        pConverter->m_pfnArrayComparison(pResult, pValue1, pValue2, 
                compare_kcg_int, 10, sizeof(kcg_int), pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int array_int_10_to_double(const void *pValue, double *nRetValue)
{
    if (pSimarray_int_10VTable != NULL) {
        return VTable_to_double(pValue, pSimarray_int_10VTable, nRetValue);
    }
    return 0;
}

int get_array_int_10_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    int i;
    pfnStrAppend("(", pData);
    for (i = 0; i < 10; i++) {
        if(i > 0)
            pfnStrAppend(",", pData);
        get_kcg_int_signature(pfnStrAppend, pData);
    }
    pfnStrAppend(")", pData);
    return 1;
}

int set_array_int_10_default_value(void *pValue)
{
    int i;
    for (i = 0; i < 10; i++)
        set_kcg_int_default_value(&((kcg_int*)pValue)[i]);
    return 1;
}

int check_array_int_10_string(const char *str, char **endptr)
{
    static array_int_10 rTemp;
    return string_to_array_int_10(str, &rTemp, endptr);
}

SimTypeUtils _Type_array_int_10_Utils = {
    array_int_10_to_string,
    check_array_int_10_string,
    string_to_array_int_10,
    is_array_int_10_double_convertion_allowed,
    array_int_10_to_double,
    compare_array_int_10,
    get_array_int_10_signature,
    set_array_int_10_default_value,
    sizeof(array_int_10)
};

/****************************************************************
 ** Q_UPDOWN 
 ****************************************************************/

struct SimTypeVTable *pSimQ_UPDOWNVTable;

static SimEnumValUtils Q_UPDOWN_values[] = {
    { "Q_UPDOWN_Down_link_telegram", Q_UPDOWN_Down_link_telegram},
    { "Q_UPDOWN_Down_link_telegram", Q_UPDOWN_Down_link_telegram},
    { "Q_UPDOWN_Up_link_telegram", Q_UPDOWN_Up_link_telegram},
    { "Q_UPDOWN_Up_link_telegram", Q_UPDOWN_Up_link_telegram},
};

int Q_UPDOWN_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_UPDOWNVTable != NULL
        && pSimQ_UPDOWNVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_UPDOWNVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_UPDOWN*)pValue, Q_UPDOWN_values, 4, pfnStrAppend, pData);
}

int string_to_Q_UPDOWN(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_UPDOWNVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_UPDOWNVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_UPDOWN_values, 4, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_UPDOWN*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_UPDOWN_double_convertion_allowed()
{
    if (pSimQ_UPDOWNVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_UPDOWNVTable);
    }
    return 1;
}

void compare_Q_UPDOWN(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_UPDOWNVTable != NULL
        && pSimQ_UPDOWNVTable->m_version >= Scv612
        && pSimQ_UPDOWNVTable->m_pfnCompare != NULL) {
        if (pSimQ_UPDOWNVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_UPDOWNVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_UPDOWNVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_UPDOWN*)pValue1), (int)(*(Q_UPDOWN*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_UPDOWN_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_UPDOWNVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_UPDOWNVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_UPDOWN*)pValue);
    return 1;
}

int get_Q_UPDOWN_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_UPDOWN_values, 4, pfnStrAppend, pData);
}

int set_Q_UPDOWN_default_value(void *pValue)
{
    *(Q_UPDOWN*)pValue = Q_UPDOWN_Down_link_telegram;
    return 1;
}

int check_Q_UPDOWN_string(const char *str, char **endptr)
{
    static Q_UPDOWN rTemp;
    return string_to_Q_UPDOWN(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_UPDOWN_Utils = {
    Q_UPDOWN_to_string,
    check_Q_UPDOWN_string,
    string_to_Q_UPDOWN,
    is_Q_UPDOWN_double_convertion_allowed,
    Q_UPDOWN_to_double,
    compare_Q_UPDOWN,
    get_Q_UPDOWN_signature,
    set_Q_UPDOWN_default_value,
    sizeof(Q_UPDOWN)
};

/****************************************************************
 ** M_VERSION 
 ****************************************************************/

struct SimTypeVTable *pSimM_VERSIONVTable;

static SimEnumValUtils M_VERSION_values[] = {
    { "M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS", M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS},
    { "M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS", M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS},
    { "M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0", M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0},
    { "M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0", M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0},
    { "M_VERSION_Version_1_1_introduced_in_SRS_3_3_0", M_VERSION_Version_1_1_introduced_in_SRS_3_3_0},
    { "M_VERSION_Version_1_1_introduced_in_SRS_3_3_0", M_VERSION_Version_1_1_introduced_in_SRS_3_3_0},
    { "M_VERSION_Version_2_0_introduced_in_SRS_3_3_0", M_VERSION_Version_2_0_introduced_in_SRS_3_3_0},
    { "M_VERSION_Version_2_0_introduced_in_SRS_3_3_0", M_VERSION_Version_2_0_introduced_in_SRS_3_3_0},
};

int M_VERSION_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimM_VERSIONVTable != NULL
        && pSimM_VERSIONVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimM_VERSIONVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(M_VERSION*)pValue, M_VERSION_values, 8, pfnStrAppend, pData);
}

int string_to_M_VERSION(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimM_VERSIONVTable != NULL) {
        nRet=string_to_VTable(str, pSimM_VERSIONVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, M_VERSION_values, 8, endptr);
        if (pValue != NULL && nRet != 0)
            *(M_VERSION*)pValue = nTemp;
    }
    return nRet;
}

int is_M_VERSION_double_convertion_allowed()
{
    if (pSimM_VERSIONVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimM_VERSIONVTable);
    }
    return 1;
}

void compare_M_VERSION(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimM_VERSIONVTable != NULL
        && pSimM_VERSIONVTable->m_version >= Scv612
        && pSimM_VERSIONVTable->m_pfnCompare != NULL) {
        if (pSimM_VERSIONVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimM_VERSIONVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimM_VERSIONVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(M_VERSION*)pValue1), (int)(*(M_VERSION*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int M_VERSION_to_double(const void *pValue, double *nRetValue)
{
    if (pSimM_VERSIONVTable != NULL) {
        return VTable_to_double(pValue, pSimM_VERSIONVTable, nRetValue);
    }
    *nRetValue = (double)*((M_VERSION*)pValue);
    return 1;
}

int get_M_VERSION_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(M_VERSION_values, 8, pfnStrAppend, pData);
}

int set_M_VERSION_default_value(void *pValue)
{
    *(M_VERSION*)pValue = M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS;
    return 1;
}

int check_M_VERSION_string(const char *str, char **endptr)
{
    static M_VERSION rTemp;
    return string_to_M_VERSION(str, &rTemp, endptr);
}

SimTypeUtils _Type_M_VERSION_Utils = {
    M_VERSION_to_string,
    check_M_VERSION_string,
    string_to_M_VERSION,
    is_M_VERSION_double_convertion_allowed,
    M_VERSION_to_double,
    compare_M_VERSION,
    get_M_VERSION_signature,
    set_M_VERSION_default_value,
    sizeof(M_VERSION)
};

/****************************************************************
 ** Q_MEDIA 
 ****************************************************************/

struct SimTypeVTable *pSimQ_MEDIAVTable;

static SimEnumValUtils Q_MEDIA_values[] = {
    { "Q_MEDIA_Balise", Q_MEDIA_Balise},
    { "Q_MEDIA_Balise", Q_MEDIA_Balise},
    { "Q_MEDIA_Loop", Q_MEDIA_Loop},
    { "Q_MEDIA_Loop", Q_MEDIA_Loop},
};

int Q_MEDIA_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_MEDIAVTable != NULL
        && pSimQ_MEDIAVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_MEDIAVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_MEDIA*)pValue, Q_MEDIA_values, 4, pfnStrAppend, pData);
}

int string_to_Q_MEDIA(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_MEDIAVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_MEDIAVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_MEDIA_values, 4, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_MEDIA*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_MEDIA_double_convertion_allowed()
{
    if (pSimQ_MEDIAVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_MEDIAVTable);
    }
    return 1;
}

void compare_Q_MEDIA(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_MEDIAVTable != NULL
        && pSimQ_MEDIAVTable->m_version >= Scv612
        && pSimQ_MEDIAVTable->m_pfnCompare != NULL) {
        if (pSimQ_MEDIAVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_MEDIAVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_MEDIAVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_MEDIA*)pValue1), (int)(*(Q_MEDIA*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_MEDIA_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_MEDIAVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_MEDIAVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_MEDIA*)pValue);
    return 1;
}

int get_Q_MEDIA_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_MEDIA_values, 4, pfnStrAppend, pData);
}

int set_Q_MEDIA_default_value(void *pValue)
{
    *(Q_MEDIA*)pValue = Q_MEDIA_Balise;
    return 1;
}

int check_Q_MEDIA_string(const char *str, char **endptr)
{
    static Q_MEDIA rTemp;
    return string_to_Q_MEDIA(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_MEDIA_Utils = {
    Q_MEDIA_to_string,
    check_Q_MEDIA_string,
    string_to_Q_MEDIA,
    is_Q_MEDIA_double_convertion_allowed,
    Q_MEDIA_to_double,
    compare_Q_MEDIA,
    get_Q_MEDIA_signature,
    set_Q_MEDIA_default_value,
    sizeof(Q_MEDIA)
};

/****************************************************************
 ** N_TOTAL 
 ****************************************************************/

struct SimTypeVTable *pSimN_TOTALVTable;

static SimEnumValUtils N_TOTAL_values[] = {
    { "N_TOTAL_1_balise_in_the_group", N_TOTAL_1_balise_in_the_group},
    { "N_TOTAL_1_balise_in_the_group", N_TOTAL_1_balise_in_the_group},
    { "N_TOTAL_2_balises_in_the_group", N_TOTAL_2_balises_in_the_group},
    { "N_TOTAL_2_balises_in_the_group", N_TOTAL_2_balises_in_the_group},
    { "N_TOTAL_3_balises_in_the_group", N_TOTAL_3_balises_in_the_group},
    { "N_TOTAL_3_balises_in_the_group", N_TOTAL_3_balises_in_the_group},
    { "N_TOTAL_4_balises_in_the_group", N_TOTAL_4_balises_in_the_group},
    { "N_TOTAL_4_balises_in_the_group", N_TOTAL_4_balises_in_the_group},
    { "N_TOTAL_5_balises_in_the_group", N_TOTAL_5_balises_in_the_group},
    { "N_TOTAL_5_balises_in_the_group", N_TOTAL_5_balises_in_the_group},
    { "N_TOTAL_6_balises_in_the_group", N_TOTAL_6_balises_in_the_group},
    { "N_TOTAL_6_balises_in_the_group", N_TOTAL_6_balises_in_the_group},
    { "N_TOTAL_7_balises_in_the_group", N_TOTAL_7_balises_in_the_group},
    { "N_TOTAL_7_balises_in_the_group", N_TOTAL_7_balises_in_the_group},
    { "N_TOTAL_8_balises_in_the_group", N_TOTAL_8_balises_in_the_group},
    { "N_TOTAL_8_balises_in_the_group", N_TOTAL_8_balises_in_the_group},
};

int N_TOTAL_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimN_TOTALVTable != NULL
        && pSimN_TOTALVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimN_TOTALVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(N_TOTAL*)pValue, N_TOTAL_values, 16, pfnStrAppend, pData);
}

int string_to_N_TOTAL(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimN_TOTALVTable != NULL) {
        nRet=string_to_VTable(str, pSimN_TOTALVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, N_TOTAL_values, 16, endptr);
        if (pValue != NULL && nRet != 0)
            *(N_TOTAL*)pValue = nTemp;
    }
    return nRet;
}

int is_N_TOTAL_double_convertion_allowed()
{
    if (pSimN_TOTALVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimN_TOTALVTable);
    }
    return 1;
}

void compare_N_TOTAL(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimN_TOTALVTable != NULL
        && pSimN_TOTALVTable->m_version >= Scv612
        && pSimN_TOTALVTable->m_pfnCompare != NULL) {
        if (pSimN_TOTALVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimN_TOTALVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimN_TOTALVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(N_TOTAL*)pValue1), (int)(*(N_TOTAL*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int N_TOTAL_to_double(const void *pValue, double *nRetValue)
{
    if (pSimN_TOTALVTable != NULL) {
        return VTable_to_double(pValue, pSimN_TOTALVTable, nRetValue);
    }
    *nRetValue = (double)*((N_TOTAL*)pValue);
    return 1;
}

int get_N_TOTAL_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(N_TOTAL_values, 16, pfnStrAppend, pData);
}

int set_N_TOTAL_default_value(void *pValue)
{
    *(N_TOTAL*)pValue = N_TOTAL_1_balise_in_the_group;
    return 1;
}

int check_N_TOTAL_string(const char *str, char **endptr)
{
    static N_TOTAL rTemp;
    return string_to_N_TOTAL(str, &rTemp, endptr);
}

SimTypeUtils _Type_N_TOTAL_Utils = {
    N_TOTAL_to_string,
    check_N_TOTAL_string,
    string_to_N_TOTAL,
    is_N_TOTAL_double_convertion_allowed,
    N_TOTAL_to_double,
    compare_N_TOTAL,
    get_N_TOTAL_signature,
    set_N_TOTAL_default_value,
    sizeof(N_TOTAL)
};

/****************************************************************
 ** M_MCOUNT 
 ****************************************************************/

struct SimTypeVTable *pSimM_MCOUNTVTable;

int M_MCOUNT_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimM_MCOUNTVTable != NULL
        && pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimM_MCOUNTVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_M_MCOUNT(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimM_MCOUNTVTable != NULL) {
        nRet=string_to_VTable(str, pSimM_MCOUNTVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_M_MCOUNT_double_convertion_allowed()
{
    if (pSimM_MCOUNTVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimM_MCOUNTVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_M_MCOUNT(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimM_MCOUNTVTable != NULL
        && pSimM_MCOUNTVTable->m_version >= Scv612
        && pSimM_MCOUNTVTable->m_pfnCompare != NULL) {
        if (pSimM_MCOUNTVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimM_MCOUNTVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimM_MCOUNTVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int M_MCOUNT_to_double(const void *pValue, double *nRetValue)
{
    if (pSimM_MCOUNTVTable != NULL) {
        return VTable_to_double(pValue, pSimM_MCOUNTVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_M_MCOUNT_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_M_MCOUNT_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_M_MCOUNT_string(const char *str, char **endptr)
{
    static M_MCOUNT rTemp;
    return string_to_M_MCOUNT(str, &rTemp, endptr);
}

SimTypeUtils _Type_M_MCOUNT_Utils = {
    M_MCOUNT_to_string,
    check_M_MCOUNT_string,
    string_to_M_MCOUNT,
    is_M_MCOUNT_double_convertion_allowed,
    M_MCOUNT_to_double,
    compare_M_MCOUNT,
    get_M_MCOUNT_signature,
    set_M_MCOUNT_default_value,
    sizeof(M_MCOUNT)
};

/****************************************************************
 ** NID_C 
 ****************************************************************/

struct SimTypeVTable *pSimNID_CVTable;

int NID_C_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_CVTable != NULL
        && pSimNID_CVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_CVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_C(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_CVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_CVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_C_double_convertion_allowed()
{
    if (pSimNID_CVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_CVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_C(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_CVTable != NULL
        && pSimNID_CVTable->m_version >= Scv612
        && pSimNID_CVTable->m_pfnCompare != NULL) {
        if (pSimNID_CVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_CVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_CVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_C_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_CVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_CVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_C_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_C_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_C_string(const char *str, char **endptr)
{
    static NID_C rTemp;
    return string_to_NID_C(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_C_Utils = {
    NID_C_to_string,
    check_NID_C_string,
    string_to_NID_C,
    is_NID_C_double_convertion_allowed,
    NID_C_to_double,
    compare_NID_C,
    get_NID_C_signature,
    set_NID_C_default_value,
    sizeof(NID_C)
};

/****************************************************************
 ** NID_BG 
 ****************************************************************/

struct SimTypeVTable *pSimNID_BGVTable;

int NID_BG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_BGVTable != NULL
        && pSimNID_BGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_BGVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_BG(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_BGVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_BGVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_BG_double_convertion_allowed()
{
    if (pSimNID_BGVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_BGVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_BG(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_BGVTable != NULL
        && pSimNID_BGVTable->m_version >= Scv612
        && pSimNID_BGVTable->m_pfnCompare != NULL) {
        if (pSimNID_BGVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_BGVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_BGVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_BG_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_BGVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_BGVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_BG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_BG_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_BG_string(const char *str, char **endptr)
{
    static NID_BG rTemp;
    return string_to_NID_BG(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_BG_Utils = {
    NID_BG_to_string,
    check_NID_BG_string,
    string_to_NID_BG,
    is_NID_BG_double_convertion_allowed,
    NID_BG_to_double,
    compare_NID_BG,
    get_NID_BG_signature,
    set_NID_BG_default_value,
    sizeof(NID_BG)
};

/****************************************************************
 ** Q_LINK 
 ****************************************************************/

struct SimTypeVTable *pSimQ_LINKVTable;

static SimEnumValUtils Q_LINK_values[] = {
    { "Q_LINK_Unlinked", Q_LINK_Unlinked},
    { "Q_LINK_Unlinked", Q_LINK_Unlinked},
    { "Q_LINK_Linked", Q_LINK_Linked},
    { "Q_LINK_Linked", Q_LINK_Linked},
};

int Q_LINK_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_LINKVTable != NULL
        && pSimQ_LINKVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_LINKVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_LINK*)pValue, Q_LINK_values, 4, pfnStrAppend, pData);
}

int string_to_Q_LINK(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_LINKVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_LINKVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_LINK_values, 4, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_LINK*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_LINK_double_convertion_allowed()
{
    if (pSimQ_LINKVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_LINKVTable);
    }
    return 1;
}

void compare_Q_LINK(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_LINKVTable != NULL
        && pSimQ_LINKVTable->m_version >= Scv612
        && pSimQ_LINKVTable->m_pfnCompare != NULL) {
        if (pSimQ_LINKVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_LINKVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_LINKVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_LINK*)pValue1), (int)(*(Q_LINK*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_LINK_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_LINKVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_LINKVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_LINK*)pValue);
    return 1;
}

int get_Q_LINK_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_LINK_values, 4, pfnStrAppend, pData);
}

int set_Q_LINK_default_value(void *pValue)
{
    *(Q_LINK*)pValue = Q_LINK_Unlinked;
    return 1;
}

int check_Q_LINK_string(const char *str, char **endptr)
{
    static Q_LINK rTemp;
    return string_to_Q_LINK(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_LINK_Utils = {
    Q_LINK_to_string,
    check_Q_LINK_string,
    string_to_Q_LINK,
    is_Q_LINK_double_convertion_allowed,
    Q_LINK_to_double,
    compare_Q_LINK,
    get_Q_LINK_signature,
    set_Q_LINK_default_value,
    sizeof(Q_LINK)
};

/****************************************************************
 ** NID_LRBG 
 ****************************************************************/

struct SimTypeVTable *pSimNID_LRBGVTable;

int NID_LRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_LRBGVTable != NULL
        && pSimNID_LRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_LRBGVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_LRBG(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_LRBGVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_LRBGVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_LRBG_double_convertion_allowed()
{
    if (pSimNID_LRBGVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_LRBGVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_LRBG(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_LRBGVTable != NULL
        && pSimNID_LRBGVTable->m_version >= Scv612
        && pSimNID_LRBGVTable->m_pfnCompare != NULL) {
        if (pSimNID_LRBGVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_LRBGVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_LRBGVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_LRBG_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_LRBGVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_LRBGVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_LRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_LRBG_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_LRBG_string(const char *str, char **endptr)
{
    static NID_LRBG rTemp;
    return string_to_NID_LRBG(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_LRBG_Utils = {
    NID_LRBG_to_string,
    check_NID_LRBG_string,
    string_to_NID_LRBG,
    is_NID_LRBG_double_convertion_allowed,
    NID_LRBG_to_double,
    compare_NID_LRBG,
    get_NID_LRBG_signature,
    set_NID_LRBG_default_value,
    sizeof(NID_LRBG)
};

/****************************************************************
 ** NID_PACKET 
 ****************************************************************/

struct SimTypeVTable *pSimNID_PACKETVTable;

int NID_PACKET_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_PACKETVTable != NULL
        && pSimNID_PACKETVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_PACKETVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_PACKET(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_PACKETVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_PACKETVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_PACKET_double_convertion_allowed()
{
    if (pSimNID_PACKETVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_PACKETVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_PACKET(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_PACKETVTable != NULL
        && pSimNID_PACKETVTable->m_version >= Scv612
        && pSimNID_PACKETVTable->m_pfnCompare != NULL) {
        if (pSimNID_PACKETVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_PACKETVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_PACKETVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_PACKET_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_PACKETVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_PACKETVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_PACKET_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_PACKET_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_PACKET_string(const char *str, char **endptr)
{
    static NID_PACKET rTemp;
    return string_to_NID_PACKET(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_PACKET_Utils = {
    NID_PACKET_to_string,
    check_NID_PACKET_string,
    string_to_NID_PACKET,
    is_NID_PACKET_double_convertion_allowed,
    NID_PACKET_to_double,
    compare_NID_PACKET,
    get_NID_PACKET_signature,
    set_NID_PACKET_default_value,
    sizeof(NID_PACKET)
};

/****************************************************************
 ** Q_DIR 
 ****************************************************************/

struct SimTypeVTable *pSimQ_DIRVTable;

static SimEnumValUtils Q_DIR_values[] = {
    { "Q_DIR_Reverse", Q_DIR_Reverse},
    { "Q_DIR_Reverse", Q_DIR_Reverse},
    { "Q_DIR_Nominal", Q_DIR_Nominal},
    { "Q_DIR_Nominal", Q_DIR_Nominal},
    { "Q_DIR_Both_directions", Q_DIR_Both_directions},
    { "Q_DIR_Both_directions", Q_DIR_Both_directions},
};

int Q_DIR_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_DIRVTable != NULL
        && pSimQ_DIRVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_DIRVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_DIR*)pValue, Q_DIR_values, 6, pfnStrAppend, pData);
}

int string_to_Q_DIR(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_DIRVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_DIRVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_DIR_values, 6, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_DIR*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_DIR_double_convertion_allowed()
{
    if (pSimQ_DIRVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_DIRVTable);
    }
    return 1;
}

void compare_Q_DIR(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_DIRVTable != NULL
        && pSimQ_DIRVTable->m_version >= Scv612
        && pSimQ_DIRVTable->m_pfnCompare != NULL) {
        if (pSimQ_DIRVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_DIRVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_DIRVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_DIR*)pValue1), (int)(*(Q_DIR*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_DIR_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_DIRVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_DIRVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_DIR*)pValue);
    return 1;
}

int get_Q_DIR_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_DIR_values, 6, pfnStrAppend, pData);
}

int set_Q_DIR_default_value(void *pValue)
{
    *(Q_DIR*)pValue = Q_DIR_Reverse;
    return 1;
}

int check_Q_DIR_string(const char *str, char **endptr)
{
    static Q_DIR rTemp;
    return string_to_Q_DIR(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_DIR_Utils = {
    Q_DIR_to_string,
    check_Q_DIR_string,
    string_to_Q_DIR,
    is_Q_DIR_double_convertion_allowed,
    Q_DIR_to_double,
    compare_Q_DIR,
    get_Q_DIR_signature,
    set_Q_DIR_default_value,
    sizeof(Q_DIR)
};

/****************************************************************
 ** L_PACKET 
 ****************************************************************/

struct SimTypeVTable *pSimL_PACKETVTable;

int L_PACKET_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimL_PACKETVTable != NULL
        && pSimL_PACKETVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimL_PACKETVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_L_PACKET(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimL_PACKETVTable != NULL) {
        nRet=string_to_VTable(str, pSimL_PACKETVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_L_PACKET_double_convertion_allowed()
{
    if (pSimL_PACKETVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimL_PACKETVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_L_PACKET(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimL_PACKETVTable != NULL
        && pSimL_PACKETVTable->m_version >= Scv612
        && pSimL_PACKETVTable->m_pfnCompare != NULL) {
        if (pSimL_PACKETVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimL_PACKETVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimL_PACKETVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int L_PACKET_to_double(const void *pValue, double *nRetValue)
{
    if (pSimL_PACKETVTable != NULL) {
        return VTable_to_double(pValue, pSimL_PACKETVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_L_PACKET_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_L_PACKET_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_L_PACKET_string(const char *str, char **endptr)
{
    static L_PACKET rTemp;
    return string_to_L_PACKET(str, &rTemp, endptr);
}

SimTypeUtils _Type_L_PACKET_Utils = {
    L_PACKET_to_string,
    check_L_PACKET_string,
    string_to_L_PACKET,
    is_L_PACKET_double_convertion_allowed,
    L_PACKET_to_double,
    compare_L_PACKET,
    get_L_PACKET_signature,
    set_L_PACKET_default_value,
    sizeof(L_PACKET)
};

/****************************************************************
 ** Q_SCALE 
 ****************************************************************/

struct SimTypeVTable *pSimQ_SCALEVTable;

static SimEnumValUtils Q_SCALE_values[] = {
    { "Q_SCALE_10_cm_scale", Q_SCALE_10_cm_scale},
    { "Q_SCALE_10_cm_scale", Q_SCALE_10_cm_scale},
    { "Q_SCALE_1_m_scale", Q_SCALE_1_m_scale},
    { "Q_SCALE_1_m_scale", Q_SCALE_1_m_scale},
    { "Q_SCALE_10_m_scale", Q_SCALE_10_m_scale},
    { "Q_SCALE_10_m_scale", Q_SCALE_10_m_scale},
};

int Q_SCALE_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_SCALEVTable != NULL
        && pSimQ_SCALEVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_SCALEVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_SCALE*)pValue, Q_SCALE_values, 6, pfnStrAppend, pData);
}

int string_to_Q_SCALE(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_SCALEVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_SCALEVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_SCALE_values, 6, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_SCALE*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_SCALE_double_convertion_allowed()
{
    if (pSimQ_SCALEVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_SCALEVTable);
    }
    return 1;
}

void compare_Q_SCALE(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_SCALEVTable != NULL
        && pSimQ_SCALEVTable->m_version >= Scv612
        && pSimQ_SCALEVTable->m_pfnCompare != NULL) {
        if (pSimQ_SCALEVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_SCALEVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_SCALEVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_SCALE*)pValue1), (int)(*(Q_SCALE*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_SCALE_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_SCALEVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_SCALEVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_SCALE*)pValue);
    return 1;
}

int get_Q_SCALE_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_SCALE_values, 6, pfnStrAppend, pData);
}

int set_Q_SCALE_default_value(void *pValue)
{
    *(Q_SCALE*)pValue = Q_SCALE_10_cm_scale;
    return 1;
}

int check_Q_SCALE_string(const char *str, char **endptr)
{
    static Q_SCALE rTemp;
    return string_to_Q_SCALE(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_SCALE_Utils = {
    Q_SCALE_to_string,
    check_Q_SCALE_string,
    string_to_Q_SCALE,
    is_Q_SCALE_double_convertion_allowed,
    Q_SCALE_to_double,
    compare_Q_SCALE,
    get_Q_SCALE_signature,
    set_Q_SCALE_default_value,
    sizeof(Q_SCALE)
};

/****************************************************************
 ** D_LINK 
 ****************************************************************/

struct SimTypeVTable *pSimD_LINKVTable;

int D_LINK_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimD_LINKVTable != NULL
        && pSimD_LINKVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimD_LINKVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_D_LINK(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimD_LINKVTable != NULL) {
        nRet=string_to_VTable(str, pSimD_LINKVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_D_LINK_double_convertion_allowed()
{
    if (pSimD_LINKVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimD_LINKVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_D_LINK(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimD_LINKVTable != NULL
        && pSimD_LINKVTable->m_version >= Scv612
        && pSimD_LINKVTable->m_pfnCompare != NULL) {
        if (pSimD_LINKVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimD_LINKVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimD_LINKVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int D_LINK_to_double(const void *pValue, double *nRetValue)
{
    if (pSimD_LINKVTable != NULL) {
        return VTable_to_double(pValue, pSimD_LINKVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_D_LINK_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_D_LINK_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_D_LINK_string(const char *str, char **endptr)
{
    static D_LINK rTemp;
    return string_to_D_LINK(str, &rTemp, endptr);
}

SimTypeUtils _Type_D_LINK_Utils = {
    D_LINK_to_string,
    check_D_LINK_string,
    string_to_D_LINK,
    is_D_LINK_double_convertion_allowed,
    D_LINK_to_double,
    compare_D_LINK,
    get_D_LINK_signature,
    set_D_LINK_default_value,
    sizeof(D_LINK)
};

/****************************************************************
 ** Q_NEWCOUNTRY 
 ****************************************************************/

struct SimTypeVTable *pSimQ_NEWCOUNTRYVTable;

static SimEnumValUtils Q_NEWCOUNTRY_values[] = {
    { "Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows", Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows},
    { "Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows", Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows},
    { "Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows", Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows},
    { "Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows", Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows},
};

int Q_NEWCOUNTRY_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_NEWCOUNTRYVTable != NULL
        && pSimQ_NEWCOUNTRYVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_NEWCOUNTRYVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_NEWCOUNTRY*)pValue, Q_NEWCOUNTRY_values, 4, pfnStrAppend, pData);
}

int string_to_Q_NEWCOUNTRY(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_NEWCOUNTRYVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_NEWCOUNTRYVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_NEWCOUNTRY_values, 4, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_NEWCOUNTRY*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_NEWCOUNTRY_double_convertion_allowed()
{
    if (pSimQ_NEWCOUNTRYVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_NEWCOUNTRYVTable);
    }
    return 1;
}

void compare_Q_NEWCOUNTRY(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_NEWCOUNTRYVTable != NULL
        && pSimQ_NEWCOUNTRYVTable->m_version >= Scv612
        && pSimQ_NEWCOUNTRYVTable->m_pfnCompare != NULL) {
        if (pSimQ_NEWCOUNTRYVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_NEWCOUNTRYVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_NEWCOUNTRYVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_NEWCOUNTRY*)pValue1), (int)(*(Q_NEWCOUNTRY*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_NEWCOUNTRY_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_NEWCOUNTRYVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_NEWCOUNTRYVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_NEWCOUNTRY*)pValue);
    return 1;
}

int get_Q_NEWCOUNTRY_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_NEWCOUNTRY_values, 4, pfnStrAppend, pData);
}

int set_Q_NEWCOUNTRY_default_value(void *pValue)
{
    *(Q_NEWCOUNTRY*)pValue = Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows;
    return 1;
}

int check_Q_NEWCOUNTRY_string(const char *str, char **endptr)
{
    static Q_NEWCOUNTRY rTemp;
    return string_to_Q_NEWCOUNTRY(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_NEWCOUNTRY_Utils = {
    Q_NEWCOUNTRY_to_string,
    check_Q_NEWCOUNTRY_string,
    string_to_Q_NEWCOUNTRY,
    is_Q_NEWCOUNTRY_double_convertion_allowed,
    Q_NEWCOUNTRY_to_double,
    compare_Q_NEWCOUNTRY,
    get_Q_NEWCOUNTRY_signature,
    set_Q_NEWCOUNTRY_default_value,
    sizeof(Q_NEWCOUNTRY)
};

/****************************************************************
 ** Q_LINKORIENTATION 
 ****************************************************************/

struct SimTypeVTable *pSimQ_LINKORIENTATIONVTable;

static SimEnumValUtils Q_LINKORIENTATION_values[] = {
    { "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction", Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction},
    { "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction", Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction},
    { "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction", Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction},
    { "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction", Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction},
};

int Q_LINKORIENTATION_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_LINKORIENTATIONVTable != NULL
        && pSimQ_LINKORIENTATIONVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_LINKORIENTATIONVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_LINKORIENTATION*)pValue, Q_LINKORIENTATION_values, 4, pfnStrAppend, pData);
}

int string_to_Q_LINKORIENTATION(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_LINKORIENTATIONVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_LINKORIENTATIONVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_LINKORIENTATION_values, 4, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_LINKORIENTATION*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_LINKORIENTATION_double_convertion_allowed()
{
    if (pSimQ_LINKORIENTATIONVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_LINKORIENTATIONVTable);
    }
    return 1;
}

void compare_Q_LINKORIENTATION(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_LINKORIENTATIONVTable != NULL
        && pSimQ_LINKORIENTATIONVTable->m_version >= Scv612
        && pSimQ_LINKORIENTATIONVTable->m_pfnCompare != NULL) {
        if (pSimQ_LINKORIENTATIONVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_LINKORIENTATIONVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_LINKORIENTATIONVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_LINKORIENTATION*)pValue1), (int)(*(Q_LINKORIENTATION*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_LINKORIENTATION_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_LINKORIENTATIONVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_LINKORIENTATIONVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_LINKORIENTATION*)pValue);
    return 1;
}

int get_Q_LINKORIENTATION_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_LINKORIENTATION_values, 4, pfnStrAppend, pData);
}

int set_Q_LINKORIENTATION_default_value(void *pValue)
{
    *(Q_LINKORIENTATION*)pValue = Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction;
    return 1;
}

int check_Q_LINKORIENTATION_string(const char *str, char **endptr)
{
    static Q_LINKORIENTATION rTemp;
    return string_to_Q_LINKORIENTATION(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_LINKORIENTATION_Utils = {
    Q_LINKORIENTATION_to_string,
    check_Q_LINKORIENTATION_string,
    string_to_Q_LINKORIENTATION,
    is_Q_LINKORIENTATION_double_convertion_allowed,
    Q_LINKORIENTATION_to_double,
    compare_Q_LINKORIENTATION,
    get_Q_LINKORIENTATION_signature,
    set_Q_LINKORIENTATION_default_value,
    sizeof(Q_LINKORIENTATION)
};

/****************************************************************
 ** Q_LINKREACTION 
 ****************************************************************/

struct SimTypeVTable *pSimQ_LINKREACTIONVTable;

static SimEnumValUtils Q_LINKREACTION_values[] = {
    { "Q_LINKREACTION_Train_trip", Q_LINKREACTION_Train_trip},
    { "Q_LINKREACTION_Train_trip", Q_LINKREACTION_Train_trip},
    { "Q_LINKREACTION_Apply_service_brake", Q_LINKREACTION_Apply_service_brake},
    { "Q_LINKREACTION_Apply_service_brake", Q_LINKREACTION_Apply_service_brake},
    { "Q_LINKREACTION_No_Reaction", Q_LINKREACTION_No_Reaction},
    { "Q_LINKREACTION_No_Reaction", Q_LINKREACTION_No_Reaction},
};

int Q_LINKREACTION_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_LINKREACTIONVTable != NULL
        && pSimQ_LINKREACTIONVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_LINKREACTIONVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_LINKREACTION*)pValue, Q_LINKREACTION_values, 6, pfnStrAppend, pData);
}

int string_to_Q_LINKREACTION(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_LINKREACTIONVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_LINKREACTIONVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_LINKREACTION_values, 6, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_LINKREACTION*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_LINKREACTION_double_convertion_allowed()
{
    if (pSimQ_LINKREACTIONVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_LINKREACTIONVTable);
    }
    return 1;
}

void compare_Q_LINKREACTION(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_LINKREACTIONVTable != NULL
        && pSimQ_LINKREACTIONVTable->m_version >= Scv612
        && pSimQ_LINKREACTIONVTable->m_pfnCompare != NULL) {
        if (pSimQ_LINKREACTIONVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_LINKREACTIONVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_LINKREACTIONVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_LINKREACTION*)pValue1), (int)(*(Q_LINKREACTION*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_LINKREACTION_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_LINKREACTIONVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_LINKREACTIONVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_LINKREACTION*)pValue);
    return 1;
}

int get_Q_LINKREACTION_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_LINKREACTION_values, 6, pfnStrAppend, pData);
}

int set_Q_LINKREACTION_default_value(void *pValue)
{
    *(Q_LINKREACTION*)pValue = Q_LINKREACTION_Train_trip;
    return 1;
}

int check_Q_LINKREACTION_string(const char *str, char **endptr)
{
    static Q_LINKREACTION rTemp;
    return string_to_Q_LINKREACTION(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_LINKREACTION_Utils = {
    Q_LINKREACTION_to_string,
    check_Q_LINKREACTION_string,
    string_to_Q_LINKREACTION,
    is_Q_LINKREACTION_double_convertion_allowed,
    Q_LINKREACTION_to_double,
    compare_Q_LINKREACTION,
    get_Q_LINKREACTION_signature,
    set_Q_LINKREACTION_default_value,
    sizeof(Q_LINKREACTION)
};

/****************************************************************
 ** Q_LOCACC 
 ****************************************************************/

struct SimTypeVTable *pSimQ_LOCACCVTable;

int Q_LOCACC_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_LOCACCVTable != NULL
        && pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_LOCACCVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_Q_LOCACC(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_LOCACCVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_LOCACCVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_Q_LOCACC_double_convertion_allowed()
{
    if (pSimQ_LOCACCVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_LOCACCVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_Q_LOCACC(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_LOCACCVTable != NULL
        && pSimQ_LOCACCVTable->m_version >= Scv612
        && pSimQ_LOCACCVTable->m_pfnCompare != NULL) {
        if (pSimQ_LOCACCVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_LOCACCVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_LOCACCVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_LOCACC_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_LOCACCVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_LOCACCVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_Q_LOCACC_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_Q_LOCACC_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_Q_LOCACC_string(const char *str, char **endptr)
{
    static Q_LOCACC rTemp;
    return string_to_Q_LOCACC(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_LOCACC_Utils = {
    Q_LOCACC_to_string,
    check_Q_LOCACC_string,
    string_to_Q_LOCACC,
    is_Q_LOCACC_double_convertion_allowed,
    Q_LOCACC_to_double,
    compare_Q_LOCACC,
    get_Q_LOCACC_signature,
    set_Q_LOCACC_default_value,
    sizeof(Q_LOCACC)
};

/****************************************************************
 ** Q_DIRLRBG 
 ****************************************************************/

struct SimTypeVTable *pSimQ_DIRLRBGVTable;

static SimEnumValUtils Q_DIRLRBG_values[] = {
    { "Q_DIRLRBG_Reverse", Q_DIRLRBG_Reverse},
    { "Q_DIRLRBG_Reverse", Q_DIRLRBG_Reverse},
    { "Q_DIRLRBG_Nominal", Q_DIRLRBG_Nominal},
    { "Q_DIRLRBG_Nominal", Q_DIRLRBG_Nominal},
    { "Q_DIRLRBG_Unknown", Q_DIRLRBG_Unknown},
    { "Q_DIRLRBG_Unknown", Q_DIRLRBG_Unknown},
};

int Q_DIRLRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_DIRLRBGVTable != NULL
        && pSimQ_DIRLRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_DIRLRBGVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_DIRLRBG*)pValue, Q_DIRLRBG_values, 6, pfnStrAppend, pData);
}

int string_to_Q_DIRLRBG(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_DIRLRBGVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_DIRLRBGVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_DIRLRBG_values, 6, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_DIRLRBG*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_DIRLRBG_double_convertion_allowed()
{
    if (pSimQ_DIRLRBGVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_DIRLRBGVTable);
    }
    return 1;
}

void compare_Q_DIRLRBG(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_DIRLRBGVTable != NULL
        && pSimQ_DIRLRBGVTable->m_version >= Scv612
        && pSimQ_DIRLRBGVTable->m_pfnCompare != NULL) {
        if (pSimQ_DIRLRBGVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_DIRLRBGVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_DIRLRBGVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_DIRLRBG*)pValue1), (int)(*(Q_DIRLRBG*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_DIRLRBG_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_DIRLRBGVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_DIRLRBGVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_DIRLRBG*)pValue);
    return 1;
}

int get_Q_DIRLRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_DIRLRBG_values, 6, pfnStrAppend, pData);
}

int set_Q_DIRLRBG_default_value(void *pValue)
{
    *(Q_DIRLRBG*)pValue = Q_DIRLRBG_Reverse;
    return 1;
}

int check_Q_DIRLRBG_string(const char *str, char **endptr)
{
    static Q_DIRLRBG rTemp;
    return string_to_Q_DIRLRBG(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_DIRLRBG_Utils = {
    Q_DIRLRBG_to_string,
    check_Q_DIRLRBG_string,
    string_to_Q_DIRLRBG,
    is_Q_DIRLRBG_double_convertion_allowed,
    Q_DIRLRBG_to_double,
    compare_Q_DIRLRBG,
    get_Q_DIRLRBG_signature,
    set_Q_DIRLRBG_default_value,
    sizeof(Q_DIRLRBG)
};

/****************************************************************
 ** Q_DIRTRAIN 
 ****************************************************************/

struct SimTypeVTable *pSimQ_DIRTRAINVTable;

static SimEnumValUtils Q_DIRTRAIN_values[] = {
    { "Q_DIRTRAIN_Reverse", Q_DIRTRAIN_Reverse},
    { "Q_DIRTRAIN_Reverse", Q_DIRTRAIN_Reverse},
    { "Q_DIRTRAIN_Nominal", Q_DIRTRAIN_Nominal},
    { "Q_DIRTRAIN_Nominal", Q_DIRTRAIN_Nominal},
    { "Q_DIRTRAIN_Unknown", Q_DIRTRAIN_Unknown},
    { "Q_DIRTRAIN_Unknown", Q_DIRTRAIN_Unknown},
};

int Q_DIRTRAIN_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_DIRTRAINVTable != NULL
        && pSimQ_DIRTRAINVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_DIRTRAINVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_DIRTRAIN*)pValue, Q_DIRTRAIN_values, 6, pfnStrAppend, pData);
}

int string_to_Q_DIRTRAIN(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_DIRTRAINVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_DIRTRAINVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_DIRTRAIN_values, 6, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_DIRTRAIN*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_DIRTRAIN_double_convertion_allowed()
{
    if (pSimQ_DIRTRAINVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_DIRTRAINVTable);
    }
    return 1;
}

void compare_Q_DIRTRAIN(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_DIRTRAINVTable != NULL
        && pSimQ_DIRTRAINVTable->m_version >= Scv612
        && pSimQ_DIRTRAINVTable->m_pfnCompare != NULL) {
        if (pSimQ_DIRTRAINVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_DIRTRAINVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_DIRTRAINVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_DIRTRAIN*)pValue1), (int)(*(Q_DIRTRAIN*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_DIRTRAIN_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_DIRTRAINVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_DIRTRAINVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_DIRTRAIN*)pValue);
    return 1;
}

int get_Q_DIRTRAIN_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_DIRTRAIN_values, 6, pfnStrAppend, pData);
}

int set_Q_DIRTRAIN_default_value(void *pValue)
{
    *(Q_DIRTRAIN*)pValue = Q_DIRTRAIN_Reverse;
    return 1;
}

int check_Q_DIRTRAIN_string(const char *str, char **endptr)
{
    static Q_DIRTRAIN rTemp;
    return string_to_Q_DIRTRAIN(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_DIRTRAIN_Utils = {
    Q_DIRTRAIN_to_string,
    check_Q_DIRTRAIN_string,
    string_to_Q_DIRTRAIN,
    is_Q_DIRTRAIN_double_convertion_allowed,
    Q_DIRTRAIN_to_double,
    compare_Q_DIRTRAIN,
    get_Q_DIRTRAIN_signature,
    set_Q_DIRTRAIN_default_value,
    sizeof(Q_DIRTRAIN)
};

/****************************************************************
 ** NID_ENGINE 
 ****************************************************************/

struct SimTypeVTable *pSimNID_ENGINEVTable;

int NID_ENGINE_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_ENGINEVTable != NULL
        && pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_ENGINEVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_ENGINE(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_ENGINEVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_ENGINEVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_ENGINE_double_convertion_allowed()
{
    if (pSimNID_ENGINEVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_ENGINEVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_ENGINE(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_ENGINEVTable != NULL
        && pSimNID_ENGINEVTable->m_version >= Scv612
        && pSimNID_ENGINEVTable->m_pfnCompare != NULL) {
        if (pSimNID_ENGINEVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_ENGINEVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_ENGINEVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_ENGINE_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_ENGINEVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_ENGINEVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_ENGINE_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_ENGINE_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_ENGINE_string(const char *str, char **endptr)
{
    static NID_ENGINE rTemp;
    return string_to_NID_ENGINE(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_ENGINE_Utils = {
    NID_ENGINE_to_string,
    check_NID_ENGINE_string,
    string_to_NID_ENGINE,
    is_NID_ENGINE_double_convertion_allowed,
    NID_ENGINE_to_double,
    compare_NID_ENGINE,
    get_NID_ENGINE_signature,
    set_NID_ENGINE_default_value,
    sizeof(NID_ENGINE)
};

/****************************************************************
 ** NID_OPERATIONAL 
 ****************************************************************/

struct SimTypeVTable *pSimNID_OPERATIONALVTable;

int NID_OPERATIONAL_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_OPERATIONALVTable != NULL
        && pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_OPERATIONALVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_OPERATIONAL(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_OPERATIONALVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_OPERATIONALVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_OPERATIONAL_double_convertion_allowed()
{
    if (pSimNID_OPERATIONALVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_OPERATIONALVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_OPERATIONAL(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_OPERATIONALVTable != NULL
        && pSimNID_OPERATIONALVTable->m_version >= Scv612
        && pSimNID_OPERATIONALVTable->m_pfnCompare != NULL) {
        if (pSimNID_OPERATIONALVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_OPERATIONALVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_OPERATIONALVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_OPERATIONAL_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_OPERATIONALVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_OPERATIONALVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_OPERATIONAL_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_OPERATIONAL_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_OPERATIONAL_string(const char *str, char **endptr)
{
    static NID_OPERATIONAL rTemp;
    return string_to_NID_OPERATIONAL(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_OPERATIONAL_Utils = {
    NID_OPERATIONAL_to_string,
    check_NID_OPERATIONAL_string,
    string_to_NID_OPERATIONAL,
    is_NID_OPERATIONAL_double_convertion_allowed,
    NID_OPERATIONAL_to_double,
    compare_NID_OPERATIONAL,
    get_NID_OPERATIONAL_signature,
    set_NID_OPERATIONAL_default_value,
    sizeof(NID_OPERATIONAL)
};

/****************************************************************
 ** L_TRAIN 
 ****************************************************************/

struct SimTypeVTable *pSimL_TRAINVTable;

int L_TRAIN_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimL_TRAINVTable != NULL
        && pSimL_TRAINVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimL_TRAINVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_L_TRAIN(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimL_TRAINVTable != NULL) {
        nRet=string_to_VTable(str, pSimL_TRAINVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_L_TRAIN_double_convertion_allowed()
{
    if (pSimL_TRAINVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimL_TRAINVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_L_TRAIN(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimL_TRAINVTable != NULL
        && pSimL_TRAINVTable->m_version >= Scv612
        && pSimL_TRAINVTable->m_pfnCompare != NULL) {
        if (pSimL_TRAINVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimL_TRAINVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimL_TRAINVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int L_TRAIN_to_double(const void *pValue, double *nRetValue)
{
    if (pSimL_TRAINVTable != NULL) {
        return VTable_to_double(pValue, pSimL_TRAINVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_L_TRAIN_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_L_TRAIN_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_L_TRAIN_string(const char *str, char **endptr)
{
    static L_TRAIN rTemp;
    return string_to_L_TRAIN(str, &rTemp, endptr);
}

SimTypeUtils _Type_L_TRAIN_Utils = {
    L_TRAIN_to_string,
    check_L_TRAIN_string,
    string_to_L_TRAIN,
    is_L_TRAIN_double_convertion_allowed,
    L_TRAIN_to_double,
    compare_L_TRAIN,
    get_L_TRAIN_signature,
    set_L_TRAIN_default_value,
    sizeof(L_TRAIN)
};

/****************************************************************
 ** Q_NVLOCACC 
 ****************************************************************/

struct SimTypeVTable *pSimQ_NVLOCACCVTable;

int Q_NVLOCACC_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_NVLOCACCVTable != NULL
        && pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_NVLOCACCVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_Q_NVLOCACC(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_NVLOCACCVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_NVLOCACCVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_Q_NVLOCACC_double_convertion_allowed()
{
    if (pSimQ_NVLOCACCVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_NVLOCACCVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_Q_NVLOCACC(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_NVLOCACCVTable != NULL
        && pSimQ_NVLOCACCVTable->m_version >= Scv612
        && pSimQ_NVLOCACCVTable->m_pfnCompare != NULL) {
        if (pSimQ_NVLOCACCVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_NVLOCACCVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_NVLOCACCVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_NVLOCACC_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_NVLOCACCVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_NVLOCACCVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_Q_NVLOCACC_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_Q_NVLOCACC_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_Q_NVLOCACC_string(const char *str, char **endptr)
{
    static Q_NVLOCACC rTemp;
    return string_to_Q_NVLOCACC(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_NVLOCACC_Utils = {
    Q_NVLOCACC_to_string,
    check_Q_NVLOCACC_string,
    string_to_Q_NVLOCACC,
    is_Q_NVLOCACC_double_convertion_allowed,
    Q_NVLOCACC_to_double,
    compare_Q_NVLOCACC,
    get_Q_NVLOCACC_signature,
    set_Q_NVLOCACC_default_value,
    sizeof(Q_NVLOCACC)
};

/****************************************************************
 ** NID_PRVLRBG 
 ****************************************************************/

struct SimTypeVTable *pSimNID_PRVLRBGVTable;

int NID_PRVLRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimNID_PRVLRBGVTable != NULL
        && pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimNID_PRVLRBGVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_NID_PRVLRBG(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimNID_PRVLRBGVTable != NULL) {
        nRet=string_to_VTable(str, pSimNID_PRVLRBGVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_NID_PRVLRBG_double_convertion_allowed()
{
    if (pSimNID_PRVLRBGVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimNID_PRVLRBGVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_NID_PRVLRBG(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimNID_PRVLRBGVTable != NULL
        && pSimNID_PRVLRBGVTable->m_version >= Scv612
        && pSimNID_PRVLRBGVTable->m_pfnCompare != NULL) {
        if (pSimNID_PRVLRBGVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimNID_PRVLRBGVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimNID_PRVLRBGVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int NID_PRVLRBG_to_double(const void *pValue, double *nRetValue)
{
    if (pSimNID_PRVLRBGVTable != NULL) {
        return VTable_to_double(pValue, pSimNID_PRVLRBGVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_NID_PRVLRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_NID_PRVLRBG_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_NID_PRVLRBG_string(const char *str, char **endptr)
{
    static NID_PRVLRBG rTemp;
    return string_to_NID_PRVLRBG(str, &rTemp, endptr);
}

SimTypeUtils _Type_NID_PRVLRBG_Utils = {
    NID_PRVLRBG_to_string,
    check_NID_PRVLRBG_string,
    string_to_NID_PRVLRBG,
    is_NID_PRVLRBG_double_convertion_allowed,
    NID_PRVLRBG_to_double,
    compare_NID_PRVLRBG,
    get_NID_PRVLRBG_signature,
    set_NID_PRVLRBG_default_value,
    sizeof(NID_PRVLRBG)
};

/****************************************************************
 ** Q_DLRBG 
 ****************************************************************/

struct SimTypeVTable *pSimQ_DLRBGVTable;

static SimEnumValUtils Q_DLRBG_values[] = {
    { "Q_DLRBG_Reverse", Q_DLRBG_Reverse},
    { "Q_DLRBG_Reverse", Q_DLRBG_Reverse},
    { "Q_DLRBG_Nominal", Q_DLRBG_Nominal},
    { "Q_DLRBG_Nominal", Q_DLRBG_Nominal},
    { "Q_DLRBG_Unknown", Q_DLRBG_Unknown},
    { "Q_DLRBG_Unknown", Q_DLRBG_Unknown},
};

int Q_DLRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimQ_DLRBGVTable != NULL
        && pSimQ_DLRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimQ_DLRBGVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(Q_DLRBG*)pValue, Q_DLRBG_values, 6, pfnStrAppend, pData);
}

int string_to_Q_DLRBG(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimQ_DLRBGVTable != NULL) {
        nRet=string_to_VTable(str, pSimQ_DLRBGVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, Q_DLRBG_values, 6, endptr);
        if (pValue != NULL && nRet != 0)
            *(Q_DLRBG*)pValue = nTemp;
    }
    return nRet;
}

int is_Q_DLRBG_double_convertion_allowed()
{
    if (pSimQ_DLRBGVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimQ_DLRBGVTable);
    }
    return 1;
}

void compare_Q_DLRBG(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimQ_DLRBGVTable != NULL
        && pSimQ_DLRBGVTable->m_version >= Scv612
        && pSimQ_DLRBGVTable->m_pfnCompare != NULL) {
        if (pSimQ_DLRBGVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimQ_DLRBGVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimQ_DLRBGVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(Q_DLRBG*)pValue1), (int)(*(Q_DLRBG*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Q_DLRBG_to_double(const void *pValue, double *nRetValue)
{
    if (pSimQ_DLRBGVTable != NULL) {
        return VTable_to_double(pValue, pSimQ_DLRBGVTable, nRetValue);
    }
    *nRetValue = (double)*((Q_DLRBG*)pValue);
    return 1;
}

int get_Q_DLRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(Q_DLRBG_values, 6, pfnStrAppend, pData);
}

int set_Q_DLRBG_default_value(void *pValue)
{
    *(Q_DLRBG*)pValue = Q_DLRBG_Reverse;
    return 1;
}

int check_Q_DLRBG_string(const char *str, char **endptr)
{
    static Q_DLRBG rTemp;
    return string_to_Q_DLRBG(str, &rTemp, endptr);
}

SimTypeUtils _Type_Q_DLRBG_Utils = {
    Q_DLRBG_to_string,
    check_Q_DLRBG_string,
    string_to_Q_DLRBG,
    is_Q_DLRBG_double_convertion_allowed,
    Q_DLRBG_to_double,
    compare_Q_DLRBG,
    get_Q_DLRBG_signature,
    set_Q_DLRBG_default_value,
    sizeof(Q_DLRBG)
};

/****************************************************************
 ** odometryFactors_T_ctp_t_pck_t_engine 
 ****************************************************************/

struct SimTypeVTable *pSimodometryFactors_T_ctp_t_pck_t_engineVTable;

int odometryFactors_T_ctp_t_pck_t_engine_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != NULL
        && pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5756_to_string(pValue, pfnStrAppend, pData);
}

int string_to_odometryFactors_T_ctp_t_pck_t_engine(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != NULL) {
        nRet=string_to_VTable(str, pSimodometryFactors_T_ctp_t_pck_t_engineVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5756(str, pValue, endptr);
    }
    return nRet;
}

int is_odometryFactors_T_ctp_t_pck_t_engine_double_convertion_allowed()
{
    if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimodometryFactors_T_ctp_t_pck_t_engineVTable);
    }
    return is_struct__5756_double_convertion_allowed();
}

void compare_odometryFactors_T_ctp_t_pck_t_engine(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != NULL
        && pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_version >= Scv612
        && pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnCompare != NULL) {
        if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5756(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int odometryFactors_T_ctp_t_pck_t_engine_to_double(const void *pValue, double *nRetValue)
{
    if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != NULL) {
        return VTable_to_double(pValue, pSimodometryFactors_T_ctp_t_pck_t_engineVTable, nRetValue);
    }
    return struct__5756_to_double(pValue, nRetValue);
}

int get_odometryFactors_T_ctp_t_pck_t_engine_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5756_signature(pfnStrAppend, pData);
}

int set_odometryFactors_T_ctp_t_pck_t_engine_default_value(void *pValue)
{
    return set_struct__5756_default_value(pValue);
}

int check_odometryFactors_T_ctp_t_pck_t_engine_string(const char *str, char **endptr)
{
    static odometryFactors_T_ctp_t_pck_t_engine rTemp;
    return string_to_odometryFactors_T_ctp_t_pck_t_engine(str, &rTemp, endptr);
}

SimTypeUtils _Type_odometryFactors_T_ctp_t_pck_t_engine_Utils = {
    odometryFactors_T_ctp_t_pck_t_engine_to_string,
    check_odometryFactors_T_ctp_t_pck_t_engine_string,
    string_to_odometryFactors_T_ctp_t_pck_t_engine,
    is_odometryFactors_T_ctp_t_pck_t_engine_double_convertion_allowed,
    odometryFactors_T_ctp_t_pck_t_engine_to_double,
    compare_odometryFactors_T_ctp_t_pck_t_engine,
    get_odometryFactors_T_ctp_t_pck_t_engine_signature,
    set_odometryFactors_T_ctp_t_pck_t_engine_default_value,
    sizeof(odometryFactors_T_ctp_t_pck_t_engine)
};

/****************************************************************
 ** genPassedBG_T_ctp_t_pck_t_engine 
 ****************************************************************/

struct SimTypeVTable *pSimgenPassedBG_T_ctp_t_pck_t_engineVTable;

int genPassedBG_T_ctp_t_pck_t_engine_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != NULL
        && pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5748_to_string(pValue, pfnStrAppend, pData);
}

int string_to_genPassedBG_T_ctp_t_pck_t_engine(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != NULL) {
        nRet=string_to_VTable(str, pSimgenPassedBG_T_ctp_t_pck_t_engineVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5748(str, pValue, endptr);
    }
    return nRet;
}

int is_genPassedBG_T_ctp_t_pck_t_engine_double_convertion_allowed()
{
    if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimgenPassedBG_T_ctp_t_pck_t_engineVTable);
    }
    return is_struct__5748_double_convertion_allowed();
}

void compare_genPassedBG_T_ctp_t_pck_t_engine(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != NULL
        && pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_version >= Scv612
        && pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnCompare != NULL) {
        if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5748(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int genPassedBG_T_ctp_t_pck_t_engine_to_double(const void *pValue, double *nRetValue)
{
    if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != NULL) {
        return VTable_to_double(pValue, pSimgenPassedBG_T_ctp_t_pck_t_engineVTable, nRetValue);
    }
    return struct__5748_to_double(pValue, nRetValue);
}

int get_genPassedBG_T_ctp_t_pck_t_engine_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5748_signature(pfnStrAppend, pData);
}

int set_genPassedBG_T_ctp_t_pck_t_engine_default_value(void *pValue)
{
    return set_struct__5748_default_value(pValue);
}

int check_genPassedBG_T_ctp_t_pck_t_engine_string(const char *str, char **endptr)
{
    static genPassedBG_T_ctp_t_pck_t_engine rTemp;
    return string_to_genPassedBG_T_ctp_t_pck_t_engine(str, &rTemp, endptr);
}

SimTypeUtils _Type_genPassedBG_T_ctp_t_pck_t_engine_Utils = {
    genPassedBG_T_ctp_t_pck_t_engine_to_string,
    check_genPassedBG_T_ctp_t_pck_t_engine_string,
    string_to_genPassedBG_T_ctp_t_pck_t_engine,
    is_genPassedBG_T_ctp_t_pck_t_engine_double_convertion_allowed,
    genPassedBG_T_ctp_t_pck_t_engine_to_double,
    compare_genPassedBG_T_ctp_t_pck_t_engine,
    get_genPassedBG_T_ctp_t_pck_t_engine_signature,
    set_genPassedBG_T_ctp_t_pck_t_engine_default_value,
    sizeof(genPassedBG_T_ctp_t_pck_t_engine)
};

/****************************************************************
 ** genPassedBGs_T_ctp_t_pck_t_engine 
 ****************************************************************/

struct SimTypeVTable *pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable;

int genPassedBGs_T_ctp_t_pck_t_engine_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != NULL
        && pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptString, pValue), pData);
    }
    return array__5753_to_string(pValue, pfnStrAppend, pData);
}

int string_to_genPassedBGs_T_ctp_t_pck_t_engine(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != NULL) {
        nRet=string_to_VTable(str, pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_array__5753(str, pValue, endptr);
    }
    return nRet;
}

int is_genPassedBGs_T_ctp_t_pck_t_engine_double_convertion_allowed()
{
    if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable);
    }
    return is_array__5753_double_convertion_allowed();
}

void compare_genPassedBGs_T_ctp_t_pck_t_engine(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != NULL
        && pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_version >= Scv612
        && pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnCompare != NULL) {
        if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_array__5753(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int genPassedBGs_T_ctp_t_pck_t_engine_to_double(const void *pValue, double *nRetValue)
{
    if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != NULL) {
        return VTable_to_double(pValue, pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable, nRetValue);
    }
    return array__5753_to_double(pValue, nRetValue);
}

int get_genPassedBGs_T_ctp_t_pck_t_engine_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_array__5753_signature(pfnStrAppend, pData);
}

int set_genPassedBGs_T_ctp_t_pck_t_engine_default_value(void *pValue)
{
    return set_array__5753_default_value(pValue);
}

int check_genPassedBGs_T_ctp_t_pck_t_engine_string(const char *str, char **endptr)
{
    static genPassedBGs_T_ctp_t_pck_t_engine rTemp;
    return string_to_genPassedBGs_T_ctp_t_pck_t_engine(str, &rTemp, endptr);
}

SimTypeUtils _Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils = {
    genPassedBGs_T_ctp_t_pck_t_engine_to_string,
    check_genPassedBGs_T_ctp_t_pck_t_engine_string,
    string_to_genPassedBGs_T_ctp_t_pck_t_engine,
    is_genPassedBGs_T_ctp_t_pck_t_engine_double_convertion_allowed,
    genPassedBGs_T_ctp_t_pck_t_engine_to_double,
    compare_genPassedBGs_T_ctp_t_pck_t_engine,
    get_genPassedBGs_T_ctp_t_pck_t_engine_signature,
    set_genPassedBGs_T_ctp_t_pck_t_engine_default_value,
    sizeof(genPassedBGs_T_ctp_t_pck_t_engine)
};

/****************************************************************
 ** positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable;

int positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != NULL
        && pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5743_to_string(pValue, pfnStrAppend, pData);
}

int string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5743(str, pValue, endptr);
    }
    return nRet;
}

int is_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_double_convertion_allowed()
{
    if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable);
    }
    return is_struct__5743_double_convertion_allowed();
}

void compare_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != NULL
        && pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_version >= Scv612
        && pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnCompare != NULL) {
        if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5743(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable, nRetValue);
    }
    return struct__5743_to_double(pValue, nRetValue);
}

int get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5743_signature(pfnStrAppend, pData);
}

int set_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_default_value(void *pValue)
{
    return set_struct__5743_default_value(pValue);
}

int check_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_string(const char *str, char **endptr)
{
    static positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg rTemp;
    return string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils = {
    positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_string,
    check_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_string,
    string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg,
    is_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_double_convertion_allowed,
    positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_double,
    compare_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg,
    get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_signature,
    set_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_default_value,
    sizeof(positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg)
};

/****************************************************************
 ** BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable;

int BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL
        && pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5714_to_string(pValue, pfnStrAppend, pData);
}

int string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5714(str, pValue, endptr);
    }
    return nRet;
}

int is_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_double_convertion_allowed()
{
    if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable);
    }
    return is_struct__5714_double_convertion_allowed();
}

void compare_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL
        && pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_version >= Scv612
        && pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnCompare != NULL) {
        if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5714(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable, nRetValue);
    }
    return struct__5714_to_double(pValue, nRetValue);
}

int get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5714_signature(pfnStrAppend, pData);
}

int set_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_default_value(void *pValue)
{
    return set_struct__5714_default_value(pValue);
}

int check_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char *str, char **endptr)
{
    static BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg rTemp;
    return string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils = {
    BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string,
    check_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string,
    string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg,
    is_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_double_convertion_allowed,
    BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double,
    compare_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg,
    get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature,
    set_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_default_value,
    sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg)
};

/****************************************************************
 ** BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable;

int BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL
        && pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5708_to_string(pValue, pfnStrAppend, pData);
}

int string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5708(str, pValue, endptr);
    }
    return nRet;
}

int is_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_double_convertion_allowed()
{
    if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable);
    }
    return is_struct__5708_double_convertion_allowed();
}

void compare_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL
        && pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_version >= Scv612
        && pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnCompare != NULL) {
        if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5708(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable, nRetValue);
    }
    return struct__5708_to_double(pValue, nRetValue);
}

int get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5708_signature(pfnStrAppend, pData);
}

int set_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_default_value(void *pValue)
{
    return set_struct__5708_default_value(pValue);
}

int check_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char *str, char **endptr)
{
    static BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg rTemp;
    return string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils = {
    BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string,
    check_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string,
    string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg,
    is_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_double_convertion_allowed,
    BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double,
    compare_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg,
    get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature,
    set_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_default_value,
    sizeof(BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg)
};

/****************************************************************
 ** refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable;

int refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL
        && pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5732_to_string(pValue, pfnStrAppend, pData);
}

int string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5732(str, pValue, endptr);
    }
    return nRet;
}

int is_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_double_convertion_allowed()
{
    if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable);
    }
    return is_struct__5732_double_convertion_allowed();
}

void compare_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL
        && pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_version >= Scv612
        && pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare != NULL) {
        if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5732(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable, nRetValue);
    }
    return struct__5732_to_double(pValue, nRetValue);
}

int get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5732_signature(pfnStrAppend, pData);
}

int set_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value(void *pValue)
{
    return set_struct__5732_default_value(pValue);
}

int check_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char *str, char **endptr)
{
    static refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
    return string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils = {
    refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string,
    check_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string,
    string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
    is_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_double_convertion_allowed,
    refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double,
    compare_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
    get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature,
    set_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value,
    sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg)
};

/****************************************************************
 ** linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable;

int linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL
        && pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5723_to_string(pValue, pfnStrAppend, pData);
}

int string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5723(str, pValue, endptr);
    }
    return nRet;
}

int is_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_double_convertion_allowed()
{
    if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable);
    }
    return is_struct__5723_double_convertion_allowed();
}

void compare_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL
        && pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_version >= Scv612
        && pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare != NULL) {
        if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5723(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable, nRetValue);
    }
    return struct__5723_to_double(pValue, nRetValue);
}

int get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5723_signature(pfnStrAppend, pData);
}

int set_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value(void *pValue)
{
    return set_struct__5723_default_value(pValue);
}

int check_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char *str, char **endptr)
{
    static linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
    return string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils = {
    linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string,
    check_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string,
    string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
    is_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_double_convertion_allowed,
    linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double,
    compare_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
    get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature,
    set_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value,
    sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg)
};

/****************************************************************
 ** linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable;

int linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL
        && pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return array__5729_to_string(pValue, pfnStrAppend, pData);
}

int string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_array__5729(str, pValue, endptr);
    }
    return nRet;
}

int is_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_double_convertion_allowed()
{
    if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable);
    }
    return is_array__5729_double_convertion_allowed();
}

void compare_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL
        && pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_version >= Scv612
        && pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare != NULL) {
        if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_array__5729(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable, nRetValue);
    }
    return array__5729_to_double(pValue, nRetValue);
}

int get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_array__5729_signature(pfnStrAppend, pData);
}

int set_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value(void *pValue)
{
    return set_array__5729_default_value(pValue);
}

int check_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char *str, char **endptr)
{
    static linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
    return string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils = {
    linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string,
    check_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string,
    string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
    is_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_double_convertion_allowed,
    linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double,
    compare_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
    get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature,
    set_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value,
    sizeof(linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg)
};

/****************************************************************
 ** trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable;

static SimEnumValUtils trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_values[] = {
    { "CalculateTrainPosition_Pkg::Pos_Pkg::trm_unknown", trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "trm_unknown", trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "CalculateTrainPosition_Pkg::Pos_Pkg::trm_standstill", trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "trm_standstill", trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "CalculateTrainPosition_Pkg::Pos_Pkg::trm_increasing", trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "trm_increasing", trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "CalculateTrainPosition_Pkg::Pos_Pkg::trm_decreasing", trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg},
    { "trm_decreasing", trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg},
};

int trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != NULL
        && pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return pConverter->m_pfnEnumToString(*(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue, trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_values, 8, pfnStrAppend, pData);
}

int string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        int nTemp = 0;
        nRet = pConverter->m_pfnStringToEnum(str, &nTemp, trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_values, 8, endptr);
        if (pValue != NULL && nRet != 0)
            *(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue = nTemp;
    }
    return nRet;
}

int is_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_double_convertion_allowed()
{
    if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable);
    }
    return 1;
}

void compare_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != NULL
        && pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_version >= Scv612
        && pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnCompare != NULL) {
        if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        unitResult = predef_compare_enum(pResult, (int)(*(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue1), (int)(*(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue2), pData);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable, nRetValue);
    }
    *nRetValue = (double)*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue);
    return 1;
}

int get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_enum_signature(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_values, 8, pfnStrAppend, pData);
}

int set_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_default_value(void *pValue)
{
    *(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue = trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg;
    return 1;
}

int check_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_string(const char *str, char **endptr)
{
    static trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg rTemp;
    return string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils = {
    trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_string,
    check_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_string,
    string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg,
    is_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_double_convertion_allowed,
    trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_double,
    compare_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg,
    get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_signature,
    set_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_default_value,
    sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg)
};

/****************************************************************
 ** passedBG_T_BG_Types_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimpassedBG_T_BG_Types_PkgVTable;

int passedBG_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimpassedBG_T_BG_Types_PkgVTable != NULL
        && pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimpassedBG_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5629_to_string(pValue, pfnStrAppend, pData);
}

int string_to_passedBG_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimpassedBG_T_BG_Types_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimpassedBG_T_BG_Types_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5629(str, pValue, endptr);
    }
    return nRet;
}

int is_passedBG_T_BG_Types_Pkg_double_convertion_allowed()
{
    if (pSimpassedBG_T_BG_Types_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimpassedBG_T_BG_Types_PkgVTable);
    }
    return is_struct__5629_double_convertion_allowed();
}

void compare_passedBG_T_BG_Types_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimpassedBG_T_BG_Types_PkgVTable != NULL
        && pSimpassedBG_T_BG_Types_PkgVTable->m_version >= Scv612
        && pSimpassedBG_T_BG_Types_PkgVTable->m_pfnCompare != NULL) {
        if (pSimpassedBG_T_BG_Types_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimpassedBG_T_BG_Types_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimpassedBG_T_BG_Types_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5629(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int passedBG_T_BG_Types_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimpassedBG_T_BG_Types_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimpassedBG_T_BG_Types_PkgVTable, nRetValue);
    }
    return struct__5629_to_double(pValue, nRetValue);
}

int get_passedBG_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5629_signature(pfnStrAppend, pData);
}

int set_passedBG_T_BG_Types_Pkg_default_value(void *pValue)
{
    return set_struct__5629_default_value(pValue);
}

int check_passedBG_T_BG_Types_Pkg_string(const char *str, char **endptr)
{
    static passedBG_T_BG_Types_Pkg rTemp;
    return string_to_passedBG_T_BG_Types_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_passedBG_T_BG_Types_Pkg_Utils = {
    passedBG_T_BG_Types_Pkg_to_string,
    check_passedBG_T_BG_Types_Pkg_string,
    string_to_passedBG_T_BG_Types_Pkg,
    is_passedBG_T_BG_Types_Pkg_double_convertion_allowed,
    passedBG_T_BG_Types_Pkg_to_double,
    compare_passedBG_T_BG_Types_Pkg,
    get_passedBG_T_BG_Types_Pkg_signature,
    set_passedBG_T_BG_Types_Pkg_default_value,
    sizeof(passedBG_T_BG_Types_Pkg)
};

/****************************************************************
 ** BG_Header_T_BG_Types_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimBG_Header_T_BG_Types_PkgVTable;

int BG_Header_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimBG_Header_T_BG_Types_PkgVTable != NULL
        && pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimBG_Header_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5618_to_string(pValue, pfnStrAppend, pData);
}

int string_to_BG_Header_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimBG_Header_T_BG_Types_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimBG_Header_T_BG_Types_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5618(str, pValue, endptr);
    }
    return nRet;
}

int is_BG_Header_T_BG_Types_Pkg_double_convertion_allowed()
{
    if (pSimBG_Header_T_BG_Types_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimBG_Header_T_BG_Types_PkgVTable);
    }
    return is_struct__5618_double_convertion_allowed();
}

void compare_BG_Header_T_BG_Types_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimBG_Header_T_BG_Types_PkgVTable != NULL
        && pSimBG_Header_T_BG_Types_PkgVTable->m_version >= Scv612
        && pSimBG_Header_T_BG_Types_PkgVTable->m_pfnCompare != NULL) {
        if (pSimBG_Header_T_BG_Types_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimBG_Header_T_BG_Types_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimBG_Header_T_BG_Types_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5618(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int BG_Header_T_BG_Types_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimBG_Header_T_BG_Types_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimBG_Header_T_BG_Types_PkgVTable, nRetValue);
    }
    return struct__5618_to_double(pValue, nRetValue);
}

int get_BG_Header_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5618_signature(pfnStrAppend, pData);
}

int set_BG_Header_T_BG_Types_Pkg_default_value(void *pValue)
{
    return set_struct__5618_default_value(pValue);
}

int check_BG_Header_T_BG_Types_Pkg_string(const char *str, char **endptr)
{
    static BG_Header_T_BG_Types_Pkg rTemp;
    return string_to_BG_Header_T_BG_Types_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_BG_Header_T_BG_Types_Pkg_Utils = {
    BG_Header_T_BG_Types_Pkg_to_string,
    check_BG_Header_T_BG_Types_Pkg_string,
    string_to_BG_Header_T_BG_Types_Pkg,
    is_BG_Header_T_BG_Types_Pkg_double_convertion_allowed,
    BG_Header_T_BG_Types_Pkg_to_double,
    compare_BG_Header_T_BG_Types_Pkg,
    get_BG_Header_T_BG_Types_Pkg_signature,
    set_BG_Header_T_BG_Types_Pkg_default_value,
    sizeof(BG_Header_T_BG_Types_Pkg)
};

/****************************************************************
 ** LinkedBGs_T_BG_Types_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimLinkedBGs_T_BG_Types_PkgVTable;

int LinkedBGs_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimLinkedBGs_T_BG_Types_PkgVTable != NULL
        && pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return array__5615_to_string(pValue, pfnStrAppend, pData);
}

int string_to_LinkedBGs_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimLinkedBGs_T_BG_Types_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimLinkedBGs_T_BG_Types_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_array__5615(str, pValue, endptr);
    }
    return nRet;
}

int is_LinkedBGs_T_BG_Types_Pkg_double_convertion_allowed()
{
    if (pSimLinkedBGs_T_BG_Types_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimLinkedBGs_T_BG_Types_PkgVTable);
    }
    return is_array__5615_double_convertion_allowed();
}

void compare_LinkedBGs_T_BG_Types_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimLinkedBGs_T_BG_Types_PkgVTable != NULL
        && pSimLinkedBGs_T_BG_Types_PkgVTable->m_version >= Scv612
        && pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnCompare != NULL) {
        if (pSimLinkedBGs_T_BG_Types_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_array__5615(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int LinkedBGs_T_BG_Types_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimLinkedBGs_T_BG_Types_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimLinkedBGs_T_BG_Types_PkgVTable, nRetValue);
    }
    return array__5615_to_double(pValue, nRetValue);
}

int get_LinkedBGs_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_array__5615_signature(pfnStrAppend, pData);
}

int set_LinkedBGs_T_BG_Types_Pkg_default_value(void *pValue)
{
    return set_array__5615_default_value(pValue);
}

int check_LinkedBGs_T_BG_Types_Pkg_string(const char *str, char **endptr)
{
    static LinkedBGs_T_BG_Types_Pkg rTemp;
    return string_to_LinkedBGs_T_BG_Types_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_LinkedBGs_T_BG_Types_Pkg_Utils = {
    LinkedBGs_T_BG_Types_Pkg_to_string,
    check_LinkedBGs_T_BG_Types_Pkg_string,
    string_to_LinkedBGs_T_BG_Types_Pkg,
    is_LinkedBGs_T_BG_Types_Pkg_double_convertion_allowed,
    LinkedBGs_T_BG_Types_Pkg_to_double,
    compare_LinkedBGs_T_BG_Types_Pkg,
    get_LinkedBGs_T_BG_Types_Pkg_signature,
    set_LinkedBGs_T_BG_Types_Pkg_default_value,
    sizeof(LinkedBGs_T_BG_Types_Pkg)
};

/****************************************************************
 ** LinkedBG_T_BG_Types_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimLinkedBG_T_BG_Types_PkgVTable;

int LinkedBG_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimLinkedBG_T_BG_Types_PkgVTable != NULL
        && pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5584_to_string(pValue, pfnStrAppend, pData);
}

int string_to_LinkedBG_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimLinkedBG_T_BG_Types_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimLinkedBG_T_BG_Types_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5584(str, pValue, endptr);
    }
    return nRet;
}

int is_LinkedBG_T_BG_Types_Pkg_double_convertion_allowed()
{
    if (pSimLinkedBG_T_BG_Types_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimLinkedBG_T_BG_Types_PkgVTable);
    }
    return is_struct__5584_double_convertion_allowed();
}

void compare_LinkedBG_T_BG_Types_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimLinkedBG_T_BG_Types_PkgVTable != NULL
        && pSimLinkedBG_T_BG_Types_PkgVTable->m_version >= Scv612
        && pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnCompare != NULL) {
        if (pSimLinkedBG_T_BG_Types_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5584(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int LinkedBG_T_BG_Types_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimLinkedBG_T_BG_Types_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimLinkedBG_T_BG_Types_PkgVTable, nRetValue);
    }
    return struct__5584_to_double(pValue, nRetValue);
}

int get_LinkedBG_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5584_signature(pfnStrAppend, pData);
}

int set_LinkedBG_T_BG_Types_Pkg_default_value(void *pValue)
{
    return set_struct__5584_default_value(pValue);
}

int check_LinkedBG_T_BG_Types_Pkg_string(const char *str, char **endptr)
{
    static LinkedBG_T_BG_Types_Pkg rTemp;
    return string_to_LinkedBG_T_BG_Types_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_LinkedBG_T_BG_Types_Pkg_Utils = {
    LinkedBG_T_BG_Types_Pkg_to_string,
    check_LinkedBG_T_BG_Types_Pkg_string,
    string_to_LinkedBG_T_BG_Types_Pkg,
    is_LinkedBG_T_BG_Types_Pkg_double_convertion_allowed,
    LinkedBG_T_BG_Types_Pkg_to_double,
    compare_LinkedBG_T_BG_Types_Pkg,
    get_LinkedBG_T_BG_Types_Pkg_signature,
    set_LinkedBG_T_BG_Types_Pkg_default_value,
    sizeof(LinkedBG_T_BG_Types_Pkg)
};

/****************************************************************
 ** T_internal_Type_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimT_internal_Type_Obu_BasicTypes_PkgVTable;

int T_internal_Type_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != NULL
        && pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_T_internal_Type_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimT_internal_Type_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_T_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimT_internal_Type_Obu_BasicTypes_PkgVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_T_internal_Type_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != NULL
        && pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int T_internal_Type_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimT_internal_Type_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_T_internal_Type_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_T_internal_Type_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_T_internal_Type_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static T_internal_Type_Obu_BasicTypes_Pkg rTemp;
    return string_to_T_internal_Type_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils = {
    T_internal_Type_Obu_BasicTypes_Pkg_to_string,
    check_T_internal_Type_Obu_BasicTypes_Pkg_string,
    string_to_T_internal_Type_Obu_BasicTypes_Pkg,
    is_T_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed,
    T_internal_Type_Obu_BasicTypes_Pkg_to_double,
    compare_T_internal_Type_Obu_BasicTypes_Pkg,
    get_T_internal_Type_Obu_BasicTypes_Pkg_signature,
    set_T_internal_Type_Obu_BasicTypes_Pkg_default_value,
    sizeof(T_internal_Type_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** OdometryLocations_T_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable;

int OdometryLocations_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5609_to_string(pValue, pfnStrAppend, pData);
}

int string_to_OdometryLocations_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5609(str, pValue, endptr);
    }
    return nRet;
}

int is_OdometryLocations_T_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable);
    }
    return is_struct__5609_double_convertion_allowed();
}

void compare_OdometryLocations_T_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5609(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int OdometryLocations_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return struct__5609_to_double(pValue, nRetValue);
}

int get_OdometryLocations_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5609_signature(pfnStrAppend, pData);
}

int set_OdometryLocations_T_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_struct__5609_default_value(pValue);
}

int check_OdometryLocations_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static OdometryLocations_T_Obu_BasicTypes_Pkg rTemp;
    return string_to_OdometryLocations_T_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils = {
    OdometryLocations_T_Obu_BasicTypes_Pkg_to_string,
    check_OdometryLocations_T_Obu_BasicTypes_Pkg_string,
    string_to_OdometryLocations_T_Obu_BasicTypes_Pkg,
    is_OdometryLocations_T_Obu_BasicTypes_Pkg_double_convertion_allowed,
    OdometryLocations_T_Obu_BasicTypes_Pkg_to_double,
    compare_OdometryLocations_T_Obu_BasicTypes_Pkg,
    get_OdometryLocations_T_Obu_BasicTypes_Pkg_signature,
    set_OdometryLocations_T_Obu_BasicTypes_Pkg_default_value,
    sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** L_internal_Type_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimL_internal_Type_Obu_BasicTypes_PkgVTable;

int L_internal_Type_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != NULL
        && pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_L_internal_Type_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimL_internal_Type_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_L_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimL_internal_Type_Obu_BasicTypes_PkgVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_L_internal_Type_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != NULL
        && pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int L_internal_Type_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimL_internal_Type_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_L_internal_Type_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_L_internal_Type_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_L_internal_Type_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static L_internal_Type_Obu_BasicTypes_Pkg rTemp;
    return string_to_L_internal_Type_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils = {
    L_internal_Type_Obu_BasicTypes_Pkg_to_string,
    check_L_internal_Type_Obu_BasicTypes_Pkg_string,
    string_to_L_internal_Type_Obu_BasicTypes_Pkg,
    is_L_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed,
    L_internal_Type_Obu_BasicTypes_Pkg_to_double,
    compare_L_internal_Type_Obu_BasicTypes_Pkg,
    get_L_internal_Type_Obu_BasicTypes_Pkg_signature,
    set_L_internal_Type_Obu_BasicTypes_Pkg_default_value,
    sizeof(L_internal_Type_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** LocWithInAcc_T_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable;

int LocWithInAcc_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5578_to_string(pValue, pfnStrAppend, pData);
}

int string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5578(str, pValue, endptr);
    }
    return nRet;
}

int is_LocWithInAcc_T_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable);
    }
    return is_struct__5578_double_convertion_allowed();
}

void compare_LocWithInAcc_T_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5578(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int LocWithInAcc_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return struct__5578_to_double(pValue, nRetValue);
}

int get_LocWithInAcc_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5578_signature(pfnStrAppend, pData);
}

int set_LocWithInAcc_T_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_struct__5578_default_value(pValue);
}

int check_LocWithInAcc_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static LocWithInAcc_T_Obu_BasicTypes_Pkg rTemp;
    return string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils = {
    LocWithInAcc_T_Obu_BasicTypes_Pkg_to_string,
    check_LocWithInAcc_T_Obu_BasicTypes_Pkg_string,
    string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg,
    is_LocWithInAcc_T_Obu_BasicTypes_Pkg_double_convertion_allowed,
    LocWithInAcc_T_Obu_BasicTypes_Pkg_to_double,
    compare_LocWithInAcc_T_Obu_BasicTypes_Pkg,
    get_LocWithInAcc_T_Obu_BasicTypes_Pkg_signature,
    set_LocWithInAcc_T_Obu_BasicTypes_Pkg_default_value,
    sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** Speed_T_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimSpeed_T_Obu_BasicTypes_PkgVTable;

int Speed_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return V_internal_Type_Obu_BasicTypes_Pkg_to_string(pValue, pfnStrAppend, pData);
}

int string_to_Speed_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimSpeed_T_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_V_internal_Type_Obu_BasicTypes_Pkg(str, pValue, endptr);
    }
    return nRet;
}

int is_Speed_T_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimSpeed_T_Obu_BasicTypes_PkgVTable);
    }
    return is_V_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed();
}

void compare_Speed_T_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_V_internal_Type_Obu_BasicTypes_Pkg(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Speed_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimSpeed_T_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return V_internal_Type_Obu_BasicTypes_Pkg_to_double(pValue, nRetValue);
}

int get_Speed_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_V_internal_Type_Obu_BasicTypes_Pkg_signature(pfnStrAppend, pData);
}

int set_Speed_T_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_V_internal_Type_Obu_BasicTypes_Pkg_default_value(pValue);
}

int check_Speed_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static Speed_T_Obu_BasicTypes_Pkg rTemp;
    return string_to_Speed_T_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_Speed_T_Obu_BasicTypes_Pkg_Utils = {
    Speed_T_Obu_BasicTypes_Pkg_to_string,
    check_Speed_T_Obu_BasicTypes_Pkg_string,
    string_to_Speed_T_Obu_BasicTypes_Pkg,
    is_Speed_T_Obu_BasicTypes_Pkg_double_convertion_allowed,
    Speed_T_Obu_BasicTypes_Pkg_to_double,
    compare_Speed_T_Obu_BasicTypes_Pkg,
    get_Speed_T_Obu_BasicTypes_Pkg_signature,
    set_Speed_T_Obu_BasicTypes_Pkg_default_value,
    sizeof(Speed_T_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** V_internal_Type_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimV_internal_Type_Obu_BasicTypes_PkgVTable;

int V_internal_Type_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != NULL
        && pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return kcg_int_to_string(pValue, pfnStrAppend, pData);
}

int string_to_V_internal_Type_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimV_internal_Type_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_kcg_int(str, pValue, endptr);
    }
    return nRet;
}

int is_V_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimV_internal_Type_Obu_BasicTypes_PkgVTable);
    }
    return is_kcg_int_double_convertion_allowed();
}

void compare_V_internal_Type_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != NULL
        && pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_kcg_int(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int V_internal_Type_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimV_internal_Type_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return kcg_int_to_double(pValue, nRetValue);
}

int get_V_internal_Type_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_kcg_int_signature(pfnStrAppend, pData);
}

int set_V_internal_Type_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_kcg_int_default_value(pValue);
}

int check_V_internal_Type_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static V_internal_Type_Obu_BasicTypes_Pkg rTemp;
    return string_to_V_internal_Type_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_V_internal_Type_Obu_BasicTypes_Pkg_Utils = {
    V_internal_Type_Obu_BasicTypes_Pkg_to_string,
    check_V_internal_Type_Obu_BasicTypes_Pkg_string,
    string_to_V_internal_Type_Obu_BasicTypes_Pkg,
    is_V_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed,
    V_internal_Type_Obu_BasicTypes_Pkg_to_double,
    compare_V_internal_Type_Obu_BasicTypes_Pkg,
    get_V_internal_Type_Obu_BasicTypes_Pkg_signature,
    set_V_internal_Type_Obu_BasicTypes_Pkg_default_value,
    sizeof(V_internal_Type_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** Location_T_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimLocation_T_Obu_BasicTypes_PkgVTable;

int Location_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimLocation_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return L_internal_Type_Obu_BasicTypes_Pkg_to_string(pValue, pfnStrAppend, pData);
}

int string_to_Location_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimLocation_T_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimLocation_T_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_L_internal_Type_Obu_BasicTypes_Pkg(str, pValue, endptr);
    }
    return nRet;
}

int is_Location_T_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimLocation_T_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimLocation_T_Obu_BasicTypes_PkgVTable);
    }
    return is_L_internal_Type_Obu_BasicTypes_Pkg_double_convertion_allowed();
}

void compare_Location_T_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimLocation_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimLocation_T_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimLocation_T_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_L_internal_Type_Obu_BasicTypes_Pkg(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int Location_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimLocation_T_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimLocation_T_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return L_internal_Type_Obu_BasicTypes_Pkg_to_double(pValue, nRetValue);
}

int get_Location_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_L_internal_Type_Obu_BasicTypes_Pkg_signature(pfnStrAppend, pData);
}

int set_Location_T_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_L_internal_Type_Obu_BasicTypes_Pkg_default_value(pValue);
}

int check_Location_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static Location_T_Obu_BasicTypes_Pkg rTemp;
    return string_to_Location_T_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_Location_T_Obu_BasicTypes_Pkg_Utils = {
    Location_T_Obu_BasicTypes_Pkg_to_string,
    check_Location_T_Obu_BasicTypes_Pkg_string,
    string_to_Location_T_Obu_BasicTypes_Pkg,
    is_Location_T_Obu_BasicTypes_Pkg_double_convertion_allowed,
    Location_T_Obu_BasicTypes_Pkg_to_double,
    compare_Location_T_Obu_BasicTypes_Pkg,
    get_Location_T_Obu_BasicTypes_Pkg_signature,
    set_Location_T_Obu_BasicTypes_Pkg_default_value,
    sizeof(Location_T_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** odometry_T_Obu_BasicTypes_Pkg 
 ****************************************************************/

struct SimTypeVTable *pSimodometry_T_Obu_BasicTypes_PkgVTable;

int odometry_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimodometry_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5701_to_string(pValue, pfnStrAppend, pData);
}

int string_to_odometry_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimodometry_T_Obu_BasicTypes_PkgVTable != NULL) {
        nRet=string_to_VTable(str, pSimodometry_T_Obu_BasicTypes_PkgVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5701(str, pValue, endptr);
    }
    return nRet;
}

int is_odometry_T_Obu_BasicTypes_Pkg_double_convertion_allowed()
{
    if (pSimodometry_T_Obu_BasicTypes_PkgVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimodometry_T_Obu_BasicTypes_PkgVTable);
    }
    return is_struct__5701_double_convertion_allowed();
}

void compare_odometry_T_Obu_BasicTypes_Pkg(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimodometry_T_Obu_BasicTypes_PkgVTable != NULL
        && pSimodometry_T_Obu_BasicTypes_PkgVTable->m_version >= Scv612
        && pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnCompare != NULL) {
        if (pSimodometry_T_Obu_BasicTypes_PkgVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5701(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int odometry_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nRetValue)
{
    if (pSimodometry_T_Obu_BasicTypes_PkgVTable != NULL) {
        return VTable_to_double(pValue, pSimodometry_T_Obu_BasicTypes_PkgVTable, nRetValue);
    }
    return struct__5701_to_double(pValue, nRetValue);
}

int get_odometry_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5701_signature(pfnStrAppend, pData);
}

int set_odometry_T_Obu_BasicTypes_Pkg_default_value(void *pValue)
{
    return set_struct__5701_default_value(pValue);
}

int check_odometry_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr)
{
    static odometry_T_Obu_BasicTypes_Pkg rTemp;
    return string_to_odometry_T_Obu_BasicTypes_Pkg(str, &rTemp, endptr);
}

SimTypeUtils _Type_odometry_T_Obu_BasicTypes_Pkg_Utils = {
    odometry_T_Obu_BasicTypes_Pkg_to_string,
    check_odometry_T_Obu_BasicTypes_Pkg_string,
    string_to_odometry_T_Obu_BasicTypes_Pkg,
    is_odometry_T_Obu_BasicTypes_Pkg_double_convertion_allowed,
    odometry_T_Obu_BasicTypes_Pkg_to_double,
    compare_odometry_T_Obu_BasicTypes_Pkg,
    get_odometry_T_Obu_BasicTypes_Pkg_signature,
    set_odometry_T_Obu_BasicTypes_Pkg_default_value,
    sizeof(odometry_T_Obu_BasicTypes_Pkg)
};

/****************************************************************
 ** positionedBG_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimpositionedBG_T_TrainPosition_Types_PckVTable;

int positionedBG_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != NULL
        && pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5642_to_string(pValue, pfnStrAppend, pData);
}

int string_to_positionedBG_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimpositionedBG_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5642(str, pValue, endptr);
    }
    return nRet;
}

int is_positionedBG_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimpositionedBG_T_TrainPosition_Types_PckVTable);
    }
    return is_struct__5642_double_convertion_allowed();
}

void compare_positionedBG_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != NULL
        && pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5642(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int positionedBG_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimpositionedBG_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return struct__5642_to_double(pValue, nRetValue);
}

int get_positionedBG_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5642_signature(pfnStrAppend, pData);
}

int set_positionedBG_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_struct__5642_default_value(pValue);
}

int check_positionedBG_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static positionedBG_T_TrainPosition_Types_Pck rTemp;
    return string_to_positionedBG_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_positionedBG_T_TrainPosition_Types_Pck_Utils = {
    positionedBG_T_TrainPosition_Types_Pck_to_string,
    check_positionedBG_T_TrainPosition_Types_Pck_string,
    string_to_positionedBG_T_TrainPosition_Types_Pck,
    is_positionedBG_T_TrainPosition_Types_Pck_double_convertion_allowed,
    positionedBG_T_TrainPosition_Types_Pck_to_double,
    compare_positionedBG_T_TrainPosition_Types_Pck,
    get_positionedBG_T_TrainPosition_Types_Pck_signature,
    set_positionedBG_T_TrainPosition_Types_Pck_default_value,
    sizeof(positionedBG_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** infoFromLinking_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSiminfoFromLinking_T_TrainPosition_Types_PckVTable;

int infoFromLinking_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != NULL
        && pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5600_to_string(pValue, pfnStrAppend, pData);
}

int string_to_infoFromLinking_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSiminfoFromLinking_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5600(str, pValue, endptr);
    }
    return nRet;
}

int is_infoFromLinking_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSiminfoFromLinking_T_TrainPosition_Types_PckVTable);
    }
    return is_struct__5600_double_convertion_allowed();
}

void compare_infoFromLinking_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != NULL
        && pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5600(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int infoFromLinking_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSiminfoFromLinking_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return struct__5600_to_double(pValue, nRetValue);
}

int get_infoFromLinking_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5600_signature(pfnStrAppend, pData);
}

int set_infoFromLinking_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_struct__5600_default_value(pValue);
}

int check_infoFromLinking_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static infoFromLinking_T_TrainPosition_Types_Pck rTemp;
    return string_to_infoFromLinking_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils = {
    infoFromLinking_T_TrainPosition_Types_Pck_to_string,
    check_infoFromLinking_T_TrainPosition_Types_Pck_string,
    string_to_infoFromLinking_T_TrainPosition_Types_Pck,
    is_infoFromLinking_T_TrainPosition_Types_Pck_double_convertion_allowed,
    infoFromLinking_T_TrainPosition_Types_Pck_to_double,
    compare_infoFromLinking_T_TrainPosition_Types_Pck,
    get_infoFromLinking_T_TrainPosition_Types_Pck_signature,
    set_infoFromLinking_T_TrainPosition_Types_Pck_default_value,
    sizeof(infoFromLinking_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** trainProperties_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimtrainProperties_T_TrainPosition_Types_PckVTable;

int trainProperties_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != NULL
        && pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5690_to_string(pValue, pfnStrAppend, pData);
}

int string_to_trainProperties_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimtrainProperties_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5690(str, pValue, endptr);
    }
    return nRet;
}

int is_trainProperties_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimtrainProperties_T_TrainPosition_Types_PckVTable);
    }
    return is_struct__5690_double_convertion_allowed();
}

void compare_trainProperties_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != NULL
        && pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5690(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int trainProperties_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimtrainProperties_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return struct__5690_to_double(pValue, nRetValue);
}

int get_trainProperties_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5690_signature(pfnStrAppend, pData);
}

int set_trainProperties_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_struct__5690_default_value(pValue);
}

int check_trainProperties_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static trainProperties_T_TrainPosition_Types_Pck rTemp;
    return string_to_trainProperties_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_trainProperties_T_TrainPosition_Types_Pck_Utils = {
    trainProperties_T_TrainPosition_Types_Pck_to_string,
    check_trainProperties_T_TrainPosition_Types_Pck_string,
    string_to_trainProperties_T_TrainPosition_Types_Pck,
    is_trainProperties_T_TrainPosition_Types_Pck_double_convertion_allowed,
    trainProperties_T_TrainPosition_Types_Pck_to_double,
    compare_trainProperties_T_TrainPosition_Types_Pck,
    get_trainProperties_T_TrainPosition_Types_Pck_signature,
    set_trainProperties_T_TrainPosition_Types_Pck_default_value,
    sizeof(trainProperties_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable;

int linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != NULL
        && pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return array__5740_to_string(pValue, pfnStrAppend, pData);
}

int string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_array__5740(str, pValue, endptr);
    }
    return nRet;
}

int is_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable);
    }
    return is_array__5740_double_convertion_allowed();
}

void compare_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != NULL
        && pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_array__5740(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return array__5740_to_double(pValue, nRetValue);
}

int get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_array__5740_signature(pfnStrAppend, pData);
}

int set_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_array__5740_default_value(pValue);
}

int check_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck rTemp;
    return string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils = {
    linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_string,
    check_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_string,
    string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck,
    is_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_double_convertion_allowed,
    linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_double,
    compare_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck,
    get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_signature,
    set_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_default_value,
    sizeof(linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** positionedBGs_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimpositionedBGs_T_TrainPosition_Types_PckVTable;

int positionedBGs_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != NULL
        && pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return array__5687_to_string(pValue, pfnStrAppend, pData);
}

int string_to_positionedBGs_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimpositionedBGs_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_array__5687(str, pValue, endptr);
    }
    return nRet;
}

int is_positionedBGs_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimpositionedBGs_T_TrainPosition_Types_PckVTable);
    }
    return is_array__5687_double_convertion_allowed();
}

void compare_positionedBGs_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != NULL
        && pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_array__5687(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int positionedBGs_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimpositionedBGs_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return array__5687_to_double(pValue, nRetValue);
}

int get_positionedBGs_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_array__5687_signature(pfnStrAppend, pData);
}

int set_positionedBGs_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_array__5687_default_value(pValue);
}

int check_positionedBGs_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static positionedBGs_T_TrainPosition_Types_Pck rTemp;
    return string_to_positionedBGs_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_positionedBGs_T_TrainPosition_Types_Pck_Utils = {
    positionedBGs_T_TrainPosition_Types_Pck_to_string,
    check_positionedBGs_T_TrainPosition_Types_Pck_string,
    string_to_positionedBGs_T_TrainPosition_Types_Pck,
    is_positionedBGs_T_TrainPosition_Types_Pck_double_convertion_allowed,
    positionedBGs_T_TrainPosition_Types_Pck_to_double,
    compare_positionedBGs_T_TrainPosition_Types_Pck,
    get_positionedBGs_T_TrainPosition_Types_Pck_signature,
    set_positionedBGs_T_TrainPosition_Types_Pck_default_value,
    sizeof(positionedBGs_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** positionErrors_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimpositionErrors_T_TrainPosition_Types_PckVTable;

int positionErrors_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != NULL
        && pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5681_to_string(pValue, pfnStrAppend, pData);
}

int string_to_positionErrors_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimpositionErrors_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5681(str, pValue, endptr);
    }
    return nRet;
}

int is_positionErrors_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimpositionErrors_T_TrainPosition_Types_PckVTable);
    }
    return is_struct__5681_double_convertion_allowed();
}

void compare_positionErrors_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != NULL
        && pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5681(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int positionErrors_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimpositionErrors_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return struct__5681_to_double(pValue, nRetValue);
}

int get_positionErrors_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5681_signature(pfnStrAppend, pData);
}

int set_positionErrors_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_struct__5681_default_value(pValue);
}

int check_positionErrors_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static positionErrors_T_TrainPosition_Types_Pck rTemp;
    return string_to_positionErrors_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_positionErrors_T_TrainPosition_Types_Pck_Utils = {
    positionErrors_T_TrainPosition_Types_Pck_to_string,
    check_positionErrors_T_TrainPosition_Types_Pck_string,
    string_to_positionErrors_T_TrainPosition_Types_Pck,
    is_positionErrors_T_TrainPosition_Types_Pck_double_convertion_allowed,
    positionErrors_T_TrainPosition_Types_Pck_to_double,
    compare_positionErrors_T_TrainPosition_Types_Pck,
    get_positionErrors_T_TrainPosition_Types_Pck_signature,
    set_positionErrors_T_TrainPosition_Types_Pck_default_value,
    sizeof(positionErrors_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** trainPosition_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimtrainPosition_T_TrainPosition_Types_PckVTable;

int trainPosition_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != NULL
        && pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5664_to_string(pValue, pfnStrAppend, pData);
}

int string_to_trainPosition_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimtrainPosition_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5664(str, pValue, endptr);
    }
    return nRet;
}

int is_trainPosition_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimtrainPosition_T_TrainPosition_Types_PckVTable);
    }
    return is_struct__5664_double_convertion_allowed();
}

void compare_trainPosition_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != NULL
        && pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5664(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int trainPosition_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimtrainPosition_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return struct__5664_to_double(pValue, nRetValue);
}

int get_trainPosition_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5664_signature(pfnStrAppend, pData);
}

int set_trainPosition_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_struct__5664_default_value(pValue);
}

int check_trainPosition_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static trainPosition_T_TrainPosition_Types_Pck rTemp;
    return string_to_trainPosition_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_trainPosition_T_TrainPosition_Types_Pck_Utils = {
    trainPosition_T_TrainPosition_Types_Pck_to_string,
    check_trainPosition_T_TrainPosition_Types_Pck_string,
    string_to_trainPosition_T_TrainPosition_Types_Pck,
    is_trainPosition_T_TrainPosition_Types_Pck_double_convertion_allowed,
    trainPosition_T_TrainPosition_Types_Pck_to_double,
    compare_trainPosition_T_TrainPosition_Types_Pck,
    get_trainPosition_T_TrainPosition_Types_Pck_signature,
    set_trainPosition_T_TrainPosition_Types_Pck_default_value,
    sizeof(trainPosition_T_TrainPosition_Types_Pck)
};

/****************************************************************
 ** trainPositionInfo_T_TrainPosition_Types_Pck 
 ****************************************************************/

struct SimTypeVTable *pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable;

int trainPositionInfo_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData)
{
    if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != NULL
        && pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
       return pfnStrAppend(*(char**)pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue), pData);
    }
    return struct__5653_to_string(pValue, pfnStrAppend, pData);
}

int string_to_trainPositionInfo_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr)
{
    int nRet=0;
    skip_whitespace(str);
    if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != NULL) {
        nRet=string_to_VTable(str, pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable, pValue, endptr);
    }
    if (nRet==0) {
        nRet = string_to_struct__5653(str, pValue, endptr);
    }
    return nRet;
}

int is_trainPositionInfo_T_TrainPosition_Types_Pck_double_convertion_allowed()
{
    if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != NULL) {
        return is_VTable_double_convertion_allowed(pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable);
    }
    return is_struct__5653_double_convertion_allowed();
}

void compare_trainPositionInfo_T_TrainPosition_Types_Pck(int *pResult, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths)
{
    int unitResult=0;
    /* Customized comparison */
    if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != NULL
        && pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_version >= Scv612
        && pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnCompare != NULL) {
        if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_version >= Scv65) {
            /*R15 and higher: VTable Compare function shall UPDATE *pResult global flag (*pResult|=SIM_CMP_RES_LT/...): */
            unitResult=pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnCompare(pResult, pValue1, pValue2);
        } else {
            /*Before R15: VTable Compare function shall SET *pResult global flag (*pResult=-1/1/0): */
            pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnCompare(&unitResult, pValue1, pValue2);
            updateCompareResult(unitResult, pResult);
        }
    } else {
        /* Predefined comparison */
        compare_struct__5653(pResult, pValue1, pValue2, pData, pszPath, pfnStrListAppend, pListErrPaths);
    }
    if (unitResult!=0 && pfnStrListAppend!=NULL && pszPath!=NULL && *pszPath!=0 && pListErrPaths!=NULL)
        pfnStrListAppend(pszPath, pListErrPaths);
}

int trainPositionInfo_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nRetValue)
{
    if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != NULL) {
        return VTable_to_double(pValue, pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable, nRetValue);
    }
    return struct__5653_to_double(pValue, nRetValue);
}

int get_trainPositionInfo_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData)
{
    return get_struct__5653_signature(pfnStrAppend, pData);
}

int set_trainPositionInfo_T_TrainPosition_Types_Pck_default_value(void *pValue)
{
    return set_struct__5653_default_value(pValue);
}

int check_trainPositionInfo_T_TrainPosition_Types_Pck_string(const char *str, char **endptr)
{
    static trainPositionInfo_T_TrainPosition_Types_Pck rTemp;
    return string_to_trainPositionInfo_T_TrainPosition_Types_Pck(str, &rTemp, endptr);
}

SimTypeUtils _Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils = {
    trainPositionInfo_T_TrainPosition_Types_Pck_to_string,
    check_trainPositionInfo_T_TrainPosition_Types_Pck_string,
    string_to_trainPositionInfo_T_TrainPosition_Types_Pck,
    is_trainPositionInfo_T_TrainPosition_Types_Pck_double_convertion_allowed,
    trainPositionInfo_T_TrainPosition_Types_Pck_to_double,
    compare_trainPositionInfo_T_TrainPosition_Types_Pck,
    get_trainPositionInfo_T_TrainPosition_Types_Pck_signature,
    set_trainPositionInfo_T_TrainPosition_Types_Pck_default_value,
    sizeof(trainPositionInfo_T_TrainPosition_Types_Pck)
};

#include "D:/programme/Esterel Technologies/SCADE R15.2/SCADE/lib/kcg_conv.c"
