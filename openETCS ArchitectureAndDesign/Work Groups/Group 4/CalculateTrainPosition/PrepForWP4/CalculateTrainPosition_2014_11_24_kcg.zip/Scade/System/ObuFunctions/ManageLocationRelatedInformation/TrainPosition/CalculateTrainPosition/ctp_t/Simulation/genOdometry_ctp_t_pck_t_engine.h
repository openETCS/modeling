/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _genOdometry_ctp_t_pck_t_engine_H_
#define _genOdometry_ctp_t_pck_t_engine_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::odometry */ odometry;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L17 */ _L17;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::_L27 */ _L27;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_int /* math::Max::_L1 */ _L1_1;
  kcg_int /* math::Max::_L2 */ _L2_1;
  kcg_bool /* math::Max::_L3 */ _L3_1;
  kcg_int /* math::Max::_L4 */ _L4_1;
  kcg_int /* math::Max::Ma_Output */ Ma_Output_1;
  kcg_int /* math::Max::I2 */ I2_1;
  kcg_int /* math::Max::I1 */ I1_1;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::_L1 */ _L1;
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::_L2 */ _L2;
  kcg_bool /* ctp_t_pck::t_engine::genOdometry::_L3 */ _L3;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::_L4 */ _L4;
  OdometryLocations_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::_L8 */ _L8;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L15 */ _L15;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L14 */ _L14;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L13 */ _L13;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L16 */ _L16;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L18 */ _L18;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L19 */ _L19;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L20 */ _L20;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L21 */ _L21;
  kcg_real /* ctp_t_pck::t_engine::genOdometry::_L22 */ _L22;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L23 */ _L23;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L24 */ _L24;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L25 */ _L25;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L26 */ _L26;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L28 */ _L28;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::_L29 */ _L29;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L30 */ _L30;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L31 */ _L31;
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L32 */ _L32;
  odometryFactors_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::genOdometry::_L33 */ _L33;
} outC_genOdometry_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::genOdometry */
extern void genOdometry_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genOdometry::trueLocation */L_internal_Type_Obu_BasicTypes_Pkg trueLocation,
  /* ctp_t_pck::t_engine::genOdometry::time */T_internal_Type_Obu_BasicTypes_Pkg time,
  /* ctp_t_pck::t_engine::genOdometry::odometryProperties */odometryFactors_T_ctp_t_pck_t_engine *odometryProperties,
  outC_genOdometry_ctp_t_pck_t_engine *outC);

extern void genOdometry_reset_ctp_t_pck_t_engine(
  outC_genOdometry_ctp_t_pck_t_engine *outC);

#endif /* _genOdometry_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genOdometry_ctp_t_pck_t_engine.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

