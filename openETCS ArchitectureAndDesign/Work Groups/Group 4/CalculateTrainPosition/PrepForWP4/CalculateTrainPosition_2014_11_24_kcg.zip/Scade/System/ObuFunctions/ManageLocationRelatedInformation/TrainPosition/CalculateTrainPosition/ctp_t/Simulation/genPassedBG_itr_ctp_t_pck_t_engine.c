/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genPassedBG_itr_ctp_t_pck_t_engine.h"

void genPassedBG_itr_reset_ctp_t_pck_t_engine(
  outC_genPassedBG_itr_ctp_t_pck_t_engine *outC)
{
}

/* ctp_t_pck::t_engine::genPassedBG_itr */
void genPassedBG_itr_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG_itr::accPassedBG */passedBG_T_BG_Types_Pkg *accPassedBG,
  /* ctp_t_pck::t_engine::genPassedBG_itr::trueLocation */L_internal_Type_Obu_BasicTypes_Pkg trueLocation,
  /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG_in */genPassedBG_T_ctp_t_pck_t_engine *passedBG_in,
  outC_genPassedBG_itr_ctp_t_pck_t_engine *outC)
{
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L10, passedBG_in);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L12, &outC->_L10.passedBG);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L11, accPassedBG);
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L1, passedBG_in);
  outC->_L2 = outC->_L1.passedBG.valid;
  outC->_L5 = outC->_L1.trueLocation;
  outC->_L4 = trueLocation;
  outC->_L6 = outC->_L5 == outC->_L4;
  outC->_L7 = outC->_L2 & outC->_L6;
  outC->_L9 = !outC->_L7;
  if (outC->_L7) {
    kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L8, &outC->_L12);
  }
  else {
    kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L8, &outC->_L11);
  }
  outC->_L3 = outC->_L2 & outC->_L9;
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->passedBG, &outC->_L8);
  outC->cont = outC->_L3;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_itr_ctp_t_pck_t_engine.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

