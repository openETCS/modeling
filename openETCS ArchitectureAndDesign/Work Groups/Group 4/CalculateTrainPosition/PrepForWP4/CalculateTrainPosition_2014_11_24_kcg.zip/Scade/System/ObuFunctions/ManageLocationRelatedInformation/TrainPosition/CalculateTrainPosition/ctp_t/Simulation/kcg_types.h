/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _KCG_TYPES_H_
#define _KCG_TYPES_H_

#define KCG_MAPW_CPY

#include "./user_macros.h"

#ifndef kcg_int
#define kcg_int kcg_int
typedef int kcg_int;
#endif /* kcg_int */

#ifndef kcg_bool
#define kcg_bool kcg_bool
typedef unsigned char kcg_bool;
#endif /* kcg_bool */

#ifndef kcg_real
#define kcg_real kcg_real
typedef double kcg_real;
#endif /* kcg_real */

#ifndef kcg_char
#define kcg_char kcg_char
typedef unsigned char kcg_char;
#endif /* kcg_char */

#ifndef kcg_false
#define kcg_false ((kcg_bool) 0)
#endif /* kcg_false */

#ifndef kcg_true
#define kcg_true ((kcg_bool) 1)
#endif /* kcg_true */

#ifndef kcg_assign
#include "kcg_assign.h"
#endif /* kcg_assign */

#ifndef kcg_assign_struct
#define kcg_assign_struct kcg_assign
#endif /* kcg_assign_struct */

#ifndef kcg_assign_array
#define kcg_assign_array kcg_assign
#endif /* kcg_assign_array */

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementDir_T */
typedef enum {
  trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg,
  trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg,
  trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg,
  trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg
} trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg;
/* Q_DLRBG */
typedef enum {
  Q_DLRBG_Reverse = 0,
  Q_DLRBG_Nominal = 1,
  Q_DLRBG_Unknown = 2
} Q_DLRBG;
/* Q_DIRLRBG */
typedef enum {
  Q_DIRLRBG_Reverse = 0,
  Q_DIRLRBG_Nominal = 1,
  Q_DIRLRBG_Unknown = 2
} Q_DIRLRBG;
/* Q_DIRTRAIN */
typedef enum {
  Q_DIRTRAIN_Reverse = 0,
  Q_DIRTRAIN_Nominal = 1,
  Q_DIRTRAIN_Unknown = 2
} Q_DIRTRAIN;
/* Q_UPDOWN */
typedef enum {
  Q_UPDOWN_Down_link_telegram = 0,
  Q_UPDOWN_Up_link_telegram = 1
} Q_UPDOWN;
/* M_VERSION */
typedef enum {
  M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS = 0,
  M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0 = 16,
  M_VERSION_Version_1_1_introduced_in_SRS_3_3_0 = 17,
  M_VERSION_Version_2_0_introduced_in_SRS_3_3_0 = 32
} M_VERSION;
/* Q_MEDIA */
typedef enum { Q_MEDIA_Balise = 0, Q_MEDIA_Loop = 1 } Q_MEDIA;
/* N_TOTAL */
typedef enum {
  N_TOTAL_1_balise_in_the_group = 0,
  N_TOTAL_2_balises_in_the_group = 1,
  N_TOTAL_3_balises_in_the_group = 2,
  N_TOTAL_4_balises_in_the_group = 3,
  N_TOTAL_5_balises_in_the_group = 4,
  N_TOTAL_6_balises_in_the_group = 5,
  N_TOTAL_7_balises_in_the_group = 6,
  N_TOTAL_8_balises_in_the_group = 7
} N_TOTAL;
/* Q_LINK */
typedef enum { Q_LINK_Unlinked = 0, Q_LINK_Linked = 1 } Q_LINK;
/* Q_DIR */
typedef enum {
  Q_DIR_Reverse = 0,
  Q_DIR_Nominal = 1,
  Q_DIR_Both_directions = 2
} Q_DIR;
/* Q_SCALE */
typedef enum {
  Q_SCALE_10_cm_scale = 0,
  Q_SCALE_1_m_scale = 1,
  Q_SCALE_10_m_scale = 2
} Q_SCALE;
/* Q_NEWCOUNTRY */
typedef enum {
  Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows = 0,
  Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows = 1
} Q_NEWCOUNTRY;
/* Q_LINKORIENTATION */
typedef enum {
  Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction = 0,
  Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction = 1
} Q_LINKORIENTATION;
/* Q_LINKREACTION */
typedef enum {
  Q_LINKREACTION_Train_trip = 0,
  Q_LINKREACTION_Apply_service_brake = 1,
  Q_LINKREACTION_No_Reaction = 2
} Q_LINKREACTION;
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */
typedef enum {
  SSM_TR_no_trans_SM1,
  SSM_TR_Unknown_1_SM1,
  SSM_TR_Unknown_2_SM1,
  SSM_TR_Unknown_3_SM1,
  SSM_TR_Decreasing_1_SM1,
  SSM_TR_Decreasing_2_SM1,
  SSM_TR_Increasing_1_SM1,
  SSM_TR_Increasing_2_SM1,
  SSM_TR_Standstill_1_SM1,
  SSM_TR_Standstill_2_SM1
} SSM_TR_SM1;
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */
typedef enum {
  SSM_st_Unknown_SM1,
  SSM_st_Decreasing_SM1,
  SSM_st_Increasing_SM1,
  SSM_st_Standstill_SM1
} SSM_ST_SM1;
/* M_MCOUNT */
typedef kcg_int M_MCOUNT;

/* NID_C */
typedef kcg_int NID_C;

/* NID_BG */
typedef kcg_int NID_BG;

/* NID_LRBG */
typedef kcg_int NID_LRBG;

/* NID_PACKET */
typedef kcg_int NID_PACKET;

/* L_PACKET */
typedef kcg_int L_PACKET;

/* D_LINK */
typedef kcg_int D_LINK;

/* Q_LOCACC */
typedef kcg_int Q_LOCACC;

/* NID_ENGINE */
typedef kcg_int NID_ENGINE;

/* NID_OPERATIONAL */
typedef kcg_int NID_OPERATIONAL;

/* L_TRAIN */
typedef kcg_int L_TRAIN;

/* Q_NVLOCACC */
typedef kcg_int Q_NVLOCACC;

/* NID_PRVLRBG */
typedef kcg_int NID_PRVLRBG;

/* Obu_BasicTypes_Pkg::T_internal_Type */
typedef kcg_int T_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::L_internal_Type */
typedef kcg_int L_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::Location_T */
typedef L_internal_Type_Obu_BasicTypes_Pkg Location_T_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::V_internal_Type */
typedef kcg_int V_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::Speed_T */
typedef V_internal_Type_Obu_BasicTypes_Pkg Speed_T_Obu_BasicTypes_Pkg;

typedef struct { kcg_int nominal; kcg_int d_min; kcg_int d_max; } struct__5578;

/* Obu_BasicTypes_Pkg::LocWithInAcc_T */
typedef struct__5578 LocWithInAcc_T_Obu_BasicTypes_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_int nid_LRBG;
  kcg_int nid_packet;
  Q_DIR q_dir;
  kcg_int l_packet;
  Q_SCALE q_scale;
  kcg_int d_link;
  Q_NEWCOUNTRY q_newcountry;
  kcg_int nid_c;
  kcg_int nid_bg;
  Q_LINKORIENTATION q_linkorientation;
  Q_LINKREACTION q_linkreaction;
  kcg_int q_locacc;
} struct__5584;

/* BG_Types_Pkg::LinkedBG_T */
typedef struct__5584 LinkedBG_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_int nid_bg_fromLinkingBG;
  kcg_int nid_c_fromLinkingBG;
  struct__5578 expectedLocation;
  struct__5578 d_link;
  struct__5584 linkingInfo;
} struct__5600;

/* TrainPosition_Types_Pck::infoFromLinking_T */
typedef struct__5600 infoFromLinking_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_int o_nominal;
  kcg_int o_min;
  kcg_int o_max;
} struct__5609;

/* Obu_BasicTypes_Pkg::OdometryLocations_T */
typedef struct__5609 OdometryLocations_T_Obu_BasicTypes_Pkg;

typedef struct__5584 array__5615[4];

/* BG_Types_Pkg::LinkedBGs_T */
typedef array__5615 LinkedBGs_T_BG_Types_Pkg;

typedef struct {
  Q_UPDOWN q_updown;
  M_VERSION m_version;
  Q_MEDIA q_media;
  N_TOTAL n_total;
  kcg_int m_mcount;
  kcg_int nid_c;
  kcg_int nid_bg;
  Q_LINK q_link;
} struct__5618;

/* BG_Types_Pkg::BG_Header_T */
typedef struct__5618 BG_Header_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_int timestamp;
  struct__5609 odometrystamp;
  struct__5578 BG_centerDetectionInaccuraccuracies;
  struct__5618 BG_Header;
  array__5615 linkedBGs;
  kcg_bool noCoordinateSystemHasBeenAssigned;
  Q_DIRLRBG trainOrientationToBG;
  Q_DIRTRAIN trainRunningDirectionToBG;
  kcg_int passingSpeed;
} struct__5629;

/* BG_Types_Pkg::passedBG_T */
typedef struct__5629 passedBG_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_int nid_c;
  kcg_int nid_bg;
  Q_LINK q_link;
  struct__5578 location;
  kcg_int seqNoOnTrack;
  struct__5600 infoFromLinking;
  struct__5629 infoFromPassing;
} struct__5642;

/* TrainPosition_Types_Pck::positionedBG_T */
typedef struct__5642 positionedBG_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPosition;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPositionDerivedFromLastLinkedBG;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPositionDerivedFromLastUnlinkedBG;
  positionedBG_T_TrainPosition_Types_Pck lastPassedLinkedBG;
  positionedBG_T_TrainPosition_Types_Pck lastPassedUnlinkedBG;
  Speed_T_Obu_BasicTypes_Pkg speed;
} struct__5653;

/* TrainPosition_Types_Pck::trainPositionInfo_T */
typedef struct__5653 trainPositionInfo_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
  kcg_bool trainPositionIsUnknown;
  kcg_bool noCoordinateSystemHasBeenAssigned;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPosition;
  Location_T_Obu_BasicTypes_Pkg estimatedFrontEndPosition;
  Location_T_Obu_BasicTypes_Pkg minSafeFrontEndPosition;
  Location_T_Obu_BasicTypes_Pkg maxSafeFrontEndPostion;
  NID_BG nid_LRBG;
  NID_PRVLRBG nid_PrvLRB;
  Q_DLRBG nominalOrReverseToLRBG;
  Q_DIRLRBG trainOrientationToLRBG;
  Q_DIRTRAIN trainRunningDirectionToLRBG;
  Speed_T_Obu_BasicTypes_Pkg speed;
} struct__5664;

/* TrainPosition_Types_Pck::trainPosition_T */
typedef struct__5664 trainPosition_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool outOfMemSpace;
  kcg_bool passedBG_notFoundWhereExpected;
  kcg_bool positionCalculation_inconsistent;
} struct__5681;

/* TrainPosition_Types_Pck::positionErrors_T */
typedef struct__5681 positionErrors_T_TrainPosition_Types_Pck;

typedef positionedBG_T_TrainPosition_Types_Pck array__5687[8];

/* TrainPosition_Types_Pck::positionedBGs_T */
typedef array__5687 positionedBGs_T_TrainPosition_Types_Pck;

typedef struct {
  NID_ENGINE nid_engine;
  NID_OPERATIONAL nid_operational;
  L_TRAIN l_train;
  LocWithInAcc_T_Obu_BasicTypes_Pkg d_baliseAntenna_2_frontend;
  LocWithInAcc_T_Obu_BasicTypes_Pkg d_frontend_2_rearend;
  Q_NVLOCACC locationAccuracy_NationalValue;
  LocWithInAcc_T_Obu_BasicTypes_Pkg locationAccuracy_DefaultValue;
  LocWithInAcc_T_Obu_BasicTypes_Pkg centerDetectionAcc_DefaultValue;
} struct__5690;

/* TrainPosition_Types_Pck::trainProperties_T */
typedef struct__5690 trainProperties_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
  OdometryLocations_T_Obu_BasicTypes_Pkg odo;
  Speed_T_Obu_BasicTypes_Pkg speed;
} struct__5701;

/* Obu_BasicTypes_Pkg::odometry_T */
typedef struct__5701 odometry_T_Obu_BasicTypes_Pkg;

typedef struct {
  kcg_int index;
  kcg_int noOfFoundBGs;
  kcg_bool BGFound;
} struct__5708;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::BG_find_T */
typedef struct__5708 BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

typedef struct {
  kcg_int unlinkedBGsCount;
  kcg_int linkedBGsCount;
  kcg_int totalBGsCount;
  kcg_int passedUnlinkedBGsCount;
  kcg_int passedLinkedBGsCount;
  kcg_int passedTotalBGsCount;
} struct__5714;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::BG_counters_T */
typedef struct__5714 BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

typedef struct {
  kcg_int previousLinkedBG_idx;
  kcg_int currentIndex;
  kcg_int subsequentLinkedBG_idx;
} struct__5723;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::linkedBG_index_T */
typedef struct__5723 linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg array__5729[8];

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::linkedBGs_indices_T */
typedef array__5729 linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef struct {
  positionedBG_T_TrainPosition_Types_Pck refBG;
  positionedBG_T_TrainPosition_Types_Pck prevLinkedBG;
  positionedBG_T_TrainPosition_Types_Pck prevUnlinkedBG;
  kcg_bool recalculate;
  LocWithInAcc_T_Obu_BasicTypes_Pkg sumOfBestDistances;
} struct__5732;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::refBGs_T */
typedef struct__5732 refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef positionedBG_T_TrainPosition_Types_Pck array__5740[4];

/* TrainPosition_Types_Pck::linkedBGs_asPositionedBGs_T */
typedef array__5740 linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck;

typedef struct {
  positionedBGs_T_TrainPosition_Types_Pck BGs;
  kcg_bool overrun;
} struct__5743;

/* CalculateTrainPosition_Pkg::positionedBGs_w_overrun_T */
typedef struct__5743 positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg;

typedef struct {
  L_internal_Type_Obu_BasicTypes_Pkg trueLocation;
  passedBG_T_BG_Types_Pkg passedBG;
} struct__5748;

/* ctp_t_pck::t_engine::genPassedBG_T */
typedef struct__5748 genPassedBG_T_ctp_t_pck_t_engine;

typedef genPassedBG_T_ctp_t_pck_t_engine array__5753[10];

/* ctp_t_pck::t_engine::genPassedBGs_T */
typedef array__5753 genPassedBGs_T_ctp_t_pck_t_engine;

typedef struct {
  kcg_real o_nominal;
  kcg_real o_min;
  kcg_real o_max;
} struct__5756;

/* ctp_t_pck::t_engine::odometryFactors_T */
typedef struct__5756 odometryFactors_T_ctp_t_pck_t_engine;

typedef trainProperties_T_TrainPosition_Types_Pck array__5762[4];

typedef kcg_int array_int_8[8];

typedef positionedBG_T_TrainPosition_Types_Pck array__5768[7];

typedef positionedBG_T_TrainPosition_Types_Pck array__5771[1];

typedef kcg_bool array_bool_8[8];

typedef trainProperties_T_TrainPosition_Types_Pck array__5777[8];

typedef positionedBGs_T_TrainPosition_Types_Pck array__5780[8];

typedef L_internal_Type_Obu_BasicTypes_Pkg array_int_10[10];

#ifndef kcg_copy_struct__5578
#define kcg_copy_struct__5578(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5578)))
#endif /* kcg_copy_struct__5578 */

#ifndef kcg_copy_struct__5584
#define kcg_copy_struct__5584(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5584)))
#endif /* kcg_copy_struct__5584 */

#ifndef kcg_copy_struct__5600
#define kcg_copy_struct__5600(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5600)))
#endif /* kcg_copy_struct__5600 */

#ifndef kcg_copy_struct__5609
#define kcg_copy_struct__5609(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5609)))
#endif /* kcg_copy_struct__5609 */

#ifndef kcg_copy_struct__5618
#define kcg_copy_struct__5618(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5618)))
#endif /* kcg_copy_struct__5618 */

#ifndef kcg_copy_struct__5629
#define kcg_copy_struct__5629(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5629)))
#endif /* kcg_copy_struct__5629 */

#ifndef kcg_copy_struct__5642
#define kcg_copy_struct__5642(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5642)))
#endif /* kcg_copy_struct__5642 */

#ifndef kcg_copy_struct__5653
#define kcg_copy_struct__5653(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5653)))
#endif /* kcg_copy_struct__5653 */

#ifndef kcg_copy_struct__5664
#define kcg_copy_struct__5664(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5664)))
#endif /* kcg_copy_struct__5664 */

#ifndef kcg_copy_struct__5681
#define kcg_copy_struct__5681(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5681)))
#endif /* kcg_copy_struct__5681 */

#ifndef kcg_copy_struct__5690
#define kcg_copy_struct__5690(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5690)))
#endif /* kcg_copy_struct__5690 */

#ifndef kcg_copy_struct__5701
#define kcg_copy_struct__5701(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5701)))
#endif /* kcg_copy_struct__5701 */

#ifndef kcg_copy_struct__5708
#define kcg_copy_struct__5708(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5708)))
#endif /* kcg_copy_struct__5708 */

#ifndef kcg_copy_struct__5714
#define kcg_copy_struct__5714(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5714)))
#endif /* kcg_copy_struct__5714 */

#ifndef kcg_copy_struct__5723
#define kcg_copy_struct__5723(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5723)))
#endif /* kcg_copy_struct__5723 */

#ifndef kcg_copy_struct__5732
#define kcg_copy_struct__5732(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5732)))
#endif /* kcg_copy_struct__5732 */

#ifndef kcg_copy_struct__5743
#define kcg_copy_struct__5743(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5743)))
#endif /* kcg_copy_struct__5743 */

#ifndef kcg_copy_struct__5748
#define kcg_copy_struct__5748(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5748)))
#endif /* kcg_copy_struct__5748 */

#ifndef kcg_copy_struct__5756
#define kcg_copy_struct__5756(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__5756)))
#endif /* kcg_copy_struct__5756 */

#ifndef kcg_copy_array__5615
#define kcg_copy_array__5615(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5615)))
#endif /* kcg_copy_array__5615 */

#ifndef kcg_copy_array__5687
#define kcg_copy_array__5687(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5687)))
#endif /* kcg_copy_array__5687 */

#ifndef kcg_copy_array__5729
#define kcg_copy_array__5729(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5729)))
#endif /* kcg_copy_array__5729 */

#ifndef kcg_copy_array__5740
#define kcg_copy_array__5740(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5740)))
#endif /* kcg_copy_array__5740 */

#ifndef kcg_copy_array__5753
#define kcg_copy_array__5753(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5753)))
#endif /* kcg_copy_array__5753 */

#ifndef kcg_copy_array__5762
#define kcg_copy_array__5762(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5762)))
#endif /* kcg_copy_array__5762 */

#ifndef kcg_copy_array_int_8
#define kcg_copy_array_int_8(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int_8)))
#endif /* kcg_copy_array_int_8 */

#ifndef kcg_copy_array__5768
#define kcg_copy_array__5768(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5768)))
#endif /* kcg_copy_array__5768 */

#ifndef kcg_copy_array__5771
#define kcg_copy_array__5771(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5771)))
#endif /* kcg_copy_array__5771 */

#ifndef kcg_copy_array_bool_8
#define kcg_copy_array_bool_8(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_bool_8)))
#endif /* kcg_copy_array_bool_8 */

#ifndef kcg_copy_array__5777
#define kcg_copy_array__5777(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5777)))
#endif /* kcg_copy_array__5777 */

#ifndef kcg_copy_array__5780
#define kcg_copy_array__5780(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__5780)))
#endif /* kcg_copy_array__5780 */

#ifndef kcg_copy_array_int_10
#define kcg_copy_array_int_10(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array_int_10)))
#endif /* kcg_copy_array_int_10 */

#ifndef kcg_comp_struct__5578
extern kcg_bool kcg_comp_struct__5578(
  struct__5578 *kcg_c1,
  struct__5578 *kcg_c2);
#endif /* kcg_comp_struct__5578 */

#ifndef kcg_comp_struct__5584
extern kcg_bool kcg_comp_struct__5584(
  struct__5584 *kcg_c1,
  struct__5584 *kcg_c2);
#endif /* kcg_comp_struct__5584 */

#ifndef kcg_comp_struct__5600
extern kcg_bool kcg_comp_struct__5600(
  struct__5600 *kcg_c1,
  struct__5600 *kcg_c2);
#endif /* kcg_comp_struct__5600 */

#ifndef kcg_comp_struct__5609
extern kcg_bool kcg_comp_struct__5609(
  struct__5609 *kcg_c1,
  struct__5609 *kcg_c2);
#endif /* kcg_comp_struct__5609 */

#ifndef kcg_comp_struct__5618
extern kcg_bool kcg_comp_struct__5618(
  struct__5618 *kcg_c1,
  struct__5618 *kcg_c2);
#endif /* kcg_comp_struct__5618 */

#ifndef kcg_comp_struct__5629
extern kcg_bool kcg_comp_struct__5629(
  struct__5629 *kcg_c1,
  struct__5629 *kcg_c2);
#endif /* kcg_comp_struct__5629 */

#ifndef kcg_comp_struct__5642
extern kcg_bool kcg_comp_struct__5642(
  struct__5642 *kcg_c1,
  struct__5642 *kcg_c2);
#endif /* kcg_comp_struct__5642 */

#ifndef kcg_comp_struct__5653
extern kcg_bool kcg_comp_struct__5653(
  struct__5653 *kcg_c1,
  struct__5653 *kcg_c2);
#endif /* kcg_comp_struct__5653 */

#ifndef kcg_comp_struct__5664
extern kcg_bool kcg_comp_struct__5664(
  struct__5664 *kcg_c1,
  struct__5664 *kcg_c2);
#endif /* kcg_comp_struct__5664 */

#ifndef kcg_comp_struct__5681
extern kcg_bool kcg_comp_struct__5681(
  struct__5681 *kcg_c1,
  struct__5681 *kcg_c2);
#endif /* kcg_comp_struct__5681 */

#ifndef kcg_comp_struct__5690
extern kcg_bool kcg_comp_struct__5690(
  struct__5690 *kcg_c1,
  struct__5690 *kcg_c2);
#endif /* kcg_comp_struct__5690 */

#ifndef kcg_comp_struct__5701
extern kcg_bool kcg_comp_struct__5701(
  struct__5701 *kcg_c1,
  struct__5701 *kcg_c2);
#endif /* kcg_comp_struct__5701 */

#ifndef kcg_comp_struct__5708
extern kcg_bool kcg_comp_struct__5708(
  struct__5708 *kcg_c1,
  struct__5708 *kcg_c2);
#endif /* kcg_comp_struct__5708 */

#ifndef kcg_comp_struct__5714
extern kcg_bool kcg_comp_struct__5714(
  struct__5714 *kcg_c1,
  struct__5714 *kcg_c2);
#endif /* kcg_comp_struct__5714 */

#ifndef kcg_comp_struct__5723
extern kcg_bool kcg_comp_struct__5723(
  struct__5723 *kcg_c1,
  struct__5723 *kcg_c2);
#endif /* kcg_comp_struct__5723 */

#ifndef kcg_comp_struct__5732
extern kcg_bool kcg_comp_struct__5732(
  struct__5732 *kcg_c1,
  struct__5732 *kcg_c2);
#endif /* kcg_comp_struct__5732 */

#ifndef kcg_comp_struct__5743
extern kcg_bool kcg_comp_struct__5743(
  struct__5743 *kcg_c1,
  struct__5743 *kcg_c2);
#endif /* kcg_comp_struct__5743 */

#ifndef kcg_comp_struct__5748
extern kcg_bool kcg_comp_struct__5748(
  struct__5748 *kcg_c1,
  struct__5748 *kcg_c2);
#endif /* kcg_comp_struct__5748 */

#ifndef kcg_comp_struct__5756
extern kcg_bool kcg_comp_struct__5756(
  struct__5756 *kcg_c1,
  struct__5756 *kcg_c2);
#endif /* kcg_comp_struct__5756 */

#ifndef kcg_comp_array__5615
extern kcg_bool kcg_comp_array__5615(array__5615 *kcg_c1, array__5615 *kcg_c2);
#endif /* kcg_comp_array__5615 */

#ifndef kcg_comp_array__5687
extern kcg_bool kcg_comp_array__5687(array__5687 *kcg_c1, array__5687 *kcg_c2);
#endif /* kcg_comp_array__5687 */

#ifndef kcg_comp_array__5729
extern kcg_bool kcg_comp_array__5729(array__5729 *kcg_c1, array__5729 *kcg_c2);
#endif /* kcg_comp_array__5729 */

#ifndef kcg_comp_array__5740
extern kcg_bool kcg_comp_array__5740(array__5740 *kcg_c1, array__5740 *kcg_c2);
#endif /* kcg_comp_array__5740 */

#ifndef kcg_comp_array__5753
extern kcg_bool kcg_comp_array__5753(array__5753 *kcg_c1, array__5753 *kcg_c2);
#endif /* kcg_comp_array__5753 */

#ifndef kcg_comp_array__5762
extern kcg_bool kcg_comp_array__5762(array__5762 *kcg_c1, array__5762 *kcg_c2);
#endif /* kcg_comp_array__5762 */

#ifndef kcg_comp_array_int_8
extern kcg_bool kcg_comp_array_int_8(array_int_8 *kcg_c1, array_int_8 *kcg_c2);
#endif /* kcg_comp_array_int_8 */

#ifndef kcg_comp_array__5768
extern kcg_bool kcg_comp_array__5768(array__5768 *kcg_c1, array__5768 *kcg_c2);
#endif /* kcg_comp_array__5768 */

#ifndef kcg_comp_array__5771
extern kcg_bool kcg_comp_array__5771(array__5771 *kcg_c1, array__5771 *kcg_c2);
#endif /* kcg_comp_array__5771 */

#ifndef kcg_comp_array_bool_8
extern kcg_bool kcg_comp_array_bool_8(
  array_bool_8 *kcg_c1,
  array_bool_8 *kcg_c2);
#endif /* kcg_comp_array_bool_8 */

#ifndef kcg_comp_array__5777
extern kcg_bool kcg_comp_array__5777(array__5777 *kcg_c1, array__5777 *kcg_c2);
#endif /* kcg_comp_array__5777 */

#ifndef kcg_comp_array__5780
extern kcg_bool kcg_comp_array__5780(array__5780 *kcg_c1, array__5780 *kcg_c2);
#endif /* kcg_comp_array__5780 */

#ifndef kcg_comp_array_int_10
extern kcg_bool kcg_comp_array_int_10(
  array_int_10 *kcg_c1,
  array_int_10 *kcg_c2);
#endif /* kcg_comp_array_int_10 */

#define kcg_comp_LocWithInAcc_T_Obu_BasicTypes_Pkg kcg_comp_struct__5578

#define kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg kcg_copy_struct__5578

#define kcg_comp_OdometryLocations_T_Obu_BasicTypes_Pkg kcg_comp_struct__5609

#define kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg kcg_copy_struct__5609

#define kcg_comp_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg kcg_comp_struct__5743

#define kcg_copy_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg kcg_copy_struct__5743

#define kcg_comp_LinkedBG_T_BG_Types_Pkg kcg_comp_struct__5584

#define kcg_copy_LinkedBG_T_BG_Types_Pkg kcg_copy_struct__5584

#define kcg_comp_LinkedBGs_T_BG_Types_Pkg kcg_comp_array__5615

#define kcg_copy_LinkedBGs_T_BG_Types_Pkg kcg_copy_array__5615

#define kcg_comp_BG_Header_T_BG_Types_Pkg kcg_comp_struct__5618

#define kcg_copy_BG_Header_T_BG_Types_Pkg kcg_copy_struct__5618

#define kcg_comp_passedBG_T_BG_Types_Pkg kcg_comp_struct__5629

#define kcg_copy_passedBG_T_BG_Types_Pkg kcg_copy_struct__5629

#define kcg_comp_genPassedBGs_T_ctp_t_pck_t_engine kcg_comp_array__5753

#define kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine kcg_copy_array__5753

#define kcg_comp_genPassedBG_T_ctp_t_pck_t_engine kcg_comp_struct__5748

#define kcg_copy_genPassedBG_T_ctp_t_pck_t_engine kcg_copy_struct__5748

#define kcg_comp_odometryFactors_T_ctp_t_pck_t_engine kcg_comp_struct__5756

#define kcg_copy_odometryFactors_T_ctp_t_pck_t_engine kcg_copy_struct__5756

#define kcg_comp_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_array__5729

#define kcg_copy_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_array__5729

#define kcg_comp_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_struct__5723

#define kcg_copy_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_struct__5723

#define kcg_comp_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_struct__5732

#define kcg_copy_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_struct__5732

#define kcg_comp_trainPositionInfo_T_TrainPosition_Types_Pck kcg_comp_struct__5653

#define kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck kcg_copy_struct__5653

#define kcg_comp_trainPosition_T_TrainPosition_Types_Pck kcg_comp_struct__5664

#define kcg_copy_trainPosition_T_TrainPosition_Types_Pck kcg_copy_struct__5664

#define kcg_comp_positionErrors_T_TrainPosition_Types_Pck kcg_comp_struct__5681

#define kcg_copy_positionErrors_T_TrainPosition_Types_Pck kcg_copy_struct__5681

#define kcg_comp_positionedBGs_T_TrainPosition_Types_Pck kcg_comp_array__5687

#define kcg_copy_positionedBGs_T_TrainPosition_Types_Pck kcg_copy_array__5687

#define kcg_comp_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck kcg_comp_array__5740

#define kcg_copy_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck kcg_copy_array__5740

#define kcg_comp_trainProperties_T_TrainPosition_Types_Pck kcg_comp_struct__5690

#define kcg_copy_trainProperties_T_TrainPosition_Types_Pck kcg_copy_struct__5690

#define kcg_comp_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_comp_struct__5708

#define kcg_copy_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_copy_struct__5708

#define kcg_comp_infoFromLinking_T_TrainPosition_Types_Pck kcg_comp_struct__5600

#define kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck kcg_copy_struct__5600

#define kcg_comp_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_comp_struct__5714

#define kcg_copy_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_copy_struct__5714

#define kcg_comp_positionedBG_T_TrainPosition_Types_Pck kcg_comp_struct__5642

#define kcg_copy_positionedBG_T_TrainPosition_Types_Pck kcg_copy_struct__5642

#define kcg_comp_odometry_T_Obu_BasicTypes_Pkg kcg_comp_struct__5701

#define kcg_copy_odometry_T_Obu_BasicTypes_Pkg kcg_copy_struct__5701

#endif /* _KCG_TYPES_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** kcg_types.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

