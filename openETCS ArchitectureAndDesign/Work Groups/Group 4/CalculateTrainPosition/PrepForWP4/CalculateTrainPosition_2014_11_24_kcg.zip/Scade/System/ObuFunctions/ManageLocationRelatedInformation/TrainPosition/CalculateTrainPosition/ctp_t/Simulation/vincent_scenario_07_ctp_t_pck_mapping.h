#ifndef VINCENT_SCENARIO_07_CTP_T_PCK_SCSIM_MAPPING
#define VINCENT_SCENARIO_07_CTP_T_PCK_SCSIM_MAPPING

#include "SmuTypes.h"
#include "vincent_scenario_07_ctp_t_pck_type.h"

void _SCSIM_Mapping_Create();
static ControlUtils _SCSIM_BoolEntity_Control_Utils;
#include "vincent_scenario_07_ctp_t_pck.h"
void _SCSIM_Mapping_vincent_scenario_07_ctp_t_pck();

void* _SCSIM_Get_vincent_scenario_07_ctp_t_pck_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "calculateTrainPosition_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_calculateTrainPosition_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_calculateTrainPosition_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "stimulator_ctp_t_pck_t_engine.h"
void _SCSIM_Mapping_stimulator_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_stimulator_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "observeBG_ctp_t_pck_t_engine.h"
void _SCSIM_Mapping_observeBG_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_observeBG_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "calculateBGLocations_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_calculateBGLocations_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_calculateBGLocations_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "calculateTrainpositionAttributes_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "calculateTrainPositionInfo_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_calculateTrainPositionInfo_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_calculateTrainPositionInfo_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "delDispensableBGs_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_delDispensableBGs_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_delDispensableBGs_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_281_Utils;
extern ControlUtils _SCSIM_298_Utils;
#include "genLocation_ctp_t_pck_t_engine.h"
void _SCSIM_Mapping_genLocation_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_genLocation_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "genOdometry_ctp_t_pck_t_engine.h"
void _SCSIM_Mapping_genOdometry_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_genOdometry_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "genPassedBG_ctp_t_pck_t_engine.h"
void _SCSIM_Mapping_genPassedBG_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_genPassedBG_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "sub_2_distances_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_sub_2_distances_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "passing_a_BG_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_passing_a_BG_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_passing_a_BG_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "prevPassedLinkedBG_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_prevPassedLinkedBG_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_prevPassedLinkedBG_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "genPassedBG_SeqNo_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_genPassedBG_SeqNo_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_genPassedBG_SeqNo_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "add_2_Distances_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_add_2_Distances_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.h"
void _SCSIM_Mapping_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_609_Utils;
extern ControlUtils _SCSIM_611_Utils;
extern ControlUtils _SCSIM_608_Utils;
extern ControlUtils _SCSIM_613_Utils;
extern ControlUtils _SCSIM_616_Utils;
extern ControlUtils _SCSIM_622_Utils;
extern ControlUtils _SCSIM_615_Utils;
extern ControlUtils _SCSIM_624_Utils;
#include "frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg.h"
void _SCSIM_Mapping_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_634_Utils;
extern ControlUtils _SCSIM_636_Utils;
extern ControlUtils _SCSIM_633_Utils;
extern ControlUtils _SCSIM_643_Utils;
#include "positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_670_Utils;
extern ControlUtils _SCSIM_675_Utils;
#include "overlapOf_2_Locations_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_overlapOf_2_Locations_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "genPassedBG_itr_ctp_t_pck_t_engine.h"
void _SCSIM_Mapping_genPassedBG_itr_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_genPassedBG_itr_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "passedBG_2_positionedBG_CalculateTrainPosition_Pkg.h"
void _SCSIM_Mapping_passedBG_2_positionedBG_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_passedBG_2_positionedBG_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_822_Utils;
extern ControlUtils _SCSIM_843_Utils;
extern ControlUtils _SCSIM_821_Utils;
extern ControlUtils _SCSIM_846_Utils;
extern ControlUtils _SCSIM_820_Utils;
extern ControlUtils _SCSIM_860_Utils;
#include "mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg.h"
void _SCSIM_Mapping_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h"
void _SCSIM_Mapping_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_SSM_TR_Unknown_1_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Unknown_2_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Unknown_3_SM1_Utils;
extern ControlUtils _SCSIM_SSM_st_Unknown_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Decreasing_1_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Decreasing_2_SM1_Utils;
extern ControlUtils _SCSIM_SSM_st_Decreasing_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Increasing_1_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Increasing_2_SM1_Utils;
extern ControlUtils _SCSIM_SSM_st_Increasing_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Standstill_1_SM1_Utils;
extern ControlUtils _SCSIM_SSM_TR_Standstill_2_SM1_Utils;
extern ControlUtils _SCSIM_SSM_st_Standstill_SM1_Utils;
#include "sub_2_odoDistances_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_sub_2_odoDistances_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "add_odo_2_Location_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_add_odo_2_Location_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_1706_Utils;
extern ControlUtils _SCSIM_1709_Utils;
extern ControlUtils _SCSIM_1705_Utils;
extern ControlUtils _SCSIM_1712_Utils;
#include "insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
void _SCSIM_Mapping_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

extern ControlUtils _SCSIM_1718_Utils;
extern ControlUtils _SCSIM_1721_Utils;
extern ControlUtils _SCSIM_1717_Utils;
extern ControlUtils _SCSIM_1724_Utils;
#include "calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"
void _SCSIM_Mapping_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "scaledDLINK_2_dlink_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

#include "odoLoc_2_refLocations_BasicLocationFunctions_Pkg.h"
void _SCSIM_Mapping_odoLoc_2_refLocations_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*));
void* _SCSIM_Get_odoLoc_2_refLocations_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize);

static int _SCSIM_ClockActive_SSM_st_Standstill_SM1(void*);
static int _SCSIM_ClockActive_SSM_st_Increasing_SM1(void*);
static int _SCSIM_ClockActive_SSM_st_Decreasing_SM1(void*);
static int _SCSIM_ClockActive_SSM_st_Unknown_SM1(void*);
static int _SCSIM_ClockActive_kcg_false(void*);
static int _SCSIM_ClockActive_kcg_true(void*);

#endif /*VINCENT_SCENARIO_07_CTP_T_PCK_SCSIM_MAPPING */
