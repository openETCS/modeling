/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "observeBG_ctp_t_pck_t_engine.h"

/* ctp_t_pck::t_engine::observeBG */
void observeBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::observeBG::positionedBGs */positionedBGs_T_TrainPosition_Types_Pck *positionedBGs,
  /* ctp_t_pck::t_engine::observeBG::BG_toBeObserved */genPassedBG_T_ctp_t_pck_t_engine *BG_toBeObserved,
  /* ctp_t_pck::t_engine::observeBG::loc_min */Location_T_Obu_BasicTypes_Pkg *loc_min,
  /* ctp_t_pck::t_engine::observeBG::loc_nom */Location_T_Obu_BasicTypes_Pkg *loc_nom,
  /* ctp_t_pck::t_engine::observeBG::loc_max */Location_T_Obu_BasicTypes_Pkg *loc_max)
{
  LocWithInAcc_T_Obu_BasicTypes_Pkg tmp1;
  positionedBG_T_TrainPosition_Types_Pck tmp;
  /* ctp_t_pck::t_engine::observeBG::_L9 */ kcg_bool _L9;
  /* ctp_t_pck::t_engine::observeBG::_L8 */ kcg_bool _L8;
  /* ctp_t_pck::t_engine::observeBG::_L7 */ kcg_int _L7;
  /* ctp_t_pck::t_engine::observeBG::_L24 */ LocWithInAcc_T_Obu_BasicTypes_Pkg _L24;
  /* ctp_t_pck::t_engine::observeBG::_L26 */ LocWithInAcc_T_Obu_BasicTypes_Pkg _L26;
  
  _L24.nominal = (*BG_toBeObserved).idealLocation;
  _L24.d_min = 0;
  _L24.d_max = 0;
  /* 1 */
  indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &(*BG_toBeObserved).passedBG,
    positionedBGs,
    kcg_true,
    &_L7,
    &_L8,
    &_L9);
  if (_L8) {
    if ((0 <= _L7) & (_L7 < 8)) {
      kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
        &tmp,
        &(*positionedBGs)[_L7]);
    }
    else {
      kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
        &tmp,
        (positionedBG_T_TrainPosition_Types_Pck *)
          &cNoPositionedBG_CalculateTrainPosition_Pkg);
    }
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&tmp1, &tmp.location);
  }
  else {
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&tmp1, &_L24);
  }
  /* 1 */ sub_2_distances_BasicLocationFunctions_Pkg(&tmp1, &_L24, &_L26);
  *loc_nom = _L26.nominal;
  *loc_max = *loc_nom + _L26.d_max;
  *loc_min = *loc_nom + _L26.d_min;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** observeBG_ctp_t_pck_t_engine.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

