/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateBGLocations_CalculateTrainPosition_Pkg.h"

void calculateBGLocations_reset_CalculateTrainPosition_Pkg(
  outC_calculateBGLocations_CalculateTrainPosition_Pkg *outC)
{
  /* 2 */ genPassedBG_SeqNo_reset_CalculateTrainPosition_Pkg(&outC->Context_2);
}

/** Calculation of the locations of passed and announced BGs */
/** "GdC_1" {Author = "Author : Uwe Steinke", DateC = "Created : 2014-15-22", DateM = "Modified : 2014-06-03", Version = "No 00.03.00"} */
/** "Remark_1" {Description = "The main function calculating the actual train position. - Description: Calculates the actual train position based on passed balise groups - Copyright Siemens AG, 2014 - Licensed under the EUPL V.1.1 ( http://joinup.ec.europa.eu/software/page/eupl/licence-eupl ) - Gist URL: --- - Cryptography: No - Author(s): Uwe Steinke  The use of this software is limited to non-vital applications.  It has not been developed for vital operation purposes and must not be used for applications which may cause harm to people, physical accidents or financial loss.  THEREFORE, NO LIABILITY WILL BE GIVEN FOR SUCH AND ANY OTHER KIND OF USE.   "} */
/* CalculateTrainPosition_Pkg::calculateBGLocations */
void calculateBGLocations_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateBGLocations::passedBG */passedBG_T_BG_Types_Pkg *passedBG,
  /* CalculateTrainPosition_Pkg::calculateBGLocations::lastBGs */positionedBGs_T_TrainPosition_Types_Pck *lastBGs,
  /* CalculateTrainPosition_Pkg::calculateBGLocations::reset */kcg_bool reset,
  /* CalculateTrainPosition_Pkg::calculateBGLocations::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  outC_calculateBGLocations_CalculateTrainPosition_Pkg *outC)
{
  positionedBG_T_TrainPosition_Types_Pck tmp;
  /* CalculateTrainPosition_Pkg::calculateBGLocations::_L87 */ positionedBG_T_TrainPosition_Types_Pck _L87;
  /* CalculateTrainPosition_Pkg::calculateBGLocations::_L88 */ positionedBGs_T_TrainPosition_Types_Pck _L88;
  /* CalculateTrainPosition_Pkg::calculateBGLocations::_L351 */ kcg_bool _L351;
  
  outC->errors.positionCalculation_inconsistent = kcg_false;
  /* 1 */
  prevPassedLinkedBG_CalculateTrainPosition_Pkg(passedBG, lastBGs, &tmp);
  /* 2 */
  genPassedBG_SeqNo_CalculateTrainPosition_Pkg(
    passedBG,
    lastBGs,
    reset,
    &outC->Context_2);
  /* 1 */
  passing_a_BG_CalculateTrainPosition_Pkg(
    passedBG,
    &tmp,
    lastBGs,
    outC->Context_2.seqNo,
    trainProperties,
    &_L87,
    &_L88,
    &outC->errors.outOfMemSpace,
    &_L351);
  outC->errors.passedBG_notFoundWhereExpected = _L351;
  _L351 = _L87.valid & (_L87.q_link == Q_LINK_Linked);
  if (reset) {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &outC->BGs,
      (positionedBGs_T_TrainPosition_Types_Pck *)
        &cNoPositionedBGs_CalculateTrainPosition_Pkg);
  }
  else if (_L351) {
    /* 1 */
    improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg(
      &_L87,
      &_L88,
      trainProperties,
      &outC->BGs);
  }
  else {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->BGs, &_L88);
  }
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateBGLocations_CalculateTrainPosition_Pkg.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

