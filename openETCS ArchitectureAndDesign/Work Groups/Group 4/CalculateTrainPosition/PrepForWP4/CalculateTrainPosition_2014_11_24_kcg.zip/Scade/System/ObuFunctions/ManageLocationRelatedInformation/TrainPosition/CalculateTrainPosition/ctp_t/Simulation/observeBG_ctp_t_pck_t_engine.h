/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _observeBG_ctp_t_pck_t_engine_H_
#define _observeBG_ctp_t_pck_t_engine_H_

#include "kcg_types.h"
#include "indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
#include "sub_2_distances_BasicLocationFunctions_Pkg.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::loc_min */ loc_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::loc_nom */ loc_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::loc_max */ loc_max;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_sub_2_distances_BasicLocationFunctions_Pkg /* 1 */ _1_Context_1;
  outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::observeBG::_L1 */ _L1;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::observeBG::_L2 */ _L2;
  kcg_bool /* ctp_t_pck::t_engine::observeBG::_L9 */ _L9;
  kcg_bool /* ctp_t_pck::t_engine::observeBG::_L8 */ _L8;
  kcg_int /* ctp_t_pck::t_engine::observeBG::_L7 */ _L7;
  positionedBGs_T_TrainPosition_Types_Pck /* ctp_t_pck::t_engine::observeBG::_L10 */ _L10;
  kcg_bool /* ctp_t_pck::t_engine::observeBG::_L11 */ _L11;
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::t_engine::observeBG::_L13 */ _L13;
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::t_engine::observeBG::_L14 */ _L14;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L16 */ _L16;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L22 */ _L22;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L21 */ _L21;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L20 */ _L20;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L23 */ _L23;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L24 */ _L24;
  kcg_int /* ctp_t_pck::t_engine::observeBG::_L25 */ _L25;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L26 */ _L26;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::observeBG::_L27 */ _L27;
  kcg_int /* ctp_t_pck::t_engine::observeBG::_L28 */ _L28;
  kcg_int /* ctp_t_pck::t_engine::observeBG::_L29 */ _L29;
} outC_observeBG_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::observeBG */
extern void observeBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::observeBG::positionedBGs */positionedBGs_T_TrainPosition_Types_Pck *positionedBGs,
  /* ctp_t_pck::t_engine::observeBG::BG_toBeObserved */genPassedBG_T_ctp_t_pck_t_engine *BG_toBeObserved,
  outC_observeBG_ctp_t_pck_t_engine *outC);

extern void observeBG_reset_ctp_t_pck_t_engine(
  outC_observeBG_ctp_t_pck_t_engine *outC);

#endif /* _observeBG_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** observeBG_ctp_t_pck_t_engine.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

