/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genPassedBG_itr_ctp_t_pck_t_engine.h"

/* ctp_t_pck::t_engine::genPassedBG_itr */
void genPassedBG_itr_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG_itr::accPassedBG */passedBG_T_BG_Types_Pkg *accPassedBG,
  /* ctp_t_pck::t_engine::genPassedBG_itr::location */L_internal_Type_Obu_BasicTypes_Pkg location,
  /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG_in */genPassedBG_T_ctp_t_pck_t_engine *passedBG_in,
  /* ctp_t_pck::t_engine::genPassedBG_itr::cont */kcg_bool *cont,
  /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG */passedBG_T_BG_Types_Pkg *passedBG)
{
  /* ctp_t_pck::t_engine::genPassedBG_itr::_L7 */ kcg_bool _L7;
  
  _L7 = (*passedBG_in).passedBG.valid & ((*passedBG_in).idealLocation ==
      location);
  if (_L7) {
    kcg_copy_passedBG_T_BG_Types_Pkg(passedBG, &(*passedBG_in).passedBG);
  }
  else {
    kcg_copy_passedBG_T_BG_Types_Pkg(passedBG, accPassedBG);
  }
  *cont = (*passedBG_in).passedBG.valid & !_L7;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_itr_ctp_t_pck_t_engine.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

