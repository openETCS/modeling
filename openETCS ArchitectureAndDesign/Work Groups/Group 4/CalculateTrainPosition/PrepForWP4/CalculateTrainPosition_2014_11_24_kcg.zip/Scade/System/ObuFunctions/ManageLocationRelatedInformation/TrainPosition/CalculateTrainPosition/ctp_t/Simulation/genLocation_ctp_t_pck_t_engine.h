/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _genLocation_ctp_t_pck_t_engine_H_
#define _genLocation_ctp_t_pck_t_engine_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::location */ location;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::time */ time;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::location_loc */ location_loc;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L1 */ _L1;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* --------------------- (-debug) assertions  ---------------------- */
  kcg_bool /* math::InRangeInIn::A1 */ A1_4;
  kcg_bool /* math::InRangeInIn::A1 */ A1_3;
  kcg_bool /* math::InRangeInIn::A1 */ A1_2;
  kcg_bool /* math::InRangeInIn::A1 */ A1_1;
  /* ------------------- (-debug) local variables -------------------- */
  kcg_int /* math::InRangeInIn::_L10 */ _L10_4;
  kcg_bool /* math::InRangeInIn::_L12 */ _L12_4;
  kcg_int /* math::InRangeInIn::_L13 */ _L13_4;
  kcg_bool /* math::InRangeInIn::_L2 */ _L2_4;
  kcg_bool /* math::InRangeInIn::_L4 */ _L4_4;
  kcg_int /* math::InRangeInIn::_L8 */ _L8_4;
  kcg_bool /* math::InRangeInIn::IRII_Output */ IRII_Output_4;
  kcg_int /* math::InRangeInIn::B */ B_4;
  kcg_int /* math::InRangeInIn::A */ A_4;
  kcg_int /* math::InRangeInIn::IRII_Input */ IRII_Input_4;
  kcg_int /* math::InRangeInIn::_L10 */ _L10_3;
  kcg_bool /* math::InRangeInIn::_L12 */ _L12_3;
  kcg_int /* math::InRangeInIn::_L13 */ _L13_3;
  kcg_bool /* math::InRangeInIn::_L2 */ _L2_3;
  kcg_bool /* math::InRangeInIn::_L4 */ _L4_3;
  kcg_int /* math::InRangeInIn::_L8 */ _L8_3;
  kcg_bool /* math::InRangeInIn::IRII_Output */ IRII_Output_3;
  kcg_int /* math::InRangeInIn::B */ B_3;
  kcg_int /* math::InRangeInIn::A */ A_3;
  kcg_int /* math::InRangeInIn::IRII_Input */ IRII_Input_3;
  kcg_int /* math::InRangeInIn::_L10 */ _L10_2;
  kcg_bool /* math::InRangeInIn::_L12 */ _L12_2;
  kcg_int /* math::InRangeInIn::_L13 */ _L13_2;
  kcg_bool /* math::InRangeInIn::_L2 */ _L2_2;
  kcg_bool /* math::InRangeInIn::_L4 */ _L4_2;
  kcg_int /* math::InRangeInIn::_L8 */ _L8_2;
  kcg_bool /* math::InRangeInIn::IRII_Output */ IRII_Output_2;
  kcg_int /* math::InRangeInIn::B */ B_2;
  kcg_int /* math::InRangeInIn::A */ A_2;
  kcg_int /* math::InRangeInIn::IRII_Input */ IRII_Input_2;
  kcg_int /* math::InRangeInIn::_L10 */ _L10_1;
  kcg_bool /* math::InRangeInIn::_L12 */ _L12_1;
  kcg_int /* math::InRangeInIn::_L13 */ _L13_1;
  kcg_bool /* math::InRangeInIn::_L2 */ _L2_1;
  kcg_bool /* math::InRangeInIn::_L4 */ _L4_1;
  kcg_int /* math::InRangeInIn::_L8 */ _L8_1;
  kcg_bool /* math::InRangeInIn::IRII_Output */ IRII_Output_1;
  kcg_int /* math::InRangeInIn::B */ B_1;
  kcg_int /* math::InRangeInIn::A */ A_1;
  kcg_int /* math::InRangeInIn::IRII_Input */ IRII_Input_1;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::incr */ incr;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L2 */ _L2;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L4 */ _L4;
  kcg_bool /* ctp_t_pck::t_engine::genLocation::_L5 */ _L5;
  kcg_bool /* ctp_t_pck::t_engine::genLocation::_L6 */ _L6;
  kcg_bool /* ctp_t_pck::t_engine::genLocation::_L7 */ _L7;
  kcg_bool /* ctp_t_pck::t_engine::genLocation::_L8 */ _L8;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L9 */ _L9;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L10 */ _L10;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L11 */ _L11;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L12 */ _L12;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L13 */ _L13;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L14 */ _L14;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L15 */ _L15;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L16 */ _L16;
  kcg_bool /* ctp_t_pck::t_engine::genLocation::_L17 */ _L17;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::_L19 */ _L19;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L20 */ _L20;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L21 */ _L21;
  kcg_int /* ctp_t_pck::t_engine::genLocation::_L22 */ _L22;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::_L23 */ _L23;
} outC_genLocation_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::genLocation */
extern void genLocation_ctp_t_pck_t_engine(
  outC_genLocation_ctp_t_pck_t_engine *outC);

extern void genLocation_reset_ctp_t_pck_t_engine(
  outC_genLocation_ctp_t_pck_t_engine *outC);

#endif /* _genLocation_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genLocation_ctp_t_pck_t_engine.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

