/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateTrainPosition_CalculateTrainPosition_Pkg.h"

void calculateTrainPosition_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainPosition_CalculateTrainPosition_Pkg *outC)
{
  outC->init = kcg_true;
  /* 1 */
  calculateTrainpositionAttributes_reset_CalculateTrainPosition_Pkg(
    &outC->Context_1);
  /* 1 */
  calculateTrainPositionInfo_reset_CalculateTrainPosition_Pkg(
    &outC->_1_Context_1);
  /* 1 */
  calculateBGLocations_reset_CalculateTrainPosition_Pkg(&outC->_2_Context_1);
}

/** The main function calculating the locations of balise groups and the actual train position. */
/** "Remark_1" {Description = "The main function calculating the actual train position. - Description: Calculates the actual train position based on passed balise groups - Copyright Siemens AG, 2014 - Licensed under the EUPL V.1.1 ( http://joinup.ec.europa.eu/software/page/eupl/licence-eupl ) - Gist URL: --- - Cryptography: No - Author(s): Uwe Steinke  The use of this software is limited to non-vital applications.  It has not been developed for vital operation purposes and must not be used for applications which may cause harm to people, physical accidents or financial loss.  THEREFORE, NO LIABILITY WILL BE GIVEN FOR SUCH AND ANY OTHER KIND OF USE.   "} */
/** "GdC_1" {Author = "Author : Uwe Steinke", DateC = "Created : 2014-15-22", DateM = "Modified : 2014-06-03", Version = "No 00.03.00"} */
/* CalculateTrainPosition_Pkg::calculateTrainPosition */
void calculateTrainPosition_CalculateTrainPosition_Pkg(
  inC_calculateTrainPosition_CalculateTrainPosition_Pkg *inC,
  outC_calculateTrainPosition_CalculateTrainPosition_Pkg *outC)
{
  static positionedBGs_T_TrainPosition_Types_Pck tmp;
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::_L210 */
  static positionedBGs_T_TrainPosition_Types_Pck _L210;
  /* CalculateTrainPosition_Pkg::calculateTrainPosition::_L229 */
  static kcg_bool _L229;
  
  _L229 = inC->passedBG.valid | inC->reset;
  if (outC->init) {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &_L210,
      (positionedBGs_T_TrainPosition_Types_Pck *)
        &cNoPositionedBGs_CalculateTrainPosition_Pkg);
  }
  else {
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&_L210, &outC->BGs);
  }
  if (_L229) {
    if (inC->reset) {
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
        &tmp,
        (positionedBGs_T_TrainPosition_Types_Pck *)
          &cNoPositionedBGs_CalculateTrainPosition_Pkg);
    }
    else {
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&tmp, &_L210);
    }
    /* 1 */
    calculateBGLocations_CalculateTrainPosition_Pkg(
      &inC->passedBG,
      &tmp,
      inC->reset,
      &inC->trainProperties,
      &outC->_2_Context_1);
    kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
      &outC->_L199,
      &outC->_2_Context_1.errors);
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
      &outC->_L198,
      &outC->_2_Context_1.BGs);
    /* 1 */
    delDispensableBGs_CalculateTrainPosition_Pkg(
      &outC->_L198,
      _L229,
      &outC->BGs);
  }
  else {
    if (outC->init) {
      kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
        &outC->_L199,
        (positionErrors_T_TrainPosition_Types_Pck *)
          &cNoPositionErrors_CalculateTrainPosition_Pkg);
      kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
        &outC->_L198,
        (positionedBGs_T_TrainPosition_Types_Pck *)
          &cNoPositionedBGs_CalculateTrainPosition_Pkg);
    }
    kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->BGs, &_L210);
  }
  outC->init = kcg_false;
  /* 1 */
  calculateTrainPositionInfo_CalculateTrainPosition_Pkg(
    &inC->currentOdometry,
    &outC->BGs,
    _L229,
    &outC->_1_Context_1);
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo,
    &outC->_1_Context_1.trainPositionInfo);
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
    &outC->errors,
    &outC->_L199);
  outC->errors.positionCalculation_inconsistent =
    outC->_1_Context_1.positionCalculationNotConsistent;
  /* 1 */
  calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(
    &inC->LRBG,
    &inC->prevLRBG,
    &outC->trainPositionInfo,
    &inC->currentOdometry,
    &inC->trainProperties,
    &outC->Context_1);
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->trainPosition,
    &outC->Context_1.trainPosition);
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainPosition_CalculateTrainPosition_Pkg.c
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

