/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "testBed_ctp_t_pck.h"

void testBed_reset_ctp_t_pck(outC_testBed_ctp_t_pck *outC)
{
  outC->init = kcg_true;
  /* 1 */
  calculateTrainPosition_reset_CalculateTrainPosition_Pkg(&outC->Context_1);
  /* 1 */ stimulator_reset_ctp_t_pck_t_engine(&outC->_1_Context_1);
}

/* ctp_t_pck::testBed */
void testBed_ctp_t_pck(outC_testBed_ctp_t_pck *outC)
{
  positionedBG_T_TrainPosition_Types_Pck tmp;
  /* ctp_t_pck::testBed::_L28 */ genPassedBGs_T_ctp_t_pck_t_engine _L28;
  
  /* 1 */ stimulator_ctp_t_pck_t_engine(&outC->_1_Context_1);
  outC->pos_ideal = outC->_1_Context_1.pos_ideal;
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &_L28,
    &outC->_1_Context_1.trackDescription);
  if (outC->init) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &tmp,
      (positionedBG_T_TrainPosition_Types_Pck *)
        &cNoPositionedBG_CalculateTrainPosition_Pkg);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&tmp, &outC->LRBG);
  }
  /* 1 */
  calculateTrainPosition_CalculateTrainPosition_Pkg(
    &outC->_1_Context_1.odometry,
    &outC->_1_Context_1.passedBG,
    &tmp,
    (positionedBG_T_TrainPosition_Types_Pck *)
      &cNoPositionedBG_CalculateTrainPosition_Pkg,
    kcg_false,
    (trainProperties_T_TrainPosition_Types_Pck *)
      &cTrainProperties_ctp_t_pck_t_engine,
    &outC->Context_1);
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->trainPosition,
    &outC->Context_1.trainPosition);
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo,
    &outC->Context_1.trainPositionInfo);
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
    &outC->BGs,
    &outC->Context_1.BGs);
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
    &outC->errors,
    &outC->Context_1.errors);
  /* 6 */
  observeBG_ctp_t_pck_t_engine(
    &outC->BGs,
    &_L28[3],
    &outC->locBG_104_min,
    &outC->locBG_104_nom,
    &outC->locBG_104_max);
  /* 5 */
  observeBG_ctp_t_pck_t_engine(
    &outC->BGs,
    &_L28[2],
    &outC->locBG_003_min,
    &outC->locBG_003_nom,
    &outC->locBG_003_max);
  /* 4 */
  observeBG_ctp_t_pck_t_engine(
    &outC->BGs,
    &_L28[1],
    &outC->locBG_102_min,
    &outC->locBG_102_nom,
    &outC->locBG_102_max);
  /* 2 */
  observeBG_ctp_t_pck_t_engine(
    &outC->BGs,
    &_L28[4],
    &outC->locBG_005_min,
    &outC->locBG_005_nom,
    &outC->locBG_005_max);
  /* 1 */
  observeBG_ctp_t_pck_t_engine(
    &outC->BGs,
    &_L28[0],
    &outC->locBG_001_min,
    &outC->locBG_001_nom,
    &outC->locBG_001_max);
  outC->pos_max = outC->trainPositionInfo.trainPosition.nominal +
    outC->trainPositionInfo.trainPosition.d_max - outC->pos_ideal;
  outC->pos_min = outC->trainPositionInfo.trainPosition.nominal +
    outC->trainPositionInfo.trainPosition.d_min - outC->pos_ideal;
  outC->pos_nom = outC->trainPositionInfo.trainPosition.nominal -
    outC->pos_ideal;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->LRBG,
    &outC->trainPositionInfo.lastPassedLinkedBG);
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** testBed_ctp_t_pck.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

