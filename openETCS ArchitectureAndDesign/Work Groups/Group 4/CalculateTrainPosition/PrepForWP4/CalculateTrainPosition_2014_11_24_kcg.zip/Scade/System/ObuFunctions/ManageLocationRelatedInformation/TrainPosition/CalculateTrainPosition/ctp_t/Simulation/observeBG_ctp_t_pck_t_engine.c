/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "observeBG_ctp_t_pck_t_engine.h"

void observeBG_reset_ctp_t_pck_t_engine(outC_observeBG_ctp_t_pck_t_engine *outC)
{
  /* 1 */ sub_2_distances_reset_BasicLocationFunctions_Pkg(&outC->_1_Context_1);
  /* 1 */
  indexOfPassedBG_by_id_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->Context_1);
}

/* ctp_t_pck::t_engine::observeBG */
void observeBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::observeBG::positionedBGs */positionedBGs_T_TrainPosition_Types_Pck *positionedBGs,
  /* ctp_t_pck::t_engine::observeBG::BG_toBeObserved */genPassedBG_T_ctp_t_pck_t_engine *BG_toBeObserved,
  outC_observeBG_ctp_t_pck_t_engine *outC)
{
  kcg_bool noname;
  
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L1, BG_toBeObserved);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L2, &outC->_L1.passedBG);
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L10, positionedBGs);
  outC->_L11 = kcg_true;
  /* 1 */
  indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_L2,
    &outC->_L10,
    outC->_L11,
    &outC->Context_1);
  outC->_L7 = outC->Context_1.indexOfBG;
  outC->_L8 = outC->Context_1.BG_found;
  outC->_L9 = outC->Context_1.indexValid;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L14,
    (positionedBG_T_TrainPosition_Types_Pck *)
      &cNoPositionedBG_CalculateTrainPosition_Pkg);
  if ((0 <= outC->_L7) & (outC->_L7 < 8)) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &outC->_L13,
      &outC->_L10[outC->_L7]);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L13, &outC->_L14);
  }
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->_L16, &outC->_L13.location);
  outC->_L27 = outC->_L1.trueLocation;
  outC->_L25 = 0;
  outC->_L24.nominal = outC->_L27;
  outC->_L24.d_min = outC->_L25;
  outC->_L24.d_max = outC->_L25;
  if (outC->_L8) {
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->_L23, &outC->_L16);
  }
  else {
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->_L23, &outC->_L24);
  }
  /* 1 */
  sub_2_distances_BasicLocationFunctions_Pkg(
    &outC->_L23,
    &outC->_L24,
    &outC->_1_Context_1);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L26,
    &outC->_1_Context_1.distance);
  outC->_L22 = outC->_L26.d_max;
  outC->_L21 = outC->_L26.d_min;
  outC->_L20 = outC->_L26.nominal;
  outC->_L29 = outC->_L20 + outC->_L22;
  outC->loc_max = outC->_L29;
  outC->loc_nom = outC->_L20;
  outC->_L28 = outC->_L20 + outC->_L21;
  outC->loc_min = outC->_L28;
  noname = outC->_L9;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** observeBG_ctp_t_pck_t_engine.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

