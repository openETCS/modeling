/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genPassedBG_ctp_t_pck_t_engine.h"

/* ctp_t_pck::t_engine::genPassedBG */
void genPassedBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG::location */L_internal_Type_Obu_BasicTypes_Pkg location,
  /* ctp_t_pck::t_engine::genPassedBG::odometry */odometry_T_Obu_BasicTypes_Pkg *odometry,
  /* ctp_t_pck::t_engine::genPassedBG::passedBGs */genPassedBGs_T_ctp_t_pck_t_engine *passedBGs,
  /* ctp_t_pck::t_engine::genPassedBG::passedBG */passedBG_T_BG_Types_Pkg *passedBG)
{
  passedBG_T_BG_Types_Pkg tmp1;
  kcg_bool tmp;
  kcg_int i;
  
  kcg_copy_passedBG_T_BG_Types_Pkg(
    passedBG,
    (passedBG_T_BG_Types_Pkg *) &cNoPassedBG_CalculateTrainPosition_Pkg);
  for (i = 0; i < 10; i++) {
    kcg_copy_passedBG_T_BG_Types_Pkg(&tmp1, passedBG);
    /* 1 */
    genPassedBG_itr_ctp_t_pck_t_engine(
      &tmp1,
      location,
      &(*passedBGs)[i],
      &tmp,
      passedBG);
    if (!tmp) {
      break;
    }
  }
  kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
    &(*passedBG).odometrystamp,
    &(*odometry).odo);
  (*passedBG).timestamp = (*odometry).timestamp;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_ctp_t_pck_t_engine.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

