/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-13T13:02:57
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "recalculate_BG_location_astern_V2_CalculateTrainPosition_Pkg_BG_relocation_Pkg.h"

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2 */
void recalculate_BG_location_astern_V2_CalculateTrainPosition_Pkg_BG_relocation_Pkg(
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::BG_in */positionedBG_T_TrainPosition_Types_Pck *BG_in,
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::prevLinkedBG */positionedBG_T_TrainPosition_Types_Pck *prevLinkedBG,
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::refBG */positionedBG_T_TrainPosition_Types_Pck *refBG,
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::sumOfBestDistances */LocWithInAcc_T_Obu_BasicTypes_Pkg *sumOfBestDistances,
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::BG_out */positionedBG_T_TrainPosition_Types_Pck *BG_out)
{
  static LocWithInAcc_T_Obu_BasicTypes_Pkg tmp1;
  static LocWithInAcc_T_Obu_BasicTypes_Pkg tmp;
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::_L181 */
  static LocWithInAcc_T_Obu_BasicTypes_Pkg _L181;
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::_L195 */
  static kcg_bool _L195;
  /* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern_V2::_L212 */
  static kcg_bool _L212;
  
  /* 1 */
  add_2_Distances_BasicLocationFunctions_Pkg(
    &(*refBG).location,
    sumOfBestDistances,
    &tmp1);
  /* 1 */
  calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg(
    BG_in,
    trainProperties,
    &tmp);
  /* 1 */ sub_2_distances_BasicLocationFunctions_Pkg(&tmp1, &tmp, &_L181);
  /* 1 */
  sub_2_odoDistances_BasicLocationFunctions_Pkg(
    &(*prevLinkedBG).infoFromPassing.odometrystamp,
    &(*BG_in).infoFromPassing.odometrystamp,
    &tmp);
  /* 3 */
  add_2_Distances_BasicLocationFunctions_Pkg(
    &(*BG_in).infoFromPassing.BG_centerDetectionInaccuraccuracies,
    &tmp,
    &tmp1);
  /* 3 */
  sub_2_distances_BasicLocationFunctions_Pkg(
    &(*prevLinkedBG).location,
    &tmp1,
    &tmp);
  /* 1 */
  overlapOf_2_Locations_BasicLocationFunctions_Pkg(&_L181, &tmp, &tmp1, &_L212);
  _L195 = (*BG_in).valid & (*BG_in).infoFromPassing.valid &
    (*prevLinkedBG).valid & (*prevLinkedBG).infoFromPassing.valid;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(BG_out, BG_in);
  if ((*BG_in).valid & (*refBG).valid & ((*BG_in).q_link == Q_LINK_Linked)) {
    if (_L212 & _L195) {
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&(*BG_out).location, &tmp1);
    }
    else {
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&(*BG_out).location, &_L181);
    }
  }
  else if (_L195) {
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&(*BG_out).location, &tmp);
  }
  else {
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
      &(*BG_out).location,
      &(*BG_in).location);
  }
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** recalculate_BG_location_astern_V2_CalculateTrainPosition_Pkg_BG_relocation_Pkg.c
** Generation date: 2014-10-13T13:02:57
*************************************************************$ */

