/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */
#ifndef _trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_H_
#define _trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction */ direction;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  SSM_ST_SM1 /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_state_nxt;
  odometry_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */ rem_currentOdometry;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
} outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg;

/* ===========  node initialization and cycle functions  =========== */
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor */
extern void trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

extern void trainMovementSensor_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

#endif /* _trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

