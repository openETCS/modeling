/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _genPassedBG_ctp_t_pck_t_engine_H_
#define _genPassedBG_ctp_t_pck_t_engine_H_

#include "kcg_types.h"
#include "genPassedBG_itr_ctp_t_pck_t_engine.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG::passedBG */ passedBG;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_genPassedBG_itr_ctp_t_pck_t_engine /* 1 */ Context_1[10];
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L1 */ _L1;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::genPassedBG::_L2 */ _L2;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L3 */ _L3;
  kcg_int /* ctp_t_pck::t_engine::genPassedBG::_L5 */ _L5;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L6 */ _L6;
  array_int_10 /* ctp_t_pck::t_engine::genPassedBG::_L7 */ _L7;
  kcg_bool /* ctp_t_pck::t_engine::genPassedBG::_L8 */ _L8;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L9 */ _L9;
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L10 */ _L10;
  OdometryLocations_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L11 */ _L11;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L12 */ _L12;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::genPassedBG::_L13 */ _L13;
} outC_genPassedBG_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::genPassedBG */
extern void genPassedBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG::trueLocation */L_internal_Type_Obu_BasicTypes_Pkg trueLocation,
  /* ctp_t_pck::t_engine::genPassedBG::odometry */odometry_T_Obu_BasicTypes_Pkg *odometry,
  /* ctp_t_pck::t_engine::genPassedBG::passedBGs */genPassedBGs_T_ctp_t_pck_t_engine *passedBGs,
  outC_genPassedBG_ctp_t_pck_t_engine *outC);

extern void genPassedBG_reset_ctp_t_pck_t_engine(
  outC_genPassedBG_ctp_t_pck_t_engine *outC);

#endif /* _genPassedBG_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_ctp_t_pck_t_engine.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

