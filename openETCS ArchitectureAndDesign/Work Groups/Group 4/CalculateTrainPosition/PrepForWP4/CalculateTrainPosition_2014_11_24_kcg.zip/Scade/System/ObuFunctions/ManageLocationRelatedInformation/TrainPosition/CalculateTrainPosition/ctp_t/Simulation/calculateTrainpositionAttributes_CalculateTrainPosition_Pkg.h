/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _calculateTrainpositionAttributes_CalculateTrainPosition_Pkg_H_
#define _calculateTrainpositionAttributes_CalculateTrainPosition_Pkg_H_

#include "kcg_types.h"
#include "nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
#include "runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.h"
#include "frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg.h"
#include "add_2_Distances_BasicLocationFunctions_Pkg.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  trainPosition_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainPosition */ trainPosition;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg /* 1 */ _3_Context_1;
  outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg /* nidC_nidBG_2_NIDLRBG */ Context_nidC_nidBG_2_NIDLRBG;
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg /* 1 */ _2_Context_1;
  outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg /* 1 */ _1_Context_1;
  outC_add_2_Distances_BasicLocationFunctions_Pkg /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  trainPosition_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L205 */ _L205;
  trainPositionInfo_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L218 */ _L218;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L219 */ _L219;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L220 */ _L220;
  positionedBG_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L221 */ _L221;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L223 */ _L223;
  trainPositionInfo_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L224 */ _L224;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L225 */ _L225;
  positionedBG_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L227 */ _L227;
  NID_BG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L229 */ _L229;
  positionedBG_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L230 */ _L230;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L234 */ _L234;
  trainProperties_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L237 */ _L237;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L242 */ _L242;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L243 */ _L243;
  L_internal_Type_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L249 */ _L249;
  L_internal_Type_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L248 */ _L248;
  L_internal_Type_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L247 */ _L247;
  NID_LRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L260 */ _L260;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L261 */ _L261;
  NID_C /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L262 */ _L262;
  NID_BG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L263 */ _L263;
  NID_LRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L264 */ _L264;
  NID_C /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L265 */ _L265;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L266 */ _L266;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L267 */ _L267;
  NID_LRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L268 */ _L268;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L269 */ _L269;
  positionedBG_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L270 */ _L270;
  Q_DIRLRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L274 */ _L274;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L275 */ _L275;
  Speed_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L276 */ _L276;
  T_internal_Type_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L301 */ _L301;
  trainPositionInfo_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L302 */ _L302;
  Speed_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L303 */ _L303;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L304 */ _L304;
  odometry_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L305 */ _L305;
  Q_DLRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L306 */ _L306;
  trainProperties_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L307 */ _L307;
  positionedBG_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L308 */ _L308;
  trainPositionInfo_T_TrainPosition_Types_Pck /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L309 */ _L309;
  kcg_bool /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L310 */ _L310;
  Q_DIRLRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L311 */ _L311;
  Q_DIRLRBG /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L312 */ _L312;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L313 */ _L313;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L314 */ _L314;
  kcg_int /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L315 */ _L315;
  kcg_int /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L316 */ _L316;
} outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg;

/* ===========  node initialization and cycle functions  =========== */
/* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes */
extern void calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::LRBG */positionedBG_T_TrainPosition_Types_Pck *LRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::prevLRBG */positionedBG_T_TrainPosition_Types_Pck *prevLRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainPositionInfo */trainPositionInfo_T_TrainPosition_Types_Pck *trainPositionInfo,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg *outC);

extern void calculateTrainpositionAttributes_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg *outC);

#endif /* _calculateTrainpositionAttributes_CalculateTrainPosition_Pkg_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainpositionAttributes_CalculateTrainPosition_Pkg.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

