/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "vincent_scenario_07_ctp_t_pck.h"

void vincent_scenario_07_reset_ctp_t_pck(
  outC_vincent_scenario_07_ctp_t_pck *outC)
{
  outC->init = kcg_true;
  /* 1 */ observeBG_reset_ctp_t_pck_t_engine(&outC->_2_Context_1);
  /* 3 */ observeBG_reset_ctp_t_pck_t_engine(&outC->Context_3);
  /* 4 */ observeBG_reset_ctp_t_pck_t_engine(&outC->Context_4);
  /* 5 */ observeBG_reset_ctp_t_pck_t_engine(&outC->Context_5);
  /* 2 */ observeBG_reset_ctp_t_pck_t_engine(&outC->Context_2);
  /* 1 */
  calculateTrainPosition_reset_CalculateTrainPosition_Pkg(&outC->_1_Context_1);
  /* 1 */ stimulator_reset_ctp_t_pck_t_engine(&outC->Context_1);
}

/* ctp_t_pck::vincent_scenario_07 */
void vincent_scenario_07_ctp_t_pck(outC_vincent_scenario_07_ctp_t_pck *outC)
{
  /* ctp_t_pck::vincent_scenario_07::LRBG */ positionedBG_T_TrainPosition_Types_Pck last_LRBG;
  
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->_L73,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cvTrack_Scenario_07_ctp_t_pck_t_engine);
  kcg_copy_odometryFactors_T_ctp_t_pck_t_engine(
    &outC->_L74,
    (odometryFactors_T_ctp_t_pck_t_engine *)
      &cvOdometryFactors_ctp_t_pck_t_engine);
  /* 1 */
  stimulator_ctp_t_pck_t_engine(&outC->_L73, &outC->_L74, &outC->Context_1);
  outC->_L21 = outC->Context_1.pos_true;
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L1, &outC->Context_1.odometry);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L10, &outC->Context_1.passedBG);
  if (outC->init) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &last_LRBG,
      (positionedBG_T_TrainPosition_Types_Pck *)
        &cNoPositionedBG_CalculateTrainPosition_Pkg);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&last_LRBG, &outC->LRBG);
  }
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L13, &last_LRBG);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L7,
    (positionedBG_T_TrainPosition_Types_Pck *)
      &cNoPositionedBG_CalculateTrainPosition_Pkg);
  outC->_L8 = kcg_false;
  kcg_copy_trainProperties_T_TrainPosition_Types_Pck(
    &outC->_L9,
    (trainProperties_T_TrainPosition_Types_Pck *)
      &cvTrainProperties_scenario_09_ctp_t_pck_t_engine);
  /* 1 */
  calculateTrainPosition_CalculateTrainPosition_Pkg(
    &outC->_L1,
    &outC->_L10,
    &outC->_L13,
    &outC->_L7,
    outC->_L8,
    &outC->_L9,
    &outC->_1_Context_1);
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->_L2,
    &outC->_1_Context_1.trainPosition);
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->_L3,
    &outC->_1_Context_1.trainPositionInfo);
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(
    &outC->_L4,
    &outC->_1_Context_1.BGs);
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(
    &outC->_L5,
    &outC->_1_Context_1.errors);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L14,
    &outC->_L3.trainPosition);
  outC->_L20 = outC->_L14.d_max;
  outC->_L19 = outC->_L14.d_min;
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L71, &outC->_L73[4]);
  /* 2 */
  observeBG_ctp_t_pck_t_engine(&outC->_L4, &outC->_L71, &outC->Context_2);
  outC->_L53 = outC->Context_2.loc_min;
  outC->_L54 = outC->Context_2.loc_nom;
  outC->_L55 = outC->Context_2.loc_max;
  outC->locBG_005_max = outC->_L55;
  outC->locBG_005_nom = outC->_L54;
  outC->locBG_005_min = outC->_L53;
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L70, &outC->_L73[3]);
  /* 5 */
  observeBG_ctp_t_pck_t_engine(&outC->_L4, &outC->_L70, &outC->Context_5);
  outC->_L65 = outC->Context_5.loc_min;
  outC->_L66 = outC->Context_5.loc_nom;
  outC->_L67 = outC->Context_5.loc_max;
  outC->locBG_004_max = outC->_L67;
  outC->locBG_004_nom = outC->_L66;
  outC->locBG_004_min = outC->_L65;
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L69, &outC->_L73[2]);
  /* 4 */
  observeBG_ctp_t_pck_t_engine(&outC->_L4, &outC->_L69, &outC->Context_4);
  outC->_L62 = outC->Context_4.loc_min;
  outC->_L63 = outC->Context_4.loc_nom;
  outC->_L64 = outC->Context_4.loc_max;
  outC->locBG_003_max = outC->_L64;
  outC->locBG_003_nom = outC->_L63;
  outC->locBG_003_min = outC->_L62;
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L68, &outC->_L73[1]);
  /* 3 */
  observeBG_ctp_t_pck_t_engine(&outC->_L4, &outC->_L68, &outC->Context_3);
  outC->_L59 = outC->Context_3.loc_min;
  outC->_L60 = outC->Context_3.loc_nom;
  outC->_L61 = outC->Context_3.loc_max;
  outC->locBG_002_max = outC->_L61;
  outC->locBG_002_nom = outC->_L60;
  outC->locBG_002_min = outC->_L59;
  kcg_copy_genPassedBG_T_ctp_t_pck_t_engine(&outC->_L52, &outC->_L73[0]);
  /* 1 */
  observeBG_ctp_t_pck_t_engine(&outC->_L4, &outC->_L52, &outC->_2_Context_1);
  outC->_L29 = outC->_2_Context_1.loc_min;
  outC->_L30 = outC->_2_Context_1.loc_nom;
  outC->_L31 = outC->_2_Context_1.loc_max;
  outC->locBG_001_max = outC->_L31;
  outC->locBG_001_nom = outC->_L30;
  outC->locBG_001_min = outC->_L29;
  outC->_L18 = outC->_L14.nominal;
  outC->_L23 = outC->_L18 + outC->_L20;
  outC->_L26 = outC->_L23 - outC->_L21;
  outC->_L22 = outC->_L18 + outC->_L19;
  outC->_L25 = outC->_L22 - outC->_L21;
  outC->_L24 = outC->_L18 - outC->_L21;
  outC->pos_max = outC->_L26;
  outC->pos_nom = outC->_L24;
  outC->pos_min = outC->_L25;
  outC->pos_true = outC->_L21;
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->trainPos, &outC->_L14);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L11,
    &outC->_L3.lastPassedLinkedBG);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->LRBG, &outC->_L11);
  kcg_copy_positionErrors_T_TrainPosition_Types_Pck(&outC->errors, &outC->_L5);
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->BGs, &outC->_L4);
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo,
    &outC->_L3);
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->trainPosition,
    &outC->_L2);
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** vincent_scenario_07_ctp_t_pck.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

