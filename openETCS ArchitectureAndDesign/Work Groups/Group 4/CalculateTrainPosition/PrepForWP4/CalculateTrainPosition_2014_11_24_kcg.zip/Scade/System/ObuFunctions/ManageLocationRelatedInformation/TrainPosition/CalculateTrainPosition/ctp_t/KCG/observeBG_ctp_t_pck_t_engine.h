/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _observeBG_ctp_t_pck_t_engine_H_
#define _observeBG_ctp_t_pck_t_engine_H_

#include "kcg_types.h"
#include "indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg.h"
#include "sub_2_distances_BasicLocationFunctions_Pkg.h"

/* =====================  no input structure  ====================== */


/* ctp_t_pck::t_engine::observeBG */
extern void observeBG_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::observeBG::positionedBGs */positionedBGs_T_TrainPosition_Types_Pck *positionedBGs,
  /* ctp_t_pck::t_engine::observeBG::BG_toBeObserved */genPassedBG_T_ctp_t_pck_t_engine *BG_toBeObserved,
  /* ctp_t_pck::t_engine::observeBG::loc_min */Location_T_Obu_BasicTypes_Pkg *loc_min,
  /* ctp_t_pck::t_engine::observeBG::loc_nom */Location_T_Obu_BasicTypes_Pkg *loc_nom,
  /* ctp_t_pck::t_engine::observeBG::loc_max */Location_T_Obu_BasicTypes_Pkg *loc_max);

#endif /* _observeBG_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** observeBG_ctp_t_pck_t_engine.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

