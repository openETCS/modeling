/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h"

void trainMovementSensor_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  outC->init = kcg_true;
}

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor */
void trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 _12_SM1_fired;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool _11_SM1_reset_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 _10_SM1_state_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction_loc */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg _9_direction_loc;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 _8_SM1_fired;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool _7_SM1_reset_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 _6_SM1_state_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction_loc */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg _5_direction_loc;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 _4_SM1_fired;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool _3_SM1_reset_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 _2_SM1_state_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction_loc */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg _1_direction_loc;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 SM1_fired;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool SM1_reset_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 SM1_state_nxt;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction_loc */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg direction_loc;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 _21_SM1_fired_strong;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool _20_SM1_reset_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 _19_SM1_state_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Unknown */ kcg_bool br_3_guard_SM1_Unknown;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Unknown */ kcg_bool br_2_guard_SM1_Unknown;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Unknown */ kcg_bool br_1_guard_SM1_Unknown;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 _18_SM1_fired_strong;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool _17_SM1_reset_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 _16_SM1_state_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Decreasing */ kcg_bool br_2_guard_SM1_Decreasing;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Decreasing */ kcg_bool br_1_guard_SM1_Decreasing;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 _15_SM1_fired_strong;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool _14_SM1_reset_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 _13_SM1_state_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Increasing */ kcg_bool br_2_guard_SM1_Increasing;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Increasing */ kcg_bool br_1_guard_SM1_Increasing;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_TR_SM1 SM1_fired_strong;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool SM1_reset_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SSM_ST_SM1 SM1_state_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Standstill */ kcg_bool br_2_guard_SM1_Standstill;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Standstill */ kcg_bool br_1_guard_SM1_Standstill;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */ odometry_T_Obu_BasicTypes_Pkg last_currentOdometry;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool SM1_reset_sel;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ kcg_bool SM1_reset_prv;
  
  if (outC->init) {
    kcg_copy_odometry_T_Obu_BasicTypes_Pkg(
      &last_currentOdometry,
      (odometry_T_Obu_BasicTypes_Pkg *)
        &cOdometryStartVal_CalculateTrainPosition_Pkg_Pos_Pkg);
  }
  else {
    kcg_copy_odometry_T_Obu_BasicTypes_Pkg(
      &last_currentOdometry,
      &outC->rem_currentOdometry);
  }
  if (outC->init) {
    outC->SM1_state_sel = SSM_st_Unknown_SM1;
  }
  else {
    outC->SM1_state_sel = outC->SM1_state_nxt;
  }
  switch (outC->SM1_state_sel) {
    case SSM_st_Increasing_SM1 :
      br_1_guard_SM1_Increasing = (*currentOdometry).speed < 0;
      break;
    case SSM_st_Standstill_SM1 :
      br_1_guard_SM1_Standstill = (*currentOdometry).speed > 0;
      br_2_guard_SM1_Standstill = (*currentOdometry).speed < 0;
      if (br_1_guard_SM1_Standstill) {
        SM1_state_act = SSM_st_Increasing_SM1;
      }
      else if (br_2_guard_SM1_Standstill) {
        SM1_state_act = SSM_st_Decreasing_SM1;
      }
      else {
        SM1_state_act = SSM_st_Standstill_SM1;
      }
      break;
    
  }
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L5, currentOdometry);
  outC->_L6 = outC->_L5.speed;
  outC->_L7 = cSpeed_0_CalculateTrainPosition_Pkg_Pos_Pkg;
  outC->_L8 = outC->_L6 == outC->_L7;
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L10, &last_currentOdometry);
  outC->_L12 = outC->_L10.speed;
  outC->_L11 = outC->_L7 == outC->_L12;
  outC->_L13 = outC->_L8 & outC->_L11;
  outC->standstillDetected = outC->_L13;
  switch (outC->SM1_state_sel) {
    case SSM_st_Unknown_SM1 :
      br_1_guard_SM1_Unknown = (*currentOdometry).speed < 0;
      br_2_guard_SM1_Unknown = (*currentOdometry).speed > 0;
      br_3_guard_SM1_Unknown = (*currentOdometry).speed == 0;
      if (br_1_guard_SM1_Unknown) {
        _19_SM1_state_act = SSM_st_Decreasing_SM1;
      }
      else if (br_2_guard_SM1_Unknown) {
        _19_SM1_state_act = SSM_st_Increasing_SM1;
      }
      else if (br_3_guard_SM1_Unknown) {
        _19_SM1_state_act = SSM_st_Standstill_SM1;
      }
      else {
        _19_SM1_state_act = SSM_st_Unknown_SM1;
      }
      outC->SM1_state_act = _19_SM1_state_act;
      break;
    case SSM_st_Decreasing_SM1 :
      br_1_guard_SM1_Decreasing = (*currentOdometry).speed > 0;
      br_2_guard_SM1_Decreasing = outC->standstillDetected;
      if (br_1_guard_SM1_Decreasing) {
        _16_SM1_state_act = SSM_st_Increasing_SM1;
      }
      else if (br_2_guard_SM1_Decreasing) {
        _16_SM1_state_act = SSM_st_Standstill_SM1;
      }
      else {
        _16_SM1_state_act = SSM_st_Decreasing_SM1;
      }
      outC->SM1_state_act = _16_SM1_state_act;
      break;
    case SSM_st_Increasing_SM1 :
      br_2_guard_SM1_Increasing = outC->standstillDetected;
      if (br_1_guard_SM1_Increasing) {
        _13_SM1_state_act = SSM_st_Decreasing_SM1;
      }
      else if (br_2_guard_SM1_Increasing) {
        _13_SM1_state_act = SSM_st_Standstill_SM1;
      }
      else {
        _13_SM1_state_act = SSM_st_Increasing_SM1;
      }
      outC->SM1_state_act = _13_SM1_state_act;
      break;
    case SSM_st_Standstill_SM1 :
      outC->SM1_state_act = SM1_state_act;
      break;
    
  }
  switch (outC->SM1_state_act) {
    case SSM_st_Unknown_SM1 :
      outC->_L1_SM1_Unknown = trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg;
      _9_direction_loc = outC->_L1_SM1_Unknown;
      outC->direction_loc = _9_direction_loc;
      break;
    case SSM_st_Decreasing_SM1 :
      outC->_L1_SM1_Decreasing =
        trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg;
      _5_direction_loc = outC->_L1_SM1_Decreasing;
      outC->direction_loc = _5_direction_loc;
      break;
    case SSM_st_Increasing_SM1 :
      outC->_L1_SM1_Increasing =
        trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg;
      _1_direction_loc = outC->_L1_SM1_Increasing;
      outC->direction_loc = _1_direction_loc;
      break;
    case SSM_st_Standstill_SM1 :
      outC->_L1_SM1_Standstill =
        trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg;
      direction_loc = outC->_L1_SM1_Standstill;
      outC->direction_loc = direction_loc;
      break;
    
  }
  outC->_L14 = outC->direction_loc;
  outC->direction = outC->_L14;
  switch (outC->SM1_state_sel) {
    case SSM_st_Unknown_SM1 :
      if (br_1_guard_SM1_Unknown) {
        _21_SM1_fired_strong = SSM_TR_Unknown_1_SM1;
      }
      else if (br_2_guard_SM1_Unknown) {
        _21_SM1_fired_strong = SSM_TR_Unknown_2_SM1;
      }
      else if (br_3_guard_SM1_Unknown) {
        _21_SM1_fired_strong = SSM_TR_Unknown_3_SM1;
      }
      else {
        _21_SM1_fired_strong = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _21_SM1_fired_strong;
      break;
    case SSM_st_Decreasing_SM1 :
      if (br_1_guard_SM1_Decreasing) {
        _18_SM1_fired_strong = SSM_TR_Decreasing_1_SM1;
      }
      else if (br_2_guard_SM1_Decreasing) {
        _18_SM1_fired_strong = SSM_TR_Decreasing_2_SM1;
      }
      else {
        _18_SM1_fired_strong = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _18_SM1_fired_strong;
      break;
    case SSM_st_Increasing_SM1 :
      if (br_1_guard_SM1_Increasing) {
        _15_SM1_fired_strong = SSM_TR_Increasing_1_SM1;
      }
      else if (br_2_guard_SM1_Increasing) {
        _15_SM1_fired_strong = SSM_TR_Increasing_2_SM1;
      }
      else {
        _15_SM1_fired_strong = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = _15_SM1_fired_strong;
      break;
    case SSM_st_Standstill_SM1 :
      if (br_1_guard_SM1_Standstill) {
        SM1_fired_strong = SSM_TR_Standstill_1_SM1;
      }
      else if (br_2_guard_SM1_Standstill) {
        SM1_fired_strong = SSM_TR_Standstill_2_SM1;
      }
      else {
        SM1_fired_strong = SSM_TR_no_trans_SM1;
      }
      outC->SM1_fired_strong = SM1_fired_strong;
      break;
    
  }
  switch (outC->SM1_state_act) {
    case SSM_st_Unknown_SM1 :
      _12_SM1_fired = outC->SM1_fired_strong;
      _11_SM1_reset_nxt = kcg_false;
      _10_SM1_state_nxt = SSM_st_Unknown_SM1;
      outC->SM1_fired = _12_SM1_fired;
      break;
    case SSM_st_Decreasing_SM1 :
      _8_SM1_fired = outC->SM1_fired_strong;
      _7_SM1_reset_nxt = kcg_false;
      _6_SM1_state_nxt = SSM_st_Decreasing_SM1;
      outC->SM1_fired = _8_SM1_fired;
      break;
    case SSM_st_Increasing_SM1 :
      _4_SM1_fired = outC->SM1_fired_strong;
      _3_SM1_reset_nxt = kcg_false;
      _2_SM1_state_nxt = SSM_st_Increasing_SM1;
      outC->SM1_fired = _4_SM1_fired;
      break;
    case SSM_st_Standstill_SM1 :
      SM1_fired = outC->SM1_fired_strong;
      SM1_reset_nxt = kcg_false;
      SM1_state_nxt = SSM_st_Standstill_SM1;
      outC->SM1_fired = SM1_fired;
      break;
    
  }
  if (outC->init) {
    SM1_reset_sel = kcg_false;
  }
  else {
    SM1_reset_sel = outC->SM1_reset_nxt;
  }
  switch (outC->SM1_state_act) {
    case SSM_st_Unknown_SM1 :
      outC->SM1_reset_nxt = _11_SM1_reset_nxt;
      outC->SM1_state_nxt = _10_SM1_state_nxt;
      break;
    case SSM_st_Decreasing_SM1 :
      outC->SM1_reset_nxt = _7_SM1_reset_nxt;
      outC->SM1_state_nxt = _6_SM1_state_nxt;
      break;
    case SSM_st_Increasing_SM1 :
      outC->SM1_reset_nxt = _3_SM1_reset_nxt;
      outC->SM1_state_nxt = _2_SM1_state_nxt;
      break;
    case SSM_st_Standstill_SM1 :
      outC->SM1_reset_nxt = SM1_reset_nxt;
      outC->SM1_state_nxt = SM1_state_nxt;
      break;
    
  }
  switch (outC->SM1_state_sel) {
    case SSM_st_Unknown_SM1 :
      if (br_1_guard_SM1_Unknown) {
        _20_SM1_reset_act = kcg_true;
      }
      else if (br_2_guard_SM1_Unknown) {
        _20_SM1_reset_act = kcg_true;
      }
      else {
        _20_SM1_reset_act = br_3_guard_SM1_Unknown;
      }
      break;
    case SSM_st_Decreasing_SM1 :
      if (br_1_guard_SM1_Decreasing) {
        _17_SM1_reset_act = kcg_true;
      }
      else {
        _17_SM1_reset_act = br_2_guard_SM1_Decreasing;
      }
      break;
    case SSM_st_Increasing_SM1 :
      if (br_1_guard_SM1_Increasing) {
        _14_SM1_reset_act = kcg_true;
      }
      else {
        _14_SM1_reset_act = br_2_guard_SM1_Increasing;
      }
      break;
    case SSM_st_Standstill_SM1 :
      if (br_1_guard_SM1_Standstill) {
        SM1_reset_act = kcg_true;
      }
      else {
        SM1_reset_act = br_2_guard_SM1_Standstill;
      }
      break;
    
  }
  if (outC->init) {
    SM1_reset_prv = kcg_false;
  }
  else {
    SM1_reset_prv = outC->SM1_reset_act;
  }
  switch (outC->SM1_state_sel) {
    case SSM_st_Unknown_SM1 :
      outC->SM1_reset_act = _20_SM1_reset_act;
      break;
    case SSM_st_Decreasing_SM1 :
      outC->SM1_reset_act = _17_SM1_reset_act;
      break;
    case SSM_st_Increasing_SM1 :
      outC->SM1_reset_act = _14_SM1_reset_act;
      break;
    case SSM_st_Standstill_SM1 :
      outC->SM1_reset_act = SM1_reset_act;
      break;
    
  }
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(
    &outC->rem_currentOdometry,
    currentOdometry);
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

