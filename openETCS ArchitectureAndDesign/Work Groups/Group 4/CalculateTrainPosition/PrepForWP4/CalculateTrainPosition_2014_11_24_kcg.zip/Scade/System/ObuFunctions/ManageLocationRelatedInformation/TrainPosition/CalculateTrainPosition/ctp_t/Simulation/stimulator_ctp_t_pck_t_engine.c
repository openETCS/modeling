/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "stimulator_ctp_t_pck_t_engine.h"

void stimulator_reset_ctp_t_pck_t_engine(
  outC_stimulator_ctp_t_pck_t_engine *outC)
{
  /* 1 */ genPassedBG_reset_ctp_t_pck_t_engine(&outC->_2_Context_1);
  /* 1 */ genOdometry_reset_ctp_t_pck_t_engine(&outC->_1_Context_1);
  /* 1 */ genLocation_reset_ctp_t_pck_t_engine(&outC->Context_1);
}

/* ctp_t_pck::t_engine::stimulator */
void stimulator_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::stimulator::trackDescription */genPassedBGs_T_ctp_t_pck_t_engine *trackDescription,
  /* ctp_t_pck::t_engine::stimulator::odometryProperties */odometryFactors_T_ctp_t_pck_t_engine *odometryProperties,
  outC_stimulator_ctp_t_pck_t_engine *outC)
{
  genPassedBGs_T_ctp_t_pck_t_engine noname;
  genPassedBGs_T_ctp_t_pck_t_engine _1_noname;
  genPassedBGs_T_ctp_t_pck_t_engine _2_noname;
  genPassedBGs_T_ctp_t_pck_t_engine _3_noname;
  genPassedBGs_T_ctp_t_pck_t_engine _4_noname;
  
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->_L9,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cTrack_3_linkedBGs_2_unlinkedBGs_far_ctp_t_pck_t_engine);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&_4_noname, &outC->_L9);
  kcg_copy_odometryFactors_T_ctp_t_pck_t_engine(
    &outC->_L10,
    odometryProperties);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&outC->_L11, trackDescription);
  /* 1 */ genLocation_ctp_t_pck_t_engine(&outC->Context_1);
  outC->_L1 = outC->Context_1.location;
  outC->_L2 = outC->Context_1.time;
  outC->pos_true = outC->_L1;
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->_L8,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cTrack_3_linkedBGs_2_unlinkedBGs_ctp_t_pck_t_engine);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&_3_noname, &outC->_L8);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->_L7,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cTrack_3_linkedBGs_withLinkingInfo_ctp_t_pck_t_engine);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&_2_noname, &outC->_L7);
  outC->truePosition = outC->_L1;
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->_L6,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cTrack_2_linkedBGs_withoutLinkingInfo_ctp_t_pck_t_engine);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&_1_noname, &outC->_L6);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->_L5,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cTrack_2_unlinkedBGs_ctp_t_pck_t_engine);
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(&noname, &outC->_L5);
  /* 1 */
  genOdometry_ctp_t_pck_t_engine(
    outC->_L1,
    outC->_L2,
    &outC->_L10,
    &outC->_1_Context_1);
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(
    &outC->_L3,
    &outC->_1_Context_1.odometry);
  /* 1 */
  genPassedBG_ctp_t_pck_t_engine(
    outC->_L1,
    &outC->_L3,
    &outC->_L11,
    &outC->_2_Context_1);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L4, &outC->_2_Context_1.passedBG);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->passedBG, &outC->_L4);
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->odometry, &outC->_L3);
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** stimulator_ctp_t_pck_t_engine.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

