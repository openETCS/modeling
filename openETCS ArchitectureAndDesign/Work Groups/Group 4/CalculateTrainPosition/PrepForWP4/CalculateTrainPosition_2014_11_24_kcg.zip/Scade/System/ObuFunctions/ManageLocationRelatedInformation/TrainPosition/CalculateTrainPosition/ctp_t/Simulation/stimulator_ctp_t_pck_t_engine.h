/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _stimulator_ctp_t_pck_t_engine_H_
#define _stimulator_ctp_t_pck_t_engine_H_

#include "kcg_types.h"
#include "genLocation_ctp_t_pck_t_engine.h"
#include "genOdometry_ctp_t_pck_t_engine.h"
#include "genPassedBG_ctp_t_pck_t_engine.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::pos_true */ pos_true;
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::odometry */ odometry;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::stimulator::passedBG */ passedBG;
  /* -----------------------   local probes  ------------------------- */
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::truePosition */ truePosition;
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_genPassedBG_ctp_t_pck_t_engine /* 1 */ _2_Context_1;
  outC_genOdometry_ctp_t_pck_t_engine /* 1 */ _1_Context_1;
  outC_genLocation_ctp_t_pck_t_engine /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::_L2 */ _L2;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::_L1 */ _L1;
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::_L3 */ _L3;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::stimulator::_L4 */ _L4;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L5 */ _L5;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L6 */ _L6;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L7 */ _L7;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L8 */ _L8;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L9 */ _L9;
  odometryFactors_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L10 */ _L10;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::_L11 */ _L11;
} outC_stimulator_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::stimulator */
extern void stimulator_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::stimulator::trackDescription */genPassedBGs_T_ctp_t_pck_t_engine *trackDescription,
  /* ctp_t_pck::t_engine::stimulator::odometryProperties */odometryFactors_T_ctp_t_pck_t_engine *odometryProperties,
  outC_stimulator_ctp_t_pck_t_engine *outC);

extern void stimulator_reset_ctp_t_pck_t_engine(
  outC_stimulator_ctp_t_pck_t_engine *outC);

#endif /* _stimulator_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** stimulator_ctp_t_pck_t_engine.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

