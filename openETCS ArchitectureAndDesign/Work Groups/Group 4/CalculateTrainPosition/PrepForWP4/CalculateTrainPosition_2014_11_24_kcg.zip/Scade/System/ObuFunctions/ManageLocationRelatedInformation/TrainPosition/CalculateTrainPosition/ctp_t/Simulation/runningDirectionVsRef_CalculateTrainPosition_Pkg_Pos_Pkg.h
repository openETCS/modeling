/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_H_
#define _runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_H_

#include "kcg_types.h"
#include "trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::trainRunningDirection */ trainRunningDirection;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg /* 1 */ Context_1;
  /* ------------------ clocks of observable data -------------------- */
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2 */ IfBlock2_clock;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock1 */ IfBlock1_clock;
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::then::_L1 */ _L1_IfBlock2;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else */ else_clock_IfBlock2;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else::else::_L1 */ _L12_IfBlock2;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else::else::_L2 */ _L2_IfBlock2;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else::else::_L3 */ _L3_IfBlock2;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else::else::_L4 */ _L4_IfBlock2;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else::else::_L6 */ _L6_IfBlock2;
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock2::else::then::_L1 */ _L11_IfBlock2;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock1::then::_L1 */ _L1_IfBlock1;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock1::else */ else_clock_IfBlock1;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock1::else::else::_L1 */ _L14_IfBlock1;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::IfBlock1::else::then::_L1 */ _L13_IfBlock1;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::currentDir */ currentDir;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refDir */ refDir;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::_L4 */ _L4;
  odometry_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::_L5 */ _L5;
} outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg;

/* ===========  node initialization and cycle functions  =========== */
/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef */
extern void runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refTrainRunningDirection */Q_DIRTRAIN refTrainRunningDirection,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refSpeed */Speed_T_Obu_BasicTypes_Pkg refSpeed,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

extern void runningDirectionVsRef_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

#endif /* _runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

