#ifndef CTP_T_TYPES_CONVERTION
#define CTP_T_TYPES_CONVERTION

#include "NewSmuTypes.h"

/****************************************************************
 ** SSM_ST_SM1 
 ****************************************************************/
extern int SSM_ST_SM1_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_SSM_ST_SM1_string(const char *str, char **endptr);
extern int string_to_SSM_ST_SM1(const char *str, void *pValue, char **endptr);
extern int is_SSM_ST_SM1_allow_double_convertion();
extern int SSM_ST_SM1_to_double(const void *pValue, double *nValue);
extern int get_SSM_ST_SM1_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_SSM_ST_SM1(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_SSM_ST_SM1_default_value(void *pValue);
extern SimTypeUtils _Type_SSM_ST_SM1_Utils;

/****************************************************************
 ** SSM_TR_SM1 
 ****************************************************************/
extern int SSM_TR_SM1_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_SSM_TR_SM1_string(const char *str, char **endptr);
extern int string_to_SSM_TR_SM1(const char *str, void *pValue, char **endptr);
extern int is_SSM_TR_SM1_allow_double_convertion();
extern int SSM_TR_SM1_to_double(const void *pValue, double *nValue);
extern int get_SSM_TR_SM1_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_SSM_TR_SM1(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_SSM_TR_SM1_default_value(void *pValue);
extern SimTypeUtils _Type_SSM_TR_SM1_Utils;

/****************************************************************
 ** kcg_real 
 ****************************************************************/
extern int kcg_real_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_kcg_real_string(const char *str, char **endptr);
extern int string_to_kcg_real(const char *str, void *pValue, char **endptr);
extern int is_kcg_real_allow_double_convertion();
extern int kcg_real_to_double(const void *pValue, double *nValue);
extern int get_kcg_real_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_kcg_real(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_kcg_real_default_value(void *pValue);
extern SimTypeUtils _Type_kcg_real_Utils;

/****************************************************************
 ** kcg_bool 
 ****************************************************************/
extern int kcg_bool_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_kcg_bool_string(const char *str, char **endptr);
extern int string_to_kcg_bool(const char *str, void *pValue, char **endptr);
extern int is_kcg_bool_allow_double_convertion();
extern int kcg_bool_to_double(const void *pValue, double *nValue);
extern int get_kcg_bool_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_kcg_bool(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_kcg_bool_default_value(void *pValue);
extern SimTypeUtils _Type_kcg_bool_Utils;

/****************************************************************
 ** kcg_char 
 ****************************************************************/
extern int kcg_char_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_kcg_char_string(const char *str, char **endptr);
extern int string_to_kcg_char(const char *str, void *pValue, char **endptr);
extern int is_kcg_char_allow_double_convertion();
extern int kcg_char_to_double(const void *pValue, double *nValue);
extern int get_kcg_char_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_kcg_char(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_kcg_char_default_value(void *pValue);
extern SimTypeUtils _Type_kcg_char_Utils;

/****************************************************************
 ** kcg_int 
 ****************************************************************/
extern int kcg_int_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_kcg_int_string(const char *str, char **endptr);
extern int string_to_kcg_int(const char *str, void *pValue, char **endptr);
extern int is_kcg_int_allow_double_convertion();
extern int kcg_int_to_double(const void *pValue, double *nValue);
extern int get_kcg_int_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_kcg_int(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_kcg_int_default_value(void *pValue);
extern SimTypeUtils _Type_kcg_int_Utils;

/****************************************************************
 ** struct__5578 
 ****************************************************************/
extern int struct__5578_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5578_string(const char *str, char **endptr);
extern int string_to_struct__5578(const char *str, void *pValue, char **endptr);
extern int is_struct__5578_allow_double_convertion();
extern int struct__5578_to_double(const void *pValue, double *nValue);
extern int get_struct__5578_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5578(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5578_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5578_Utils;

/****************************************************************
 ** struct__5584 
 ****************************************************************/
extern int struct__5584_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5584_string(const char *str, char **endptr);
extern int string_to_struct__5584(const char *str, void *pValue, char **endptr);
extern int is_struct__5584_allow_double_convertion();
extern int struct__5584_to_double(const void *pValue, double *nValue);
extern int get_struct__5584_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5584(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5584_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5584_Utils;

/****************************************************************
 ** struct__5600 
 ****************************************************************/
extern int struct__5600_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5600_string(const char *str, char **endptr);
extern int string_to_struct__5600(const char *str, void *pValue, char **endptr);
extern int is_struct__5600_allow_double_convertion();
extern int struct__5600_to_double(const void *pValue, double *nValue);
extern int get_struct__5600_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5600(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5600_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5600_Utils;

/****************************************************************
 ** struct__5609 
 ****************************************************************/
extern int struct__5609_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5609_string(const char *str, char **endptr);
extern int string_to_struct__5609(const char *str, void *pValue, char **endptr);
extern int is_struct__5609_allow_double_convertion();
extern int struct__5609_to_double(const void *pValue, double *nValue);
extern int get_struct__5609_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5609(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5609_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5609_Utils;

/****************************************************************
 ** array__5615 
 ****************************************************************/
extern int array__5615_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5615_string(const char *str, char **endptr);
extern int string_to_array__5615(const char *str, void *pValue, char **endptr);
extern int is_array__5615_allow_double_convertion();
extern int array__5615_to_double(const void *pValue, double *nValue);
extern int get_array__5615_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5615(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5615_default_value(void *pValue);
extern SimTypeUtils _Type_array__5615_Utils;

/****************************************************************
 ** struct__5618 
 ****************************************************************/
extern int struct__5618_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5618_string(const char *str, char **endptr);
extern int string_to_struct__5618(const char *str, void *pValue, char **endptr);
extern int is_struct__5618_allow_double_convertion();
extern int struct__5618_to_double(const void *pValue, double *nValue);
extern int get_struct__5618_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5618(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5618_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5618_Utils;

/****************************************************************
 ** struct__5629 
 ****************************************************************/
extern int struct__5629_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5629_string(const char *str, char **endptr);
extern int string_to_struct__5629(const char *str, void *pValue, char **endptr);
extern int is_struct__5629_allow_double_convertion();
extern int struct__5629_to_double(const void *pValue, double *nValue);
extern int get_struct__5629_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5629(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5629_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5629_Utils;

/****************************************************************
 ** struct__5642 
 ****************************************************************/
extern int struct__5642_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5642_string(const char *str, char **endptr);
extern int string_to_struct__5642(const char *str, void *pValue, char **endptr);
extern int is_struct__5642_allow_double_convertion();
extern int struct__5642_to_double(const void *pValue, double *nValue);
extern int get_struct__5642_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5642(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5642_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5642_Utils;

/****************************************************************
 ** struct__5653 
 ****************************************************************/
extern int struct__5653_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5653_string(const char *str, char **endptr);
extern int string_to_struct__5653(const char *str, void *pValue, char **endptr);
extern int is_struct__5653_allow_double_convertion();
extern int struct__5653_to_double(const void *pValue, double *nValue);
extern int get_struct__5653_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5653(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5653_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5653_Utils;

/****************************************************************
 ** struct__5664 
 ****************************************************************/
extern int struct__5664_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5664_string(const char *str, char **endptr);
extern int string_to_struct__5664(const char *str, void *pValue, char **endptr);
extern int is_struct__5664_allow_double_convertion();
extern int struct__5664_to_double(const void *pValue, double *nValue);
extern int get_struct__5664_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5664(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5664_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5664_Utils;

/****************************************************************
 ** struct__5681 
 ****************************************************************/
extern int struct__5681_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5681_string(const char *str, char **endptr);
extern int string_to_struct__5681(const char *str, void *pValue, char **endptr);
extern int is_struct__5681_allow_double_convertion();
extern int struct__5681_to_double(const void *pValue, double *nValue);
extern int get_struct__5681_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5681(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5681_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5681_Utils;

/****************************************************************
 ** array__5687 
 ****************************************************************/
extern int array__5687_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5687_string(const char *str, char **endptr);
extern int string_to_array__5687(const char *str, void *pValue, char **endptr);
extern int is_array__5687_allow_double_convertion();
extern int array__5687_to_double(const void *pValue, double *nValue);
extern int get_array__5687_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5687(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5687_default_value(void *pValue);
extern SimTypeUtils _Type_array__5687_Utils;

/****************************************************************
 ** struct__5690 
 ****************************************************************/
extern int struct__5690_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5690_string(const char *str, char **endptr);
extern int string_to_struct__5690(const char *str, void *pValue, char **endptr);
extern int is_struct__5690_allow_double_convertion();
extern int struct__5690_to_double(const void *pValue, double *nValue);
extern int get_struct__5690_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5690(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5690_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5690_Utils;

/****************************************************************
 ** struct__5701 
 ****************************************************************/
extern int struct__5701_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5701_string(const char *str, char **endptr);
extern int string_to_struct__5701(const char *str, void *pValue, char **endptr);
extern int is_struct__5701_allow_double_convertion();
extern int struct__5701_to_double(const void *pValue, double *nValue);
extern int get_struct__5701_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5701(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5701_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5701_Utils;

/****************************************************************
 ** struct__5708 
 ****************************************************************/
extern int struct__5708_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5708_string(const char *str, char **endptr);
extern int string_to_struct__5708(const char *str, void *pValue, char **endptr);
extern int is_struct__5708_allow_double_convertion();
extern int struct__5708_to_double(const void *pValue, double *nValue);
extern int get_struct__5708_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5708(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5708_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5708_Utils;

/****************************************************************
 ** struct__5714 
 ****************************************************************/
extern int struct__5714_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5714_string(const char *str, char **endptr);
extern int string_to_struct__5714(const char *str, void *pValue, char **endptr);
extern int is_struct__5714_allow_double_convertion();
extern int struct__5714_to_double(const void *pValue, double *nValue);
extern int get_struct__5714_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5714(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5714_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5714_Utils;

/****************************************************************
 ** struct__5723 
 ****************************************************************/
extern int struct__5723_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5723_string(const char *str, char **endptr);
extern int string_to_struct__5723(const char *str, void *pValue, char **endptr);
extern int is_struct__5723_allow_double_convertion();
extern int struct__5723_to_double(const void *pValue, double *nValue);
extern int get_struct__5723_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5723(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5723_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5723_Utils;

/****************************************************************
 ** array__5729 
 ****************************************************************/
extern int array__5729_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5729_string(const char *str, char **endptr);
extern int string_to_array__5729(const char *str, void *pValue, char **endptr);
extern int is_array__5729_allow_double_convertion();
extern int array__5729_to_double(const void *pValue, double *nValue);
extern int get_array__5729_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5729(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5729_default_value(void *pValue);
extern SimTypeUtils _Type_array__5729_Utils;

/****************************************************************
 ** struct__5732 
 ****************************************************************/
extern int struct__5732_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5732_string(const char *str, char **endptr);
extern int string_to_struct__5732(const char *str, void *pValue, char **endptr);
extern int is_struct__5732_allow_double_convertion();
extern int struct__5732_to_double(const void *pValue, double *nValue);
extern int get_struct__5732_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5732(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5732_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5732_Utils;

/****************************************************************
 ** array__5740 
 ****************************************************************/
extern int array__5740_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5740_string(const char *str, char **endptr);
extern int string_to_array__5740(const char *str, void *pValue, char **endptr);
extern int is_array__5740_allow_double_convertion();
extern int array__5740_to_double(const void *pValue, double *nValue);
extern int get_array__5740_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5740(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5740_default_value(void *pValue);
extern SimTypeUtils _Type_array__5740_Utils;

/****************************************************************
 ** struct__5743 
 ****************************************************************/
extern int struct__5743_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5743_string(const char *str, char **endptr);
extern int string_to_struct__5743(const char *str, void *pValue, char **endptr);
extern int is_struct__5743_allow_double_convertion();
extern int struct__5743_to_double(const void *pValue, double *nValue);
extern int get_struct__5743_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5743(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5743_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5743_Utils;

/****************************************************************
 ** struct__5748 
 ****************************************************************/
extern int struct__5748_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5748_string(const char *str, char **endptr);
extern int string_to_struct__5748(const char *str, void *pValue, char **endptr);
extern int is_struct__5748_allow_double_convertion();
extern int struct__5748_to_double(const void *pValue, double *nValue);
extern int get_struct__5748_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5748(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5748_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5748_Utils;

/****************************************************************
 ** array__5753 
 ****************************************************************/
extern int array__5753_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5753_string(const char *str, char **endptr);
extern int string_to_array__5753(const char *str, void *pValue, char **endptr);
extern int is_array__5753_allow_double_convertion();
extern int array__5753_to_double(const void *pValue, double *nValue);
extern int get_array__5753_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5753(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5753_default_value(void *pValue);
extern SimTypeUtils _Type_array__5753_Utils;

/****************************************************************
 ** struct__5756 
 ****************************************************************/
extern int struct__5756_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_struct__5756_string(const char *str, char **endptr);
extern int string_to_struct__5756(const char *str, void *pValue, char **endptr);
extern int is_struct__5756_allow_double_convertion();
extern int struct__5756_to_double(const void *pValue, double *nValue);
extern int get_struct__5756_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_struct__5756(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_struct__5756_default_value(void *pValue);
extern SimTypeUtils _Type_struct__5756_Utils;

/****************************************************************
 ** array__5762 
 ****************************************************************/
extern int array__5762_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5762_string(const char *str, char **endptr);
extern int string_to_array__5762(const char *str, void *pValue, char **endptr);
extern int is_array__5762_allow_double_convertion();
extern int array__5762_to_double(const void *pValue, double *nValue);
extern int get_array__5762_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5762(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5762_default_value(void *pValue);
extern SimTypeUtils _Type_array__5762_Utils;

/****************************************************************
 ** array_int_8 
 ****************************************************************/
extern int array_int_8_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array_int_8_string(const char *str, char **endptr);
extern int string_to_array_int_8(const char *str, void *pValue, char **endptr);
extern int is_array_int_8_allow_double_convertion();
extern int array_int_8_to_double(const void *pValue, double *nValue);
extern int get_array_int_8_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array_int_8(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array_int_8_default_value(void *pValue);
extern SimTypeUtils _Type_array_int_8_Utils;

/****************************************************************
 ** array__5768 
 ****************************************************************/
extern int array__5768_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5768_string(const char *str, char **endptr);
extern int string_to_array__5768(const char *str, void *pValue, char **endptr);
extern int is_array__5768_allow_double_convertion();
extern int array__5768_to_double(const void *pValue, double *nValue);
extern int get_array__5768_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5768(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5768_default_value(void *pValue);
extern SimTypeUtils _Type_array__5768_Utils;

/****************************************************************
 ** array__5771 
 ****************************************************************/
extern int array__5771_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5771_string(const char *str, char **endptr);
extern int string_to_array__5771(const char *str, void *pValue, char **endptr);
extern int is_array__5771_allow_double_convertion();
extern int array__5771_to_double(const void *pValue, double *nValue);
extern int get_array__5771_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5771(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5771_default_value(void *pValue);
extern SimTypeUtils _Type_array__5771_Utils;

/****************************************************************
 ** array_bool_8 
 ****************************************************************/
extern int array_bool_8_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array_bool_8_string(const char *str, char **endptr);
extern int string_to_array_bool_8(const char *str, void *pValue, char **endptr);
extern int is_array_bool_8_allow_double_convertion();
extern int array_bool_8_to_double(const void *pValue, double *nValue);
extern int get_array_bool_8_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array_bool_8(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array_bool_8_default_value(void *pValue);
extern SimTypeUtils _Type_array_bool_8_Utils;

/****************************************************************
 ** array__5777 
 ****************************************************************/
extern int array__5777_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5777_string(const char *str, char **endptr);
extern int string_to_array__5777(const char *str, void *pValue, char **endptr);
extern int is_array__5777_allow_double_convertion();
extern int array__5777_to_double(const void *pValue, double *nValue);
extern int get_array__5777_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5777(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5777_default_value(void *pValue);
extern SimTypeUtils _Type_array__5777_Utils;

/****************************************************************
 ** array__5780 
 ****************************************************************/
extern int array__5780_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array__5780_string(const char *str, char **endptr);
extern int string_to_array__5780(const char *str, void *pValue, char **endptr);
extern int is_array__5780_allow_double_convertion();
extern int array__5780_to_double(const void *pValue, double *nValue);
extern int get_array__5780_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array__5780(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array__5780_default_value(void *pValue);
extern SimTypeUtils _Type_array__5780_Utils;

/****************************************************************
 ** array_int_10 
 ****************************************************************/
extern int array_int_10_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_array_int_10_string(const char *str, char **endptr);
extern int string_to_array_int_10(const char *str, void *pValue, char **endptr);
extern int is_array_int_10_allow_double_convertion();
extern int array_int_10_to_double(const void *pValue, double *nValue);
extern int get_array_int_10_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_array_int_10(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_array_int_10_default_value(void *pValue);
extern SimTypeUtils _Type_array_int_10_Utils;

/****************************************************************
 ** Q_UPDOWN 
 ****************************************************************/
extern int Q_UPDOWN_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_UPDOWN_string(const char *str, char **endptr);
extern int string_to_Q_UPDOWN(const char *str, void *pValue, char **endptr);
extern int is_Q_UPDOWN_allow_double_convertion();
extern int Q_UPDOWN_to_double(const void *pValue, double *nValue);
extern int get_Q_UPDOWN_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_UPDOWN(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_UPDOWN_default_value(void *pValue);
extern SimTypeUtils _Type_Q_UPDOWN_Utils;

/****************************************************************
 ** M_VERSION 
 ****************************************************************/
extern int M_VERSION_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_M_VERSION_string(const char *str, char **endptr);
extern int string_to_M_VERSION(const char *str, void *pValue, char **endptr);
extern int is_M_VERSION_allow_double_convertion();
extern int M_VERSION_to_double(const void *pValue, double *nValue);
extern int get_M_VERSION_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_M_VERSION(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_M_VERSION_default_value(void *pValue);
extern SimTypeUtils _Type_M_VERSION_Utils;

/****************************************************************
 ** Q_MEDIA 
 ****************************************************************/
extern int Q_MEDIA_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_MEDIA_string(const char *str, char **endptr);
extern int string_to_Q_MEDIA(const char *str, void *pValue, char **endptr);
extern int is_Q_MEDIA_allow_double_convertion();
extern int Q_MEDIA_to_double(const void *pValue, double *nValue);
extern int get_Q_MEDIA_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_MEDIA(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_MEDIA_default_value(void *pValue);
extern SimTypeUtils _Type_Q_MEDIA_Utils;

/****************************************************************
 ** N_TOTAL 
 ****************************************************************/
extern int N_TOTAL_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_N_TOTAL_string(const char *str, char **endptr);
extern int string_to_N_TOTAL(const char *str, void *pValue, char **endptr);
extern int is_N_TOTAL_allow_double_convertion();
extern int N_TOTAL_to_double(const void *pValue, double *nValue);
extern int get_N_TOTAL_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_N_TOTAL(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_N_TOTAL_default_value(void *pValue);
extern SimTypeUtils _Type_N_TOTAL_Utils;

/****************************************************************
 ** M_MCOUNT 
 ****************************************************************/
extern int M_MCOUNT_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_M_MCOUNT_string(const char *str, char **endptr);
extern int string_to_M_MCOUNT(const char *str, void *pValue, char **endptr);
extern int is_M_MCOUNT_allow_double_convertion();
extern int M_MCOUNT_to_double(const void *pValue, double *nValue);
extern int get_M_MCOUNT_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_M_MCOUNT(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_M_MCOUNT_default_value(void *pValue);
extern SimTypeUtils _Type_M_MCOUNT_Utils;

/****************************************************************
 ** NID_C 
 ****************************************************************/
extern int NID_C_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_C_string(const char *str, char **endptr);
extern int string_to_NID_C(const char *str, void *pValue, char **endptr);
extern int is_NID_C_allow_double_convertion();
extern int NID_C_to_double(const void *pValue, double *nValue);
extern int get_NID_C_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_C(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_C_default_value(void *pValue);
extern SimTypeUtils _Type_NID_C_Utils;

/****************************************************************
 ** NID_BG 
 ****************************************************************/
extern int NID_BG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_BG_string(const char *str, char **endptr);
extern int string_to_NID_BG(const char *str, void *pValue, char **endptr);
extern int is_NID_BG_allow_double_convertion();
extern int NID_BG_to_double(const void *pValue, double *nValue);
extern int get_NID_BG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_BG(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_BG_default_value(void *pValue);
extern SimTypeUtils _Type_NID_BG_Utils;

/****************************************************************
 ** Q_LINK 
 ****************************************************************/
extern int Q_LINK_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_LINK_string(const char *str, char **endptr);
extern int string_to_Q_LINK(const char *str, void *pValue, char **endptr);
extern int is_Q_LINK_allow_double_convertion();
extern int Q_LINK_to_double(const void *pValue, double *nValue);
extern int get_Q_LINK_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_LINK(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_LINK_default_value(void *pValue);
extern SimTypeUtils _Type_Q_LINK_Utils;

/****************************************************************
 ** NID_LRBG 
 ****************************************************************/
extern int NID_LRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_LRBG_string(const char *str, char **endptr);
extern int string_to_NID_LRBG(const char *str, void *pValue, char **endptr);
extern int is_NID_LRBG_allow_double_convertion();
extern int NID_LRBG_to_double(const void *pValue, double *nValue);
extern int get_NID_LRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_LRBG(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_LRBG_default_value(void *pValue);
extern SimTypeUtils _Type_NID_LRBG_Utils;

/****************************************************************
 ** NID_PACKET 
 ****************************************************************/
extern int NID_PACKET_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_PACKET_string(const char *str, char **endptr);
extern int string_to_NID_PACKET(const char *str, void *pValue, char **endptr);
extern int is_NID_PACKET_allow_double_convertion();
extern int NID_PACKET_to_double(const void *pValue, double *nValue);
extern int get_NID_PACKET_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_PACKET(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_PACKET_default_value(void *pValue);
extern SimTypeUtils _Type_NID_PACKET_Utils;

/****************************************************************
 ** Q_DIR 
 ****************************************************************/
extern int Q_DIR_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_DIR_string(const char *str, char **endptr);
extern int string_to_Q_DIR(const char *str, void *pValue, char **endptr);
extern int is_Q_DIR_allow_double_convertion();
extern int Q_DIR_to_double(const void *pValue, double *nValue);
extern int get_Q_DIR_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_DIR(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_DIR_default_value(void *pValue);
extern SimTypeUtils _Type_Q_DIR_Utils;

/****************************************************************
 ** L_PACKET 
 ****************************************************************/
extern int L_PACKET_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_L_PACKET_string(const char *str, char **endptr);
extern int string_to_L_PACKET(const char *str, void *pValue, char **endptr);
extern int is_L_PACKET_allow_double_convertion();
extern int L_PACKET_to_double(const void *pValue, double *nValue);
extern int get_L_PACKET_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_L_PACKET(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_L_PACKET_default_value(void *pValue);
extern SimTypeUtils _Type_L_PACKET_Utils;

/****************************************************************
 ** Q_SCALE 
 ****************************************************************/
extern int Q_SCALE_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_SCALE_string(const char *str, char **endptr);
extern int string_to_Q_SCALE(const char *str, void *pValue, char **endptr);
extern int is_Q_SCALE_allow_double_convertion();
extern int Q_SCALE_to_double(const void *pValue, double *nValue);
extern int get_Q_SCALE_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_SCALE(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_SCALE_default_value(void *pValue);
extern SimTypeUtils _Type_Q_SCALE_Utils;

/****************************************************************
 ** D_LINK 
 ****************************************************************/
extern int D_LINK_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_D_LINK_string(const char *str, char **endptr);
extern int string_to_D_LINK(const char *str, void *pValue, char **endptr);
extern int is_D_LINK_allow_double_convertion();
extern int D_LINK_to_double(const void *pValue, double *nValue);
extern int get_D_LINK_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_D_LINK(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_D_LINK_default_value(void *pValue);
extern SimTypeUtils _Type_D_LINK_Utils;

/****************************************************************
 ** Q_NEWCOUNTRY 
 ****************************************************************/
extern int Q_NEWCOUNTRY_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_NEWCOUNTRY_string(const char *str, char **endptr);
extern int string_to_Q_NEWCOUNTRY(const char *str, void *pValue, char **endptr);
extern int is_Q_NEWCOUNTRY_allow_double_convertion();
extern int Q_NEWCOUNTRY_to_double(const void *pValue, double *nValue);
extern int get_Q_NEWCOUNTRY_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_NEWCOUNTRY(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_NEWCOUNTRY_default_value(void *pValue);
extern SimTypeUtils _Type_Q_NEWCOUNTRY_Utils;

/****************************************************************
 ** Q_LINKORIENTATION 
 ****************************************************************/
extern int Q_LINKORIENTATION_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_LINKORIENTATION_string(const char *str, char **endptr);
extern int string_to_Q_LINKORIENTATION(const char *str, void *pValue, char **endptr);
extern int is_Q_LINKORIENTATION_allow_double_convertion();
extern int Q_LINKORIENTATION_to_double(const void *pValue, double *nValue);
extern int get_Q_LINKORIENTATION_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_LINKORIENTATION(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_LINKORIENTATION_default_value(void *pValue);
extern SimTypeUtils _Type_Q_LINKORIENTATION_Utils;

/****************************************************************
 ** Q_LINKREACTION 
 ****************************************************************/
extern int Q_LINKREACTION_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_LINKREACTION_string(const char *str, char **endptr);
extern int string_to_Q_LINKREACTION(const char *str, void *pValue, char **endptr);
extern int is_Q_LINKREACTION_allow_double_convertion();
extern int Q_LINKREACTION_to_double(const void *pValue, double *nValue);
extern int get_Q_LINKREACTION_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_LINKREACTION(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_LINKREACTION_default_value(void *pValue);
extern SimTypeUtils _Type_Q_LINKREACTION_Utils;

/****************************************************************
 ** Q_LOCACC 
 ****************************************************************/
extern int Q_LOCACC_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_LOCACC_string(const char *str, char **endptr);
extern int string_to_Q_LOCACC(const char *str, void *pValue, char **endptr);
extern int is_Q_LOCACC_allow_double_convertion();
extern int Q_LOCACC_to_double(const void *pValue, double *nValue);
extern int get_Q_LOCACC_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_LOCACC(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_LOCACC_default_value(void *pValue);
extern SimTypeUtils _Type_Q_LOCACC_Utils;

/****************************************************************
 ** Q_DIRLRBG 
 ****************************************************************/
extern int Q_DIRLRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_DIRLRBG_string(const char *str, char **endptr);
extern int string_to_Q_DIRLRBG(const char *str, void *pValue, char **endptr);
extern int is_Q_DIRLRBG_allow_double_convertion();
extern int Q_DIRLRBG_to_double(const void *pValue, double *nValue);
extern int get_Q_DIRLRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_DIRLRBG(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_DIRLRBG_default_value(void *pValue);
extern SimTypeUtils _Type_Q_DIRLRBG_Utils;

/****************************************************************
 ** Q_DIRTRAIN 
 ****************************************************************/
extern int Q_DIRTRAIN_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_DIRTRAIN_string(const char *str, char **endptr);
extern int string_to_Q_DIRTRAIN(const char *str, void *pValue, char **endptr);
extern int is_Q_DIRTRAIN_allow_double_convertion();
extern int Q_DIRTRAIN_to_double(const void *pValue, double *nValue);
extern int get_Q_DIRTRAIN_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_DIRTRAIN(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_DIRTRAIN_default_value(void *pValue);
extern SimTypeUtils _Type_Q_DIRTRAIN_Utils;

/****************************************************************
 ** NID_ENGINE 
 ****************************************************************/
extern int NID_ENGINE_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_ENGINE_string(const char *str, char **endptr);
extern int string_to_NID_ENGINE(const char *str, void *pValue, char **endptr);
extern int is_NID_ENGINE_allow_double_convertion();
extern int NID_ENGINE_to_double(const void *pValue, double *nValue);
extern int get_NID_ENGINE_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_ENGINE(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_ENGINE_default_value(void *pValue);
extern SimTypeUtils _Type_NID_ENGINE_Utils;

/****************************************************************
 ** NID_OPERATIONAL 
 ****************************************************************/
extern int NID_OPERATIONAL_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_OPERATIONAL_string(const char *str, char **endptr);
extern int string_to_NID_OPERATIONAL(const char *str, void *pValue, char **endptr);
extern int is_NID_OPERATIONAL_allow_double_convertion();
extern int NID_OPERATIONAL_to_double(const void *pValue, double *nValue);
extern int get_NID_OPERATIONAL_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_OPERATIONAL(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_OPERATIONAL_default_value(void *pValue);
extern SimTypeUtils _Type_NID_OPERATIONAL_Utils;

/****************************************************************
 ** L_TRAIN 
 ****************************************************************/
extern int L_TRAIN_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_L_TRAIN_string(const char *str, char **endptr);
extern int string_to_L_TRAIN(const char *str, void *pValue, char **endptr);
extern int is_L_TRAIN_allow_double_convertion();
extern int L_TRAIN_to_double(const void *pValue, double *nValue);
extern int get_L_TRAIN_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_L_TRAIN(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_L_TRAIN_default_value(void *pValue);
extern SimTypeUtils _Type_L_TRAIN_Utils;

/****************************************************************
 ** Q_NVLOCACC 
 ****************************************************************/
extern int Q_NVLOCACC_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_NVLOCACC_string(const char *str, char **endptr);
extern int string_to_Q_NVLOCACC(const char *str, void *pValue, char **endptr);
extern int is_Q_NVLOCACC_allow_double_convertion();
extern int Q_NVLOCACC_to_double(const void *pValue, double *nValue);
extern int get_Q_NVLOCACC_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_NVLOCACC(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_NVLOCACC_default_value(void *pValue);
extern SimTypeUtils _Type_Q_NVLOCACC_Utils;

/****************************************************************
 ** NID_PRVLRBG 
 ****************************************************************/
extern int NID_PRVLRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_NID_PRVLRBG_string(const char *str, char **endptr);
extern int string_to_NID_PRVLRBG(const char *str, void *pValue, char **endptr);
extern int is_NID_PRVLRBG_allow_double_convertion();
extern int NID_PRVLRBG_to_double(const void *pValue, double *nValue);
extern int get_NID_PRVLRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_NID_PRVLRBG(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_NID_PRVLRBG_default_value(void *pValue);
extern SimTypeUtils _Type_NID_PRVLRBG_Utils;

/****************************************************************
 ** Q_DLRBG 
 ****************************************************************/
extern int Q_DLRBG_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Q_DLRBG_string(const char *str, char **endptr);
extern int string_to_Q_DLRBG(const char *str, void *pValue, char **endptr);
extern int is_Q_DLRBG_allow_double_convertion();
extern int Q_DLRBG_to_double(const void *pValue, double *nValue);
extern int get_Q_DLRBG_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Q_DLRBG(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Q_DLRBG_default_value(void *pValue);
extern SimTypeUtils _Type_Q_DLRBG_Utils;

/****************************************************************
 ** odometryFactors_T_ctp_t_pck_t_engine 
 ****************************************************************/
extern int odometryFactors_T_ctp_t_pck_t_engine_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_odometryFactors_T_ctp_t_pck_t_engine_string(const char *str, char **endptr);
extern int string_to_odometryFactors_T_ctp_t_pck_t_engine(const char *str, void *pValue, char **endptr);
extern int is_odometryFactors_T_ctp_t_pck_t_engine_allow_double_convertion();
extern int odometryFactors_T_ctp_t_pck_t_engine_to_double(const void *pValue, double *nValue);
extern int get_odometryFactors_T_ctp_t_pck_t_engine_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_odometryFactors_T_ctp_t_pck_t_engine(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_odometryFactors_T_ctp_t_pck_t_engine_default_value(void *pValue);
extern SimTypeUtils _Type_odometryFactors_T_ctp_t_pck_t_engine_Utils;

/****************************************************************
 ** genPassedBG_T_ctp_t_pck_t_engine 
 ****************************************************************/
extern int genPassedBG_T_ctp_t_pck_t_engine_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_genPassedBG_T_ctp_t_pck_t_engine_string(const char *str, char **endptr);
extern int string_to_genPassedBG_T_ctp_t_pck_t_engine(const char *str, void *pValue, char **endptr);
extern int is_genPassedBG_T_ctp_t_pck_t_engine_allow_double_convertion();
extern int genPassedBG_T_ctp_t_pck_t_engine_to_double(const void *pValue, double *nValue);
extern int get_genPassedBG_T_ctp_t_pck_t_engine_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_genPassedBG_T_ctp_t_pck_t_engine(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_genPassedBG_T_ctp_t_pck_t_engine_default_value(void *pValue);
extern SimTypeUtils _Type_genPassedBG_T_ctp_t_pck_t_engine_Utils;

/****************************************************************
 ** genPassedBGs_T_ctp_t_pck_t_engine 
 ****************************************************************/
extern int genPassedBGs_T_ctp_t_pck_t_engine_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_genPassedBGs_T_ctp_t_pck_t_engine_string(const char *str, char **endptr);
extern int string_to_genPassedBGs_T_ctp_t_pck_t_engine(const char *str, void *pValue, char **endptr);
extern int is_genPassedBGs_T_ctp_t_pck_t_engine_allow_double_convertion();
extern int genPassedBGs_T_ctp_t_pck_t_engine_to_double(const void *pValue, double *nValue);
extern int get_genPassedBGs_T_ctp_t_pck_t_engine_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_genPassedBGs_T_ctp_t_pck_t_engine(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_genPassedBGs_T_ctp_t_pck_t_engine_default_value(void *pValue);
extern SimTypeUtils _Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils;

/****************************************************************
 ** positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg 
 ****************************************************************/
extern int positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_string(const char *str, char **endptr);
extern int string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(const char *str, void *pValue, char **endptr);
extern int is_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_allow_double_convertion();
extern int positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_double(const void *pValue, double *nValue);
extern int get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils;

/****************************************************************
 ** BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg 
 ****************************************************************/
extern int BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char *str, char **endptr);
extern int string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char *str, void *pValue, char **endptr);
extern int is_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion();
extern int BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(const void *pValue, double *nValue);
extern int get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils;

/****************************************************************
 ** BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg 
 ****************************************************************/
extern int BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char *str, char **endptr);
extern int string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char *str, void *pValue, char **endptr);
extern int is_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion();
extern int BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(const void *pValue, double *nValue);
extern int get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils;

/****************************************************************
 ** refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg 
 ****************************************************************/
extern int refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char *str, char **endptr);
extern int string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char *str, void *pValue, char **endptr);
extern int is_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion();
extern int refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(const void *pValue, double *nValue);
extern int get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils;

/****************************************************************
 ** linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg 
 ****************************************************************/
extern int linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char *str, char **endptr);
extern int string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char *str, void *pValue, char **endptr);
extern int is_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion();
extern int linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(const void *pValue, double *nValue);
extern int get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils;

/****************************************************************
 ** linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg 
 ****************************************************************/
extern int linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char *str, char **endptr);
extern int string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char *str, void *pValue, char **endptr);
extern int is_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion();
extern int linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(const void *pValue, double *nValue);
extern int get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils;

/****************************************************************
 ** trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg 
 ****************************************************************/
extern int trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_string(const char *str, char **endptr);
extern int string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(const char *str, void *pValue, char **endptr);
extern int is_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_allow_double_convertion();
extern int trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_double(const void *pValue, double *nValue);
extern int get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils;

/****************************************************************
 ** passedBG_T_BG_Types_Pkg 
 ****************************************************************/
extern int passedBG_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_passedBG_T_BG_Types_Pkg_string(const char *str, char **endptr);
extern int string_to_passedBG_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr);
extern int is_passedBG_T_BG_Types_Pkg_allow_double_convertion();
extern int passedBG_T_BG_Types_Pkg_to_double(const void *pValue, double *nValue);
extern int get_passedBG_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_passedBG_T_BG_Types_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_passedBG_T_BG_Types_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_passedBG_T_BG_Types_Pkg_Utils;

/****************************************************************
 ** BG_Header_T_BG_Types_Pkg 
 ****************************************************************/
extern int BG_Header_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_BG_Header_T_BG_Types_Pkg_string(const char *str, char **endptr);
extern int string_to_BG_Header_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr);
extern int is_BG_Header_T_BG_Types_Pkg_allow_double_convertion();
extern int BG_Header_T_BG_Types_Pkg_to_double(const void *pValue, double *nValue);
extern int get_BG_Header_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_BG_Header_T_BG_Types_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_BG_Header_T_BG_Types_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_BG_Header_T_BG_Types_Pkg_Utils;

/****************************************************************
 ** LinkedBGs_T_BG_Types_Pkg 
 ****************************************************************/
extern int LinkedBGs_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_LinkedBGs_T_BG_Types_Pkg_string(const char *str, char **endptr);
extern int string_to_LinkedBGs_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr);
extern int is_LinkedBGs_T_BG_Types_Pkg_allow_double_convertion();
extern int LinkedBGs_T_BG_Types_Pkg_to_double(const void *pValue, double *nValue);
extern int get_LinkedBGs_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_LinkedBGs_T_BG_Types_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_LinkedBGs_T_BG_Types_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_LinkedBGs_T_BG_Types_Pkg_Utils;

/****************************************************************
 ** LinkedBG_T_BG_Types_Pkg 
 ****************************************************************/
extern int LinkedBG_T_BG_Types_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_LinkedBG_T_BG_Types_Pkg_string(const char *str, char **endptr);
extern int string_to_LinkedBG_T_BG_Types_Pkg(const char *str, void *pValue, char **endptr);
extern int is_LinkedBG_T_BG_Types_Pkg_allow_double_convertion();
extern int LinkedBG_T_BG_Types_Pkg_to_double(const void *pValue, double *nValue);
extern int get_LinkedBG_T_BG_Types_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_LinkedBG_T_BG_Types_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_LinkedBG_T_BG_Types_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_LinkedBG_T_BG_Types_Pkg_Utils;

/****************************************************************
 ** T_internal_Type_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int T_internal_Type_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_T_internal_Type_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_T_internal_Type_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_T_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int T_internal_Type_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_T_internal_Type_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_T_internal_Type_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_T_internal_Type_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** OdometryLocations_T_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int OdometryLocations_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_OdometryLocations_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_OdometryLocations_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_OdometryLocations_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int OdometryLocations_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_OdometryLocations_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_OdometryLocations_T_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_OdometryLocations_T_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** L_internal_Type_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int L_internal_Type_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_L_internal_Type_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_L_internal_Type_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_L_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int L_internal_Type_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_L_internal_Type_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_L_internal_Type_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_L_internal_Type_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** LocWithInAcc_T_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int LocWithInAcc_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_LocWithInAcc_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_LocWithInAcc_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int LocWithInAcc_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_LocWithInAcc_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_LocWithInAcc_T_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_LocWithInAcc_T_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** Speed_T_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int Speed_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Speed_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_Speed_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_Speed_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int Speed_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_Speed_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Speed_T_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Speed_T_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_Speed_T_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** V_internal_Type_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int V_internal_Type_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_V_internal_Type_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_V_internal_Type_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_V_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int V_internal_Type_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_V_internal_Type_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_V_internal_Type_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_V_internal_Type_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_V_internal_Type_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** Location_T_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int Location_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_Location_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_Location_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_Location_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int Location_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_Location_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_Location_T_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_Location_T_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_Location_T_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** odometry_T_Obu_BasicTypes_Pkg 
 ****************************************************************/
extern int odometry_T_Obu_BasicTypes_Pkg_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_odometry_T_Obu_BasicTypes_Pkg_string(const char *str, char **endptr);
extern int string_to_odometry_T_Obu_BasicTypes_Pkg(const char *str, void *pValue, char **endptr);
extern int is_odometry_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int odometry_T_Obu_BasicTypes_Pkg_to_double(const void *pValue, double *nValue);
extern int get_odometry_T_Obu_BasicTypes_Pkg_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_odometry_T_Obu_BasicTypes_Pkg(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_odometry_T_Obu_BasicTypes_Pkg_default_value(void *pValue);
extern SimTypeUtils _Type_odometry_T_Obu_BasicTypes_Pkg_Utils;

/****************************************************************
 ** positionedBG_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int positionedBG_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_positionedBG_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_positionedBG_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_positionedBG_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int positionedBG_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_positionedBG_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_positionedBG_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_positionedBG_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_positionedBG_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** infoFromLinking_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int infoFromLinking_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_infoFromLinking_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_infoFromLinking_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_infoFromLinking_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int infoFromLinking_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_infoFromLinking_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_infoFromLinking_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_infoFromLinking_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** trainProperties_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int trainProperties_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_trainProperties_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_trainProperties_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_trainProperties_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int trainProperties_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_trainProperties_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_trainProperties_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_trainProperties_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_trainProperties_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** positionedBGs_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int positionedBGs_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_positionedBGs_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_positionedBGs_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_positionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int positionedBGs_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_positionedBGs_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_positionedBGs_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_positionedBGs_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_positionedBGs_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** positionErrors_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int positionErrors_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_positionErrors_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_positionErrors_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_positionErrors_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int positionErrors_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_positionErrors_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_positionErrors_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_positionErrors_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_positionErrors_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** trainPosition_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int trainPosition_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_trainPosition_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_trainPosition_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_trainPosition_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int trainPosition_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_trainPosition_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_trainPosition_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_trainPosition_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_trainPosition_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** trainPositionInfo_T_TrainPosition_Types_Pck 
 ****************************************************************/
extern int trainPositionInfo_T_TrainPosition_Types_Pck_to_string(const void *pValue, PFNSTRAPPEND pfnStrAppend, void *pData);
extern int check_trainPositionInfo_T_TrainPosition_Types_Pck_string(const char *str, char **endptr);
extern int string_to_trainPositionInfo_T_TrainPosition_Types_Pck(const char *str, void *pValue, char **endptr);
extern int is_trainPositionInfo_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int trainPositionInfo_T_TrainPosition_Types_Pck_to_double(const void *pValue, double *nValue);
extern int get_trainPositionInfo_T_TrainPosition_Types_Pck_signature(int (*pfnStrAppend)(const char *str, void *pData), void *pData);
extern void compare_trainPositionInfo_T_TrainPosition_Types_Pck(int *nStatus, const void *pValue1, const void *pValue2, void *pData, const char *pszPath, PFNSTRAPPEND pfnStrListAppend, void *pListErrPaths);
extern int set_trainPositionInfo_T_TrainPosition_Types_Pck_default_value(void *pValue);
extern SimTypeUtils _Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils;


#endif /*CTP_T_TYPES_CONVERTION */
