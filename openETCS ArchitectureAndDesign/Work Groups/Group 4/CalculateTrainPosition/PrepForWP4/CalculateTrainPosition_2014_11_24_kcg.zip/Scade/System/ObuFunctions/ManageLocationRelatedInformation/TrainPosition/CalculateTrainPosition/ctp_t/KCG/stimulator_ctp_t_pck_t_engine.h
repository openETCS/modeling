/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _stimulator_ctp_t_pck_t_engine_H_
#define _stimulator_ctp_t_pck_t_engine_H_

#include "kcg_types.h"
#include "genPassedBG_ctp_t_pck_t_engine.h"
#include "genLocation_ctp_t_pck_t_engine.h"
#include "genOdometry_ctp_t_pck_t_engine.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::pos_ideal */ pos_ideal;
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::stimulator::odometry */ odometry;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::t_engine::stimulator::passedBG */ passedBG;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::t_engine::stimulator::trackDescription */ trackDescription;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_genLocation_ctp_t_pck_t_engine /* 1 */ _1_Context_1;
  outC_genOdometry_ctp_t_pck_t_engine /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
} outC_stimulator_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::stimulator */
extern void stimulator_ctp_t_pck_t_engine(
  outC_stimulator_ctp_t_pck_t_engine *outC);

extern void stimulator_reset_ctp_t_pck_t_engine(
  outC_stimulator_ctp_t_pck_t_engine *outC);

#endif /* _stimulator_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** stimulator_ctp_t_pck_t_engine.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

