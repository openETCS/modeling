/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */
#ifndef _runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_H_
#define _runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_H_

#include "kcg_types.h"
#include "trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  Q_DIRTRAIN /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::trainRunningDirection */ trainRunningDirection;
  /* -----------------------  no local probes  ----------------------- */
  /* -----------------  no initialization variables  ----------------- */
  /* -----------------------  no local memory  ----------------------- */
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
} outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg;

/* ===========  node initialization and cycle functions  =========== */
/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef */
extern void runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refTrainRunningDirection */Q_DIRTRAIN refTrainRunningDirection,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refSpeed */Speed_T_Obu_BasicTypes_Pkg refSpeed,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

extern void runningDirectionVsRef_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

#endif /* _runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.h
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

