/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.h"

void runningDirectionVsRef_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  /* 1 */
  trainMovementSensor_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
    &outC->Context_1);
}

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef */
void runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refTrainRunningDirection */Q_DIRTRAIN refTrainRunningDirection,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refSpeed */Speed_T_Obu_BasicTypes_Pkg refSpeed,
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::trainRunningDirection */ Q_DIRTRAIN _1_trainRunningDirection;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::trainRunningDirection */ Q_DIRTRAIN trainRunningDirection;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::trainRunningDirection */ Q_DIRTRAIN _2_trainRunningDirection;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::trainRunningDirection */ Q_DIRTRAIN _3_trainRunningDirection;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refDir */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg _4_refDir;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refDir */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg refDir;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refDir */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg _5_refDir;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef::refDir */ trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg _6_refDir;
  
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L5, currentOdometry);
  /* 1 */
  trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(
    &outC->_L5,
    &outC->Context_1);
  outC->_L4 = outC->Context_1.direction;
  outC->currentDir = outC->_L4;
  outC->IfBlock1_clock = refSpeed > 0;
  if (outC->IfBlock1_clock) {
    outC->_L1_IfBlock1 = trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg;
    _4_refDir = outC->_L1_IfBlock1;
    outC->refDir = _4_refDir;
  }
  else {
    outC->else_clock_IfBlock1 = refSpeed < 0;
    if (outC->else_clock_IfBlock1) {
      outC->_L13_IfBlock1 = trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg;
      _6_refDir = outC->_L13_IfBlock1;
      refDir = _6_refDir;
    }
    else {
      outC->_L14_IfBlock1 = trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg;
      _5_refDir = outC->_L14_IfBlock1;
      refDir = _5_refDir;
    }
    outC->refDir = refDir;
  }
  outC->IfBlock2_clock = outC->currentDir == outC->refDir;
  if (outC->IfBlock2_clock) {
    outC->_L1_IfBlock2 = refTrainRunningDirection;
    _1_trainRunningDirection = outC->_L1_IfBlock2;
    outC->trainRunningDirection = _1_trainRunningDirection;
  }
  else {
    outC->else_clock_IfBlock2 = (outC->currentDir ==
        trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg) | (outC->refDir ==
        trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg);
    if (outC->else_clock_IfBlock2) {
      outC->_L11_IfBlock2 = Q_DIRTRAIN_Unknown;
      _3_trainRunningDirection = outC->_L11_IfBlock2;
      trainRunningDirection = _3_trainRunningDirection;
    }
    else {
      outC->_L12_IfBlock2 = refTrainRunningDirection;
      outC->_L3_IfBlock2 = Q_DIRTRAIN_Nominal;
      outC->_L2_IfBlock2 = outC->_L12_IfBlock2 == outC->_L3_IfBlock2;
      outC->_L6_IfBlock2 = Q_DIRTRAIN_Reverse;
      if (outC->_L2_IfBlock2) {
        outC->_L4_IfBlock2 = outC->_L6_IfBlock2;
      }
      else {
        outC->_L4_IfBlock2 = outC->_L3_IfBlock2;
      }
      _2_trainRunningDirection = outC->_L4_IfBlock2;
      trainRunningDirection = _2_trainRunningDirection;
    }
    outC->trainRunningDirection = trainRunningDirection;
  }
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

