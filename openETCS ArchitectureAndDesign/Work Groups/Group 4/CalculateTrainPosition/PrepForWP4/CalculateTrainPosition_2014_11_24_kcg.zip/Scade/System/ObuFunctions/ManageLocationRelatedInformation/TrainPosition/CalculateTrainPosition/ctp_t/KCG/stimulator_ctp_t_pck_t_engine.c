/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "stimulator_ctp_t_pck_t_engine.h"

void stimulator_reset_ctp_t_pck_t_engine(
  outC_stimulator_ctp_t_pck_t_engine *outC)
{
  /* 1 */ genOdometry_reset_ctp_t_pck_t_engine(&outC->Context_1);
  /* 1 */ genLocation_reset_ctp_t_pck_t_engine(&outC->_1_Context_1);
}

/* ctp_t_pck::t_engine::stimulator */
void stimulator_ctp_t_pck_t_engine(outC_stimulator_ctp_t_pck_t_engine *outC)
{
  kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine(
    &outC->trackDescription,
    (genPassedBGs_T_ctp_t_pck_t_engine *)
      &cTrack_3_linkedBGs_2_unlinkedBGs_far_ctp_t_pck_t_engine);
  /* 1 */ genLocation_ctp_t_pck_t_engine(&outC->_1_Context_1);
  outC->pos_ideal = outC->_1_Context_1.location;
  /* 1 */
  genOdometry_ctp_t_pck_t_engine(
    outC->pos_ideal,
    outC->_1_Context_1.time,
    &outC->Context_1);
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(
    &outC->odometry,
    &outC->Context_1.odometry);
  /* 1 */
  genPassedBG_ctp_t_pck_t_engine(
    outC->pos_ideal,
    &outC->odometry,
    &outC->trackDescription,
    &outC->passedBG);
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** stimulator_ctp_t_pck_t_engine.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

