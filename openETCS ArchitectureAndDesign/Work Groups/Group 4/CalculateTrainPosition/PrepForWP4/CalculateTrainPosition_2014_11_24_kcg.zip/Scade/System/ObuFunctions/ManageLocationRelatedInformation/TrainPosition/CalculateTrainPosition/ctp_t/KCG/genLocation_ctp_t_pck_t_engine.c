/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genLocation_ctp_t_pck_t_engine.h"

void genLocation_reset_ctp_t_pck_t_engine(
  outC_genLocation_ctp_t_pck_t_engine *outC)
{
  outC->init = kcg_true;
}

/* ctp_t_pck::t_engine::genLocation */
void genLocation_ctp_t_pck_t_engine(outC_genLocation_ctp_t_pck_t_engine *outC)
{
  kcg_int tmp;
  
  if (outC->init) {
    tmp = - 100;
  }
  else {
    tmp = outC->time;
  }
  outC->location = 100 + tmp;
  outC->time = outC->location;
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genLocation_ctp_t_pck_t_engine.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

