/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genLocation_ctp_t_pck_t_engine.h"

void genLocation_reset_ctp_t_pck_t_engine(
  outC_genLocation_ctp_t_pck_t_engine *outC)
{
  outC->init = kcg_true;
}

/* ctp_t_pck::t_engine::genLocation */
void genLocation_ctp_t_pck_t_engine(outC_genLocation_ctp_t_pck_t_engine *outC)
{
  /* ctp_t_pck::t_engine::genLocation::location_loc */ L_internal_Type_Obu_BasicTypes_Pkg last_location_loc;
  
  outC->_L16 = 94000;
  outC->B_4 = outC->_L16;
  outC->_L15 = 93900;
  outC->A_4 = outC->_L15;
  outC->_L14 = 39300;
  outC->B_3 = outC->_L14;
  outC->_L13 = 39200;
  outC->A_3 = outC->_L13;
  outC->_L10 = 11800;
  outC->B_2 = outC->_L10;
  outC->_L9 = 11700;
  outC->A_2 = outC->_L9;
  outC->_L12 = 22200;
  outC->B_1 = outC->_L12;
  outC->_L11 = 22100;
  outC->A_1 = outC->_L11;
  if (outC->init) {
    last_location_loc = 0;
  }
  else {
    last_location_loc = outC->location_loc;
  }
  outC->_L13_2 = outC->B_2;
  outC->_L19 = last_location_loc;
  outC->IRII_Input_2 = outC->_L19;
  outC->_L8_2 = outC->IRII_Input_2;
  outC->_L12_2 = outC->_L13_2 >= outC->_L8_2;
  outC->_L10_2 = outC->A_2;
  outC->_L4_2 = outC->_L8_2 >= outC->_L10_2;
  outC->_L2_2 = outC->_L12_2 & outC->_L4_2;
  outC->IRII_Output_2 = outC->_L2_2;
  outC->_L6 = outC->IRII_Output_2;
  outC->_L13_1 = outC->B_1;
  outC->IRII_Input_1 = outC->_L19;
  outC->_L8_1 = outC->IRII_Input_1;
  outC->_L12_1 = outC->_L13_1 >= outC->_L8_1;
  outC->_L10_1 = outC->A_1;
  outC->_L4_1 = outC->_L8_1 >= outC->_L10_1;
  outC->_L2_1 = outC->_L12_1 & outC->_L4_1;
  outC->IRII_Output_1 = outC->_L2_1;
  outC->_L5 = outC->IRII_Output_1;
  outC->_L13_3 = outC->B_3;
  outC->IRII_Input_3 = outC->_L19;
  outC->_L8_3 = outC->IRII_Input_3;
  outC->_L12_3 = outC->_L13_3 >= outC->_L8_3;
  outC->_L10_3 = outC->A_3;
  outC->_L4_3 = outC->_L8_3 >= outC->_L10_3;
  outC->_L2_3 = outC->_L12_3 & outC->_L4_3;
  outC->IRII_Output_3 = outC->_L2_3;
  outC->_L7 = outC->IRII_Output_3;
  outC->_L13_4 = outC->B_4;
  outC->IRII_Input_4 = outC->_L19;
  outC->_L8_4 = outC->IRII_Input_4;
  outC->_L12_4 = outC->_L13_4 >= outC->_L8_4;
  outC->_L10_4 = outC->A_4;
  outC->_L4_4 = outC->_L8_4 >= outC->_L10_4;
  outC->_L2_4 = outC->_L12_4 & outC->_L4_4;
  outC->IRII_Output_4 = outC->_L2_4;
  outC->_L8 = outC->IRII_Output_4;
  outC->_L17 = outC->_L6 | outC->_L5 | outC->_L7 | outC->_L8;
  outC->_L21 = 100;
  outC->_L22 = 100;
  if (outC->_L17) {
    outC->_L20 = outC->_L21;
  }
  else {
    outC->_L20 = outC->_L22;
  }
  outC->incr = outC->_L20;
  outC->_L23 = outC->incr;
  outC->_L4 = - outC->_L23;
  if (outC->init) {
    outC->_L2 = outC->_L4;
  }
  else {
    outC->_L2 = outC->_L1;
  }
  outC->_L1 = outC->_L23 + outC->_L2;
  outC->location_loc = outC->_L1;
  outC->time = outC->_L1;
  outC->location = outC->_L1;
  outC->A1_1 = outC->A_1 <= outC->B_1;
  outC->A1_2 = outC->A_2 <= outC->B_2;
  outC->A1_3 = outC->A_3 <= outC->B_3;
  outC->A1_4 = outC->A_4 <= outC->B_4;
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genLocation_ctp_t_pck_t_engine.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

