/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _KCG_TYPES_H_
#define _KCG_TYPES_H_

#define KCG_MAPW_CPY

#include "./user_macros.h"

#ifndef kcg_int
#define kcg_int kcg_int
typedef int kcg_int;
#endif /* kcg_int */

#ifndef kcg_bool
#define kcg_bool kcg_bool
typedef unsigned char kcg_bool;
#endif /* kcg_bool */

#ifndef kcg_real
#define kcg_real kcg_real
typedef double kcg_real;
#endif /* kcg_real */

#ifndef kcg_char
#define kcg_char kcg_char
typedef unsigned char kcg_char;
#endif /* kcg_char */

#ifndef kcg_false
#define kcg_false ((kcg_bool) 0)
#endif /* kcg_false */

#ifndef kcg_true
#define kcg_true ((kcg_bool) 1)
#endif /* kcg_true */

#ifndef kcg_assign
#include "kcg_assign.h"
#endif /* kcg_assign */

#ifndef kcg_assign_struct
#define kcg_assign_struct kcg_assign
#endif /* kcg_assign_struct */

#ifndef kcg_assign_array
#define kcg_assign_array kcg_assign
#endif /* kcg_assign_array */

/* L_NVKRINT */
typedef enum {
  L_NVKRINT_0m = 0,
  L_NVKRINT_25m = 1,
  L_NVKRINT_50m = 2,
  L_NVKRINT_75m = 3,
  L_NVKRINT_100m = 4,
  L_NVKRINT_150m = 5,
  L_NVKRINT_200m = 6,
  L_NVKRINT_300m = 7,
  L_NVKRINT_400m = 8,
  L_NVKRINT_500m = 9,
  L_NVKRINT_600m = 10,
  L_NVKRINT_700m = 11,
  L_NVKRINT_800m = 12,
  L_NVKRINT_900m = 13,
  L_NVKRINT_1000m = 14,
  L_NVKRINT_1100m = 15,
  L_NVKRINT_1200m = 16,
  L_NVKRINT_1300m = 17,
  L_NVKRINT_1400m = 18,
  L_NVKRINT_1500m = 19,
  L_NVKRINT_1600m = 20,
  L_NVKRINT_1700m = 21,
  L_NVKRINT_1800m = 22,
  L_NVKRINT_1900m = 23,
  L_NVKRINT_2000m = 24,
  L_NVKRINT_2100m = 25,
  L_NVKRINT_2200m = 26,
  L_NVKRINT_2300m = 27,
  L_NVKRINT_2400m = 28,
  L_NVKRINT_2500m = 29,
  L_NVKRINT_2600m = 30,
  L_NVKRINT_2700m = 31
} L_NVKRINT;
/* M_ACK */
typedef enum {
  M_ACK_No_acknowledgement_required = 0,
  M_ACK_Acknowledgement_required = 1
} M_ACK;
/* M_ADHESION */
typedef enum {
  M_ADHESION_Slippery_rail = 0,
  M_ADHESION_Non_slippery_rail = 1
} M_ADHESION;
/* M_AIRTIGHT */
typedef enum { M_AIRTIGHT_Not_fitted = 0, M_AIRTIGHT_Fitted = 1 } M_AIRTIGHT;
/* M_AXLELOADCAT */
typedef enum {
  M_AXLELOADCAT_A = 0,
  M_AXLELOADCAT_HS17 = 1,
  M_AXLELOADCAT_B1 = 2,
  M_AXLELOADCAT_B2 = 3,
  M_AXLELOADCAT_C2 = 4,
  M_AXLELOADCAT_C3 = 5,
  M_AXLELOADCAT_C4 = 6,
  M_AXLELOADCAT_D2 = 7,
  M_AXLELOADCAT_D3 = 8,
  M_AXLELOADCAT_D4 = 9,
  M_AXLELOADCAT_D4XL = 10,
  M_AXLELOADCAT_E4 = 11,
  M_AXLELOADCAT_E5 = 12
} M_AXLELOADCAT;
/* M_LEVELTEXTDISPLAY */
typedef enum {
  M_LEVELTEXTDISPLAY_Level_0 = 0,
  M_LEVELTEXTDISPLAY_Level_NTC_specified_by_NID_NTC = 1,
  M_LEVELTEXTDISPLAY_Level_1 = 2,
  M_LEVELTEXTDISPLAY_Level_2 = 3,
  M_LEVELTEXTDISPLAY_Level_3 = 4,
  M_LEVELTEXTDISPLAY_The_display_of_the_text_shall_not_be_limited_by_the_level = 5
} M_LEVELTEXTDISPLAY;
/* M_LINEGAUGE */
typedef enum {
  M_LINEGAUGE_G1 = 1,
  M_LINEGAUGE_GA = 2,
  M_LINEGAUGE_GB = 4,
  M_LINEGAUGE_GC = 8
} M_LINEGAUGE;
/* M_LOADINGGAUGE */
typedef enum {
  M_LOADINGGAUGE_The_train_does_not_fit_to_any_of_the_interoperable_loading_gauge_profiles = 0,
  M_LOADINGGAUGE_G1 = 1,
  M_LOADINGGAUGE_GA = 2,
  M_LOADINGGAUGE_GB = 3,
  M_LOADINGGAUGE_GC = 4
} M_LOADINGGAUGE;
/* M_MAMODE */
typedef enum {
  M_MAMODE_On_Sight = 0,
  M_MAMODE_Shunting = 1,
  M_MAMODE_Limited_Supervision = 2
} M_MAMODE;
/* M_MODETEXTDISPLAY */
typedef enum {
  M_MODETEXTDISPLAY_Full_Supervision = 0,
  M_MODETEXTDISPLAY_On_Sight = 1,
  M_MODETEXTDISPLAY_Staff_Responsible = 2,
  M_MODETEXTDISPLAY_Unfitted = 4,
  M_MODETEXTDISPLAY_Stand_By = 6,
  M_MODETEXTDISPLAY_Trip = 7,
  M_MODETEXTDISPLAY_Post_Trip = 8,
  M_MODETEXTDISPLAY_Non_Leading = 11,
  M_MODETEXTDISPLAY_Limited_Supervision = 12,
  M_MODETEXTDISPLAY_Reversing = 14,
  M_MODETEXTDISPLAY_The_display_of_the_text_shall_not_be_limited_by_the_mode = 15
} M_MODETEXTDISPLAY;
/* M_NVCONTACT */
typedef enum {
  M_NVCONTACT_Train_trip = 0,
  M_NVCONTACT_Apply_service_brake = 1,
  M_NVCONTACT_No_Reaction = 2
} M_NVCONTACT;
/* M_NVDERUN */
typedef enum { M_NVDERUN_No = 0, M_NVDERUN_Yes = 1 } M_NVDERUN;
/* M_NVEBCL */
typedef enum {
  M_NVEBCL_Confidence_level_50 = 0,
  M_NVEBCL_Confidence_level_90 = 1,
  M_NVEBCL_Confidence_level_99 = 2,
  M_NVEBCL_Confidence_level_99_9 = 3,
  M_NVEBCL_Confidence_level_99_99 = 4,
  M_NVEBCL_Confidence_level_99_999 = 5,
  M_NVEBCL_Confidence_level_99_9999 = 6,
  M_NVEBCL_Confidence_level_99_99999 = 7,
  M_NVEBCL_Confidence_level_99_999999 = 8,
  M_NVEBCL_Confidence_level_99_9999999 = 9
} M_NVEBCL;
/* M_PLATFORM */
typedef enum {
  M_PLATFORM_200_mm = 0,
  M_PLATFORM_300380_mm = 1,
  M_PLATFORM_550_mm = 2,
  M_PLATFORM_580_mm = 3,
  M_PLATFORM_680_mm = 4,
  M_PLATFORM_685_mm = 5,
  M_PLATFORM_730_mm = 6,
  M_PLATFORM_760_mm = 7,
  M_PLATFORM_840_mm = 8,
  M_PLATFORM_900_mm = 9,
  M_PLATFORM_915_mm = 10,
  M_PLATFORM_920_mm = 11,
  M_PLATFORM_960_mm = 12,
  M_PLATFORM_1100_mm = 13
} M_PLATFORM;
/* M_TRACKCOND */
typedef enum {
  M_TRACKCOND_Non_stopping_area_Initial_state_is_stopping_permitted = 0,
  M_TRACKCOND_Tunnel_stopping_area_Initial_state_is_no_tunnel_stopping_area = 1,
  M_TRACKCOND_Sound_horn_Initial_state_is_is_no_request_for_sound_horn = 2,
  M_TRACKCOND_Powerless_section_Lower_pantograph_Initial_state_is_not_powerless_section = 3,
  M_TRACKCOND_Radio_hole_stop_supervising_T_NVCONTACT_Initial_state_is_supervise_T_NVCONTACT = 4,
  M_TRACKCOND_Air_tightness_Initial_state_is_no_request_for_air_tightness = 5,
  M_TRACKCOND_Switch_off_regenerative_brake_Initial_state_is_regenerative_brake_on = 6,
  M_TRACKCOND_Switch_off_eddy_current_brake_for_service_brake_Initial_state_is_eddy_current_brake_for_service_brake_on = 7,
  M_TRACKCOND_Switch_off_magnetic_shoe_brake_Initial_state_is_magnetic_shoe_brake_on = 8,
  M_TRACKCOND_Powerless_section_switch_off_the_main_power_switch_Initial_state_is_not_powerless_section = 9,
  M_TRACKCOND_Switch_off_eddy_current_brake_for_emergency_brake_Initial_state_is_eddy_current_brake_for_emergency_brake_on = 10
} M_TRACKCOND;
/* M_VOLTAGE */
typedef enum {
  M_VOLTAGE_Line_not_fitted_with_any_traction_system = 0,
  M_VOLTAGE_AC_25_kV_50_Hz = 1,
  M_VOLTAGE_AC_15_kV_16_7_Hz = 2,
  M_VOLTAGE_DC_3_kV = 3,
  M_VOLTAGE_DC_1_5_kV = 4,
  M_VOLTAGE_DC_600_or_750_V = 5
} M_VOLTAGE;
/* NC_CDDIFF */
typedef enum {
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_80_mm = 0,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_100_mm = 1,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_130_mm = 2,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_150_mm = 3,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_165_mm = 4,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_180_mm = 5,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_210_mm = 6,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_225_mm = 7,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_245_mm = 8,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_275_mm = 9,
  NC_CDDIFF_Specific_SSP_applicable_to_Cant_Deficiency_300_mm = 10
} NC_CDDIFF;
/* NC_CDTRAIN */
typedef enum {
  NC_CDTRAIN_Cant_Deficiency_80_mm = 0,
  NC_CDTRAIN_Cant_Deficiency_100_mm = 1,
  NC_CDTRAIN_Cant_Deficiency_130_mm = 2,
  NC_CDTRAIN_Cant_Deficiency_150_mm = 3,
  NC_CDTRAIN_Cant_Deficiency_165_mm = 4,
  NC_CDTRAIN_Cant_Deficiency_180_mm = 5,
  NC_CDTRAIN_Cant_Deficiency_210_mm = 6,
  NC_CDTRAIN_Cant_Deficiency_225_mm = 7,
  NC_CDTRAIN_Cant_Deficiency_245_mm = 8,
  NC_CDTRAIN_Cant_Deficiency_275_mm = 9,
  NC_CDTRAIN_Cant_Deficiency_300_mm = 10
} NC_CDTRAIN;
/* NC_TRAIN */
typedef enum {
  NC_TRAIN_Train_does_not_belong_to_any_of_the_Other_International_Train_Category = 0,
  NC_TRAIN_Freight_train_braked_in_P_position = 1,
  NC_TRAIN_Freight_train_braked_in_G_position = 2,
  NC_TRAIN_Passenger_train = 4
} NC_TRAIN;
/* Q_ASPECT */
typedef enum {
  Q_ASPECT_Stop_if_in_SH_mode = 0,
  Q_ASPECT_Go_if_in_SH_mode = 1
} Q_ASPECT;
/* Q_CONFTEXTDISPLAY */
typedef enum {
  Q_CONFTEXTDISPLAY_Driver_acknowledgement_always_ends_the_text_display_regardless_of_the_end_condition = 0,
  Q_CONFTEXTDISPLAY_Driver_acknowledgement_is_an_additional_condition_to_end_the_display = 1
} Q_CONFTEXTDISPLAY;
/* Q_DANGERPOINT */
typedef enum {
  Q_DANGERPOINT_No_danger_point_information = 0,
  Q_DANGERPOINT_Danger_point_information_to_follow = 1
} Q_DANGERPOINT;
/* Q_DIFF */
typedef enum {
  Q_DIFF_Cant_Deficiency_specific_category = 0,
  Q_DIFF_Other_specific_category_replaces_the_Cant_Deficiency_SSP = 1,
  Q_DIFF_Other_specific_category_does_not_replace_the_Cant_Deficiency_SSP = 2
} Q_DIFF;
/* Q_EMERGENCYSTOP */
typedef enum {
  Q_EMERGENCYSTOP_Conditional_Emergency_Stop_accepted_with_update_of_EOA = 0,
  Q_EMERGENCYSTOP_Conditional_Emergency_Stop_accepted_with_no_update_of_EOA = 1,
  Q_EMERGENCYSTOP_Unconditional_Emergency_Stop_accepted = 2,
  Q_EMERGENCYSTOP_Emergency_stop = 3
} Q_EMERGENCYSTOP;
/* Q_ENDTIMER */
typedef enum {
  Q_ENDTIMER_No_End_section_timer_information = 0,
  Q_ENDTIMER_End_section_timer_information_to_follow = 1
} Q_ENDTIMER;
/* Q_FRONT */
typedef enum {
  Q_FRONT_Train_length_delay_on_validity_end_point_of_profile_element = 0,
  Q_FRONT_No_train_length_delay_on_validity_end_point_of_profile_element = 1
} Q_FRONT;
/* Q_GDIR */
typedef enum { Q_GDIR_downhill = 0, Q_GDIR_uphill = 1 } Q_GDIR;
/* Q_INFILL */
typedef enum { Q_INFILL_Enter = 0, Q_INFILL_Exit = 1 } Q_INFILL;
/* Q_LOOPDIR */
typedef enum { Q_LOOPDIR_Opposite = 0, Q_LOOPDIR_Same = 1 } Q_LOOPDIR;
/* Q_LXSTATUS */
typedef enum {
  Q_LXSTATUS_LX_is_protected = 0,
  Q_LXSTATUS_LX_is_not_protected = 1
} Q_LXSTATUS;
/* Q_MAMODE */
typedef enum {
  Q_MAMODE_as_the_EOA = 0,
  Q_MAMODE_as_both_the_EOA_and_SvL = 1
} Q_MAMODE;
/* Q_MARQSTREASON */
typedef enum {
  Q_MARQSTREASON_Start_selected_by_driver = 1,
  Q_MARQSTREASON_Time_before_reaching_preindication_location_for_the_EOA_or_LOA_reached = 2,
  Q_MARQSTREASON_Time_before_a_section_timer_or_LOA_speed_timer_expires_reached = 4,
  Q_MARQSTREASON_Track_description_deleted = 8,
  Q_MARQSTREASON_TAF_up_to_level_2_or_3_transition_location = 16
} Q_MARQSTREASON;
/* Q_MPOSITION */
typedef enum { Q_MPOSITION_Opposite = 0, Q_MPOSITION_Same = 1 } Q_MPOSITION;
/* Q_NVDRIVER_ADHES */
typedef enum {
  Q_NVDRIVER_ADHES_Not_allowed = 0,
  Q_NVDRIVER_ADHES_Allowed = 1
} Q_NVDRIVER_ADHES;
/* Q_NVEMRRLS */
typedef enum {
  Q_NVEMRRLS_Revoke_emergency_brake_command_at_standstill = 0,
  Q_NVEMRRLS_Revoke_emergency_brake_command_when_permitted_speed_supervision_limit_is_no_longer_exceeded = 1
} Q_NVEMRRLS;
/* Q_NVGUIPERM */
typedef enum { Q_NVGUIPERM_No = 0, Q_NVGUIPERM_Yes = 1 } Q_NVGUIPERM;
/* Q_NVINHSMICPERM */
typedef enum {
  Q_NVINHSMICPERM_No = 0,
  Q_NVINHSMICPERM_Yes = 1
} Q_NVINHSMICPERM;
/* Q_NVKINT */
typedef enum {
  Q_NVKINT_No_integrated_correction_factors_follow = 0,
  Q_NVKINT_Integrated_correction_factors_follow = 1
} Q_NVKINT;
/* Q_NVKVINTSET */
typedef enum {
  Q_NVKVINTSET_Freight_trains = 0,
  Q_NVKVINTSET_Conventional_passenger_trains = 1
} Q_NVKVINTSET;
/* Q_NVSBFBPERM */
typedef enum { Q_NVSBFBPERM_No = 0, Q_NVSBFBPERM_Yes = 1 } Q_NVSBFBPERM;
/* Q_NVSBTSMPERM */
typedef enum { Q_NVSBTSMPERM_No = 0, Q_NVSBTSMPERM_Yes = 1 } Q_NVSBTSMPERM;
/* Q_ORIENTATION */
typedef enum {
  Q_ORIENTATION_The_balise_group_has_been_passed_by_the_train_in_reverse_direction = 0,
  Q_ORIENTATION_The_balise_group_has_been_passed_by_the_train_in_nominal_direction = 1
} Q_ORIENTATION;
/* Q_OVERLAP */
typedef enum {
  Q_OVERLAP_No_overlap_information = 0,
  Q_OVERLAP_Overlap_information_to_follow = 1
} Q_OVERLAP;
/* Q_PBDSR */
typedef enum {
  Q_PBDSR_EB_intervention_requested = 0,
  Q_PBDSR_SB_intervention_requested = 1
} Q_PBDSR;
/* Q_PLATFORM */
typedef enum {
  Q_PLATFORM_Platform_on_left_side = 0,
  Q_PLATFORM_Platform_on_right_side = 1,
  Q_PLATFORM_Platform_on_both_sides = 2
} Q_PLATFORM;
/* Q_RBC */
typedef enum {
  Q_RBC_Terminate_communication_session = 0,
  Q_RBC_Establish_communication_session = 1
} Q_RBC;
/* Q_RIU */
typedef enum {
  Q_RIU_Terminate_communication_session = 0,
  Q_RIU_Establish_communication_session = 1
} Q_RIU;
/* Q_SECTIONTIMER */
typedef enum {
  Q_SECTIONTIMER_No_Section_Timer_information = 0,
  Q_SECTIONTIMER_Section_Timer_information_to_follow = 1
} Q_SECTIONTIMER;
/* Q_SLEEPSESSION */
typedef enum {
  Q_SLEEPSESSION_Ignore_session_establishment_order = 0,
  Q_SLEEPSESSION_Execute_session_establishment_order = 1
} Q_SLEEPSESSION;
/* Q_SRSTOP */
typedef enum {
  Q_SRSTOP_Stop_if_in_SR_mode = 0,
  Q_SRSTOP_Go_if_in_SR_mode = 1
} Q_SRSTOP;
/* Q_STATUS */
typedef enum { Q_STATUS_Valid = 1, Q_STATUS_Unknown = 2 } Q_STATUS;
/* Q_STOPLX */
typedef enum {
  Q_STOPLX_No_stop_required = 0,
  Q_STOPLX_Stop_required = 1
} Q_STOPLX;
/* Q_SUITABILITY */
typedef enum {
  Q_SUITABILITY_Loading_gauge = 0,
  Q_SUITABILITY_Max_axle_load = 1,
  Q_SUITABILITY_Traction_system = 2
} Q_SUITABILITY;
/* Q_TEXT */
typedef enum {
  Q_TEXT_Level_crossing_not_protected = 0,
  Q_TEXT_Acknowledgement = 1
} Q_TEXT;
/* Q_TEXTCLASS */
typedef enum {
  Q_TEXTCLASS_Auxiliary_Information = 0,
  Q_TEXTCLASS_Important_Information = 1
} Q_TEXTCLASS;
/* Q_TEXTCONFIRM */
typedef enum {
  Q_TEXTCONFIRM_No_confirmation_required = 0,
  Q_TEXTCONFIRM_Confirmation_required = 1,
  Q_TEXTCONFIRM_Confirmation_required_command_application_of_the_service_brake_when_display_end_condition_is_fulfilled_unless_the_text_has_already_been_acknowledged_by_the_driver = 2,
  Q_TEXTCONFIRM_Confirmation_required_command_application_of_the_emergency_brake_when_display_end_condition_is_fulfilled_unless_the_text_has_already_been_acknowledged_by_the_driver = 3
} Q_TEXTCONFIRM;
/* Q_TEXTDISPLAY */
typedef enum {
  Q_TEXTDISPLAY_No_display_as_soon_as__or__until_one_of_the_events_is_fulfilled = 0,
  Q_TEXTDISPLAY_Yes_display_as_soon_as__or__until_all_events_are_fulfilled = 1
} Q_TEXTDISPLAY;
/* Q_TEXTREPORT */
typedef enum {
  Q_TEXTREPORT_No_driver_acknowledgement_report_required = 0,
  Q_TEXTREPORT_Driver_acknowledgement_report_required = 1
} Q_TEXTREPORT;
/* Q_TRACKINIT */
typedef enum {
  Q_TRACKINIT_No_initial_states_to_be_resumed_profile_to_follow = 0,
  Q_TRACKINIT_Empty_profile_initial_states_to_be_resumed = 1
} Q_TRACKINIT;
/* Q_VBCO */
typedef enum {
  Q_VBCO_Remove_the_Virtual_Balise_Cover = 0,
  Q_VBCO_Set_the_Virtual_Balise_Cover = 1
} Q_VBCO;
/* M_LOC */
typedef enum {
  M_LOC_Now = 0,
  M_LOC_Every_LRBG_compliant_balise_group = 1,
  M_LOC_Do_not_send_position_report_on_passage_of_LRBG_compliant_balise_group = 2
} M_LOC;
/* Q_LGTLOC */
typedef enum {
  Q_LGTLOC_Min_safe_rear_end = 0,
  Q_LGTLOC_Max_safe_front_end = 1
} Q_LGTLOC;
/* M_ERROR */
typedef enum {
  M_ERROR_Balise_group_linking_consistency_error = 0,
  M_ERROR_Linked_balise_group_message_consistency_erro = 1,
  M_ERROR_Unlinked_balise_group_message_consistency_error = 2,
  M_ERROR_Radio_message_consistency_error = 3,
  M_ERROR_Radio_sequence_error = 4,
  M_ERROR_Radio_safe_radio_connection_error = 5,
  M_ERROR_Safety_critical_failure = 6,
  M_ERROR_Double_linking_error = 7,
  M_ERROR_Double_repositioning_error = 8
} M_ERROR;
/* Radio_TrainToTrack::Validated_Train_Data_OptionalPackets */
typedef enum {
  Validated_Train_Data_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Validated_Train_Data_OptionalPackageNumber_1_Radio_TrainToTrack = 1,
  Validated_Train_Data_OptionalPackageNumber_11_Radio_TrainToTrack = 11
} Validated_Train_Data_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Request_for_Shunting_OptionalPackets */
typedef enum {
  Request_for_Shunting_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Request_for_Shunting_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Request_for_Shunting_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::MA_Request_OptionalPackets */
typedef enum {
  MA_Request_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  MA_Request_OptionalPackageNumber_1_Radio_TrainToTrack = 1,
  MA_Request_OptionalPackageNumber_9_Radio_TrainToTrack = 9
} MA_Request_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Train_Position_Report_OptionalPackets */
typedef enum {
  Train_Position_Report_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Train_Position_Report_OptionalPackageNumber_1_Radio_TrainToTrack = 1,
  Train_Position_Report_OptionalPackageNumber_4_Radio_TrainToTrack = 4,
  Train_Position_Report_OptionalPackageNumber_5_Radio_TrainToTrack = 5,
  Train_Position_Report_OptionalPackageNumber_44_Radio_TrainToTrack = 44
} Train_Position_Report_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Request_to_shorten_MA_is_granted_OptionalPackets */
typedef enum {
  Request_to_shorten_MA_is_granted_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Request_to_shorten_MA_is_granted_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Request_to_shorten_MA_is_granted_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Request_to_shorten_MA_is_rejected_OptionalPackets */
typedef enum {
  Request_to_shorten_MA_is_rejected_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Request_to_shorten_MA_is_rejected_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Request_to_shorten_MA_is_rejected_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Acknowledgement_of_Emergency_Stop_OptionalPackets */
typedef enum {
  Acknowledgement_of_Emergency_Stop_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Acknowledgement_of_Emergency_Stop_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Acknowledgement_of_Emergency_Stop_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Track_Ahead_Free_Granted_OptionalPackets */
typedef enum {
  Track_Ahead_Free_Granted_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Track_Ahead_Free_Granted_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Track_Ahead_Free_Granted_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::End_of_Mission_OptionalPackets */
typedef enum {
  End_of_Mission_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  End_of_Mission_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} End_of_Mission_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Radio_infill_request_OptionalPackets */
typedef enum {
  Radio_infill_request_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Radio_infill_request_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Radio_infill_request_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::SoM_Position_Report_OptionalPackets */
typedef enum {
  SoM_Position_Report_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  SoM_Position_Report_OptionalPackageNumber_1_Radio_TrainToTrack = 1,
  SoM_Position_Report_OptionalPackageNumber_4_Radio_TrainToTrack = 4,
  SoM_Position_Report_OptionalPackageNumber_5_Radio_TrainToTrack = 5,
  SoM_Position_Report_OptionalPackageNumber_44_Radio_TrainToTrack = 44
} SoM_Position_Report_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Text_message_acknowledged_by_driver_OptionalPackets */
typedef enum {
  Text_message_acknowledged_by_driver_OptionalPackageNumber_0_Radio_TrainToTrack = 0,
  Text_message_acknowledged_by_driver_OptionalPackageNumber_1_Radio_TrainToTrack = 1
} Text_message_acknowledged_by_driver_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrainToTrack::Session_Established_OptionalPackets */
typedef enum {
  Session_Established_OptionalPackageNumber_3_Radio_TrainToTrack = 3
} Session_Established_OptionalPackets_Radio_TrainToTrack;
/* Radio_TrackToTrain::SR_Authorisation_OptionalPackets */
typedef enum {
  SR_Authorisation_OptionalPackageNumber_63_Radio_TrackToTrain = 63
} SR_Authorisation_OptionalPackets_Radio_TrackToTrain;
/* Radio_TrackToTrain::Movement_Authority_OptionalPackets */
typedef enum {
  Movement_Authority_OptionalPackageNumber_15_Radio_TrackToTrain = 15,
  Movement_Authority_OptionalPackageNumber_21_Radio_TrackToTrain = 21,
  Movement_Authority_OptionalPackageNumber_27_Radio_TrackToTrain = 27,
  Movement_Authority_OptionalPackageNumber_49_Radio_TrackToTrain = 49,
  Movement_Authority_OptionalPackageNumber_80_Radio_TrackToTrain = 80,
  Movement_Authority_OptionalPackageNumber_3_Radio_TrackToTrain = 3,
  Movement_Authority_OptionalPackageNumber_5_Radio_TrackToTrain = 5,
  Movement_Authority_OptionalPackageNumber_39_Radio_TrackToTrain = 39,
  Movement_Authority_OptionalPackageNumber_40_Radio_TrackToTrain = 40,
  Movement_Authority_OptionalPackageNumber_51_Radio_TrackToTrain = 51,
  Movement_Authority_OptionalPackageNumber_41_Radio_TrackToTrain = 41,
  Movement_Authority_OptionalPackageNumber_42_Radio_TrackToTrain = 42,
  Movement_Authority_OptionalPackageNumber_44_Radio_TrackToTrain = 44,
  Movement_Authority_OptionalPackageNumber_45_Radio_TrackToTrain = 45,
  Movement_Authority_OptionalPackageNumber_52_Radio_TrackToTrain = 52,
  Movement_Authority_OptionalPackageNumber_57_Radio_TrackToTrain = 57,
  Movement_Authority_OptionalPackageNumber_58_Radio_TrackToTrain = 58,
  Movement_Authority_OptionalPackageNumber_64_Radio_TrackToTrain = 64,
  Movement_Authority_OptionalPackageNumber_65_Radio_TrackToTrain = 65,
  Movement_Authority_OptionalPackageNumber_66_Radio_TrackToTrain = 66,
  Movement_Authority_OptionalPackageNumber_68_Radio_TrackToTrain = 68,
  Movement_Authority_OptionalPackageNumber_69_Radio_TrackToTrain = 69,
  Movement_Authority_OptionalPackageNumber_70_Radio_TrackToTrain = 70,
  Movement_Authority_OptionalPackageNumber_71_Radio_TrackToTrain = 71,
  Movement_Authority_OptionalPackageNumber_72_Radio_TrackToTrain = 72,
  Movement_Authority_OptionalPackageNumber_76_Radio_TrackToTrain = 76,
  Movement_Authority_OptionalPackageNumber_79_Radio_TrackToTrain = 79,
  Movement_Authority_OptionalPackageNumber_88_Radio_TrackToTrain = 88,
  Movement_Authority_OptionalPackageNumber_131_Radio_TrackToTrain = 131,
  Movement_Authority_OptionalPackageNumber_138_Radio_TrackToTrain = 138,
  Movement_Authority_OptionalPackageNumber_139_Radio_TrackToTrain = 139,
  Movement_Authority_OptionalPackageNumber_140_Radio_TrackToTrain = 140
} Movement_Authority_OptionalPackets_Radio_TrackToTrain;
/* Radio_TrackToTrain::Request_to_Shorten_MA_OptionalPackets */
typedef enum {
  Request_to_Shorten_MA_OptionalPackageNumber_15_Radio_TrackToTrain = 15,
  Request_to_Shorten_MA_OptionalPackageNumber_80_Radio_TrackToTrain = 80
} Request_to_Shorten_MA_OptionalPackets_Radio_TrackToTrain;
/* Radio_TrackToTrain::General_message_OptionalPackets */
typedef enum {
  General_message_OptionalPackageNumber_21_Radio_TrackToTrain = 21,
  General_message_OptionalPackageNumber_27_Radio_TrackToTrain = 27,
  General_message_OptionalPackageNumber_45_Radio_TrackToTrain = 45,
  General_message_OptionalPackageNumber_143_Radio_TrackToTrain = 143,
  General_message_OptionalPackageNumber_254_Radio_TrackToTrain = 254,
  General_message_OptionalPackageNumber_3_Radio_TrackToTrain = 3,
  General_message_OptionalPackageNumber_5_Radio_TrackToTrain = 5,
  General_message_OptionalPackageNumber_39_Radio_TrackToTrain = 39,
  General_message_OptionalPackageNumber_40_Radio_TrackToTrain = 40,
  General_message_OptionalPackageNumber_51_Radio_TrackToTrain = 51,
  General_message_OptionalPackageNumber_41_Radio_TrackToTrain = 41,
  General_message_OptionalPackageNumber_42_Radio_TrackToTrain = 42,
  General_message_OptionalPackageNumber_44_Radio_TrackToTrain = 44,
  General_message_OptionalPackageNumber_52_Radio_TrackToTrain = 52,
  General_message_OptionalPackageNumber_57_Radio_TrackToTrain = 57,
  General_message_OptionalPackageNumber_58_Radio_TrackToTrain = 58,
  General_message_OptionalPackageNumber_64_Radio_TrackToTrain = 64,
  General_message_OptionalPackageNumber_65_Radio_TrackToTrain = 65,
  General_message_OptionalPackageNumber_66_Radio_TrackToTrain = 66,
  General_message_OptionalPackageNumber_68_Radio_TrackToTrain = 68,
  General_message_OptionalPackageNumber_69_Radio_TrackToTrain = 69,
  General_message_OptionalPackageNumber_70_Radio_TrackToTrain = 70,
  General_message_OptionalPackageNumber_71_Radio_TrackToTrain = 71,
  General_message_OptionalPackageNumber_72_Radio_TrackToTrain = 72,
  General_message_OptionalPackageNumber_76_Radio_TrackToTrain = 76,
  General_message_OptionalPackageNumber_79_Radio_TrackToTrain = 79,
  General_message_OptionalPackageNumber_88_Radio_TrackToTrain = 88,
  General_message_OptionalPackageNumber_131_Radio_TrackToTrain = 131,
  General_message_OptionalPackageNumber_138_Radio_TrackToTrain = 138,
  General_message_OptionalPackageNumber_139_Radio_TrackToTrain = 139,
  General_message_OptionalPackageNumber_140_Radio_TrackToTrain = 140
} General_message_OptionalPackets_Radio_TrackToTrain;
/* Radio_TrackToTrain::SH_Authorised_OptionalPackets */
typedef enum {
  SH_Authorised_OptionalPackageNumber_3_Radio_TrackToTrain = 3,
  SH_Authorised_OptionalPackageNumber_44_Radio_TrackToTrain = 44,
  SH_Authorised_OptionalPackageNumber_49_Radio_TrackToTrain = 49
} SH_Authorised_OptionalPackets_Radio_TrackToTrain;
/* Radio_TrackToTrain::MA_with_Shifted_Location_Reference_OptionalPackets */
typedef enum {
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_15_Radio_TrackToTrain = 15,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_21_Radio_TrackToTrain = 21,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_27_Radio_TrackToTrain = 27,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_49_Radio_TrackToTrain = 49,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_80_Radio_TrackToTrain = 80,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_3_Radio_TrackToTrain = 3,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_5_Radio_TrackToTrain = 5,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_39_Radio_TrackToTrain = 39,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_40_Radio_TrackToTrain = 40,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_51_Radio_TrackToTrain = 51,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_41_Radio_TrackToTrain = 41,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_42_Radio_TrackToTrain = 42,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_44_Radio_TrackToTrain = 44,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_45_Radio_TrackToTrain = 45,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_52_Radio_TrackToTrain = 52,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_57_Radio_TrackToTrain = 57,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_58_Radio_TrackToTrain = 58,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_64_Radio_TrackToTrain = 64,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_65_Radio_TrackToTrain = 65,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_66_Radio_TrackToTrain = 66,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_68_Radio_TrackToTrain = 68,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_69_Radio_TrackToTrain = 69,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_70_Radio_TrackToTrain = 70,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_71_Radio_TrackToTrain = 71,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_72_Radio_TrackToTrain = 72,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_76_Radio_TrackToTrain = 76,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_79_Radio_TrackToTrain = 79,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_88_Radio_TrackToTrain = 88,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_131_Radio_TrackToTrain = 131,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_138_Radio_TrackToTrain = 138,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_139_Radio_TrackToTrain = 139,
  MA_with_Shifted_Location_Reference_OptionalPackageNumber_140_Radio_TrackToTrain = 140
} MA_with_Shifted_Location_Reference_OptionalPackets_Radio_TrackToTrain;
/* Radio_TrackToTrain::Infill_MA_OptionalPackets */
typedef enum {
  Infill_MA_OptionalPackageNumber_136_Radio_TrackToTrain = 136,
  Infill_MA_OptionalPackageNumber_12_Radio_TrackToTrain = 12,
  Infill_MA_OptionalPackageNumber_5_Radio_TrackToTrain = 5,
  Infill_MA_OptionalPackageNumber_21_Radio_TrackToTrain = 21,
  Infill_MA_OptionalPackageNumber_27_Radio_TrackToTrain = 27,
  Infill_MA_OptionalPackageNumber_39_Radio_TrackToTrain = 39,
  Infill_MA_OptionalPackageNumber_40_Radio_TrackToTrain = 40,
  Infill_MA_OptionalPackageNumber_41_Radio_TrackToTrain = 41,
  Infill_MA_OptionalPackageNumber_44_Radio_TrackToTrain = 44,
  Infill_MA_OptionalPackageNumber_49_Radio_TrackToTrain = 49,
  Infill_MA_OptionalPackageNumber_51_Radio_TrackToTrain = 51,
  Infill_MA_OptionalPackageNumber_65_Radio_TrackToTrain = 65,
  Infill_MA_OptionalPackageNumber_66_Radio_TrackToTrain = 66,
  Infill_MA_OptionalPackageNumber_68_Radio_TrackToTrain = 68,
  Infill_MA_OptionalPackageNumber_69_Radio_TrackToTrain = 69,
  Infill_MA_OptionalPackageNumber_70_Radio_TrackToTrain = 70,
  Infill_MA_OptionalPackageNumber_71_Radio_TrackToTrain = 71,
  Infill_MA_OptionalPackageNumber_80_Radio_TrackToTrain = 80,
  Infill_MA_OptionalPackageNumber_88_Radio_TrackToTrain = 88,
  Infill_MA_OptionalPackageNumber_138_Radio_TrackToTrain = 138,
  Infill_MA_OptionalPackageNumber_139_Radio_TrackToTrain = 139
} Infill_MA_OptionalPackets_Radio_TrackToTrain;
/* truthtables::TruthTableValues */
typedef enum {
  T_truthtables,
  F_truthtables,
  X_truthtables
} TruthTableValues_truthtables;
/* M_LEVEL */
typedef enum {
  M_LEVEL_Level_0 = 0,
  M_LEVEL_Level_NTC_specified_by_NID_NTC = 1,
  M_LEVEL_Level_1 = 2,
  M_LEVEL_Level_2 = 3,
  M_LEVEL_Level_3 = 4
} M_LEVEL;
/* M_MODE */
typedef enum {
  M_MODE_Full_Supervision = 0,
  M_MODE_On_Sight = 1,
  M_MODE_Staff_Responsible = 2,
  M_MODE_Shunting = 3,
  M_MODE_Unfitted = 4,
  M_MODE_Sleeping = 5,
  M_MODE_Stand_By = 6,
  M_MODE_Trip = 7,
  M_MODE_Post_Trip = 8,
  M_MODE_System_Failure = 9,
  M_MODE_Isolation = 10,
  M_MODE_Non_Leading = 11,
  M_MODE_Limited_Supervision = 12,
  M_MODE_National_System = 13,
  M_MODE_Reversing = 14,
  M_MODE_Passive_Shunting = 15
} M_MODE;
/* Q_LENGTH */
typedef enum {
  Q_LENGTH_No_train_integrity_information_available = 0,
  Q_LENGTH_Train_integrity_confirmed_by_integrity_monitoring_device = 1,
  Q_LENGTH_Train_integrity_confirmed_by_driver = 2,
  Q_LENGTH_Train_integrity_lost = 3
} Q_LENGTH;
/* M_DUP */
typedef enum {
  M_DUP_No_duplicates = 0,
  M_DUP_This_balise_is_a_duplicate_of_the_next_balise = 1,
  M_DUP_This_balise_is_a_duplicate_of_the_previous_balise = 2
} M_DUP;
/* N_PIG */
typedef enum {
  N_PIG_I_am_the_1st = 0,
  N_PIG_I_am_the_2nd = 1,
  N_PIG_I_am_the_3rd = 2,
  N_PIG_I_am_the_4th = 3,
  N_PIG_I_am_the_5th = 4,
  N_PIG_I_am_the_6th = 5,
  N_PIG_I_am_the_7th = 6,
  N_PIG_I_am_the_8th = 7
} N_PIG;
/* M_LEVELTR */
typedef enum {
  M_LEVELTR_Level_0 = 0,
  M_LEVELTR_Level_NTC_specified_by_NID_NTC = 1,
  M_LEVELTR_Level_1 = 2,
  M_LEVELTR_Level_2 = 3,
  M_LEVELTR_Level_3 = 4
} M_LEVELTR;
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementDir_T */
typedef enum {
  trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg,
  trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg,
  trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg,
  trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg
} trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg;
/* Q_DLRBG */
typedef enum {
  Q_DLRBG_Reverse = 0,
  Q_DLRBG_Nominal = 1,
  Q_DLRBG_Unknown = 2
} Q_DLRBG;
/* Q_DIRLRBG */
typedef enum {
  Q_DIRLRBG_Reverse = 0,
  Q_DIRLRBG_Nominal = 1,
  Q_DIRLRBG_Unknown = 2
} Q_DIRLRBG;
/* Q_DIRTRAIN */
typedef enum {
  Q_DIRTRAIN_Reverse = 0,
  Q_DIRTRAIN_Nominal = 1,
  Q_DIRTRAIN_Unknown = 2
} Q_DIRTRAIN;
/* M_VERSION */
typedef enum {
  M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS = 0,
  M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0 = 16,
  M_VERSION_Version_1_1_introduced_in_SRS_3_3_0 = 17,
  M_VERSION_Version_2_0_introduced_in_SRS_3_3_0 = 32
} M_VERSION;
/* N_TOTAL */
typedef enum {
  N_TOTAL_1_balise_in_the_group = 0,
  N_TOTAL_2_balises_in_the_group = 1,
  N_TOTAL_3_balises_in_the_group = 2,
  N_TOTAL_4_balises_in_the_group = 3,
  N_TOTAL_5_balises_in_the_group = 4,
  N_TOTAL_6_balises_in_the_group = 5,
  N_TOTAL_7_balises_in_the_group = 6,
  N_TOTAL_8_balises_in_the_group = 7
} N_TOTAL;
/* Q_LINK */
typedef enum { Q_LINK_Unlinked = 0, Q_LINK_Linked = 1 } Q_LINK;
/* Q_MEDIA */
typedef enum { Q_MEDIA_Balise = 0, Q_MEDIA_Loop = 1 } Q_MEDIA;
/* Q_UPDOWN */
typedef enum {
  Q_UPDOWN_Down_link_telegram = 0,
  Q_UPDOWN_Up_link_telegram = 1
} Q_UPDOWN;
/* Q_DIR */
typedef enum {
  Q_DIR_Reverse = 0,
  Q_DIR_Nominal = 1,
  Q_DIR_Both_directions = 2
} Q_DIR;
/* Q_LINKORIENTATION */
typedef enum {
  Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction = 0,
  Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction = 1
} Q_LINKORIENTATION;
/* Q_LINKREACTION */
typedef enum {
  Q_LINKREACTION_Train_trip = 0,
  Q_LINKREACTION_Apply_service_brake = 1,
  Q_LINKREACTION_No_Reaction = 2
} Q_LINKREACTION;
/* Q_NEWCOUNTRY */
typedef enum {
  Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows = 0,
  Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows = 1
} Q_NEWCOUNTRY;
/* Q_SCALE */
typedef enum {
  Q_SCALE_10_cm_scale = 0,
  Q_SCALE_1_m_scale = 1,
  Q_SCALE_10_m_scale = 2
} Q_SCALE;
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */
typedef enum {
  SSM_TR_no_trans_SM1,
  SSM_TR_Unknown_1_SM1,
  SSM_TR_Unknown_2_SM1,
  SSM_TR_Unknown_3_SM1,
  SSM_TR_Decreasing_1_SM1,
  SSM_TR_Decreasing_2_SM1,
  SSM_TR_Increasing_1_SM1,
  SSM_TR_Increasing_2_SM1,
  SSM_TR_Standstill_1_SM1,
  SSM_TR_Standstill_2_SM1
} SSM_TR_SM1;
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */
typedef enum {
  SSM_st_Unknown_SM1,
  SSM_st_Decreasing_SM1,
  SSM_st_Increasing_SM1,
  SSM_st_Standstill_SM1
} SSM_ST_SM1;
/* A_NVMAXREDADH1 */
typedef kcg_real A_NVMAXREDADH1;

/* A_NVMAXREDADH2 */
typedef kcg_real A_NVMAXREDADH2;

/* A_NVMAXREDADH3 */
typedef kcg_real A_NVMAXREDADH3;

/* A_NVP12 */
typedef kcg_real A_NVP12;

/* A_NVP23 */
typedef kcg_real A_NVP23;

/* M_NVAVADH */
typedef kcg_real M_NVAVADH;

/* M_NVKRINT */
typedef kcg_real M_NVKRINT;

/* M_NVKTINT */
typedef kcg_real M_NVKTINT;

/* M_NVKVINT */
typedef kcg_real M_NVKVINT;

/* T_TRAIN */
typedef kcg_real T_TRAIN;

/* D_ADHESION */
typedef kcg_int D_ADHESION;

/* D_AXLELOAD */
typedef kcg_int D_AXLELOAD;

/* D_CURRENT */
typedef kcg_int D_CURRENT;

/* D_CYCLOC */
typedef kcg_int D_CYCLOC;

/* D_DP */
typedef kcg_int D_DP;

/* D_EMERGENCYSTOP */
typedef kcg_int D_EMERGENCYSTOP;

/* D_ENDTIMERSTARTLOC */
typedef kcg_int D_ENDTIMERSTARTLOC;

/* D_GRADIENT */
typedef kcg_int D_GRADIENT;

/* D_INFILL */
typedef kcg_int D_INFILL;

/* D_LEVELTR */
typedef kcg_int D_LEVELTR;

/* D_LINK */
typedef kcg_int D_LINK;

/* D_LOC */
typedef kcg_int D_LOC;

/* D_LOOP */
typedef kcg_int D_LOOP;

/* D_LRBG */
typedef kcg_int D_LRBG;

/* D_LX */
typedef kcg_int D_LX;

/* D_MAMODE */
typedef kcg_int D_MAMODE;

/* D_NVOVTRP */
typedef kcg_int D_NVOVTRP;

/* D_NVPOTRP */
typedef kcg_int D_NVPOTRP;

/* D_NVROLL */
typedef kcg_int D_NVROLL;

/* D_NVSTFF */
typedef kcg_int D_NVSTFF;

/* D_OL */
typedef kcg_int D_OL;

/* D_PBD */
typedef kcg_int D_PBD;

/* D_PBDSR */
typedef kcg_int D_PBDSR;

/* D_POSOFF */
typedef kcg_int D_POSOFF;

/* D_RBCTR */
typedef kcg_int D_RBCTR;

/* D_REF */
typedef kcg_int D_REF;

/* D_REVERSE */
typedef kcg_int D_REVERSE;

/* D_SECTIONTIMERSTOPLOC */
typedef kcg_int D_SECTIONTIMERSTOPLOC;

/* D_SR */
typedef kcg_int D_SR;

/* D_STARTOL */
typedef kcg_int D_STARTOL;

/* D_STARTREVERSE */
typedef kcg_int D_STARTREVERSE;

/* D_STATIC */
typedef kcg_int D_STATIC;

/* D_SUITABILITY */
typedef kcg_int D_SUITABILITY;

/* D_TAFDISPLAY */
typedef kcg_int D_TAFDISPLAY;

/* D_TEXTDISPLAY */
typedef kcg_int D_TEXTDISPLAY;

/* D_TRACKINIT */
typedef kcg_int D_TRACKINIT;

/* D_TRACKCOND */
typedef kcg_int D_TRACKCOND;

/* D_TRACTION */
typedef kcg_int D_TRACTION;

/* D_TSR */
typedef kcg_int D_TSR;

/* D_VALIDNV */
typedef kcg_int D_VALIDNV;

/* G_A */
typedef kcg_int G_A;

/* G_PBDSR */
typedef kcg_int G_PBDSR;

/* G_TSR */
typedef kcg_int G_TSR;

/* L_ACKLEVELTR */
typedef kcg_int L_ACKLEVELTR;

/* L_ACKMAMODE */
typedef kcg_int L_ACKMAMODE;

/* L_ADHESION */
typedef kcg_int L_ADHESION;

/* L_AXLELOAD */
typedef kcg_int L_AXLELOAD;

/* L_DOUBTOVER */
typedef kcg_int L_DOUBTOVER;

/* L_DOUBTUNDER */
typedef kcg_int L_DOUBTUNDER;

/* L_ENDSECTION */
typedef kcg_int L_ENDSECTION;

/* L_LOOP */
typedef kcg_int L_LOOP;

/* L_LX */
typedef kcg_int L_LX;

/* L_MAMODE */
typedef kcg_int L_MAMODE;

/* L_MESSAGE */
typedef kcg_int L_MESSAGE;

/* L_PACKET */
typedef kcg_int L_PACKET;

/* L_PBDSR */
typedef kcg_int L_PBDSR;

/* L_REVERSEAREA */
typedef kcg_int L_REVERSEAREA;

/* L_SECTION */
typedef kcg_int L_SECTION;

/* L_STOPLX */
typedef kcg_int L_STOPLX;

/* L_TAFDISPLAY */
typedef kcg_int L_TAFDISPLAY;

/* L_TEXT */
typedef kcg_int L_TEXT;

/* L_TEXTDISPLAY */
typedef kcg_int L_TEXTDISPLAY;

/* L_TRACKCOND */
typedef kcg_int L_TRACKCOND;

/* L_TRAIN */
typedef kcg_int L_TRAIN;

/* L_TRAININT */
typedef kcg_int L_TRAININT;

/* L_TSR */
typedef kcg_int L_TSR;

/* M_CURRENT */
typedef kcg_int M_CURRENT;

/* M_MCOUNT */
typedef kcg_int M_MCOUNT;

/* M_POSITION */
typedef kcg_int M_POSITION;

/* N_AXLE */
typedef kcg_int N_AXLE;

/* N_ITER */
typedef kcg_int N_ITER;

/* NC_DIFF */
typedef kcg_int NC_DIFF;

/* NID_BG */
typedef kcg_int NID_BG;

/* NID_C */
typedef kcg_int NID_C;

/* NID_CTRACTION */
typedef kcg_int NID_CTRACTION;

/* NID_EM */
typedef kcg_int NID_EM;

/* NID_ENGINE */
typedef kcg_int NID_ENGINE;

/* NID_LOOP */
typedef kcg_int NID_LOOP;

/* NID_LRBG */
typedef kcg_int NID_LRBG;

/* NID_LTRBG */
typedef kcg_int NID_LTRBG;

/* NID_LX */
typedef kcg_int NID_LX;

/* NID_MESSAGE */
typedef kcg_int NID_MESSAGE;

/* NID_MN */
typedef kcg_int NID_MN;

/* NID_OPERATIONAL */
typedef kcg_int NID_OPERATIONAL;

/* NID_PACKET */
typedef kcg_int NID_PACKET;

/* NID_PRVLRBG */
typedef kcg_int NID_PRVLRBG;

/* NID_RADIO */
typedef kcg_int NID_RADIO;

/* NID_RBC */
typedef kcg_int NID_RBC;

/* NID_RIU */
typedef kcg_int NID_RIU;

/* NID_NTC */
typedef kcg_int NID_NTC;

/* NID_TEXTMESSAGE */
typedef kcg_int NID_TEXTMESSAGE;

/* NID_TSR */
typedef kcg_int NID_TSR;

/* NID_VBCMK */
typedef kcg_int NID_VBCMK;

/* NID_XUSER */
typedef kcg_int NID_XUSER;

/* Q_LOCACC */
typedef kcg_int Q_LOCACC;

/* Q_NVLOCACC */
typedef kcg_int Q_NVLOCACC;

/* Q_SSCODE */
typedef kcg_int Q_SSCODE;

/* T_CYCLOC */
typedef kcg_int T_CYCLOC;

/* T_CYCRQST */
typedef kcg_int T_CYCRQST;

/* T_ENDTIMER */
typedef kcg_int T_ENDTIMER;

/* T_LOA */
typedef kcg_int T_LOA;

/* T_MAR */
typedef kcg_int T_MAR;

/* T_NVCONTACT */
typedef kcg_int T_NVCONTACT;

/* T_NVOVTRP */
typedef kcg_int T_NVOVTRP;

/* T_OL */
typedef kcg_int T_OL;

/* T_SECTIONTIMER */
typedef kcg_int T_SECTIONTIMER;

/* T_TEXTDISPLAY */
typedef kcg_int T_TEXTDISPLAY;

/* T_TIMEOUTRQST */
typedef kcg_int T_TIMEOUTRQST;

/* T_VBC */
typedef kcg_int T_VBC;

/* V_AXLELOAD */
typedef kcg_int V_AXLELOAD;

/* V_DIFF */
typedef kcg_int V_DIFF;

/* V_LOA */
typedef kcg_int V_LOA;

/* V_LX */
typedef kcg_int V_LX;

/* V_MAIN */
typedef kcg_int V_MAIN;

/* V_MAMODE */
typedef kcg_int V_MAMODE;

/* V_MAXTRAIN */
typedef kcg_int V_MAXTRAIN;

/* V_NVALLOWOVTRP */
typedef kcg_int V_NVALLOWOVTRP;

/* V_NVKVINT */
typedef kcg_int V_NVKVINT;

/* V_NVLIMSUPERV */
typedef kcg_int V_NVLIMSUPERV;

/* V_NVONSIGHT */
typedef kcg_int V_NVONSIGHT;

/* V_NVSUPOVTRP */
typedef kcg_int V_NVSUPOVTRP;

/* V_NVREL */
typedef kcg_int V_NVREL;

/* V_NVSHUNT */
typedef kcg_int V_NVSHUNT;

/* V_NVSTFF */
typedef kcg_int V_NVSTFF;

/* V_NVUNFIT */
typedef kcg_int V_NVUNFIT;

/* V_RELEASEDP */
typedef kcg_int V_RELEASEDP;

/* V_RELEASEOL */
typedef kcg_int V_RELEASEOL;

/* V_REVERSE */
typedef kcg_int V_REVERSE;

/* V_STATIC */
typedef kcg_int V_STATIC;

/* V_TRAIN */
typedef kcg_int V_TRAIN;

/* V_TSR */
typedef kcg_int V_TSR;

/* X_TEXT */
typedef kcg_int X_TEXT;

/* Obu_BasicTypes_Pkg::L_internal_Type */
typedef kcg_int L_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::Location_T */
typedef L_internal_Type_Obu_BasicTypes_Pkg Location_T_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::T_internal_Type */
typedef kcg_int T_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::V_internal_Type */
typedef kcg_int V_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::Speed_T */
typedef V_internal_Type_Obu_BasicTypes_Pkg Speed_T_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::G_internal_Type */
typedef kcg_int G_internal_Type_Obu_BasicTypes_Pkg;

/* Obu_BasicTypes_Pkg::A_internal_Type */
typedef kcg_int A_internal_Type_Obu_BasicTypes_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_int nid_LRBG;
  kcg_int nid_packet;
  Q_DIR q_dir;
  kcg_int l_packet;
  Q_SCALE q_scale;
  kcg_int d_link;
  Q_NEWCOUNTRY q_newcountry;
  kcg_int nid_c;
  kcg_int nid_bg;
  Q_LINKORIENTATION q_linkorientation;
  Q_LINKREACTION q_linkreaction;
  kcg_int q_locacc;
} struct__13859;

/* BG_Types_Pkg::LinkedBG_T */
typedef struct__13859 LinkedBG_T_BG_Types_Pkg;

typedef struct__13859 array__13875[4];

/* BG_Types_Pkg::LinkedBGs_T */
typedef array__13875 LinkedBGs_T_BG_Types_Pkg;

typedef struct {
  Q_UPDOWN q_updown;
  M_VERSION m_version;
  Q_MEDIA q_media;
  N_TOTAL n_total;
  kcg_int m_mcount;
  kcg_int nid_c;
  kcg_int nid_bg;
  Q_LINK q_link;
} struct__13878;

/* BG_Types_Pkg::BG_Header_T */
typedef struct__13878 BG_Header_T_BG_Types_Pkg;

typedef struct {
  kcg_int o_nominal;
  kcg_int o_min;
  kcg_int o_max;
} struct__13889;

/* Obu_BasicTypes_Pkg::OdometryLocations_T */
typedef struct__13889 OdometryLocations_T_Obu_BasicTypes_Pkg;

typedef struct { kcg_int nominal; kcg_int d_min; kcg_int d_max; } struct__13895;

/* Obu_BasicTypes_Pkg::LocWithInAcc_T */
typedef struct__13895 LocWithInAcc_T_Obu_BasicTypes_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_int timestamp;
  struct__13889 odometrystamp;
  struct__13895 BG_centerDetectionInaccuraccuracies;
  struct__13878 BG_Header;
  array__13875 linkedBGs;
  kcg_bool noCoordinateSystemHasBeenAssigned;
  Q_DIRLRBG trainOrientationToBG;
  Q_DIRTRAIN trainRunningDirectionToBG;
  kcg_int passingSpeed;
} struct__13901;

/* BG_Types_Pkg::passedBG_T */
typedef struct__13901 passedBG_T_BG_Types_Pkg;

typedef struct {
  kcg_bool outOfMemSpace;
  kcg_bool passedBG_notFoundWhereExpected;
  kcg_bool positionCalculation_inconsistent;
} struct__13914;

/* TrainPosition_Types_Pck::positionErrors_T */
typedef struct__13914 positionErrors_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  kcg_int nid_bg_fromLinkingBG;
  kcg_int nid_c_fromLinkingBG;
  struct__13895 expectedLocation;
  struct__13895 d_link;
  struct__13859 linkingInfo;
} struct__13920;

/* TrainPosition_Types_Pck::infoFromLinking_T */
typedef struct__13920 infoFromLinking_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  kcg_int nid_c;
  kcg_int nid_bg;
  Q_LINK q_link;
  struct__13895 location;
  kcg_int seqNoOnTrack;
  struct__13920 infoFromLinking;
  struct__13901 infoFromPassing;
} struct__13929;

/* TrainPosition_Types_Pck::positionedBG_T */
typedef struct__13929 positionedBG_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPosition;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPositionDerivedFromLastLinkedBG;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPositionDerivedFromLastUnlinkedBG;
  positionedBG_T_TrainPosition_Types_Pck lastPassedLinkedBG;
  positionedBG_T_TrainPosition_Types_Pck lastPassedUnlinkedBG;
  Speed_T_Obu_BasicTypes_Pkg speed;
} struct__13940;

/* TrainPosition_Types_Pck::trainPositionInfo_T */
typedef struct__13940 trainPositionInfo_T_TrainPosition_Types_Pck;

typedef positionedBG_T_TrainPosition_Types_Pck array__13951[8];

/* TrainPosition_Types_Pck::positionedBGs_T */
typedef array__13951 positionedBGs_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_bool valid;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
  kcg_bool trainPositionIsUnknown;
  kcg_bool noCoordinateSystemHasBeenAssigned;
  LocWithInAcc_T_Obu_BasicTypes_Pkg trainPosition;
  Location_T_Obu_BasicTypes_Pkg estimatedFrontEndPosition;
  Location_T_Obu_BasicTypes_Pkg minSafeFrontEndPosition;
  Location_T_Obu_BasicTypes_Pkg maxSafeFrontEndPostion;
  NID_BG nid_LRBG;
  NID_PRVLRBG nid_PrvLRB;
  Q_DLRBG nominalOrReverseToLRBG;
  Q_DIRLRBG trainOrientationToLRBG;
  Q_DIRTRAIN trainRunningDirectionToLRBG;
  Speed_T_Obu_BasicTypes_Pkg speed;
} struct__13954;

/* TrainPosition_Types_Pck::trainPosition_T */
typedef struct__13954 trainPosition_T_TrainPosition_Types_Pck;

typedef struct {
  NID_ENGINE nid_engine;
  NID_OPERATIONAL nid_operational;
  L_TRAIN l_train;
  LocWithInAcc_T_Obu_BasicTypes_Pkg d_baliseAntenna_2_frontend;
  LocWithInAcc_T_Obu_BasicTypes_Pkg d_frontend_2_rearend;
  Q_NVLOCACC locationAccuracy_NationalValue;
  LocWithInAcc_T_Obu_BasicTypes_Pkg locationAccuracy_DefaultValue;
  LocWithInAcc_T_Obu_BasicTypes_Pkg centerDetectionAcc_DefaultValue;
} struct__13971;

/* TrainPosition_Types_Pck::trainProperties_T */
typedef struct__13971 trainProperties_T_TrainPosition_Types_Pck;

typedef struct {
  kcg_int index;
  kcg_int noOfFoundBGs;
  kcg_bool BGFound;
} struct__13982;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::BG_find_T */
typedef struct__13982 BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

typedef struct {
  kcg_int unlinkedBGsCount;
  kcg_int linkedBGsCount;
  kcg_int totalBGsCount;
  kcg_int passedUnlinkedBGsCount;
  kcg_int passedLinkedBGsCount;
  kcg_int passedTotalBGsCount;
} struct__13988;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::BG_counters_T */
typedef struct__13988 BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

typedef struct {
  kcg_bool valid;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
  OdometryLocations_T_Obu_BasicTypes_Pkg odo;
  Speed_T_Obu_BasicTypes_Pkg speed;
} struct__13997;

/* Obu_BasicTypes_Pkg::odometry_T */
typedef struct__13997 odometry_T_Obu_BasicTypes_Pkg;

typedef positionedBG_T_TrainPosition_Types_Pck array__14004[4];

/* TrainPosition_Types_Pck::linkedBGs_asPositionedBGs_T */
typedef array__14004 linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck;

typedef struct {
  positionedBGs_T_TrainPosition_Types_Pck BGs;
  kcg_bool overrun;
} struct__14007;

/* CalculateTrainPosition_Pkg::positionedBGs_w_overrun_T */
typedef struct__14007 positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg;

typedef struct {
  kcg_int previousLinkedBG_idx;
  kcg_int currentIndex;
  kcg_int subsequentLinkedBG_idx;
} struct__14012;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::linkedBG_index_T */
typedef struct__14012 linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg array__14018[8];

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::linkedBGs_indices_T */
typedef array__14018 linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef struct {
  positionedBG_T_TrainPosition_Types_Pck refBG;
  positionedBG_T_TrainPosition_Types_Pck prevLinkedBG;
  positionedBG_T_TrainPosition_Types_Pck prevUnlinkedBG;
  kcg_bool recalculate;
  LocWithInAcc_T_Obu_BasicTypes_Pkg sumOfBestDistances;
} struct__14021;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::refBGs_T */
typedef struct__14021 refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef struct {
  L_internal_Type_Obu_BasicTypes_Pkg idealLocation;
  passedBG_T_BG_Types_Pkg passedBG;
} struct__14029;

/* ctp_t_pck::t_engine::genPassedBG_T */
typedef struct__14029 genPassedBG_T_ctp_t_pck_t_engine;

typedef genPassedBG_T_ctp_t_pck_t_engine array__14034[10];

/* ctp_t_pck::t_engine::genPassedBGs_T */
typedef array__14034 genPassedBGs_T_ctp_t_pck_t_engine;

typedef struct {
  kcg_real o_nominal;
  kcg_real o_min;
  kcg_real o_max;
} struct__14037;

/* ctp_t_pck::t_engine::odometryFactors_T */
typedef struct__14037 odometryFactors_T_ctp_t_pck_t_engine;

typedef struct {
  kcg_bool valid;
  Q_DIR q_dir;
  Q_SCALE q_scale;
  D_LEVELTR d_leveltr;
  M_LEVELTR m_leveltr;
  NID_NTC nid_ntc;
  L_ACKLEVELTR l_ackleveltr;
} struct__14043;

/* BG_Types_Pkg::levelTransitionOrder_T */
typedef struct__14043 levelTransitionOrder_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  L_internal_Type_Obu_BasicTypes_Pkg distanceSinceLTORef;
  levelTransitionOrder_T_BG_Types_Pkg nextLTO;
} struct__14053;

/* BG_Types_Pkg::levelTransitionOrderCmd_T */
typedef struct__14053 levelTransitionOrderCmd_T_BG_Types_Pkg;

typedef levelTransitionOrder_T_BG_Types_Pkg array__14059[4];

/* BG_Types_Pkg::levelTransitionOrders_T */
typedef array__14059 levelTransitionOrders_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  BG_Header_T_BG_Types_Pkg BG_Header;
  levelTransitionOrders_T_BG_Types_Pkg orders;
} struct__14062;

/* BG_Types_Pkg::levelTransitionOrderBGMsg_T */
typedef struct__14062 levelTransitionOrderBGMsg_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  OdometryLocations_T_Obu_BasicTypes_Pkg centerOfBalisePosition;
  LocWithInAcc_T_Obu_BasicTypes_Pkg BG_centerDetectionInaccuraccuracies;
  T_internal_Type_Obu_BasicTypes_Pkg timestamp;
} struct__14068;

/* BG_Types_Pkg::centerOfBalisePosition_T */
typedef struct__14068 centerOfBalisePosition_T_BG_Types_Pkg;

typedef struct {
  Q_UPDOWN q_updown;
  M_VERSION m_version;
  Q_MEDIA q_media;
  N_PIG n_pig;
  N_TOTAL n_total;
  M_DUP m_dup;
  M_MCOUNT m_mcount;
  NID_C nid_c;
  NID_BG nid_bg;
  Q_LINK q_link;
} struct__14075;

/* BG_Types_Pkg::TelegramHeader_T */
typedef struct__14075 TelegramHeader_T_BG_Types_Pkg;

typedef struct { LinkedBGs_T_BG_Types_Pkg linkingPackets; } struct__14088;

/* BG_Types_Pkg::AdditionalInformation_T */
typedef struct__14088 AdditionalInformation_T_BG_Types_Pkg;

typedef struct {
  kcg_bool valid;
  kcg_bool checkResult;
  TelegramHeader_T_BG_Types_Pkg telegramheader;
  AdditionalInformation_T_BG_Types_Pkg packets;
} struct__14092;

/* BG_Types_Pkg::Telegram_T */
typedef struct__14092 Telegram_T_BG_Types_Pkg;

typedef Telegram_T_BG_Types_Pkg array__14099[8];

/* BG_Types_Pkg::TelegramArray_T */
typedef array__14099 TelegramArray_T_BG_Types_Pkg;

typedef struct {
  kcg_bool present;
  TelegramArray_T_BG_Types_Pkg Telegrams;
  kcg_int numberBalises;
  centerOfBalisePosition_T_BG_Types_Pkg centerOfBalisePosition;
  Q_DIRTRAIN BGOrientation;
} struct__14102;

/* BG_Types_Pkg::BG_Message_T */
typedef struct__14102 BG_Message_T_BG_Types_Pkg;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int Q_ORIENTATION;
} struct__14110;

/* Radio_TrackToTrain::Assignment_of_coordinate_system */
typedef struct__14110 Assignment_of_coordinate_system_Radio_TrackToTrain;

typedef struct {
  Assignment_of_coordinate_system_Radio_TrackToTrain assignment_of_coordinate_system;
} struct__14119;

/* BG_Types_Pkg::RBCOrientationReport_T */
typedef struct__14119 RBCOrientationReport_T_BG_Types_Pkg;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING3;
  kcg_int Train_Position_Report_OptionalPackets;
} struct__14123;

/* Radio_TrainToTrack::Train_Position_Report */
typedef struct__14123 Train_Position_Report_Radio_TrainToTrack;

typedef struct {
  Train_Position_Report_Radio_TrainToTrack train_position_report;
} struct__14132;

/* BG_Types_Pkg::RBCReport_T */
typedef struct__14132 RBCReport_T_BG_Types_Pkg;

typedef struct {
  M_MODE m_mode;
  M_LEVEL m_level;
  M_LEVELTR m_leveltr;
  NID_NTC nid_ntc;
  Q_LENGTH q_length;
} struct__14136;

/* BG_Types_Pkg::TrainToTrackStatus_T */
typedef struct__14136 TrainToTrackStatus_T_BG_Types_Pkg;

typedef struct {
  positionedBG_T_TrainPosition_Types_Pck prevLinkedBG;
  positionedBG_T_TrainPosition_Types_Pck unlinkedBG;
  kcg_int indexOfUnlinkedBG;
} struct__14144;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::BGs_forImprovement_T */
typedef struct__14144 BGs_forImprovement_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

typedef struct { kcg_int k; kcg_real f; } struct__14150;

/* lut::LutIndex */
typedef struct__14150 LutIndex_lut;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
} struct__14155;

/* Radio_TrackToTrain::Recognition_of_exit_from_TRIP_mode */
typedef struct__14155 Recognition_of_exit_from_TRIP_mode_Radio_TrackToTrain;

/* Radio_TrackToTrain::Initiation_of_a_communication_session */
typedef struct__14155 Initiation_of_a_communication_session_Radio_TrackToTrain;

/* Radio_TrackToTrain::Acknowledgement_of_termination_of_a_communication_session */
typedef struct__14155 Acknowledgement_of_termination_of_a_communication_session_Radio_TrackToTrain;

/* Radio_TrackToTrain::Train_Rejected */
typedef struct__14155 Train_Rejected_Radio_TrackToTrain;

/* Radio_TrackToTrain::Train_Accepted */
typedef struct__14155 Train_Accepted_Radio_TrackToTrain;

/* Radio_TrackToTrain::SoM_position_report_confirmed_by_RBC */
typedef struct__14155 SoM_position_report_confirmed_by_RBC_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int PADDING18;
  kcg_int Infill_MA_OptionalPackets;
} struct__14163;

/* Radio_TrackToTrain::Infill_MA */
typedef struct__14163 Infill_MA_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int Q_SCALE;
  kcg_int D_REF;
  kcg_int Q_DIR;
  kcg_int D_TAFDISPLAY;
  kcg_int L_TAFDISPLAY;
} struct__14173;

/* Radio_TrackToTrain::Track_Ahead_Free_Request */
typedef struct__14173 Track_Ahead_Free_Request_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int Q_SCALE;
  kcg_int D_REF;
  kcg_int PADDING17;
  kcg_int MA_with_Shifted_Location_Reference_OptionalPackets;
} struct__14186;

/* Radio_TrackToTrain::MA_with_Shifted_Location_Reference */
typedef struct__14186 MA_with_Shifted_Location_Reference_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int M_VERSION;
} struct__14198;

/* Radio_TrackToTrain::RBC_or_RIU_System_Version */
typedef struct__14198 RBC_or_RIU_System_Version_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN0;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_real T_TRAIN1;
  kcg_int PADDING16;
  kcg_int SH_Authorised_OptionalPackets;
} struct__14207;

/* Radio_TrackToTrain::SH_Authorised */
typedef struct__14207 SH_Authorised_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN0;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_real T_TRAIN1;
} struct__14218;

/* Radio_TrackToTrain::Acknowledgement_of_Train_Data */
typedef struct__14218 Acknowledgement_of_Train_Data_Radio_TrackToTrain;

/* Radio_TrackToTrain::SH_Refused */
typedef struct__14218 SH_Refused_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int PADDING15;
  kcg_int General_message_OptionalPackets;
} struct__14227;

/* Radio_TrackToTrain::General_message */
typedef struct__14227 General_message_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int NID_EM;
} struct__14237;

/* Radio_TrackToTrain::Unconditional_Emergency_Stop */
typedef struct__14237 Unconditional_Emergency_Stop_Radio_TrackToTrain;

/* Radio_TrackToTrain::Revocation_of_Emergency_Stop */
typedef struct__14237 Revocation_of_Emergency_Stop_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int NID_EM;
  kcg_int Q_SCALE;
  kcg_int D_REF;
  kcg_int Q_DIR;
  kcg_int D_EMERGENCYSTOP;
} struct__14246;

/* Radio_TrackToTrain::Conditional_Emergency_Stop */
typedef struct__14246 Conditional_Emergency_Stop_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int PADDING14;
  kcg_int Request_to_Shorten_MA_OptionalPackets;
} struct__14259;

/* Radio_TrackToTrain::Request_to_Shorten_MA */
typedef struct__14259 Request_to_Shorten_MA_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int PADDING13;
  kcg_int Movement_Authority_OptionalPackets;
} struct__14269;

/* Radio_TrackToTrain::Movement_Authority */
typedef struct__14269 Movement_Authority_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int M_ACK;
  kcg_int NID_LRBG;
  kcg_int Q_SCALE;
  kcg_int D_SR;
  kcg_int PADDING12;
  kcg_int SR_Authorisation_OptionalPackets;
} struct__14279;

/* Radio_TrackToTrain::SR_Authorisation */
typedef struct__14279 SR_Authorisation_Radio_TrackToTrain;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING11;
  kcg_int Session_Established_OptionalPackets;
} struct__14291;

/* Radio_TrainToTrack::Session_Established */
typedef struct__14291 Session_Established_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int NID_TEXTMESSAGE;
  kcg_int PADDING10;
  kcg_int Text_message_acknowledged_by_driver_OptionalPackets;
} struct__14300;

/* Radio_TrainToTrack::Text_message_acknowledged_by_driver */
typedef struct__14300 Text_message_acknowledged_by_driver_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int Q_STATUS;
  kcg_int PADDING9;
  kcg_int SoM_Position_Report_OptionalPackets;
} struct__14310;

/* Radio_TrainToTrack::SoM_Position_Report */
typedef struct__14310 SoM_Position_Report_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
} struct__14320;

/* Radio_TrainToTrack::Acknowledgement */
typedef struct__14320 Acknowledgement_Radio_TrainToTrack;

/* Radio_TrainToTrack::No_compatible_version_supported */
typedef struct__14320 No_compatible_version_supported_Radio_TrainToTrack;

/* Radio_TrainToTrack::Initiation_of_a_communication_session */
typedef struct__14320 Initiation_of_a_communication_session_Radio_TrainToTrack;

/* Radio_TrainToTrack::Termination_of_a_communication_session */
typedef struct__14320 Termination_of_a_communication_session_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int NID_C;
  kcg_int NID_BG;
  kcg_int Q_INFILL;
  kcg_int PADDING8;
  kcg_int Radio_infill_request_OptionalPackets;
} struct__14327;

/* Radio_TrainToTrack::Radio_infill_request */
typedef struct__14327 Radio_infill_request_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING7;
  kcg_int End_of_Mission_OptionalPackets;
} struct__14339;

/* Radio_TrainToTrack::End_of_Mission */
typedef struct__14339 End_of_Mission_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING6;
  kcg_int Track_Ahead_Free_Granted_OptionalPackets;
} struct__14348;

/* Radio_TrainToTrack::Track_Ahead_Free_Granted */
typedef struct__14348 Track_Ahead_Free_Granted_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int NID_EM;
  kcg_int Q_EMERGENCYSTOP;
  kcg_int Acknowledgement_of_Emergency_Stop_OptionalPackets;
} struct__14357;

/* Radio_TrainToTrack::Acknowledgement_of_Emergency_Stop */
typedef struct__14357 Acknowledgement_of_Emergency_Stop_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING5;
  kcg_int Request_to_shorten_MA_is_rejected_OptionalPackets;
} struct__14367;

/* Radio_TrainToTrack::Request_to_shorten_MA_is_rejected */
typedef struct__14367 Request_to_shorten_MA_is_rejected_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING4;
  kcg_int Request_to_shorten_MA_is_granted_OptionalPackets;
} struct__14376;

/* Radio_TrainToTrack::Request_to_shorten_MA_is_granted */
typedef struct__14376 Request_to_shorten_MA_is_granted_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int Q_MARQSTREASON;
  kcg_int PADDING2;
  kcg_int MA_Request_OptionalPackets;
} struct__14385;

/* Radio_TrainToTrack::MA_Request */
typedef struct__14385 MA_Request_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING1;
  kcg_int Request_for_Shunting_OptionalPackets;
} struct__14395;

/* Radio_TrainToTrack::Request_for_Shunting */
typedef struct__14395 Request_for_Shunting_Radio_TrainToTrack;

typedef struct {
  kcg_int NID_MESSAGE;
  kcg_int L_MESSAGE;
  kcg_real T_TRAIN;
  kcg_int NID_ENGINE;
  kcg_int PADDING0;
  kcg_int Validated_Train_Data_OptionalPackets;
} struct__14404;

/* Radio_TrainToTrack::Validated_Train_Data */
typedef struct__14404 Validated_Train_Data_Radio_TrainToTrack;

typedef struct { kcg_int NID_PACKET; } struct__14413;

/* BothWays::End_of_Information */
typedef struct__14413 End_of_Information_BothWays;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  kcg_int NID_XUSER;
  kcg_int Other_data_depending_on__NID_XUSER;
} struct__14417;

/* TrainToTrack::Data_used_by_applications_outside_the_ERTMS_or_ETCS_system */
typedef struct__14417 Data_used_by_applications_outside_the_ERTMS_or_ETCS_system_TrainToTrack;

typedef struct { kcg_int NID_NTC; } struct__14424;

/* TrainToTrack::Var111 */
typedef struct__14424 Var111_TrainToTrack;

typedef Var111_TrainToTrack array__14428[33];

/* TrainToTrack::AVar111 */
typedef array__14428 AVar111_TrainToTrack;

typedef struct { kcg_int N_ITER; AVar111_TrainToTrack Array; } struct__14431;

/* TrainToTrack::SVar111 */
typedef struct__14431 SVar111_TrainToTrack;

typedef struct { kcg_int M_VOLTAGE; kcg_int NID_CTRACTION; } struct__14436;

/* TrainToTrack::Var110 */
typedef struct__14436 Var110_TrainToTrack;

typedef Var110_TrainToTrack array__14441[33];

/* TrainToTrack::AVar110 */
typedef array__14441 AVar110_TrainToTrack;

typedef struct { kcg_int N_ITER; AVar110_TrainToTrack Array; } struct__14444;

/* TrainToTrack::SVar110 */
typedef struct__14444 SVar110_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  kcg_int NC_CDTRAIN;
  kcg_int NC_TRAIN;
  kcg_int L_TRAIN;
  kcg_int V_MAXTRAIN;
  kcg_int M_LOADINGGAUGE;
  kcg_int M_AXLELOADCAT;
  kcg_int M_AIRTIGHT;
  kcg_int N_AXLE;
  SVar110_TrainToTrack Struct47;
  SVar111_TrainToTrack Struct48;
} struct__14449;

/* TrainToTrack::Validated_train_data */
typedef struct__14449 Validated_train_data_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  kcg_int NID_LTRBG;
} struct__14464;

/* TrainToTrack::Level_23_transition_information */
typedef struct__14464 Level_23_transition_information_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  kcg_int NID_OPERATIONAL;
} struct__14470;

/* TrainToTrack::Train_running_number */
typedef struct__14470 Train_running_number_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  M_ERROR error;
} struct__14476;

/* TrainToTrack::Error_reporting */
typedef struct__14476 Error_reporting_TrainToTrack;

typedef struct { kcg_int NID_RADIO; } struct__14482;

/* TrainToTrack::Var30 */
typedef struct__14482 Var30_TrainToTrack;

typedef Var30_TrainToTrack array__14486[33];

/* TrainToTrack::AVar30 */
typedef array__14486 AVar30_TrainToTrack;

typedef struct { kcg_int N_ITER; AVar30_TrainToTrack Array; } struct__14489;

/* TrainToTrack::SVar30 */
typedef struct__14489 SVar30_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  SVar30_TrainToTrack Struct46;
} struct__14494;

/* TrainToTrack::Onboard_telephone_numbers */
typedef struct__14494 Onboard_telephone_numbers_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  Q_SCALE qscale;
  kcg_int NID_LRBG;
  kcg_int NID_PRVLRBG;
  kcg_int D_LRBG;
  Q_DIRLRBG dirlrbg;
  Q_DLRBG dlrbg;
  kcg_int L_DOUBTOVER;
  kcg_int L_DOUBTUNDER;
  Q_LENGTH length;
  kcg_int L_TRAININT;
  kcg_int V_TRAIN;
  Q_DIRTRAIN dirtrain;
  M_MODE mode;
  M_LEVEL level;
  kcg_int NID_NTC;
} struct__14500;

/* TrainToTrack::Position_Report_based_on_two_balise_groups */
typedef struct__14500 Position_Report_based_on_two_balise_groups_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int L_PACKET;
  Q_SCALE qscale;
  kcg_int NID_LRBG;
  kcg_int D_LRBG;
  Q_DIRLRBG dirlrbg;
  Q_DLRBG dlrbg;
  kcg_int L_DOUBTOVER;
  kcg_int L_DOUBTUNDER;
  Q_LENGTH length;
  kcg_int L_TRAININT;
  kcg_int V_TRAIN;
  Q_DIRTRAIN dirtrain;
  M_MODE mode;
  M_LEVEL level;
  kcg_int NID_NTC;
} struct__14520;

/* TrainToTrack::Position_Report */
typedef struct__14520 Position_Report_TrainToTrack;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
} struct__14539;

/* TrackToTrain::Inhibition_of_revocable_TSRs_from_balises_in_L23 */
typedef struct__14539 Inhibition_of_revocable_TSRs_from_balises_in_L23_TrackToTrain;

/* TrackToTrain::Stop_Shunting_on_desk_opening */
typedef struct__14539 Stop_Shunting_on_desk_opening_TrackToTrain;

/* TrackToTrain::Inhibition_of_balise_group_message_consistency_reaction */
typedef struct__14539 Inhibition_of_balise_group_message_consistency_reaction_TrackToTrain;

/* TrackToTrain::Default_balise_or_Loop_or_RIU_information */
typedef struct__14539 Default_balise_or_Loop_or_RIU_information_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_RIU;
  kcg_int NID_C;
  kcg_int NID_RIU;
  kcg_int NID_RADIO;
} struct__14545;

/* TrackToTrain::Session_Management_with_neighbouring_Radio_Infill_Unit */
typedef struct__14545 Session_Management_with_neighbouring_Radio_Infill_Unit_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_GDIR;
  kcg_int G_TSR;
} struct__14555;

/* TrackToTrain::Default_Gradient_for_Temporary_Speed_Restriction */
typedef struct__14555 Default_Gradient_for_Temporary_Speed_Restriction_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int NID_OPERATIONAL;
} struct__14563;

/* TrackToTrain::Train_running_number_from_RBC */
typedef struct__14563 Train_running_number_from_RBC_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_REVERSE;
  kcg_int V_REVERSE;
} struct__14570;

/* TrackToTrain::Reversing_supervision_information */
typedef struct__14570 Reversing_supervision_information_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_STARTREVERSE;
  kcg_int L_REVERSEAREA;
} struct__14579;

/* TrackToTrain::Reversing_area_information */
typedef struct__14579 Reversing_area_information_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SRSTOP;
} struct__14588;

/* TrackToTrain::Stop_if_in_Staff_Responsible */
typedef struct__14588 Stop_if_in_Staff_Responsible_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
} struct__14595;

/* TrackToTrain::Track_Ahead_Free_up_to_level_23_transition_location */
typedef struct__14595 Track_Ahead_Free_up_to_level_23_transition_location_TrackToTrain;

/* TrackToTrain::Infill_location_reference */
typedef struct__14595 Infill_location_reference_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int NID_LOOP;
  kcg_int D_LOOP;
  kcg_int L_LOOP;
  kcg_int Q_LOOPDIR;
  kcg_int Q_SSCODE;
} struct__14604;

/* TrackToTrain::EOLM_Packet */
typedef struct__14604 EOLM_Packet_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_RIU;
  kcg_int NID_C;
  kcg_int NID_RIU;
  kcg_int NID_RADIO;
  kcg_int D_INFILL;
  kcg_int NID_BG;
} struct__14616;

/* TrackToTrain::Radio_infill_area_information */
typedef struct__14616 Radio_infill_area_information_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_ASPECT;
} struct__14629;

/* TrackToTrain::Danger_for_Shunting_information */
typedef struct__14629 Danger_for_Shunting_information_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_RBCTR;
  kcg_int NID_C;
  kcg_int NID_RBC;
  kcg_int NID_RADIO;
  kcg_int Q_SLEEPSESSION;
} struct__14636;

/* TrackToTrain::RBC_transition_order */
typedef struct__14636 RBC_transition_order_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int NID_LX;
  kcg_int D_LX;
  kcg_int L_LX;
  kcg_int Q_LXSTATUS;
  kcg_int V_LX;
  kcg_int Q_STOPLX;
  kcg_int L_STOPLX;
} struct__14648;

/* TrackToTrain::Level_Crossing_information */
typedef struct__14648 Level_Crossing_information_TrackToTrain;

typedef struct {
  kcg_int D_MAMODE;
  kcg_int M_MAMODE;
  kcg_int V_MAMODE;
  kcg_int L_MAMODE;
  kcg_int L_ACKMAMODE;
  kcg_int Q_MAMODE;
} struct__14662;

/* TrackToTrain::Var800 */
typedef struct__14662 Var800_TrackToTrain;

typedef Var800_TrackToTrain array__14671[33];

/* TrackToTrain::AVar800 */
typedef array__14671 AVar800_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar800_TrackToTrain Array; } struct__14674;

/* TrackToTrain::SVar800 */
typedef struct__14674 SVar800_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_MAMODE;
  kcg_int M_MAMODE;
  kcg_int V_MAMODE;
  kcg_int L_MAMODE;
  kcg_int L_ACKMAMODE;
  kcg_int Q_MAMODE;
  SVar800_TrackToTrain Struct45;
} struct__14679;

/* TrackToTrain::Mode_profile */
typedef struct__14679 Mode_profile_TrackToTrain;

typedef struct {
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
  kcg_int D_POSOFF;
  kcg_int Q_MPOSITION;
  kcg_int M_POSITION;
} struct__14693;

/* TrackToTrain::Var790 */
typedef struct__14693 Var790_TrackToTrain;

typedef Var790_TrackToTrain array__14702[33];

/* TrackToTrain::AVar790 */
typedef array__14702 AVar790_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar790_TrackToTrain Array; } struct__14705;

/* TrackToTrain::SVar790 */
typedef struct__14705 SVar790_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
  kcg_int D_POSOFF;
  kcg_int Q_MPOSITION;
  kcg_int M_POSITION;
  SVar790_TrackToTrain Struct44;
} struct__14710;

/* TrackToTrain::Geographical_Position_Information */
typedef struct__14710 Geographical_Position_Information_TrackToTrain;

typedef struct {
  kcg_int M_MODETEXTDISPLAY;
  kcg_int M_LEVELTEXTDISPLAY;
  kcg_int NID_NTC;
} struct__14724;

/* TrackToTrain::Var727 */
typedef struct__14724 Var727_TrackToTrain;

/* TrackToTrain::Var767 */
typedef struct__14724 Var767_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TEXTCLASS;
  kcg_int Q_TEXTDISPLAY;
  kcg_int D_TEXTDISPLAY;
  Var767_TrackToTrain Struct40;
  kcg_int L_TEXTDISPLAY;
  kcg_int T_TEXTDISPLAY;
  Var767_TrackToTrain Struct43;
  kcg_int Q_TEXTCONFIRM;
  kcg_int Q_CONFTEXTDISPLAY;
  kcg_int Q_TEXTREPORT;
  kcg_int NID_TEXTMESSAGE;
  kcg_int NID_C;
  kcg_int NID_RBC;
  kcg_int Q_TEXT;
} struct__14730;

/* TrackToTrain::Packet_for_sending_fixed_text_messages */
typedef struct__14730 Packet_for_sending_fixed_text_messages_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TEXTCLASS;
  kcg_int Q_TEXTDISPLAY;
  kcg_int D_TEXTDISPLAY;
  Var727_TrackToTrain Struct34;
  kcg_int L_TEXTDISPLAY;
  kcg_int T_TEXTDISPLAY;
  Var727_TrackToTrain Struct37;
  kcg_int Q_TEXTCONFIRM;
  kcg_int Q_CONFTEXTDISPLAY;
  kcg_int Q_TEXTREPORT;
  kcg_int NID_TEXTMESSAGE;
  kcg_int NID_C;
  kcg_int NID_RBC;
  kcg_int L_TEXT;
  kcg_int X_TEXT;
} struct__14751;

/* TrackToTrain::Packet_for_sending_plain_text_messages */
typedef struct__14751 Packet_for_sending_plain_text_messages_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_ADHESION;
  kcg_int L_ADHESION;
  kcg_int M_ADHESION;
} struct__14773;

/* TrackToTrain::Adhesion_factor */
typedef struct__14773 Adhesion_factor_TrackToTrain;

typedef struct {
  kcg_int D_SUITABILITY;
  kcg_int Q_SUITABILITY;
  kcg_int M_LINEGAUGE;
  kcg_int M_AXLELOADCAT;
  kcg_int M_VOLTAGE;
  kcg_int NID_CTRACTION;
} struct__14783;

/* TrackToTrain::Var700 */
typedef struct__14783 Var700_TrackToTrain;

typedef Var700_TrackToTrain array__14792[33];

/* TrackToTrain::AVar700 */
typedef array__14792 AVar700_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar700_TrackToTrain Array; } struct__14795;

/* TrackToTrain::SVar700 */
typedef struct__14795 SVar700_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TRACKINIT;
  kcg_int D_TRACKINIT;
  kcg_int D_SUITABILITY;
  kcg_int Q_SUITABILITY;
  kcg_int M_LINEGAUGE;
  kcg_int M_AXLELOADCAT;
  kcg_int M_VOLTAGE;
  kcg_int NID_CTRACTION;
  SVar700_TrackToTrain Struct31;
} struct__14800;

/* TrackToTrain::Route_Suitability_Data */
typedef struct__14800 Route_Suitability_Data_TrackToTrain;

typedef struct {
  kcg_int D_TRACKCOND;
  kcg_int L_TRACKCOND;
  kcg_int M_PLATFORM;
  kcg_int Q_PLATFORM;
} struct__14816;

/* TrackToTrain::Var690 */
typedef struct__14816 Var690_TrackToTrain;

typedef Var690_TrackToTrain array__14823[33];

/* TrackToTrain::AVar690 */
typedef array__14823 AVar690_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar690_TrackToTrain Array; } struct__14826;

/* TrackToTrain::SVar690 */
typedef struct__14826 SVar690_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TRACKINIT;
  kcg_int D_TRACKINIT;
  kcg_int D_TRACKCOND;
  kcg_int L_TRACKCOND;
  kcg_int M_PLATFORM;
  kcg_int Q_PLATFORM;
  SVar690_TrackToTrain Struct30;
} struct__14831;

/* TrackToTrain::Track_Condition_Station_Platforms */
typedef struct__14831 Track_Condition_Station_Platforms_TrackToTrain;

typedef struct {
  kcg_int D_TRACKCOND;
  kcg_int L_TRACKCOND;
  kcg_int M_TRACKCOND;
} struct__14845;

/* TrackToTrain::Var680 */
typedef struct__14845 Var680_TrackToTrain;

typedef Var680_TrackToTrain array__14851[33];

/* TrackToTrain::AVar680 */
typedef array__14851 AVar680_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar680_TrackToTrain Array; } struct__14854;

/* TrackToTrain::SVar680 */
typedef struct__14854 SVar680_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TRACKINIT;
  kcg_int D_TRACKINIT;
  kcg_int D_TRACKCOND;
  kcg_int L_TRACKCOND;
  kcg_int M_TRACKCOND;
  SVar680_TrackToTrain Struct29;
} struct__14859;

/* TrackToTrain::Track_Condition */
typedef struct__14859 Track_Condition_TrackToTrain;

typedef struct { kcg_int D_TRACKCOND; kcg_int L_TRACKCOND; } struct__14872;

/* TrackToTrain::Var670 */
typedef struct__14872 Var670_TrackToTrain;

typedef Var670_TrackToTrain array__14877[33];

/* TrackToTrain::AVar670 */
typedef array__14877 AVar670_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar670_TrackToTrain Array; } struct__14880;

/* TrackToTrain::SVar670 */
typedef struct__14880 SVar670_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_TRACKCOND;
  kcg_int L_TRACKCOND;
  SVar670_TrackToTrain Struct28;
} struct__14885;

/* TrackToTrain::Track_Condition_Big_Metal_Masses */
typedef struct__14885 Track_Condition_Big_Metal_Masses_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int NID_TSR;
} struct__14895;

/* TrackToTrain::Temporary_Speed_Restriction_Revocation */
typedef struct__14895 Temporary_Speed_Restriction_Revocation_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int NID_TSR;
  kcg_int D_TSR;
  kcg_int L_TSR;
  kcg_int Q_FRONT;
  kcg_int V_TSR;
} struct__14902;

/* TrackToTrain::Temporary_Speed_Restriction */
typedef struct__14902 Temporary_Speed_Restriction_TrackToTrain;

typedef struct {
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
} struct__14914;

/* TrackToTrain::Var137 */
typedef struct__14914 Var137_TrackToTrain;

/* TrackToTrain::Var490 */
typedef struct__14914 Var490_TrackToTrain;

/* TrackToTrain::Var630 */
typedef struct__14914 Var630_TrackToTrain;

typedef struct__14914 array__14920[33];

/* TrackToTrain::AVar490 */
typedef array__14920 AVar490_TrackToTrain;

/* TrackToTrain::AVar630 */
typedef array__14920 AVar630_TrackToTrain;

typedef struct { kcg_int N_ITER; array__14920 Array; } struct__14923;

/* TrackToTrain::SVar490 */
typedef struct__14923 SVar490_TrackToTrain;

/* TrackToTrain::SVar630 */
typedef struct__14923 SVar630_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  SVar630_TrackToTrain Struct27;
} struct__14928;

/* TrackToTrain::List_of_Balises_in_SR_Authority */
typedef struct__14928 List_of_Balises_in_SR_Authority_TrackToTrain;

typedef struct { kcg_int D_LOC; Q_LGTLOC q_lgtloc; } struct__14935;

/* TrackToTrain::Var580 */
typedef struct__14935 Var580_TrackToTrain;

typedef Var580_TrackToTrain array__14940[33];

/* TrackToTrain::AVar580 */
typedef array__14940 AVar580_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar580_TrackToTrain Array; } struct__14943;

/* TrackToTrain::SVar580 */
typedef struct__14943 SVar580_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  Q_DIR q_dir;
  kcg_int L_PACKET;
  Q_SCALE q_scale;
  kcg_int T_CYCLOC;
  kcg_int D_CYCLOC;
  M_LOC m_loc;
  SVar580_TrackToTrain Struct26;
} struct__14948;

/* TrackToTrain::Position_Report_Parameters */
typedef struct__14948 Position_Report_Parameters_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int T_MAR;
  kcg_int T_TIMEOUTRQST;
  kcg_int T_CYCRQST;
} struct__14959;

/* TrackToTrain::Movement_Authority_Request_Parameters */
typedef struct__14959 Movement_Authority_Request_Parameters_TrackToTrain;

typedef struct {
  kcg_int D_PBD;
  kcg_int Q_GDIR;
  kcg_int G_PBDSR;
  kcg_int Q_PBDSR;
  kcg_int D_PBDSR;
  kcg_int L_PBDSR;
} struct__14968;

/* TrackToTrain::Var520 */
typedef struct__14968 Var520_TrackToTrain;

typedef Var520_TrackToTrain array__14977[33];

/* TrackToTrain::AVar520 */
typedef array__14977 AVar520_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar520_TrackToTrain Array; } struct__14980;

/* TrackToTrain::SVar520 */
typedef struct__14980 SVar520_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TRACKINIT;
  kcg_int D_TRACKINIT;
  kcg_int D_PBD;
  kcg_int Q_GDIR;
  kcg_int G_PBDSR;
  kcg_int Q_PBDSR;
  kcg_int D_PBDSR;
  kcg_int L_PBDSR;
  SVar520_TrackToTrain Struct25;
} struct__14985;

/* TrackToTrain::Permitted_Braking_Distance_Information */
typedef struct__14985 Permitted_Braking_Distance_Information_TrackToTrain;

typedef struct { kcg_int M_AXLELOADCAT; kcg_int V_AXLELOAD; } struct__15001;

/* TrackToTrain::Var510 */
typedef struct__15001 Var510_TrackToTrain;

/* TrackToTrain::Var512 */
typedef struct__15001 Var512_TrackToTrain;

typedef struct__15001 array__15006[33];

/* TrackToTrain::AVar510 */
typedef array__15006 AVar510_TrackToTrain;

/* TrackToTrain::AVar512 */
typedef array__15006 AVar512_TrackToTrain;

typedef struct { kcg_int N_ITER; array__15006 Array; } struct__15009;

/* TrackToTrain::SVar510 */
typedef struct__15009 SVar510_TrackToTrain;

/* TrackToTrain::SVar512 */
typedef struct__15009 SVar512_TrackToTrain;

typedef struct {
  kcg_int D_AXLELOAD;
  kcg_int L_AXLELOAD;
  kcg_int Q_FRONT;
  SVar512_TrackToTrain Struct68;
} struct__15014;

/* TrackToTrain::Var511 */
typedef struct__15014 Var511_TrackToTrain;

typedef Var511_TrackToTrain array__15021[33];

/* TrackToTrain::AVar511 */
typedef array__15021 AVar511_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar511_TrackToTrain Array; } struct__15024;

/* TrackToTrain::SVar511 */
typedef struct__15024 SVar511_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int Q_TRACKINIT;
  kcg_int D_TRACKINIT;
  kcg_int D_AXLELOAD;
  kcg_int L_AXLELOAD;
  kcg_int Q_FRONT;
  SVar510_TrackToTrain Struct22;
  SVar511_TrackToTrain Struct23;
} struct__15029;

/* TrackToTrain::Axle_Load_Speed_Profile */
typedef struct__15029 Axle_Load_Speed_Profile_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  SVar490_TrackToTrain Struct21;
} struct__15043;

/* TrackToTrain::List_of_balises_for_SH_Area */
typedef struct__15043 List_of_balises_for_SH_Area_TrackToTrain;

typedef struct { kcg_int M_LEVELTR; kcg_int NID_NTC; } struct__15050;

/* TrackToTrain::Var460 */
typedef struct__15050 Var460_TrackToTrain;

typedef Var460_TrackToTrain array__15055[33];

/* TrackToTrain::AVar460 */
typedef array__15055 AVar460_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar460_TrackToTrain Array; } struct__15058;

/* TrackToTrain::SVar460 */
typedef struct__15058 SVar460_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int M_LEVELTR;
  kcg_int NID_NTC;
  SVar460_TrackToTrain Struct20;
} struct__15063;

/* TrackToTrain::Conditional_Level_Transition_Order */
typedef struct__15063 Conditional_Level_Transition_Order_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int NID_MN;
} struct__15072;

/* TrackToTrain::Radio_Network_registration */
typedef struct__15072 Radio_Network_registration_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int NID_XUSER;
  kcg_int NID_NTC;
  kcg_int Other_data_depending_on__NID_XUSER;
} struct__15079;

/* TrackToTrain::Data_used_by_applications_outside_the_ERTMSETCS_system */
typedef struct__15079 Data_used_by_applications_outside_the_ERTMSETCS_system_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_RBC;
  kcg_int NID_C;
  kcg_int NID_RBC;
  kcg_int NID_RADIO;
  kcg_int Q_SLEEPSESSION;
} struct__15088;

/* TrackToTrain::Session_Management */
typedef struct__15088 Session_Management_TrackToTrain;

typedef struct {
  kcg_int M_LEVELTR;
  kcg_int NID_NTC;
  kcg_int L_ACKLEVELTR;
} struct__15099;

/* TrackToTrain::Var410 */
typedef struct__15099 Var410_TrackToTrain;

typedef Var410_TrackToTrain array__15105[33];

/* TrackToTrain::AVar410 */
typedef array__15105 AVar410_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar410_TrackToTrain Array; } struct__15108;

/* TrackToTrain::SVar410 */
typedef struct__15108 SVar410_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_LEVELTR;
  kcg_int M_LEVELTR;
  kcg_int NID_NTC;
  kcg_int L_ACKLEVELTR;
  SVar410_TrackToTrain Struct19;
} struct__15113;

/* TrackToTrain::Level_Transition_Order */
typedef struct__15113 Level_Transition_Order_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_CURRENT;
  kcg_int M_CURRENT;
} struct__15125;

/* TrackToTrain::Track_Condition_Change_of_allowed_current_consumption */
typedef struct__15125 Track_Condition_Change_of_allowed_current_consumption_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_TRACTION;
  kcg_int M_VOLTAGE;
  kcg_int NID_CTRACTION;
} struct__15134;

/* TrackToTrain::Track_Condition_Change_of_traction_system */
typedef struct__15134 Track_Condition_Change_of_traction_system_TrackToTrain;

typedef struct {
  kcg_int Q_DIFF;
  kcg_int NC_CDDIFF;
  kcg_int NC_DIFF;
  kcg_int V_DIFF;
} struct__15144;

/* TrackToTrain::Var270 */
typedef struct__15144 Var270_TrackToTrain;

/* TrackToTrain::Var272 */
typedef struct__15144 Var272_TrackToTrain;

typedef struct__15144 array__15151[33];

/* TrackToTrain::AVar270 */
typedef array__15151 AVar270_TrackToTrain;

/* TrackToTrain::AVar272 */
typedef array__15151 AVar272_TrackToTrain;

typedef struct { kcg_int N_ITER; array__15151 Array; } struct__15154;

/* TrackToTrain::SVar270 */
typedef struct__15154 SVar270_TrackToTrain;

/* TrackToTrain::SVar272 */
typedef struct__15154 SVar272_TrackToTrain;

typedef struct {
  kcg_int D_STATIC;
  kcg_int V_STATIC;
  kcg_int Q_FRONT;
  SVar272_TrackToTrain Struct62;
} struct__15159;

/* TrackToTrain::Var271 */
typedef struct__15159 Var271_TrackToTrain;

typedef Var271_TrackToTrain array__15166[33];

/* TrackToTrain::AVar271 */
typedef array__15166 AVar271_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar271_TrackToTrain Array; } struct__15169;

/* TrackToTrain::SVar271 */
typedef struct__15169 SVar271_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_STATIC;
  kcg_int V_STATIC;
  kcg_int Q_FRONT;
  SVar270_TrackToTrain Struct16;
  SVar271_TrackToTrain Struct17;
} struct__15174;

/* TrackToTrain::International_Static_Speed_Profile */
typedef struct__15174 International_Static_Speed_Profile_TrackToTrain;

typedef struct {
  kcg_int D_GRADIENT;
  kcg_int Q_GDIR;
  kcg_int G_A;
} struct__15186;

/* TrackToTrain::Var210 */
typedef struct__15186 Var210_TrackToTrain;

typedef Var210_TrackToTrain array__15192[33];

/* TrackToTrain::AVar210 */
typedef array__15192 AVar210_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar210_TrackToTrain Array; } struct__15195;

/* TrackToTrain::SVar210 */
typedef struct__15195 SVar210_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_GRADIENT;
  kcg_int Q_GDIR;
  kcg_int G_A;
  SVar210_TrackToTrain Struct15;
} struct__15200;

/* TrackToTrain::Gradient_Profile */
typedef struct__15200 Gradient_Profile_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int L_SECTION;
} struct__15211;

/* TrackToTrain::Repositioning_Information */
typedef struct__15211 Repositioning_Information_TrackToTrain;

typedef struct {
  kcg_int L_SECTION;
  kcg_int Q_SECTIONTIMER;
  kcg_int T_SECTIONTIMER;
  kcg_int D_SECTIONTIMERSTOPLOC;
} struct__15219;

/* TrackToTrain::Var120 */
typedef struct__15219 Var120_TrackToTrain;

/* TrackToTrain::Var150 */
typedef struct__15219 Var150_TrackToTrain;

typedef struct__15219 array__15226[33];

/* TrackToTrain::AVar120 */
typedef array__15226 AVar120_TrackToTrain;

/* TrackToTrain::AVar150 */
typedef array__15226 AVar150_TrackToTrain;

typedef struct { kcg_int N_ITER; array__15226 Array; } struct__15229;

/* TrackToTrain::SVar120 */
typedef struct__15229 SVar120_TrackToTrain;

/* TrackToTrain::SVar150 */
typedef struct__15229 SVar150_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int V_LOA;
  kcg_int T_LOA;
  SVar150_TrackToTrain Struct14;
  kcg_int L_ENDSECTION;
  kcg_int Q_SECTIONTIMER;
  kcg_int T_SECTIONTIMER;
  kcg_int D_SECTIONTIMERSTOPLOC;
  kcg_int Q_ENDTIMER;
  kcg_int T_ENDTIMER;
  kcg_int D_ENDTIMERSTARTLOC;
  kcg_int Q_DANGERPOINT;
  kcg_int D_DP;
  kcg_int V_RELEASEDP;
  kcg_int Q_OVERLAP;
  kcg_int D_STARTOL;
  kcg_int T_OL;
  kcg_int D_OL;
  kcg_int V_RELEASEOL;
} struct__15234;

/* TrackToTrain::Level_23_Movement_Authority */
typedef struct__15234 Level_23_Movement_Authority_TrackToTrain;

typedef struct {
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
  kcg_int D_SR;
} struct__15259;

/* TrackToTrain::Var130 */
typedef struct__15259 Var130_TrackToTrain;

typedef Var130_TrackToTrain array__15266[33];

/* TrackToTrain::AVar130 */
typedef array__15266 AVar130_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar130_TrackToTrain Array; } struct__15269;

/* TrackToTrain::SVar130 */
typedef struct__15269 SVar130_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  Var137_TrackToTrain Struct9;
  Var137_TrackToTrain Struct12;
  kcg_int D_SR;
  SVar130_TrackToTrain Struct13;
} struct__15274;

/* TrackToTrain::Staff_Responsible_distance_Information_from_loop */
typedef struct__15274 Staff_Responsible_distance_Information_from_loop_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int V_MAIN;
  kcg_int V_LOA;
  kcg_int T_LOA;
  SVar120_TrackToTrain Struct6;
  kcg_int L_ENDSECTION;
  kcg_int Q_SECTIONTIMER;
  kcg_int T_SECTIONTIMER;
  kcg_int D_SECTIONTIMERSTOPLOC;
  kcg_int Q_ENDTIMER;
  kcg_int T_ENDTIMER;
  kcg_int D_ENDTIMERSTARTLOC;
  kcg_int Q_DANGERPOINT;
  kcg_int D_DP;
  kcg_int V_RELEASEDP;
  kcg_int Q_OVERLAP;
  kcg_int D_STARTOL;
  kcg_int T_OL;
  kcg_int D_OL;
  kcg_int V_RELEASEOL;
} struct__15285;

/* TrackToTrain::Level_1_Movement_Authority */
typedef struct__15285 Level_1_Movement_Authority_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_VBCO;
  kcg_int NID_VBCMK;
  kcg_int NID_C;
  kcg_int T_VBC;
} struct__15311;

/* TrackToTrain::Virtual_Balise_Cover_order */
typedef struct__15311 Virtual_Balise_Cover_order_TrackToTrain;

typedef struct {
  kcg_int D_LINK;
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
  kcg_int Q_LINKORIENTATION;
  kcg_int Q_LINKREACTION;
  kcg_int Q_LOCACC;
} struct__15321;

/* TrackToTrain::Var50 */
typedef struct__15321 Var50_TrackToTrain;

typedef Var50_TrackToTrain array__15331[33];

/* TrackToTrain::AVar50 */
typedef array__15331 AVar50_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar50_TrackToTrain Array; } struct__15334;

/* TrackToTrain::SVar50 */
typedef struct__15334 SVar50_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_LINK;
  kcg_int Q_NEWCOUNTRY;
  kcg_int NID_C;
  kcg_int NID_BG;
  kcg_int Q_LINKORIENTATION;
  kcg_int Q_LINKREACTION;
  kcg_int Q_LOCACC;
  SVar50_TrackToTrain Struct5;
} struct__15339;

/* TrackToTrain::Linking */
typedef struct__15339 Linking_TrackToTrain;

typedef struct { kcg_int L_NVKRINT; kcg_real M_NVKRINT; } struct__15354;

/* TrackToTrain::Var34 */
typedef struct__15354 Var34_TrackToTrain;

typedef Var34_TrackToTrain array__15359[33];

/* TrackToTrain::AVar34 */
typedef array__15359 AVar34_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar34_TrackToTrain Array; } struct__15362;

/* TrackToTrain::SVar34 */
typedef struct__15362 SVar34_TrackToTrain;

typedef struct { kcg_int V_NVKVINT; kcg_real M_NVKVINT; } struct__15367;

/* TrackToTrain::Var31 */
typedef struct__15367 Var31_TrackToTrain;

/* TrackToTrain::Var33 */
typedef struct__15367 Var33_TrackToTrain;

typedef struct__15367 array__15372[33];

/* TrackToTrain::AVar31 */
typedef array__15372 AVar31_TrackToTrain;

/* TrackToTrain::AVar33 */
typedef array__15372 AVar33_TrackToTrain;

typedef struct { kcg_int N_ITER; array__15372 Array; } struct__15375;

/* TrackToTrain::SVar31 */
typedef struct__15375 SVar31_TrackToTrain;

/* TrackToTrain::SVar33 */
typedef struct__15375 SVar33_TrackToTrain;

typedef struct {
  kcg_int Q_NVKVINTSET;
  kcg_real A_NVP12;
  kcg_real A_NVP23;
  kcg_int V_NVKVINT;
  kcg_real M_NVKVINT;
  SVar33_TrackToTrain Struct51;
} struct__15380;

/* TrackToTrain::Var32 */
typedef struct__15380 Var32_TrackToTrain;

typedef Var32_TrackToTrain array__15389[33];

/* TrackToTrain::AVar32 */
typedef array__15389 AVar32_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar32_TrackToTrain Array; } struct__15392;

/* TrackToTrain::SVar32 */
typedef struct__15392 SVar32_TrackToTrain;

typedef struct { kcg_int NID_C; } struct__15397;

/* TrackToTrain::Var30 */
typedef struct__15397 Var30_TrackToTrain;

typedef Var30_TrackToTrain array__15401[33];

/* TrackToTrain::AVar30 */
typedef array__15401 AVar30_TrackToTrain;

typedef struct { kcg_int N_ITER; AVar30_TrackToTrain Array; } struct__15404;

/* TrackToTrain::SVar30 */
typedef struct__15404 SVar30_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int Q_SCALE;
  kcg_int D_VALIDNV;
  kcg_int NID_C;
  SVar30_TrackToTrain Struct0;
  kcg_int V_NVSHUNT;
  kcg_int V_NVSTFF;
  kcg_int V_NVONSIGHT;
  kcg_int V_NVLIMSUPERV;
  kcg_int V_NVUNFIT;
  kcg_int V_NVREL;
  kcg_int D_NVROLL;
  kcg_int Q_NVSBTSMPERM;
  kcg_int Q_NVEMRRLS;
  kcg_int Q_NVGUIPERM;
  kcg_int Q_NVSBFBPERM;
  kcg_int Q_NVINHSMICPERM;
  kcg_int V_NVALLOWOVTRP;
  kcg_int V_NVSUPOVTRP;
  kcg_int D_NVOVTRP;
  kcg_int T_NVOVTRP;
  kcg_int D_NVPOTRP;
  kcg_int M_NVCONTACT;
  kcg_int T_NVCONTACT;
  kcg_int M_NVDERUN;
  kcg_int D_NVSTFF;
  kcg_int Q_NVDRIVER_ADHES;
  kcg_real A_NVMAXREDADH1;
  kcg_real A_NVMAXREDADH2;
  kcg_real A_NVMAXREDADH3;
  kcg_int Q_NVLOCACC;
  kcg_real M_NVAVADH;
  kcg_int M_NVEBCL;
  kcg_int Q_NVKINT;
  kcg_int Q_NVKVINTSET;
  kcg_real A_NVP12;
  kcg_real A_NVP23;
  kcg_int V_NVKVINT;
  kcg_real M_NVKVINT;
  SVar31_TrackToTrain Struct1;
  SVar32_TrackToTrain Struct2;
  kcg_int L_NVKRINT;
  kcg_real M_NVKRINT;
  SVar34_TrackToTrain Struct4;
  kcg_real M_NVKTINT;
} struct__15409;

/* TrackToTrain::National_Values */
typedef struct__15409 National_Values_TrackToTrain;

typedef struct {
  kcg_int NID_PACKET;
  kcg_int Q_DIR;
  kcg_int L_PACKET;
  kcg_int M_VERSION;
} struct__15459;

/* TrackToTrain::System_Version_order */
typedef struct__15459 System_Version_order_TrackToTrain;

typedef struct { kcg_int NID_PACKET; kcg_int NID_VBCMK; } struct__15466;

/* TrackToTrain::Virtual_Balise_Cover_marker */
typedef struct__15466 Virtual_Balise_Cover_marker_TrackToTrain;

typedef positionedBG_T_TrainPosition_Types_Pck array__15471[1];

typedef positionedBG_T_TrainPosition_Types_Pck array__16143[7];

#ifndef kcg_copy_struct__13859
#define kcg_copy_struct__13859(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13859)))
#endif /* kcg_copy_struct__13859 */

#ifndef kcg_copy_struct__13878
#define kcg_copy_struct__13878(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13878)))
#endif /* kcg_copy_struct__13878 */

#ifndef kcg_copy_struct__13889
#define kcg_copy_struct__13889(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13889)))
#endif /* kcg_copy_struct__13889 */

#ifndef kcg_copy_struct__13895
#define kcg_copy_struct__13895(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13895)))
#endif /* kcg_copy_struct__13895 */

#ifndef kcg_copy_struct__13901
#define kcg_copy_struct__13901(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13901)))
#endif /* kcg_copy_struct__13901 */

#ifndef kcg_copy_struct__13914
#define kcg_copy_struct__13914(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13914)))
#endif /* kcg_copy_struct__13914 */

#ifndef kcg_copy_struct__13920
#define kcg_copy_struct__13920(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13920)))
#endif /* kcg_copy_struct__13920 */

#ifndef kcg_copy_struct__13929
#define kcg_copy_struct__13929(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13929)))
#endif /* kcg_copy_struct__13929 */

#ifndef kcg_copy_struct__13940
#define kcg_copy_struct__13940(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13940)))
#endif /* kcg_copy_struct__13940 */

#ifndef kcg_copy_struct__13954
#define kcg_copy_struct__13954(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13954)))
#endif /* kcg_copy_struct__13954 */

#ifndef kcg_copy_struct__13971
#define kcg_copy_struct__13971(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13971)))
#endif /* kcg_copy_struct__13971 */

#ifndef kcg_copy_struct__13982
#define kcg_copy_struct__13982(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13982)))
#endif /* kcg_copy_struct__13982 */

#ifndef kcg_copy_struct__13988
#define kcg_copy_struct__13988(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13988)))
#endif /* kcg_copy_struct__13988 */

#ifndef kcg_copy_struct__13997
#define kcg_copy_struct__13997(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__13997)))
#endif /* kcg_copy_struct__13997 */

#ifndef kcg_copy_struct__14007
#define kcg_copy_struct__14007(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14007)))
#endif /* kcg_copy_struct__14007 */

#ifndef kcg_copy_struct__14012
#define kcg_copy_struct__14012(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14012)))
#endif /* kcg_copy_struct__14012 */

#ifndef kcg_copy_struct__14021
#define kcg_copy_struct__14021(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14021)))
#endif /* kcg_copy_struct__14021 */

#ifndef kcg_copy_struct__14029
#define kcg_copy_struct__14029(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14029)))
#endif /* kcg_copy_struct__14029 */

#ifndef kcg_copy_struct__14037
#define kcg_copy_struct__14037(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14037)))
#endif /* kcg_copy_struct__14037 */

#ifndef kcg_copy_struct__14043
#define kcg_copy_struct__14043(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14043)))
#endif /* kcg_copy_struct__14043 */

#ifndef kcg_copy_struct__14053
#define kcg_copy_struct__14053(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14053)))
#endif /* kcg_copy_struct__14053 */

#ifndef kcg_copy_struct__14062
#define kcg_copy_struct__14062(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14062)))
#endif /* kcg_copy_struct__14062 */

#ifndef kcg_copy_struct__14068
#define kcg_copy_struct__14068(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14068)))
#endif /* kcg_copy_struct__14068 */

#ifndef kcg_copy_struct__14075
#define kcg_copy_struct__14075(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14075)))
#endif /* kcg_copy_struct__14075 */

#ifndef kcg_copy_struct__14088
#define kcg_copy_struct__14088(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14088)))
#endif /* kcg_copy_struct__14088 */

#ifndef kcg_copy_struct__14092
#define kcg_copy_struct__14092(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14092)))
#endif /* kcg_copy_struct__14092 */

#ifndef kcg_copy_struct__14102
#define kcg_copy_struct__14102(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14102)))
#endif /* kcg_copy_struct__14102 */

#ifndef kcg_copy_struct__14110
#define kcg_copy_struct__14110(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14110)))
#endif /* kcg_copy_struct__14110 */

#ifndef kcg_copy_struct__14119
#define kcg_copy_struct__14119(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14119)))
#endif /* kcg_copy_struct__14119 */

#ifndef kcg_copy_struct__14123
#define kcg_copy_struct__14123(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14123)))
#endif /* kcg_copy_struct__14123 */

#ifndef kcg_copy_struct__14132
#define kcg_copy_struct__14132(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14132)))
#endif /* kcg_copy_struct__14132 */

#ifndef kcg_copy_struct__14136
#define kcg_copy_struct__14136(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14136)))
#endif /* kcg_copy_struct__14136 */

#ifndef kcg_copy_struct__14144
#define kcg_copy_struct__14144(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14144)))
#endif /* kcg_copy_struct__14144 */

#ifndef kcg_copy_struct__14150
#define kcg_copy_struct__14150(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14150)))
#endif /* kcg_copy_struct__14150 */

#ifndef kcg_copy_struct__14155
#define kcg_copy_struct__14155(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14155)))
#endif /* kcg_copy_struct__14155 */

#ifndef kcg_copy_struct__14163
#define kcg_copy_struct__14163(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14163)))
#endif /* kcg_copy_struct__14163 */

#ifndef kcg_copy_struct__14173
#define kcg_copy_struct__14173(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14173)))
#endif /* kcg_copy_struct__14173 */

#ifndef kcg_copy_struct__14186
#define kcg_copy_struct__14186(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14186)))
#endif /* kcg_copy_struct__14186 */

#ifndef kcg_copy_struct__14198
#define kcg_copy_struct__14198(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14198)))
#endif /* kcg_copy_struct__14198 */

#ifndef kcg_copy_struct__14207
#define kcg_copy_struct__14207(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14207)))
#endif /* kcg_copy_struct__14207 */

#ifndef kcg_copy_struct__14218
#define kcg_copy_struct__14218(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14218)))
#endif /* kcg_copy_struct__14218 */

#ifndef kcg_copy_struct__14227
#define kcg_copy_struct__14227(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14227)))
#endif /* kcg_copy_struct__14227 */

#ifndef kcg_copy_struct__14237
#define kcg_copy_struct__14237(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14237)))
#endif /* kcg_copy_struct__14237 */

#ifndef kcg_copy_struct__14246
#define kcg_copy_struct__14246(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14246)))
#endif /* kcg_copy_struct__14246 */

#ifndef kcg_copy_struct__14259
#define kcg_copy_struct__14259(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14259)))
#endif /* kcg_copy_struct__14259 */

#ifndef kcg_copy_struct__14269
#define kcg_copy_struct__14269(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14269)))
#endif /* kcg_copy_struct__14269 */

#ifndef kcg_copy_struct__14279
#define kcg_copy_struct__14279(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14279)))
#endif /* kcg_copy_struct__14279 */

#ifndef kcg_copy_struct__14291
#define kcg_copy_struct__14291(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14291)))
#endif /* kcg_copy_struct__14291 */

#ifndef kcg_copy_struct__14300
#define kcg_copy_struct__14300(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14300)))
#endif /* kcg_copy_struct__14300 */

#ifndef kcg_copy_struct__14310
#define kcg_copy_struct__14310(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14310)))
#endif /* kcg_copy_struct__14310 */

#ifndef kcg_copy_struct__14320
#define kcg_copy_struct__14320(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14320)))
#endif /* kcg_copy_struct__14320 */

#ifndef kcg_copy_struct__14327
#define kcg_copy_struct__14327(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14327)))
#endif /* kcg_copy_struct__14327 */

#ifndef kcg_copy_struct__14339
#define kcg_copy_struct__14339(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14339)))
#endif /* kcg_copy_struct__14339 */

#ifndef kcg_copy_struct__14348
#define kcg_copy_struct__14348(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14348)))
#endif /* kcg_copy_struct__14348 */

#ifndef kcg_copy_struct__14357
#define kcg_copy_struct__14357(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14357)))
#endif /* kcg_copy_struct__14357 */

#ifndef kcg_copy_struct__14367
#define kcg_copy_struct__14367(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14367)))
#endif /* kcg_copy_struct__14367 */

#ifndef kcg_copy_struct__14376
#define kcg_copy_struct__14376(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14376)))
#endif /* kcg_copy_struct__14376 */

#ifndef kcg_copy_struct__14385
#define kcg_copy_struct__14385(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14385)))
#endif /* kcg_copy_struct__14385 */

#ifndef kcg_copy_struct__14395
#define kcg_copy_struct__14395(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14395)))
#endif /* kcg_copy_struct__14395 */

#ifndef kcg_copy_struct__14404
#define kcg_copy_struct__14404(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14404)))
#endif /* kcg_copy_struct__14404 */

#ifndef kcg_copy_struct__14413
#define kcg_copy_struct__14413(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14413)))
#endif /* kcg_copy_struct__14413 */

#ifndef kcg_copy_struct__14417
#define kcg_copy_struct__14417(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14417)))
#endif /* kcg_copy_struct__14417 */

#ifndef kcg_copy_struct__14424
#define kcg_copy_struct__14424(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14424)))
#endif /* kcg_copy_struct__14424 */

#ifndef kcg_copy_struct__14431
#define kcg_copy_struct__14431(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14431)))
#endif /* kcg_copy_struct__14431 */

#ifndef kcg_copy_struct__14436
#define kcg_copy_struct__14436(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14436)))
#endif /* kcg_copy_struct__14436 */

#ifndef kcg_copy_struct__14444
#define kcg_copy_struct__14444(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14444)))
#endif /* kcg_copy_struct__14444 */

#ifndef kcg_copy_struct__14449
#define kcg_copy_struct__14449(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14449)))
#endif /* kcg_copy_struct__14449 */

#ifndef kcg_copy_struct__14464
#define kcg_copy_struct__14464(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14464)))
#endif /* kcg_copy_struct__14464 */

#ifndef kcg_copy_struct__14470
#define kcg_copy_struct__14470(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14470)))
#endif /* kcg_copy_struct__14470 */

#ifndef kcg_copy_struct__14476
#define kcg_copy_struct__14476(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14476)))
#endif /* kcg_copy_struct__14476 */

#ifndef kcg_copy_struct__14482
#define kcg_copy_struct__14482(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14482)))
#endif /* kcg_copy_struct__14482 */

#ifndef kcg_copy_struct__14489
#define kcg_copy_struct__14489(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14489)))
#endif /* kcg_copy_struct__14489 */

#ifndef kcg_copy_struct__14494
#define kcg_copy_struct__14494(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14494)))
#endif /* kcg_copy_struct__14494 */

#ifndef kcg_copy_struct__14500
#define kcg_copy_struct__14500(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14500)))
#endif /* kcg_copy_struct__14500 */

#ifndef kcg_copy_struct__14520
#define kcg_copy_struct__14520(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14520)))
#endif /* kcg_copy_struct__14520 */

#ifndef kcg_copy_struct__14539
#define kcg_copy_struct__14539(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14539)))
#endif /* kcg_copy_struct__14539 */

#ifndef kcg_copy_struct__14545
#define kcg_copy_struct__14545(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14545)))
#endif /* kcg_copy_struct__14545 */

#ifndef kcg_copy_struct__14555
#define kcg_copy_struct__14555(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14555)))
#endif /* kcg_copy_struct__14555 */

#ifndef kcg_copy_struct__14563
#define kcg_copy_struct__14563(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14563)))
#endif /* kcg_copy_struct__14563 */

#ifndef kcg_copy_struct__14570
#define kcg_copy_struct__14570(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14570)))
#endif /* kcg_copy_struct__14570 */

#ifndef kcg_copy_struct__14579
#define kcg_copy_struct__14579(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14579)))
#endif /* kcg_copy_struct__14579 */

#ifndef kcg_copy_struct__14588
#define kcg_copy_struct__14588(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14588)))
#endif /* kcg_copy_struct__14588 */

#ifndef kcg_copy_struct__14595
#define kcg_copy_struct__14595(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14595)))
#endif /* kcg_copy_struct__14595 */

#ifndef kcg_copy_struct__14604
#define kcg_copy_struct__14604(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14604)))
#endif /* kcg_copy_struct__14604 */

#ifndef kcg_copy_struct__14616
#define kcg_copy_struct__14616(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14616)))
#endif /* kcg_copy_struct__14616 */

#ifndef kcg_copy_struct__14629
#define kcg_copy_struct__14629(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14629)))
#endif /* kcg_copy_struct__14629 */

#ifndef kcg_copy_struct__14636
#define kcg_copy_struct__14636(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14636)))
#endif /* kcg_copy_struct__14636 */

#ifndef kcg_copy_struct__14648
#define kcg_copy_struct__14648(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14648)))
#endif /* kcg_copy_struct__14648 */

#ifndef kcg_copy_struct__14662
#define kcg_copy_struct__14662(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14662)))
#endif /* kcg_copy_struct__14662 */

#ifndef kcg_copy_struct__14674
#define kcg_copy_struct__14674(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14674)))
#endif /* kcg_copy_struct__14674 */

#ifndef kcg_copy_struct__14679
#define kcg_copy_struct__14679(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14679)))
#endif /* kcg_copy_struct__14679 */

#ifndef kcg_copy_struct__14693
#define kcg_copy_struct__14693(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14693)))
#endif /* kcg_copy_struct__14693 */

#ifndef kcg_copy_struct__14705
#define kcg_copy_struct__14705(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14705)))
#endif /* kcg_copy_struct__14705 */

#ifndef kcg_copy_struct__14710
#define kcg_copy_struct__14710(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14710)))
#endif /* kcg_copy_struct__14710 */

#ifndef kcg_copy_struct__14724
#define kcg_copy_struct__14724(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14724)))
#endif /* kcg_copy_struct__14724 */

#ifndef kcg_copy_struct__14730
#define kcg_copy_struct__14730(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14730)))
#endif /* kcg_copy_struct__14730 */

#ifndef kcg_copy_struct__14751
#define kcg_copy_struct__14751(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14751)))
#endif /* kcg_copy_struct__14751 */

#ifndef kcg_copy_struct__14773
#define kcg_copy_struct__14773(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14773)))
#endif /* kcg_copy_struct__14773 */

#ifndef kcg_copy_struct__14783
#define kcg_copy_struct__14783(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14783)))
#endif /* kcg_copy_struct__14783 */

#ifndef kcg_copy_struct__14795
#define kcg_copy_struct__14795(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14795)))
#endif /* kcg_copy_struct__14795 */

#ifndef kcg_copy_struct__14800
#define kcg_copy_struct__14800(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14800)))
#endif /* kcg_copy_struct__14800 */

#ifndef kcg_copy_struct__14816
#define kcg_copy_struct__14816(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14816)))
#endif /* kcg_copy_struct__14816 */

#ifndef kcg_copy_struct__14826
#define kcg_copy_struct__14826(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14826)))
#endif /* kcg_copy_struct__14826 */

#ifndef kcg_copy_struct__14831
#define kcg_copy_struct__14831(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14831)))
#endif /* kcg_copy_struct__14831 */

#ifndef kcg_copy_struct__14845
#define kcg_copy_struct__14845(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14845)))
#endif /* kcg_copy_struct__14845 */

#ifndef kcg_copy_struct__14854
#define kcg_copy_struct__14854(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14854)))
#endif /* kcg_copy_struct__14854 */

#ifndef kcg_copy_struct__14859
#define kcg_copy_struct__14859(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14859)))
#endif /* kcg_copy_struct__14859 */

#ifndef kcg_copy_struct__14872
#define kcg_copy_struct__14872(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14872)))
#endif /* kcg_copy_struct__14872 */

#ifndef kcg_copy_struct__14880
#define kcg_copy_struct__14880(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14880)))
#endif /* kcg_copy_struct__14880 */

#ifndef kcg_copy_struct__14885
#define kcg_copy_struct__14885(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14885)))
#endif /* kcg_copy_struct__14885 */

#ifndef kcg_copy_struct__14895
#define kcg_copy_struct__14895(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14895)))
#endif /* kcg_copy_struct__14895 */

#ifndef kcg_copy_struct__14902
#define kcg_copy_struct__14902(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14902)))
#endif /* kcg_copy_struct__14902 */

#ifndef kcg_copy_struct__14914
#define kcg_copy_struct__14914(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14914)))
#endif /* kcg_copy_struct__14914 */

#ifndef kcg_copy_struct__14923
#define kcg_copy_struct__14923(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14923)))
#endif /* kcg_copy_struct__14923 */

#ifndef kcg_copy_struct__14928
#define kcg_copy_struct__14928(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14928)))
#endif /* kcg_copy_struct__14928 */

#ifndef kcg_copy_struct__14935
#define kcg_copy_struct__14935(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14935)))
#endif /* kcg_copy_struct__14935 */

#ifndef kcg_copy_struct__14943
#define kcg_copy_struct__14943(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14943)))
#endif /* kcg_copy_struct__14943 */

#ifndef kcg_copy_struct__14948
#define kcg_copy_struct__14948(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14948)))
#endif /* kcg_copy_struct__14948 */

#ifndef kcg_copy_struct__14959
#define kcg_copy_struct__14959(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14959)))
#endif /* kcg_copy_struct__14959 */

#ifndef kcg_copy_struct__14968
#define kcg_copy_struct__14968(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14968)))
#endif /* kcg_copy_struct__14968 */

#ifndef kcg_copy_struct__14980
#define kcg_copy_struct__14980(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14980)))
#endif /* kcg_copy_struct__14980 */

#ifndef kcg_copy_struct__14985
#define kcg_copy_struct__14985(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__14985)))
#endif /* kcg_copy_struct__14985 */

#ifndef kcg_copy_struct__15001
#define kcg_copy_struct__15001(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15001)))
#endif /* kcg_copy_struct__15001 */

#ifndef kcg_copy_struct__15009
#define kcg_copy_struct__15009(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15009)))
#endif /* kcg_copy_struct__15009 */

#ifndef kcg_copy_struct__15014
#define kcg_copy_struct__15014(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15014)))
#endif /* kcg_copy_struct__15014 */

#ifndef kcg_copy_struct__15024
#define kcg_copy_struct__15024(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15024)))
#endif /* kcg_copy_struct__15024 */

#ifndef kcg_copy_struct__15029
#define kcg_copy_struct__15029(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15029)))
#endif /* kcg_copy_struct__15029 */

#ifndef kcg_copy_struct__15043
#define kcg_copy_struct__15043(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15043)))
#endif /* kcg_copy_struct__15043 */

#ifndef kcg_copy_struct__15050
#define kcg_copy_struct__15050(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15050)))
#endif /* kcg_copy_struct__15050 */

#ifndef kcg_copy_struct__15058
#define kcg_copy_struct__15058(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15058)))
#endif /* kcg_copy_struct__15058 */

#ifndef kcg_copy_struct__15063
#define kcg_copy_struct__15063(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15063)))
#endif /* kcg_copy_struct__15063 */

#ifndef kcg_copy_struct__15072
#define kcg_copy_struct__15072(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15072)))
#endif /* kcg_copy_struct__15072 */

#ifndef kcg_copy_struct__15079
#define kcg_copy_struct__15079(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15079)))
#endif /* kcg_copy_struct__15079 */

#ifndef kcg_copy_struct__15088
#define kcg_copy_struct__15088(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15088)))
#endif /* kcg_copy_struct__15088 */

#ifndef kcg_copy_struct__15099
#define kcg_copy_struct__15099(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15099)))
#endif /* kcg_copy_struct__15099 */

#ifndef kcg_copy_struct__15108
#define kcg_copy_struct__15108(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15108)))
#endif /* kcg_copy_struct__15108 */

#ifndef kcg_copy_struct__15113
#define kcg_copy_struct__15113(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15113)))
#endif /* kcg_copy_struct__15113 */

#ifndef kcg_copy_struct__15125
#define kcg_copy_struct__15125(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15125)))
#endif /* kcg_copy_struct__15125 */

#ifndef kcg_copy_struct__15134
#define kcg_copy_struct__15134(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15134)))
#endif /* kcg_copy_struct__15134 */

#ifndef kcg_copy_struct__15144
#define kcg_copy_struct__15144(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15144)))
#endif /* kcg_copy_struct__15144 */

#ifndef kcg_copy_struct__15154
#define kcg_copy_struct__15154(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15154)))
#endif /* kcg_copy_struct__15154 */

#ifndef kcg_copy_struct__15159
#define kcg_copy_struct__15159(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15159)))
#endif /* kcg_copy_struct__15159 */

#ifndef kcg_copy_struct__15169
#define kcg_copy_struct__15169(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15169)))
#endif /* kcg_copy_struct__15169 */

#ifndef kcg_copy_struct__15174
#define kcg_copy_struct__15174(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15174)))
#endif /* kcg_copy_struct__15174 */

#ifndef kcg_copy_struct__15186
#define kcg_copy_struct__15186(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15186)))
#endif /* kcg_copy_struct__15186 */

#ifndef kcg_copy_struct__15195
#define kcg_copy_struct__15195(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15195)))
#endif /* kcg_copy_struct__15195 */

#ifndef kcg_copy_struct__15200
#define kcg_copy_struct__15200(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15200)))
#endif /* kcg_copy_struct__15200 */

#ifndef kcg_copy_struct__15211
#define kcg_copy_struct__15211(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15211)))
#endif /* kcg_copy_struct__15211 */

#ifndef kcg_copy_struct__15219
#define kcg_copy_struct__15219(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15219)))
#endif /* kcg_copy_struct__15219 */

#ifndef kcg_copy_struct__15229
#define kcg_copy_struct__15229(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15229)))
#endif /* kcg_copy_struct__15229 */

#ifndef kcg_copy_struct__15234
#define kcg_copy_struct__15234(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15234)))
#endif /* kcg_copy_struct__15234 */

#ifndef kcg_copy_struct__15259
#define kcg_copy_struct__15259(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15259)))
#endif /* kcg_copy_struct__15259 */

#ifndef kcg_copy_struct__15269
#define kcg_copy_struct__15269(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15269)))
#endif /* kcg_copy_struct__15269 */

#ifndef kcg_copy_struct__15274
#define kcg_copy_struct__15274(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15274)))
#endif /* kcg_copy_struct__15274 */

#ifndef kcg_copy_struct__15285
#define kcg_copy_struct__15285(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15285)))
#endif /* kcg_copy_struct__15285 */

#ifndef kcg_copy_struct__15311
#define kcg_copy_struct__15311(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15311)))
#endif /* kcg_copy_struct__15311 */

#ifndef kcg_copy_struct__15321
#define kcg_copy_struct__15321(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15321)))
#endif /* kcg_copy_struct__15321 */

#ifndef kcg_copy_struct__15334
#define kcg_copy_struct__15334(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15334)))
#endif /* kcg_copy_struct__15334 */

#ifndef kcg_copy_struct__15339
#define kcg_copy_struct__15339(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15339)))
#endif /* kcg_copy_struct__15339 */

#ifndef kcg_copy_struct__15354
#define kcg_copy_struct__15354(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15354)))
#endif /* kcg_copy_struct__15354 */

#ifndef kcg_copy_struct__15362
#define kcg_copy_struct__15362(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15362)))
#endif /* kcg_copy_struct__15362 */

#ifndef kcg_copy_struct__15367
#define kcg_copy_struct__15367(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15367)))
#endif /* kcg_copy_struct__15367 */

#ifndef kcg_copy_struct__15375
#define kcg_copy_struct__15375(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15375)))
#endif /* kcg_copy_struct__15375 */

#ifndef kcg_copy_struct__15380
#define kcg_copy_struct__15380(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15380)))
#endif /* kcg_copy_struct__15380 */

#ifndef kcg_copy_struct__15392
#define kcg_copy_struct__15392(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15392)))
#endif /* kcg_copy_struct__15392 */

#ifndef kcg_copy_struct__15397
#define kcg_copy_struct__15397(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15397)))
#endif /* kcg_copy_struct__15397 */

#ifndef kcg_copy_struct__15404
#define kcg_copy_struct__15404(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15404)))
#endif /* kcg_copy_struct__15404 */

#ifndef kcg_copy_struct__15409
#define kcg_copy_struct__15409(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15409)))
#endif /* kcg_copy_struct__15409 */

#ifndef kcg_copy_struct__15459
#define kcg_copy_struct__15459(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15459)))
#endif /* kcg_copy_struct__15459 */

#ifndef kcg_copy_struct__15466
#define kcg_copy_struct__15466(kcg_C1, kcg_C2) (kcg_assign_struct((kcg_C1), (kcg_C2), sizeof (struct__15466)))
#endif /* kcg_copy_struct__15466 */

#ifndef kcg_copy_array__13875
#define kcg_copy_array__13875(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__13875)))
#endif /* kcg_copy_array__13875 */

#ifndef kcg_copy_array__13951
#define kcg_copy_array__13951(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__13951)))
#endif /* kcg_copy_array__13951 */

#ifndef kcg_copy_array__14004
#define kcg_copy_array__14004(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14004)))
#endif /* kcg_copy_array__14004 */

#ifndef kcg_copy_array__14018
#define kcg_copy_array__14018(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14018)))
#endif /* kcg_copy_array__14018 */

#ifndef kcg_copy_array__14034
#define kcg_copy_array__14034(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14034)))
#endif /* kcg_copy_array__14034 */

#ifndef kcg_copy_array__14059
#define kcg_copy_array__14059(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14059)))
#endif /* kcg_copy_array__14059 */

#ifndef kcg_copy_array__14099
#define kcg_copy_array__14099(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14099)))
#endif /* kcg_copy_array__14099 */

#ifndef kcg_copy_array__14428
#define kcg_copy_array__14428(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14428)))
#endif /* kcg_copy_array__14428 */

#ifndef kcg_copy_array__14441
#define kcg_copy_array__14441(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14441)))
#endif /* kcg_copy_array__14441 */

#ifndef kcg_copy_array__14486
#define kcg_copy_array__14486(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14486)))
#endif /* kcg_copy_array__14486 */

#ifndef kcg_copy_array__14671
#define kcg_copy_array__14671(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14671)))
#endif /* kcg_copy_array__14671 */

#ifndef kcg_copy_array__14702
#define kcg_copy_array__14702(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14702)))
#endif /* kcg_copy_array__14702 */

#ifndef kcg_copy_array__14792
#define kcg_copy_array__14792(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14792)))
#endif /* kcg_copy_array__14792 */

#ifndef kcg_copy_array__14823
#define kcg_copy_array__14823(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14823)))
#endif /* kcg_copy_array__14823 */

#ifndef kcg_copy_array__14851
#define kcg_copy_array__14851(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14851)))
#endif /* kcg_copy_array__14851 */

#ifndef kcg_copy_array__14877
#define kcg_copy_array__14877(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14877)))
#endif /* kcg_copy_array__14877 */

#ifndef kcg_copy_array__14920
#define kcg_copy_array__14920(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14920)))
#endif /* kcg_copy_array__14920 */

#ifndef kcg_copy_array__14940
#define kcg_copy_array__14940(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14940)))
#endif /* kcg_copy_array__14940 */

#ifndef kcg_copy_array__14977
#define kcg_copy_array__14977(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__14977)))
#endif /* kcg_copy_array__14977 */

#ifndef kcg_copy_array__15006
#define kcg_copy_array__15006(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15006)))
#endif /* kcg_copy_array__15006 */

#ifndef kcg_copy_array__15021
#define kcg_copy_array__15021(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15021)))
#endif /* kcg_copy_array__15021 */

#ifndef kcg_copy_array__15055
#define kcg_copy_array__15055(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15055)))
#endif /* kcg_copy_array__15055 */

#ifndef kcg_copy_array__15105
#define kcg_copy_array__15105(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15105)))
#endif /* kcg_copy_array__15105 */

#ifndef kcg_copy_array__15151
#define kcg_copy_array__15151(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15151)))
#endif /* kcg_copy_array__15151 */

#ifndef kcg_copy_array__15166
#define kcg_copy_array__15166(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15166)))
#endif /* kcg_copy_array__15166 */

#ifndef kcg_copy_array__15192
#define kcg_copy_array__15192(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15192)))
#endif /* kcg_copy_array__15192 */

#ifndef kcg_copy_array__15226
#define kcg_copy_array__15226(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15226)))
#endif /* kcg_copy_array__15226 */

#ifndef kcg_copy_array__15266
#define kcg_copy_array__15266(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15266)))
#endif /* kcg_copy_array__15266 */

#ifndef kcg_copy_array__15331
#define kcg_copy_array__15331(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15331)))
#endif /* kcg_copy_array__15331 */

#ifndef kcg_copy_array__15359
#define kcg_copy_array__15359(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15359)))
#endif /* kcg_copy_array__15359 */

#ifndef kcg_copy_array__15372
#define kcg_copy_array__15372(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15372)))
#endif /* kcg_copy_array__15372 */

#ifndef kcg_copy_array__15389
#define kcg_copy_array__15389(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15389)))
#endif /* kcg_copy_array__15389 */

#ifndef kcg_copy_array__15401
#define kcg_copy_array__15401(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15401)))
#endif /* kcg_copy_array__15401 */

#ifndef kcg_copy_array__15471
#define kcg_copy_array__15471(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__15471)))
#endif /* kcg_copy_array__15471 */

#ifndef kcg_copy_array__16143
#define kcg_copy_array__16143(kcg_C1, kcg_C2) (kcg_assign_array((kcg_C1), (kcg_C2), sizeof (array__16143)))
#endif /* kcg_copy_array__16143 */

#ifndef kcg_comp_struct__13859
extern kcg_bool kcg_comp_struct__13859(
  struct__13859 *kcg_c1,
  struct__13859 *kcg_c2);
#endif /* kcg_comp_struct__13859 */

#ifndef kcg_comp_struct__13878
extern kcg_bool kcg_comp_struct__13878(
  struct__13878 *kcg_c1,
  struct__13878 *kcg_c2);
#endif /* kcg_comp_struct__13878 */

#ifndef kcg_comp_struct__13889
extern kcg_bool kcg_comp_struct__13889(
  struct__13889 *kcg_c1,
  struct__13889 *kcg_c2);
#endif /* kcg_comp_struct__13889 */

#ifndef kcg_comp_struct__13895
extern kcg_bool kcg_comp_struct__13895(
  struct__13895 *kcg_c1,
  struct__13895 *kcg_c2);
#endif /* kcg_comp_struct__13895 */

#ifndef kcg_comp_struct__13901
extern kcg_bool kcg_comp_struct__13901(
  struct__13901 *kcg_c1,
  struct__13901 *kcg_c2);
#endif /* kcg_comp_struct__13901 */

#ifndef kcg_comp_struct__13914
extern kcg_bool kcg_comp_struct__13914(
  struct__13914 *kcg_c1,
  struct__13914 *kcg_c2);
#endif /* kcg_comp_struct__13914 */

#ifndef kcg_comp_struct__13920
extern kcg_bool kcg_comp_struct__13920(
  struct__13920 *kcg_c1,
  struct__13920 *kcg_c2);
#endif /* kcg_comp_struct__13920 */

#ifndef kcg_comp_struct__13929
extern kcg_bool kcg_comp_struct__13929(
  struct__13929 *kcg_c1,
  struct__13929 *kcg_c2);
#endif /* kcg_comp_struct__13929 */

#ifndef kcg_comp_struct__13940
extern kcg_bool kcg_comp_struct__13940(
  struct__13940 *kcg_c1,
  struct__13940 *kcg_c2);
#endif /* kcg_comp_struct__13940 */

#ifndef kcg_comp_struct__13954
extern kcg_bool kcg_comp_struct__13954(
  struct__13954 *kcg_c1,
  struct__13954 *kcg_c2);
#endif /* kcg_comp_struct__13954 */

#ifndef kcg_comp_struct__13971
extern kcg_bool kcg_comp_struct__13971(
  struct__13971 *kcg_c1,
  struct__13971 *kcg_c2);
#endif /* kcg_comp_struct__13971 */

#ifndef kcg_comp_struct__13982
extern kcg_bool kcg_comp_struct__13982(
  struct__13982 *kcg_c1,
  struct__13982 *kcg_c2);
#endif /* kcg_comp_struct__13982 */

#ifndef kcg_comp_struct__13988
extern kcg_bool kcg_comp_struct__13988(
  struct__13988 *kcg_c1,
  struct__13988 *kcg_c2);
#endif /* kcg_comp_struct__13988 */

#ifndef kcg_comp_struct__13997
extern kcg_bool kcg_comp_struct__13997(
  struct__13997 *kcg_c1,
  struct__13997 *kcg_c2);
#endif /* kcg_comp_struct__13997 */

#ifndef kcg_comp_struct__14007
extern kcg_bool kcg_comp_struct__14007(
  struct__14007 *kcg_c1,
  struct__14007 *kcg_c2);
#endif /* kcg_comp_struct__14007 */

#ifndef kcg_comp_struct__14012
extern kcg_bool kcg_comp_struct__14012(
  struct__14012 *kcg_c1,
  struct__14012 *kcg_c2);
#endif /* kcg_comp_struct__14012 */

#ifndef kcg_comp_struct__14021
extern kcg_bool kcg_comp_struct__14021(
  struct__14021 *kcg_c1,
  struct__14021 *kcg_c2);
#endif /* kcg_comp_struct__14021 */

#ifndef kcg_comp_struct__14029
extern kcg_bool kcg_comp_struct__14029(
  struct__14029 *kcg_c1,
  struct__14029 *kcg_c2);
#endif /* kcg_comp_struct__14029 */

#ifndef kcg_comp_struct__14037
extern kcg_bool kcg_comp_struct__14037(
  struct__14037 *kcg_c1,
  struct__14037 *kcg_c2);
#endif /* kcg_comp_struct__14037 */

#ifndef kcg_comp_struct__14043
extern kcg_bool kcg_comp_struct__14043(
  struct__14043 *kcg_c1,
  struct__14043 *kcg_c2);
#endif /* kcg_comp_struct__14043 */

#ifndef kcg_comp_struct__14053
extern kcg_bool kcg_comp_struct__14053(
  struct__14053 *kcg_c1,
  struct__14053 *kcg_c2);
#endif /* kcg_comp_struct__14053 */

#ifndef kcg_comp_struct__14062
extern kcg_bool kcg_comp_struct__14062(
  struct__14062 *kcg_c1,
  struct__14062 *kcg_c2);
#endif /* kcg_comp_struct__14062 */

#ifndef kcg_comp_struct__14068
extern kcg_bool kcg_comp_struct__14068(
  struct__14068 *kcg_c1,
  struct__14068 *kcg_c2);
#endif /* kcg_comp_struct__14068 */

#ifndef kcg_comp_struct__14075
extern kcg_bool kcg_comp_struct__14075(
  struct__14075 *kcg_c1,
  struct__14075 *kcg_c2);
#endif /* kcg_comp_struct__14075 */

#ifndef kcg_comp_struct__14088
extern kcg_bool kcg_comp_struct__14088(
  struct__14088 *kcg_c1,
  struct__14088 *kcg_c2);
#endif /* kcg_comp_struct__14088 */

#ifndef kcg_comp_struct__14092
extern kcg_bool kcg_comp_struct__14092(
  struct__14092 *kcg_c1,
  struct__14092 *kcg_c2);
#endif /* kcg_comp_struct__14092 */

#ifndef kcg_comp_struct__14102
extern kcg_bool kcg_comp_struct__14102(
  struct__14102 *kcg_c1,
  struct__14102 *kcg_c2);
#endif /* kcg_comp_struct__14102 */

#ifndef kcg_comp_struct__14110
extern kcg_bool kcg_comp_struct__14110(
  struct__14110 *kcg_c1,
  struct__14110 *kcg_c2);
#endif /* kcg_comp_struct__14110 */

#ifndef kcg_comp_struct__14119
extern kcg_bool kcg_comp_struct__14119(
  struct__14119 *kcg_c1,
  struct__14119 *kcg_c2);
#endif /* kcg_comp_struct__14119 */

#ifndef kcg_comp_struct__14123
extern kcg_bool kcg_comp_struct__14123(
  struct__14123 *kcg_c1,
  struct__14123 *kcg_c2);
#endif /* kcg_comp_struct__14123 */

#ifndef kcg_comp_struct__14132
extern kcg_bool kcg_comp_struct__14132(
  struct__14132 *kcg_c1,
  struct__14132 *kcg_c2);
#endif /* kcg_comp_struct__14132 */

#ifndef kcg_comp_struct__14136
extern kcg_bool kcg_comp_struct__14136(
  struct__14136 *kcg_c1,
  struct__14136 *kcg_c2);
#endif /* kcg_comp_struct__14136 */

#ifndef kcg_comp_struct__14144
extern kcg_bool kcg_comp_struct__14144(
  struct__14144 *kcg_c1,
  struct__14144 *kcg_c2);
#endif /* kcg_comp_struct__14144 */

#ifndef kcg_comp_struct__14150
extern kcg_bool kcg_comp_struct__14150(
  struct__14150 *kcg_c1,
  struct__14150 *kcg_c2);
#endif /* kcg_comp_struct__14150 */

#ifndef kcg_comp_struct__14155
extern kcg_bool kcg_comp_struct__14155(
  struct__14155 *kcg_c1,
  struct__14155 *kcg_c2);
#endif /* kcg_comp_struct__14155 */

#ifndef kcg_comp_struct__14163
extern kcg_bool kcg_comp_struct__14163(
  struct__14163 *kcg_c1,
  struct__14163 *kcg_c2);
#endif /* kcg_comp_struct__14163 */

#ifndef kcg_comp_struct__14173
extern kcg_bool kcg_comp_struct__14173(
  struct__14173 *kcg_c1,
  struct__14173 *kcg_c2);
#endif /* kcg_comp_struct__14173 */

#ifndef kcg_comp_struct__14186
extern kcg_bool kcg_comp_struct__14186(
  struct__14186 *kcg_c1,
  struct__14186 *kcg_c2);
#endif /* kcg_comp_struct__14186 */

#ifndef kcg_comp_struct__14198
extern kcg_bool kcg_comp_struct__14198(
  struct__14198 *kcg_c1,
  struct__14198 *kcg_c2);
#endif /* kcg_comp_struct__14198 */

#ifndef kcg_comp_struct__14207
extern kcg_bool kcg_comp_struct__14207(
  struct__14207 *kcg_c1,
  struct__14207 *kcg_c2);
#endif /* kcg_comp_struct__14207 */

#ifndef kcg_comp_struct__14218
extern kcg_bool kcg_comp_struct__14218(
  struct__14218 *kcg_c1,
  struct__14218 *kcg_c2);
#endif /* kcg_comp_struct__14218 */

#ifndef kcg_comp_struct__14227
extern kcg_bool kcg_comp_struct__14227(
  struct__14227 *kcg_c1,
  struct__14227 *kcg_c2);
#endif /* kcg_comp_struct__14227 */

#ifndef kcg_comp_struct__14237
extern kcg_bool kcg_comp_struct__14237(
  struct__14237 *kcg_c1,
  struct__14237 *kcg_c2);
#endif /* kcg_comp_struct__14237 */

#ifndef kcg_comp_struct__14246
extern kcg_bool kcg_comp_struct__14246(
  struct__14246 *kcg_c1,
  struct__14246 *kcg_c2);
#endif /* kcg_comp_struct__14246 */

#ifndef kcg_comp_struct__14259
extern kcg_bool kcg_comp_struct__14259(
  struct__14259 *kcg_c1,
  struct__14259 *kcg_c2);
#endif /* kcg_comp_struct__14259 */

#ifndef kcg_comp_struct__14269
extern kcg_bool kcg_comp_struct__14269(
  struct__14269 *kcg_c1,
  struct__14269 *kcg_c2);
#endif /* kcg_comp_struct__14269 */

#ifndef kcg_comp_struct__14279
extern kcg_bool kcg_comp_struct__14279(
  struct__14279 *kcg_c1,
  struct__14279 *kcg_c2);
#endif /* kcg_comp_struct__14279 */

#ifndef kcg_comp_struct__14291
extern kcg_bool kcg_comp_struct__14291(
  struct__14291 *kcg_c1,
  struct__14291 *kcg_c2);
#endif /* kcg_comp_struct__14291 */

#ifndef kcg_comp_struct__14300
extern kcg_bool kcg_comp_struct__14300(
  struct__14300 *kcg_c1,
  struct__14300 *kcg_c2);
#endif /* kcg_comp_struct__14300 */

#ifndef kcg_comp_struct__14310
extern kcg_bool kcg_comp_struct__14310(
  struct__14310 *kcg_c1,
  struct__14310 *kcg_c2);
#endif /* kcg_comp_struct__14310 */

#ifndef kcg_comp_struct__14320
extern kcg_bool kcg_comp_struct__14320(
  struct__14320 *kcg_c1,
  struct__14320 *kcg_c2);
#endif /* kcg_comp_struct__14320 */

#ifndef kcg_comp_struct__14327
extern kcg_bool kcg_comp_struct__14327(
  struct__14327 *kcg_c1,
  struct__14327 *kcg_c2);
#endif /* kcg_comp_struct__14327 */

#ifndef kcg_comp_struct__14339
extern kcg_bool kcg_comp_struct__14339(
  struct__14339 *kcg_c1,
  struct__14339 *kcg_c2);
#endif /* kcg_comp_struct__14339 */

#ifndef kcg_comp_struct__14348
extern kcg_bool kcg_comp_struct__14348(
  struct__14348 *kcg_c1,
  struct__14348 *kcg_c2);
#endif /* kcg_comp_struct__14348 */

#ifndef kcg_comp_struct__14357
extern kcg_bool kcg_comp_struct__14357(
  struct__14357 *kcg_c1,
  struct__14357 *kcg_c2);
#endif /* kcg_comp_struct__14357 */

#ifndef kcg_comp_struct__14367
extern kcg_bool kcg_comp_struct__14367(
  struct__14367 *kcg_c1,
  struct__14367 *kcg_c2);
#endif /* kcg_comp_struct__14367 */

#ifndef kcg_comp_struct__14376
extern kcg_bool kcg_comp_struct__14376(
  struct__14376 *kcg_c1,
  struct__14376 *kcg_c2);
#endif /* kcg_comp_struct__14376 */

#ifndef kcg_comp_struct__14385
extern kcg_bool kcg_comp_struct__14385(
  struct__14385 *kcg_c1,
  struct__14385 *kcg_c2);
#endif /* kcg_comp_struct__14385 */

#ifndef kcg_comp_struct__14395
extern kcg_bool kcg_comp_struct__14395(
  struct__14395 *kcg_c1,
  struct__14395 *kcg_c2);
#endif /* kcg_comp_struct__14395 */

#ifndef kcg_comp_struct__14404
extern kcg_bool kcg_comp_struct__14404(
  struct__14404 *kcg_c1,
  struct__14404 *kcg_c2);
#endif /* kcg_comp_struct__14404 */

#ifndef kcg_comp_struct__14413
extern kcg_bool kcg_comp_struct__14413(
  struct__14413 *kcg_c1,
  struct__14413 *kcg_c2);
#endif /* kcg_comp_struct__14413 */

#ifndef kcg_comp_struct__14417
extern kcg_bool kcg_comp_struct__14417(
  struct__14417 *kcg_c1,
  struct__14417 *kcg_c2);
#endif /* kcg_comp_struct__14417 */

#ifndef kcg_comp_struct__14424
extern kcg_bool kcg_comp_struct__14424(
  struct__14424 *kcg_c1,
  struct__14424 *kcg_c2);
#endif /* kcg_comp_struct__14424 */

#ifndef kcg_comp_struct__14431
extern kcg_bool kcg_comp_struct__14431(
  struct__14431 *kcg_c1,
  struct__14431 *kcg_c2);
#endif /* kcg_comp_struct__14431 */

#ifndef kcg_comp_struct__14436
extern kcg_bool kcg_comp_struct__14436(
  struct__14436 *kcg_c1,
  struct__14436 *kcg_c2);
#endif /* kcg_comp_struct__14436 */

#ifndef kcg_comp_struct__14444
extern kcg_bool kcg_comp_struct__14444(
  struct__14444 *kcg_c1,
  struct__14444 *kcg_c2);
#endif /* kcg_comp_struct__14444 */

#ifndef kcg_comp_struct__14449
extern kcg_bool kcg_comp_struct__14449(
  struct__14449 *kcg_c1,
  struct__14449 *kcg_c2);
#endif /* kcg_comp_struct__14449 */

#ifndef kcg_comp_struct__14464
extern kcg_bool kcg_comp_struct__14464(
  struct__14464 *kcg_c1,
  struct__14464 *kcg_c2);
#endif /* kcg_comp_struct__14464 */

#ifndef kcg_comp_struct__14470
extern kcg_bool kcg_comp_struct__14470(
  struct__14470 *kcg_c1,
  struct__14470 *kcg_c2);
#endif /* kcg_comp_struct__14470 */

#ifndef kcg_comp_struct__14476
extern kcg_bool kcg_comp_struct__14476(
  struct__14476 *kcg_c1,
  struct__14476 *kcg_c2);
#endif /* kcg_comp_struct__14476 */

#ifndef kcg_comp_struct__14482
extern kcg_bool kcg_comp_struct__14482(
  struct__14482 *kcg_c1,
  struct__14482 *kcg_c2);
#endif /* kcg_comp_struct__14482 */

#ifndef kcg_comp_struct__14489
extern kcg_bool kcg_comp_struct__14489(
  struct__14489 *kcg_c1,
  struct__14489 *kcg_c2);
#endif /* kcg_comp_struct__14489 */

#ifndef kcg_comp_struct__14494
extern kcg_bool kcg_comp_struct__14494(
  struct__14494 *kcg_c1,
  struct__14494 *kcg_c2);
#endif /* kcg_comp_struct__14494 */

#ifndef kcg_comp_struct__14500
extern kcg_bool kcg_comp_struct__14500(
  struct__14500 *kcg_c1,
  struct__14500 *kcg_c2);
#endif /* kcg_comp_struct__14500 */

#ifndef kcg_comp_struct__14520
extern kcg_bool kcg_comp_struct__14520(
  struct__14520 *kcg_c1,
  struct__14520 *kcg_c2);
#endif /* kcg_comp_struct__14520 */

#ifndef kcg_comp_struct__14539
extern kcg_bool kcg_comp_struct__14539(
  struct__14539 *kcg_c1,
  struct__14539 *kcg_c2);
#endif /* kcg_comp_struct__14539 */

#ifndef kcg_comp_struct__14545
extern kcg_bool kcg_comp_struct__14545(
  struct__14545 *kcg_c1,
  struct__14545 *kcg_c2);
#endif /* kcg_comp_struct__14545 */

#ifndef kcg_comp_struct__14555
extern kcg_bool kcg_comp_struct__14555(
  struct__14555 *kcg_c1,
  struct__14555 *kcg_c2);
#endif /* kcg_comp_struct__14555 */

#ifndef kcg_comp_struct__14563
extern kcg_bool kcg_comp_struct__14563(
  struct__14563 *kcg_c1,
  struct__14563 *kcg_c2);
#endif /* kcg_comp_struct__14563 */

#ifndef kcg_comp_struct__14570
extern kcg_bool kcg_comp_struct__14570(
  struct__14570 *kcg_c1,
  struct__14570 *kcg_c2);
#endif /* kcg_comp_struct__14570 */

#ifndef kcg_comp_struct__14579
extern kcg_bool kcg_comp_struct__14579(
  struct__14579 *kcg_c1,
  struct__14579 *kcg_c2);
#endif /* kcg_comp_struct__14579 */

#ifndef kcg_comp_struct__14588
extern kcg_bool kcg_comp_struct__14588(
  struct__14588 *kcg_c1,
  struct__14588 *kcg_c2);
#endif /* kcg_comp_struct__14588 */

#ifndef kcg_comp_struct__14595
extern kcg_bool kcg_comp_struct__14595(
  struct__14595 *kcg_c1,
  struct__14595 *kcg_c2);
#endif /* kcg_comp_struct__14595 */

#ifndef kcg_comp_struct__14604
extern kcg_bool kcg_comp_struct__14604(
  struct__14604 *kcg_c1,
  struct__14604 *kcg_c2);
#endif /* kcg_comp_struct__14604 */

#ifndef kcg_comp_struct__14616
extern kcg_bool kcg_comp_struct__14616(
  struct__14616 *kcg_c1,
  struct__14616 *kcg_c2);
#endif /* kcg_comp_struct__14616 */

#ifndef kcg_comp_struct__14629
extern kcg_bool kcg_comp_struct__14629(
  struct__14629 *kcg_c1,
  struct__14629 *kcg_c2);
#endif /* kcg_comp_struct__14629 */

#ifndef kcg_comp_struct__14636
extern kcg_bool kcg_comp_struct__14636(
  struct__14636 *kcg_c1,
  struct__14636 *kcg_c2);
#endif /* kcg_comp_struct__14636 */

#ifndef kcg_comp_struct__14648
extern kcg_bool kcg_comp_struct__14648(
  struct__14648 *kcg_c1,
  struct__14648 *kcg_c2);
#endif /* kcg_comp_struct__14648 */

#ifndef kcg_comp_struct__14662
extern kcg_bool kcg_comp_struct__14662(
  struct__14662 *kcg_c1,
  struct__14662 *kcg_c2);
#endif /* kcg_comp_struct__14662 */

#ifndef kcg_comp_struct__14674
extern kcg_bool kcg_comp_struct__14674(
  struct__14674 *kcg_c1,
  struct__14674 *kcg_c2);
#endif /* kcg_comp_struct__14674 */

#ifndef kcg_comp_struct__14679
extern kcg_bool kcg_comp_struct__14679(
  struct__14679 *kcg_c1,
  struct__14679 *kcg_c2);
#endif /* kcg_comp_struct__14679 */

#ifndef kcg_comp_struct__14693
extern kcg_bool kcg_comp_struct__14693(
  struct__14693 *kcg_c1,
  struct__14693 *kcg_c2);
#endif /* kcg_comp_struct__14693 */

#ifndef kcg_comp_struct__14705
extern kcg_bool kcg_comp_struct__14705(
  struct__14705 *kcg_c1,
  struct__14705 *kcg_c2);
#endif /* kcg_comp_struct__14705 */

#ifndef kcg_comp_struct__14710
extern kcg_bool kcg_comp_struct__14710(
  struct__14710 *kcg_c1,
  struct__14710 *kcg_c2);
#endif /* kcg_comp_struct__14710 */

#ifndef kcg_comp_struct__14724
extern kcg_bool kcg_comp_struct__14724(
  struct__14724 *kcg_c1,
  struct__14724 *kcg_c2);
#endif /* kcg_comp_struct__14724 */

#ifndef kcg_comp_struct__14730
extern kcg_bool kcg_comp_struct__14730(
  struct__14730 *kcg_c1,
  struct__14730 *kcg_c2);
#endif /* kcg_comp_struct__14730 */

#ifndef kcg_comp_struct__14751
extern kcg_bool kcg_comp_struct__14751(
  struct__14751 *kcg_c1,
  struct__14751 *kcg_c2);
#endif /* kcg_comp_struct__14751 */

#ifndef kcg_comp_struct__14773
extern kcg_bool kcg_comp_struct__14773(
  struct__14773 *kcg_c1,
  struct__14773 *kcg_c2);
#endif /* kcg_comp_struct__14773 */

#ifndef kcg_comp_struct__14783
extern kcg_bool kcg_comp_struct__14783(
  struct__14783 *kcg_c1,
  struct__14783 *kcg_c2);
#endif /* kcg_comp_struct__14783 */

#ifndef kcg_comp_struct__14795
extern kcg_bool kcg_comp_struct__14795(
  struct__14795 *kcg_c1,
  struct__14795 *kcg_c2);
#endif /* kcg_comp_struct__14795 */

#ifndef kcg_comp_struct__14800
extern kcg_bool kcg_comp_struct__14800(
  struct__14800 *kcg_c1,
  struct__14800 *kcg_c2);
#endif /* kcg_comp_struct__14800 */

#ifndef kcg_comp_struct__14816
extern kcg_bool kcg_comp_struct__14816(
  struct__14816 *kcg_c1,
  struct__14816 *kcg_c2);
#endif /* kcg_comp_struct__14816 */

#ifndef kcg_comp_struct__14826
extern kcg_bool kcg_comp_struct__14826(
  struct__14826 *kcg_c1,
  struct__14826 *kcg_c2);
#endif /* kcg_comp_struct__14826 */

#ifndef kcg_comp_struct__14831
extern kcg_bool kcg_comp_struct__14831(
  struct__14831 *kcg_c1,
  struct__14831 *kcg_c2);
#endif /* kcg_comp_struct__14831 */

#ifndef kcg_comp_struct__14845
extern kcg_bool kcg_comp_struct__14845(
  struct__14845 *kcg_c1,
  struct__14845 *kcg_c2);
#endif /* kcg_comp_struct__14845 */

#ifndef kcg_comp_struct__14854
extern kcg_bool kcg_comp_struct__14854(
  struct__14854 *kcg_c1,
  struct__14854 *kcg_c2);
#endif /* kcg_comp_struct__14854 */

#ifndef kcg_comp_struct__14859
extern kcg_bool kcg_comp_struct__14859(
  struct__14859 *kcg_c1,
  struct__14859 *kcg_c2);
#endif /* kcg_comp_struct__14859 */

#ifndef kcg_comp_struct__14872
extern kcg_bool kcg_comp_struct__14872(
  struct__14872 *kcg_c1,
  struct__14872 *kcg_c2);
#endif /* kcg_comp_struct__14872 */

#ifndef kcg_comp_struct__14880
extern kcg_bool kcg_comp_struct__14880(
  struct__14880 *kcg_c1,
  struct__14880 *kcg_c2);
#endif /* kcg_comp_struct__14880 */

#ifndef kcg_comp_struct__14885
extern kcg_bool kcg_comp_struct__14885(
  struct__14885 *kcg_c1,
  struct__14885 *kcg_c2);
#endif /* kcg_comp_struct__14885 */

#ifndef kcg_comp_struct__14895
extern kcg_bool kcg_comp_struct__14895(
  struct__14895 *kcg_c1,
  struct__14895 *kcg_c2);
#endif /* kcg_comp_struct__14895 */

#ifndef kcg_comp_struct__14902
extern kcg_bool kcg_comp_struct__14902(
  struct__14902 *kcg_c1,
  struct__14902 *kcg_c2);
#endif /* kcg_comp_struct__14902 */

#ifndef kcg_comp_struct__14914
extern kcg_bool kcg_comp_struct__14914(
  struct__14914 *kcg_c1,
  struct__14914 *kcg_c2);
#endif /* kcg_comp_struct__14914 */

#ifndef kcg_comp_struct__14923
extern kcg_bool kcg_comp_struct__14923(
  struct__14923 *kcg_c1,
  struct__14923 *kcg_c2);
#endif /* kcg_comp_struct__14923 */

#ifndef kcg_comp_struct__14928
extern kcg_bool kcg_comp_struct__14928(
  struct__14928 *kcg_c1,
  struct__14928 *kcg_c2);
#endif /* kcg_comp_struct__14928 */

#ifndef kcg_comp_struct__14935
extern kcg_bool kcg_comp_struct__14935(
  struct__14935 *kcg_c1,
  struct__14935 *kcg_c2);
#endif /* kcg_comp_struct__14935 */

#ifndef kcg_comp_struct__14943
extern kcg_bool kcg_comp_struct__14943(
  struct__14943 *kcg_c1,
  struct__14943 *kcg_c2);
#endif /* kcg_comp_struct__14943 */

#ifndef kcg_comp_struct__14948
extern kcg_bool kcg_comp_struct__14948(
  struct__14948 *kcg_c1,
  struct__14948 *kcg_c2);
#endif /* kcg_comp_struct__14948 */

#ifndef kcg_comp_struct__14959
extern kcg_bool kcg_comp_struct__14959(
  struct__14959 *kcg_c1,
  struct__14959 *kcg_c2);
#endif /* kcg_comp_struct__14959 */

#ifndef kcg_comp_struct__14968
extern kcg_bool kcg_comp_struct__14968(
  struct__14968 *kcg_c1,
  struct__14968 *kcg_c2);
#endif /* kcg_comp_struct__14968 */

#ifndef kcg_comp_struct__14980
extern kcg_bool kcg_comp_struct__14980(
  struct__14980 *kcg_c1,
  struct__14980 *kcg_c2);
#endif /* kcg_comp_struct__14980 */

#ifndef kcg_comp_struct__14985
extern kcg_bool kcg_comp_struct__14985(
  struct__14985 *kcg_c1,
  struct__14985 *kcg_c2);
#endif /* kcg_comp_struct__14985 */

#ifndef kcg_comp_struct__15001
extern kcg_bool kcg_comp_struct__15001(
  struct__15001 *kcg_c1,
  struct__15001 *kcg_c2);
#endif /* kcg_comp_struct__15001 */

#ifndef kcg_comp_struct__15009
extern kcg_bool kcg_comp_struct__15009(
  struct__15009 *kcg_c1,
  struct__15009 *kcg_c2);
#endif /* kcg_comp_struct__15009 */

#ifndef kcg_comp_struct__15014
extern kcg_bool kcg_comp_struct__15014(
  struct__15014 *kcg_c1,
  struct__15014 *kcg_c2);
#endif /* kcg_comp_struct__15014 */

#ifndef kcg_comp_struct__15024
extern kcg_bool kcg_comp_struct__15024(
  struct__15024 *kcg_c1,
  struct__15024 *kcg_c2);
#endif /* kcg_comp_struct__15024 */

#ifndef kcg_comp_struct__15029
extern kcg_bool kcg_comp_struct__15029(
  struct__15029 *kcg_c1,
  struct__15029 *kcg_c2);
#endif /* kcg_comp_struct__15029 */

#ifndef kcg_comp_struct__15043
extern kcg_bool kcg_comp_struct__15043(
  struct__15043 *kcg_c1,
  struct__15043 *kcg_c2);
#endif /* kcg_comp_struct__15043 */

#ifndef kcg_comp_struct__15050
extern kcg_bool kcg_comp_struct__15050(
  struct__15050 *kcg_c1,
  struct__15050 *kcg_c2);
#endif /* kcg_comp_struct__15050 */

#ifndef kcg_comp_struct__15058
extern kcg_bool kcg_comp_struct__15058(
  struct__15058 *kcg_c1,
  struct__15058 *kcg_c2);
#endif /* kcg_comp_struct__15058 */

#ifndef kcg_comp_struct__15063
extern kcg_bool kcg_comp_struct__15063(
  struct__15063 *kcg_c1,
  struct__15063 *kcg_c2);
#endif /* kcg_comp_struct__15063 */

#ifndef kcg_comp_struct__15072
extern kcg_bool kcg_comp_struct__15072(
  struct__15072 *kcg_c1,
  struct__15072 *kcg_c2);
#endif /* kcg_comp_struct__15072 */

#ifndef kcg_comp_struct__15079
extern kcg_bool kcg_comp_struct__15079(
  struct__15079 *kcg_c1,
  struct__15079 *kcg_c2);
#endif /* kcg_comp_struct__15079 */

#ifndef kcg_comp_struct__15088
extern kcg_bool kcg_comp_struct__15088(
  struct__15088 *kcg_c1,
  struct__15088 *kcg_c2);
#endif /* kcg_comp_struct__15088 */

#ifndef kcg_comp_struct__15099
extern kcg_bool kcg_comp_struct__15099(
  struct__15099 *kcg_c1,
  struct__15099 *kcg_c2);
#endif /* kcg_comp_struct__15099 */

#ifndef kcg_comp_struct__15108
extern kcg_bool kcg_comp_struct__15108(
  struct__15108 *kcg_c1,
  struct__15108 *kcg_c2);
#endif /* kcg_comp_struct__15108 */

#ifndef kcg_comp_struct__15113
extern kcg_bool kcg_comp_struct__15113(
  struct__15113 *kcg_c1,
  struct__15113 *kcg_c2);
#endif /* kcg_comp_struct__15113 */

#ifndef kcg_comp_struct__15125
extern kcg_bool kcg_comp_struct__15125(
  struct__15125 *kcg_c1,
  struct__15125 *kcg_c2);
#endif /* kcg_comp_struct__15125 */

#ifndef kcg_comp_struct__15134
extern kcg_bool kcg_comp_struct__15134(
  struct__15134 *kcg_c1,
  struct__15134 *kcg_c2);
#endif /* kcg_comp_struct__15134 */

#ifndef kcg_comp_struct__15144
extern kcg_bool kcg_comp_struct__15144(
  struct__15144 *kcg_c1,
  struct__15144 *kcg_c2);
#endif /* kcg_comp_struct__15144 */

#ifndef kcg_comp_struct__15154
extern kcg_bool kcg_comp_struct__15154(
  struct__15154 *kcg_c1,
  struct__15154 *kcg_c2);
#endif /* kcg_comp_struct__15154 */

#ifndef kcg_comp_struct__15159
extern kcg_bool kcg_comp_struct__15159(
  struct__15159 *kcg_c1,
  struct__15159 *kcg_c2);
#endif /* kcg_comp_struct__15159 */

#ifndef kcg_comp_struct__15169
extern kcg_bool kcg_comp_struct__15169(
  struct__15169 *kcg_c1,
  struct__15169 *kcg_c2);
#endif /* kcg_comp_struct__15169 */

#ifndef kcg_comp_struct__15174
extern kcg_bool kcg_comp_struct__15174(
  struct__15174 *kcg_c1,
  struct__15174 *kcg_c2);
#endif /* kcg_comp_struct__15174 */

#ifndef kcg_comp_struct__15186
extern kcg_bool kcg_comp_struct__15186(
  struct__15186 *kcg_c1,
  struct__15186 *kcg_c2);
#endif /* kcg_comp_struct__15186 */

#ifndef kcg_comp_struct__15195
extern kcg_bool kcg_comp_struct__15195(
  struct__15195 *kcg_c1,
  struct__15195 *kcg_c2);
#endif /* kcg_comp_struct__15195 */

#ifndef kcg_comp_struct__15200
extern kcg_bool kcg_comp_struct__15200(
  struct__15200 *kcg_c1,
  struct__15200 *kcg_c2);
#endif /* kcg_comp_struct__15200 */

#ifndef kcg_comp_struct__15211
extern kcg_bool kcg_comp_struct__15211(
  struct__15211 *kcg_c1,
  struct__15211 *kcg_c2);
#endif /* kcg_comp_struct__15211 */

#ifndef kcg_comp_struct__15219
extern kcg_bool kcg_comp_struct__15219(
  struct__15219 *kcg_c1,
  struct__15219 *kcg_c2);
#endif /* kcg_comp_struct__15219 */

#ifndef kcg_comp_struct__15229
extern kcg_bool kcg_comp_struct__15229(
  struct__15229 *kcg_c1,
  struct__15229 *kcg_c2);
#endif /* kcg_comp_struct__15229 */

#ifndef kcg_comp_struct__15234
extern kcg_bool kcg_comp_struct__15234(
  struct__15234 *kcg_c1,
  struct__15234 *kcg_c2);
#endif /* kcg_comp_struct__15234 */

#ifndef kcg_comp_struct__15259
extern kcg_bool kcg_comp_struct__15259(
  struct__15259 *kcg_c1,
  struct__15259 *kcg_c2);
#endif /* kcg_comp_struct__15259 */

#ifndef kcg_comp_struct__15269
extern kcg_bool kcg_comp_struct__15269(
  struct__15269 *kcg_c1,
  struct__15269 *kcg_c2);
#endif /* kcg_comp_struct__15269 */

#ifndef kcg_comp_struct__15274
extern kcg_bool kcg_comp_struct__15274(
  struct__15274 *kcg_c1,
  struct__15274 *kcg_c2);
#endif /* kcg_comp_struct__15274 */

#ifndef kcg_comp_struct__15285
extern kcg_bool kcg_comp_struct__15285(
  struct__15285 *kcg_c1,
  struct__15285 *kcg_c2);
#endif /* kcg_comp_struct__15285 */

#ifndef kcg_comp_struct__15311
extern kcg_bool kcg_comp_struct__15311(
  struct__15311 *kcg_c1,
  struct__15311 *kcg_c2);
#endif /* kcg_comp_struct__15311 */

#ifndef kcg_comp_struct__15321
extern kcg_bool kcg_comp_struct__15321(
  struct__15321 *kcg_c1,
  struct__15321 *kcg_c2);
#endif /* kcg_comp_struct__15321 */

#ifndef kcg_comp_struct__15334
extern kcg_bool kcg_comp_struct__15334(
  struct__15334 *kcg_c1,
  struct__15334 *kcg_c2);
#endif /* kcg_comp_struct__15334 */

#ifndef kcg_comp_struct__15339
extern kcg_bool kcg_comp_struct__15339(
  struct__15339 *kcg_c1,
  struct__15339 *kcg_c2);
#endif /* kcg_comp_struct__15339 */

#ifndef kcg_comp_struct__15354
extern kcg_bool kcg_comp_struct__15354(
  struct__15354 *kcg_c1,
  struct__15354 *kcg_c2);
#endif /* kcg_comp_struct__15354 */

#ifndef kcg_comp_struct__15362
extern kcg_bool kcg_comp_struct__15362(
  struct__15362 *kcg_c1,
  struct__15362 *kcg_c2);
#endif /* kcg_comp_struct__15362 */

#ifndef kcg_comp_struct__15367
extern kcg_bool kcg_comp_struct__15367(
  struct__15367 *kcg_c1,
  struct__15367 *kcg_c2);
#endif /* kcg_comp_struct__15367 */

#ifndef kcg_comp_struct__15375
extern kcg_bool kcg_comp_struct__15375(
  struct__15375 *kcg_c1,
  struct__15375 *kcg_c2);
#endif /* kcg_comp_struct__15375 */

#ifndef kcg_comp_struct__15380
extern kcg_bool kcg_comp_struct__15380(
  struct__15380 *kcg_c1,
  struct__15380 *kcg_c2);
#endif /* kcg_comp_struct__15380 */

#ifndef kcg_comp_struct__15392
extern kcg_bool kcg_comp_struct__15392(
  struct__15392 *kcg_c1,
  struct__15392 *kcg_c2);
#endif /* kcg_comp_struct__15392 */

#ifndef kcg_comp_struct__15397
extern kcg_bool kcg_comp_struct__15397(
  struct__15397 *kcg_c1,
  struct__15397 *kcg_c2);
#endif /* kcg_comp_struct__15397 */

#ifndef kcg_comp_struct__15404
extern kcg_bool kcg_comp_struct__15404(
  struct__15404 *kcg_c1,
  struct__15404 *kcg_c2);
#endif /* kcg_comp_struct__15404 */

#ifndef kcg_comp_struct__15409
extern kcg_bool kcg_comp_struct__15409(
  struct__15409 *kcg_c1,
  struct__15409 *kcg_c2);
#endif /* kcg_comp_struct__15409 */

#ifndef kcg_comp_struct__15459
extern kcg_bool kcg_comp_struct__15459(
  struct__15459 *kcg_c1,
  struct__15459 *kcg_c2);
#endif /* kcg_comp_struct__15459 */

#ifndef kcg_comp_struct__15466
extern kcg_bool kcg_comp_struct__15466(
  struct__15466 *kcg_c1,
  struct__15466 *kcg_c2);
#endif /* kcg_comp_struct__15466 */

#ifndef kcg_comp_array__13875
extern kcg_bool kcg_comp_array__13875(
  array__13875 *kcg_c1,
  array__13875 *kcg_c2);
#endif /* kcg_comp_array__13875 */

#ifndef kcg_comp_array__13951
extern kcg_bool kcg_comp_array__13951(
  array__13951 *kcg_c1,
  array__13951 *kcg_c2);
#endif /* kcg_comp_array__13951 */

#ifndef kcg_comp_array__14004
extern kcg_bool kcg_comp_array__14004(
  array__14004 *kcg_c1,
  array__14004 *kcg_c2);
#endif /* kcg_comp_array__14004 */

#ifndef kcg_comp_array__14018
extern kcg_bool kcg_comp_array__14018(
  array__14018 *kcg_c1,
  array__14018 *kcg_c2);
#endif /* kcg_comp_array__14018 */

#ifndef kcg_comp_array__14034
extern kcg_bool kcg_comp_array__14034(
  array__14034 *kcg_c1,
  array__14034 *kcg_c2);
#endif /* kcg_comp_array__14034 */

#ifndef kcg_comp_array__14059
extern kcg_bool kcg_comp_array__14059(
  array__14059 *kcg_c1,
  array__14059 *kcg_c2);
#endif /* kcg_comp_array__14059 */

#ifndef kcg_comp_array__14099
extern kcg_bool kcg_comp_array__14099(
  array__14099 *kcg_c1,
  array__14099 *kcg_c2);
#endif /* kcg_comp_array__14099 */

#ifndef kcg_comp_array__14428
extern kcg_bool kcg_comp_array__14428(
  array__14428 *kcg_c1,
  array__14428 *kcg_c2);
#endif /* kcg_comp_array__14428 */

#ifndef kcg_comp_array__14441
extern kcg_bool kcg_comp_array__14441(
  array__14441 *kcg_c1,
  array__14441 *kcg_c2);
#endif /* kcg_comp_array__14441 */

#ifndef kcg_comp_array__14486
extern kcg_bool kcg_comp_array__14486(
  array__14486 *kcg_c1,
  array__14486 *kcg_c2);
#endif /* kcg_comp_array__14486 */

#ifndef kcg_comp_array__14671
extern kcg_bool kcg_comp_array__14671(
  array__14671 *kcg_c1,
  array__14671 *kcg_c2);
#endif /* kcg_comp_array__14671 */

#ifndef kcg_comp_array__14702
extern kcg_bool kcg_comp_array__14702(
  array__14702 *kcg_c1,
  array__14702 *kcg_c2);
#endif /* kcg_comp_array__14702 */

#ifndef kcg_comp_array__14792
extern kcg_bool kcg_comp_array__14792(
  array__14792 *kcg_c1,
  array__14792 *kcg_c2);
#endif /* kcg_comp_array__14792 */

#ifndef kcg_comp_array__14823
extern kcg_bool kcg_comp_array__14823(
  array__14823 *kcg_c1,
  array__14823 *kcg_c2);
#endif /* kcg_comp_array__14823 */

#ifndef kcg_comp_array__14851
extern kcg_bool kcg_comp_array__14851(
  array__14851 *kcg_c1,
  array__14851 *kcg_c2);
#endif /* kcg_comp_array__14851 */

#ifndef kcg_comp_array__14877
extern kcg_bool kcg_comp_array__14877(
  array__14877 *kcg_c1,
  array__14877 *kcg_c2);
#endif /* kcg_comp_array__14877 */

#ifndef kcg_comp_array__14920
extern kcg_bool kcg_comp_array__14920(
  array__14920 *kcg_c1,
  array__14920 *kcg_c2);
#endif /* kcg_comp_array__14920 */

#ifndef kcg_comp_array__14940
extern kcg_bool kcg_comp_array__14940(
  array__14940 *kcg_c1,
  array__14940 *kcg_c2);
#endif /* kcg_comp_array__14940 */

#ifndef kcg_comp_array__14977
extern kcg_bool kcg_comp_array__14977(
  array__14977 *kcg_c1,
  array__14977 *kcg_c2);
#endif /* kcg_comp_array__14977 */

#ifndef kcg_comp_array__15006
extern kcg_bool kcg_comp_array__15006(
  array__15006 *kcg_c1,
  array__15006 *kcg_c2);
#endif /* kcg_comp_array__15006 */

#ifndef kcg_comp_array__15021
extern kcg_bool kcg_comp_array__15021(
  array__15021 *kcg_c1,
  array__15021 *kcg_c2);
#endif /* kcg_comp_array__15021 */

#ifndef kcg_comp_array__15055
extern kcg_bool kcg_comp_array__15055(
  array__15055 *kcg_c1,
  array__15055 *kcg_c2);
#endif /* kcg_comp_array__15055 */

#ifndef kcg_comp_array__15105
extern kcg_bool kcg_comp_array__15105(
  array__15105 *kcg_c1,
  array__15105 *kcg_c2);
#endif /* kcg_comp_array__15105 */

#ifndef kcg_comp_array__15151
extern kcg_bool kcg_comp_array__15151(
  array__15151 *kcg_c1,
  array__15151 *kcg_c2);
#endif /* kcg_comp_array__15151 */

#ifndef kcg_comp_array__15166
extern kcg_bool kcg_comp_array__15166(
  array__15166 *kcg_c1,
  array__15166 *kcg_c2);
#endif /* kcg_comp_array__15166 */

#ifndef kcg_comp_array__15192
extern kcg_bool kcg_comp_array__15192(
  array__15192 *kcg_c1,
  array__15192 *kcg_c2);
#endif /* kcg_comp_array__15192 */

#ifndef kcg_comp_array__15226
extern kcg_bool kcg_comp_array__15226(
  array__15226 *kcg_c1,
  array__15226 *kcg_c2);
#endif /* kcg_comp_array__15226 */

#ifndef kcg_comp_array__15266
extern kcg_bool kcg_comp_array__15266(
  array__15266 *kcg_c1,
  array__15266 *kcg_c2);
#endif /* kcg_comp_array__15266 */

#ifndef kcg_comp_array__15331
extern kcg_bool kcg_comp_array__15331(
  array__15331 *kcg_c1,
  array__15331 *kcg_c2);
#endif /* kcg_comp_array__15331 */

#ifndef kcg_comp_array__15359
extern kcg_bool kcg_comp_array__15359(
  array__15359 *kcg_c1,
  array__15359 *kcg_c2);
#endif /* kcg_comp_array__15359 */

#ifndef kcg_comp_array__15372
extern kcg_bool kcg_comp_array__15372(
  array__15372 *kcg_c1,
  array__15372 *kcg_c2);
#endif /* kcg_comp_array__15372 */

#ifndef kcg_comp_array__15389
extern kcg_bool kcg_comp_array__15389(
  array__15389 *kcg_c1,
  array__15389 *kcg_c2);
#endif /* kcg_comp_array__15389 */

#ifndef kcg_comp_array__15401
extern kcg_bool kcg_comp_array__15401(
  array__15401 *kcg_c1,
  array__15401 *kcg_c2);
#endif /* kcg_comp_array__15401 */

#ifndef kcg_comp_array__15471
extern kcg_bool kcg_comp_array__15471(
  array__15471 *kcg_c1,
  array__15471 *kcg_c2);
#endif /* kcg_comp_array__15471 */

#ifndef kcg_comp_array__16143
extern kcg_bool kcg_comp_array__16143(
  array__16143 *kcg_c1,
  array__16143 *kcg_c2);
#endif /* kcg_comp_array__16143 */

#define kcg_comp_Telegram_T_BG_Types_Pkg kcg_comp_struct__14092

#define kcg_copy_Telegram_T_BG_Types_Pkg kcg_copy_struct__14092

#define kcg_comp_TelegramArray_T_BG_Types_Pkg kcg_comp_array__14099

#define kcg_copy_TelegramArray_T_BG_Types_Pkg kcg_copy_array__14099

#define kcg_comp_TrainToTrackStatus_T_BG_Types_Pkg kcg_comp_struct__14136

#define kcg_copy_TrainToTrackStatus_T_BG_Types_Pkg kcg_copy_struct__14136

#define kcg_comp_TelegramHeader_T_BG_Types_Pkg kcg_comp_struct__14075

#define kcg_copy_TelegramHeader_T_BG_Types_Pkg kcg_copy_struct__14075

#define kcg_comp_AdditionalInformation_T_BG_Types_Pkg kcg_comp_struct__14088

#define kcg_copy_AdditionalInformation_T_BG_Types_Pkg kcg_copy_struct__14088

#define kcg_comp_passedBG_T_BG_Types_Pkg kcg_comp_struct__13901

#define kcg_copy_passedBG_T_BG_Types_Pkg kcg_copy_struct__13901

#define kcg_comp_LinkedBGs_T_BG_Types_Pkg kcg_comp_array__13875

#define kcg_copy_LinkedBGs_T_BG_Types_Pkg kcg_copy_array__13875

#define kcg_comp_LinkedBG_T_BG_Types_Pkg kcg_comp_struct__13859

#define kcg_copy_LinkedBG_T_BG_Types_Pkg kcg_copy_struct__13859

#define kcg_comp_BG_Header_T_BG_Types_Pkg kcg_comp_struct__13878

#define kcg_copy_BG_Header_T_BG_Types_Pkg kcg_copy_struct__13878

#define kcg_comp_positionErrors_T_TrainPosition_Types_Pck kcg_comp_struct__13914

#define kcg_copy_positionErrors_T_TrainPosition_Types_Pck kcg_copy_struct__13914

#define kcg_comp_trainPositionInfo_T_TrainPosition_Types_Pck kcg_comp_struct__13940

#define kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck kcg_copy_struct__13940

#define kcg_comp_positionedBGs_T_TrainPosition_Types_Pck kcg_comp_array__13951

#define kcg_copy_positionedBGs_T_TrainPosition_Types_Pck kcg_copy_array__13951

#define kcg_comp_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck kcg_comp_array__14004

#define kcg_copy_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck kcg_copy_array__14004

#define kcg_comp_infoFromLinking_T_TrainPosition_Types_Pck kcg_comp_struct__13920

#define kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck kcg_copy_struct__13920

#define kcg_comp_positionedBG_T_TrainPosition_Types_Pck kcg_comp_struct__13929

#define kcg_copy_positionedBG_T_TrainPosition_Types_Pck kcg_copy_struct__13929

#define kcg_comp_trainPosition_T_TrainPosition_Types_Pck kcg_comp_struct__13954

#define kcg_copy_trainPosition_T_TrainPosition_Types_Pck kcg_copy_struct__13954

#define kcg_comp_trainProperties_T_TrainPosition_Types_Pck kcg_comp_struct__13971

#define kcg_copy_trainProperties_T_TrainPosition_Types_Pck kcg_copy_struct__13971

#define kcg_comp_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg kcg_comp_struct__14007

#define kcg_copy_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg kcg_copy_struct__14007

#define kcg_comp_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_array__14018

#define kcg_copy_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_array__14018

#define kcg_comp_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_struct__14012

#define kcg_copy_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_struct__14012

#define kcg_comp_BGs_forImprovement_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_struct__14144

#define kcg_copy_BGs_forImprovement_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_struct__14144

#define kcg_comp_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_comp_struct__14021

#define kcg_copy_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg kcg_copy_struct__14021

#define kcg_comp_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_comp_struct__13982

#define kcg_copy_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_copy_struct__13982

#define kcg_comp_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_comp_struct__13988

#define kcg_copy_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg kcg_copy_struct__13988

#define kcg_comp_odometry_T_Obu_BasicTypes_Pkg kcg_comp_struct__13997

#define kcg_copy_odometry_T_Obu_BasicTypes_Pkg kcg_copy_struct__13997

#define kcg_comp_OdometryLocations_T_Obu_BasicTypes_Pkg kcg_comp_struct__13889

#define kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg kcg_copy_struct__13889

#define kcg_comp_LocWithInAcc_T_Obu_BasicTypes_Pkg kcg_comp_struct__13895

#define kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg kcg_copy_struct__13895

#define kcg_comp_LutIndex_lut kcg_comp_struct__14150

#define kcg_copy_LutIndex_lut kcg_copy_struct__14150

#define kcg_comp_genPassedBGs_T_ctp_t_pck_t_engine kcg_comp_array__14034

#define kcg_copy_genPassedBGs_T_ctp_t_pck_t_engine kcg_copy_array__14034

#define kcg_comp_genPassedBG_T_ctp_t_pck_t_engine kcg_comp_struct__14029

#define kcg_copy_genPassedBG_T_ctp_t_pck_t_engine kcg_copy_struct__14029

#define kcg_comp_odometryFactors_T_ctp_t_pck_t_engine kcg_comp_struct__14037

#define kcg_copy_odometryFactors_T_ctp_t_pck_t_engine kcg_copy_struct__14037

#define kcg_comp_Assignment_of_coordinate_system_Radio_TrackToTrain kcg_comp_struct__14110

#define kcg_copy_Assignment_of_coordinate_system_Radio_TrackToTrain kcg_copy_struct__14110

#define kcg_comp_SoM_position_report_confirmed_by_RBC_Radio_TrackToTrain kcg_comp_struct__14155

#define kcg_copy_SoM_position_report_confirmed_by_RBC_Radio_TrackToTrain kcg_copy_struct__14155

#define kcg_comp_Train_Accepted_Radio_TrackToTrain kcg_comp_struct__14155

#define kcg_copy_Train_Accepted_Radio_TrackToTrain kcg_copy_struct__14155

#define kcg_comp_Train_Rejected_Radio_TrackToTrain kcg_comp_struct__14155

#define kcg_copy_Train_Rejected_Radio_TrackToTrain kcg_copy_struct__14155

#define kcg_comp_Acknowledgement_of_termination_of_a_communication_session_Radio_TrackToTrain kcg_comp_struct__14155

#define kcg_copy_Acknowledgement_of_termination_of_a_communication_session_Radio_TrackToTrain kcg_copy_struct__14155

#define kcg_comp_Initiation_of_a_communication_session_Radio_TrackToTrain kcg_comp_struct__14155

#define kcg_copy_Initiation_of_a_communication_session_Radio_TrackToTrain kcg_copy_struct__14155

#define kcg_comp_Infill_MA_Radio_TrackToTrain kcg_comp_struct__14163

#define kcg_copy_Infill_MA_Radio_TrackToTrain kcg_copy_struct__14163

#define kcg_comp_Track_Ahead_Free_Request_Radio_TrackToTrain kcg_comp_struct__14173

#define kcg_copy_Track_Ahead_Free_Request_Radio_TrackToTrain kcg_copy_struct__14173

#define kcg_comp_MA_with_Shifted_Location_Reference_Radio_TrackToTrain kcg_comp_struct__14186

#define kcg_copy_MA_with_Shifted_Location_Reference_Radio_TrackToTrain kcg_copy_struct__14186

#define kcg_comp_RBC_or_RIU_System_Version_Radio_TrackToTrain kcg_comp_struct__14198

#define kcg_copy_RBC_or_RIU_System_Version_Radio_TrackToTrain kcg_copy_struct__14198

#define kcg_comp_SH_Authorised_Radio_TrackToTrain kcg_comp_struct__14207

#define kcg_copy_SH_Authorised_Radio_TrackToTrain kcg_copy_struct__14207

#define kcg_comp_SH_Refused_Radio_TrackToTrain kcg_comp_struct__14218

#define kcg_copy_SH_Refused_Radio_TrackToTrain kcg_copy_struct__14218

#define kcg_comp_General_message_Radio_TrackToTrain kcg_comp_struct__14227

#define kcg_copy_General_message_Radio_TrackToTrain kcg_copy_struct__14227

#define kcg_comp_Revocation_of_Emergency_Stop_Radio_TrackToTrain kcg_comp_struct__14237

#define kcg_copy_Revocation_of_Emergency_Stop_Radio_TrackToTrain kcg_copy_struct__14237

#define kcg_comp_Unconditional_Emergency_Stop_Radio_TrackToTrain kcg_comp_struct__14237

#define kcg_copy_Unconditional_Emergency_Stop_Radio_TrackToTrain kcg_copy_struct__14237

#define kcg_comp_Conditional_Emergency_Stop_Radio_TrackToTrain kcg_comp_struct__14246

#define kcg_copy_Conditional_Emergency_Stop_Radio_TrackToTrain kcg_copy_struct__14246

#define kcg_comp_Request_to_Shorten_MA_Radio_TrackToTrain kcg_comp_struct__14259

#define kcg_copy_Request_to_Shorten_MA_Radio_TrackToTrain kcg_copy_struct__14259

#define kcg_comp_Acknowledgement_of_Train_Data_Radio_TrackToTrain kcg_comp_struct__14218

#define kcg_copy_Acknowledgement_of_Train_Data_Radio_TrackToTrain kcg_copy_struct__14218

#define kcg_comp_Recognition_of_exit_from_TRIP_mode_Radio_TrackToTrain kcg_comp_struct__14155

#define kcg_copy_Recognition_of_exit_from_TRIP_mode_Radio_TrackToTrain kcg_copy_struct__14155

#define kcg_comp_Movement_Authority_Radio_TrackToTrain kcg_comp_struct__14269

#define kcg_copy_Movement_Authority_Radio_TrackToTrain kcg_copy_struct__14269

#define kcg_comp_SR_Authorisation_Radio_TrackToTrain kcg_comp_struct__14279

#define kcg_copy_SR_Authorisation_Radio_TrackToTrain kcg_copy_struct__14279

#define kcg_comp_Session_Established_Radio_TrainToTrack kcg_comp_struct__14291

#define kcg_copy_Session_Established_Radio_TrainToTrack kcg_copy_struct__14291

#define kcg_comp_Text_message_acknowledged_by_driver_Radio_TrainToTrack kcg_comp_struct__14300

#define kcg_copy_Text_message_acknowledged_by_driver_Radio_TrainToTrack kcg_copy_struct__14300

#define kcg_comp_SoM_Position_Report_Radio_TrainToTrack kcg_comp_struct__14310

#define kcg_copy_SoM_Position_Report_Radio_TrainToTrack kcg_copy_struct__14310

#define kcg_comp_Termination_of_a_communication_session_Radio_TrainToTrack kcg_comp_struct__14320

#define kcg_copy_Termination_of_a_communication_session_Radio_TrainToTrack kcg_copy_struct__14320

#define kcg_comp_Initiation_of_a_communication_session_Radio_TrainToTrack kcg_comp_struct__14320

#define kcg_copy_Initiation_of_a_communication_session_Radio_TrainToTrack kcg_copy_struct__14320

#define kcg_comp_No_compatible_version_supported_Radio_TrainToTrack kcg_comp_struct__14320

#define kcg_copy_No_compatible_version_supported_Radio_TrainToTrack kcg_copy_struct__14320

#define kcg_comp_Radio_infill_request_Radio_TrainToTrack kcg_comp_struct__14327

#define kcg_copy_Radio_infill_request_Radio_TrainToTrack kcg_copy_struct__14327

#define kcg_comp_End_of_Mission_Radio_TrainToTrack kcg_comp_struct__14339

#define kcg_copy_End_of_Mission_Radio_TrainToTrack kcg_copy_struct__14339

#define kcg_comp_Track_Ahead_Free_Granted_Radio_TrainToTrack kcg_comp_struct__14348

#define kcg_copy_Track_Ahead_Free_Granted_Radio_TrainToTrack kcg_copy_struct__14348

#define kcg_comp_Acknowledgement_of_Emergency_Stop_Radio_TrainToTrack kcg_comp_struct__14357

#define kcg_copy_Acknowledgement_of_Emergency_Stop_Radio_TrainToTrack kcg_copy_struct__14357

#define kcg_comp_Acknowledgement_Radio_TrainToTrack kcg_comp_struct__14320

#define kcg_copy_Acknowledgement_Radio_TrainToTrack kcg_copy_struct__14320

#define kcg_comp_Request_to_shorten_MA_is_rejected_Radio_TrainToTrack kcg_comp_struct__14367

#define kcg_copy_Request_to_shorten_MA_is_rejected_Radio_TrainToTrack kcg_copy_struct__14367

#define kcg_comp_Request_to_shorten_MA_is_granted_Radio_TrainToTrack kcg_comp_struct__14376

#define kcg_copy_Request_to_shorten_MA_is_granted_Radio_TrainToTrack kcg_copy_struct__14376

#define kcg_comp_Train_Position_Report_Radio_TrainToTrack kcg_comp_struct__14123

#define kcg_copy_Train_Position_Report_Radio_TrainToTrack kcg_copy_struct__14123

#define kcg_comp_MA_Request_Radio_TrainToTrack kcg_comp_struct__14385

#define kcg_copy_MA_Request_Radio_TrainToTrack kcg_copy_struct__14385

#define kcg_comp_Request_for_Shunting_Radio_TrainToTrack kcg_comp_struct__14395

#define kcg_copy_Request_for_Shunting_Radio_TrainToTrack kcg_copy_struct__14395

#define kcg_comp_Validated_Train_Data_Radio_TrainToTrack kcg_comp_struct__14404

#define kcg_copy_Validated_Train_Data_Radio_TrainToTrack kcg_copy_struct__14404

#define kcg_comp_End_of_Information_BothWays kcg_comp_struct__14413

#define kcg_copy_End_of_Information_BothWays kcg_copy_struct__14413

#define kcg_comp_Data_used_by_applications_outside_the_ERTMS_or_ETCS_system_TrainToTrack kcg_comp_struct__14417

#define kcg_copy_Data_used_by_applications_outside_the_ERTMS_or_ETCS_system_TrainToTrack kcg_copy_struct__14417

#define kcg_comp_Validated_train_data_TrainToTrack kcg_comp_struct__14449

#define kcg_copy_Validated_train_data_TrainToTrack kcg_copy_struct__14449

#define kcg_comp_SVar111_TrainToTrack kcg_comp_struct__14431

#define kcg_copy_SVar111_TrainToTrack kcg_copy_struct__14431

#define kcg_comp_AVar111_TrainToTrack kcg_comp_array__14428

#define kcg_copy_AVar111_TrainToTrack kcg_copy_array__14428

#define kcg_comp_Var111_TrainToTrack kcg_comp_struct__14424

#define kcg_copy_Var111_TrainToTrack kcg_copy_struct__14424

#define kcg_comp_SVar110_TrainToTrack kcg_comp_struct__14444

#define kcg_copy_SVar110_TrainToTrack kcg_copy_struct__14444

#define kcg_comp_AVar110_TrainToTrack kcg_comp_array__14441

#define kcg_copy_AVar110_TrainToTrack kcg_copy_array__14441

#define kcg_comp_Var110_TrainToTrack kcg_comp_struct__14436

#define kcg_copy_Var110_TrainToTrack kcg_copy_struct__14436

#define kcg_comp_Level_23_transition_information_TrainToTrack kcg_comp_struct__14464

#define kcg_copy_Level_23_transition_information_TrainToTrack kcg_copy_struct__14464

#define kcg_comp_Train_running_number_TrainToTrack kcg_comp_struct__14470

#define kcg_copy_Train_running_number_TrainToTrack kcg_copy_struct__14470

#define kcg_comp_Error_reporting_TrainToTrack kcg_comp_struct__14476

#define kcg_copy_Error_reporting_TrainToTrack kcg_copy_struct__14476

#define kcg_comp_Onboard_telephone_numbers_TrainToTrack kcg_comp_struct__14494

#define kcg_copy_Onboard_telephone_numbers_TrainToTrack kcg_copy_struct__14494

#define kcg_comp_SVar30_TrainToTrack kcg_comp_struct__14489

#define kcg_copy_SVar30_TrainToTrack kcg_copy_struct__14489

#define kcg_comp_AVar30_TrainToTrack kcg_comp_array__14486

#define kcg_copy_AVar30_TrainToTrack kcg_copy_array__14486

#define kcg_comp_Var30_TrainToTrack kcg_comp_struct__14482

#define kcg_copy_Var30_TrainToTrack kcg_copy_struct__14482

#define kcg_comp_Position_Report_based_on_two_balise_groups_TrainToTrack kcg_comp_struct__14500

#define kcg_copy_Position_Report_based_on_two_balise_groups_TrainToTrack kcg_copy_struct__14500

#define kcg_comp_Position_Report_TrainToTrack kcg_comp_struct__14520

#define kcg_copy_Position_Report_TrainToTrack kcg_copy_struct__14520

#define kcg_comp_Default_balise_or_Loop_or_RIU_information_TrackToTrain kcg_comp_struct__14539

#define kcg_copy_Default_balise_or_Loop_or_RIU_information_TrackToTrain kcg_copy_struct__14539

#define kcg_comp_Inhibition_of_balise_group_message_consistency_reaction_TrackToTrain kcg_comp_struct__14539

#define kcg_copy_Inhibition_of_balise_group_message_consistency_reaction_TrackToTrain kcg_copy_struct__14539

#define kcg_comp_Session_Management_with_neighbouring_Radio_Infill_Unit_TrackToTrain kcg_comp_struct__14545

#define kcg_copy_Session_Management_with_neighbouring_Radio_Infill_Unit_TrackToTrain kcg_copy_struct__14545

#define kcg_comp_Default_Gradient_for_Temporary_Speed_Restriction_TrackToTrain kcg_comp_struct__14555

#define kcg_copy_Default_Gradient_for_Temporary_Speed_Restriction_TrackToTrain kcg_copy_struct__14555

#define kcg_comp_Train_running_number_from_RBC_TrackToTrain kcg_comp_struct__14563

#define kcg_copy_Train_running_number_from_RBC_TrackToTrain kcg_copy_struct__14563

#define kcg_comp_Reversing_supervision_information_TrackToTrain kcg_comp_struct__14570

#define kcg_copy_Reversing_supervision_information_TrackToTrain kcg_copy_struct__14570

#define kcg_comp_Reversing_area_information_TrackToTrain kcg_comp_struct__14579

#define kcg_copy_Reversing_area_information_TrackToTrain kcg_copy_struct__14579

#define kcg_comp_Stop_if_in_Staff_Responsible_TrackToTrain kcg_comp_struct__14588

#define kcg_copy_Stop_if_in_Staff_Responsible_TrackToTrain kcg_copy_struct__14588

#define kcg_comp_Infill_location_reference_TrackToTrain kcg_comp_struct__14595

#define kcg_copy_Infill_location_reference_TrackToTrain kcg_copy_struct__14595

#define kcg_comp_Stop_Shunting_on_desk_opening_TrackToTrain kcg_comp_struct__14539

#define kcg_copy_Stop_Shunting_on_desk_opening_TrackToTrain kcg_copy_struct__14539

#define kcg_comp_EOLM_Packet_TrackToTrain kcg_comp_struct__14604

#define kcg_copy_EOLM_Packet_TrackToTrain kcg_copy_struct__14604

#define kcg_comp_Radio_infill_area_information_TrackToTrain kcg_comp_struct__14616

#define kcg_copy_Radio_infill_area_information_TrackToTrain kcg_copy_struct__14616

#define kcg_comp_Danger_for_Shunting_information_TrackToTrain kcg_comp_struct__14629

#define kcg_copy_Danger_for_Shunting_information_TrackToTrain kcg_copy_struct__14629

#define kcg_comp_RBC_transition_order_TrackToTrain kcg_comp_struct__14636

#define kcg_copy_RBC_transition_order_TrackToTrain kcg_copy_struct__14636

#define kcg_comp_Track_Ahead_Free_up_to_level_23_transition_location_TrackToTrain kcg_comp_struct__14595

#define kcg_copy_Track_Ahead_Free_up_to_level_23_transition_location_TrackToTrain kcg_copy_struct__14595

#define kcg_comp_Level_Crossing_information_TrackToTrain kcg_comp_struct__14648

#define kcg_copy_Level_Crossing_information_TrackToTrain kcg_copy_struct__14648

#define kcg_comp_Mode_profile_TrackToTrain kcg_comp_struct__14679

#define kcg_copy_Mode_profile_TrackToTrain kcg_copy_struct__14679

#define kcg_comp_SVar800_TrackToTrain kcg_comp_struct__14674

#define kcg_copy_SVar800_TrackToTrain kcg_copy_struct__14674

#define kcg_comp_AVar800_TrackToTrain kcg_comp_array__14671

#define kcg_copy_AVar800_TrackToTrain kcg_copy_array__14671

#define kcg_comp_Var800_TrackToTrain kcg_comp_struct__14662

#define kcg_copy_Var800_TrackToTrain kcg_copy_struct__14662

#define kcg_comp_Geographical_Position_Information_TrackToTrain kcg_comp_struct__14710

#define kcg_copy_Geographical_Position_Information_TrackToTrain kcg_copy_struct__14710

#define kcg_comp_SVar790_TrackToTrain kcg_comp_struct__14705

#define kcg_copy_SVar790_TrackToTrain kcg_copy_struct__14705

#define kcg_comp_AVar790_TrackToTrain kcg_comp_array__14702

#define kcg_copy_AVar790_TrackToTrain kcg_copy_array__14702

#define kcg_comp_Var790_TrackToTrain kcg_comp_struct__14693

#define kcg_copy_Var790_TrackToTrain kcg_copy_struct__14693

#define kcg_comp_Packet_for_sending_fixed_text_messages_TrackToTrain kcg_comp_struct__14730

#define kcg_copy_Packet_for_sending_fixed_text_messages_TrackToTrain kcg_copy_struct__14730

#define kcg_comp_Var767_TrackToTrain kcg_comp_struct__14724

#define kcg_copy_Var767_TrackToTrain kcg_copy_struct__14724

#define kcg_comp_Packet_for_sending_plain_text_messages_TrackToTrain kcg_comp_struct__14751

#define kcg_copy_Packet_for_sending_plain_text_messages_TrackToTrain kcg_copy_struct__14751

#define kcg_comp_Var727_TrackToTrain kcg_comp_struct__14724

#define kcg_copy_Var727_TrackToTrain kcg_copy_struct__14724

#define kcg_comp_Adhesion_factor_TrackToTrain kcg_comp_struct__14773

#define kcg_copy_Adhesion_factor_TrackToTrain kcg_copy_struct__14773

#define kcg_comp_Route_Suitability_Data_TrackToTrain kcg_comp_struct__14800

#define kcg_copy_Route_Suitability_Data_TrackToTrain kcg_copy_struct__14800

#define kcg_comp_SVar700_TrackToTrain kcg_comp_struct__14795

#define kcg_copy_SVar700_TrackToTrain kcg_copy_struct__14795

#define kcg_comp_AVar700_TrackToTrain kcg_comp_array__14792

#define kcg_copy_AVar700_TrackToTrain kcg_copy_array__14792

#define kcg_comp_Var700_TrackToTrain kcg_comp_struct__14783

#define kcg_copy_Var700_TrackToTrain kcg_copy_struct__14783

#define kcg_comp_Track_Condition_Station_Platforms_TrackToTrain kcg_comp_struct__14831

#define kcg_copy_Track_Condition_Station_Platforms_TrackToTrain kcg_copy_struct__14831

#define kcg_comp_SVar690_TrackToTrain kcg_comp_struct__14826

#define kcg_copy_SVar690_TrackToTrain kcg_copy_struct__14826

#define kcg_comp_AVar690_TrackToTrain kcg_comp_array__14823

#define kcg_copy_AVar690_TrackToTrain kcg_copy_array__14823

#define kcg_comp_Var690_TrackToTrain kcg_comp_struct__14816

#define kcg_copy_Var690_TrackToTrain kcg_copy_struct__14816

#define kcg_comp_Track_Condition_TrackToTrain kcg_comp_struct__14859

#define kcg_copy_Track_Condition_TrackToTrain kcg_copy_struct__14859

#define kcg_comp_SVar680_TrackToTrain kcg_comp_struct__14854

#define kcg_copy_SVar680_TrackToTrain kcg_copy_struct__14854

#define kcg_comp_AVar680_TrackToTrain kcg_comp_array__14851

#define kcg_copy_AVar680_TrackToTrain kcg_copy_array__14851

#define kcg_comp_Var680_TrackToTrain kcg_comp_struct__14845

#define kcg_copy_Var680_TrackToTrain kcg_copy_struct__14845

#define kcg_comp_Track_Condition_Big_Metal_Masses_TrackToTrain kcg_comp_struct__14885

#define kcg_copy_Track_Condition_Big_Metal_Masses_TrackToTrain kcg_copy_struct__14885

#define kcg_comp_SVar670_TrackToTrain kcg_comp_struct__14880

#define kcg_copy_SVar670_TrackToTrain kcg_copy_struct__14880

#define kcg_comp_AVar670_TrackToTrain kcg_comp_array__14877

#define kcg_copy_AVar670_TrackToTrain kcg_copy_array__14877

#define kcg_comp_Var670_TrackToTrain kcg_comp_struct__14872

#define kcg_copy_Var670_TrackToTrain kcg_copy_struct__14872

#define kcg_comp_Temporary_Speed_Restriction_Revocation_TrackToTrain kcg_comp_struct__14895

#define kcg_copy_Temporary_Speed_Restriction_Revocation_TrackToTrain kcg_copy_struct__14895

#define kcg_comp_Temporary_Speed_Restriction_TrackToTrain kcg_comp_struct__14902

#define kcg_copy_Temporary_Speed_Restriction_TrackToTrain kcg_copy_struct__14902

#define kcg_comp_Inhibition_of_revocable_TSRs_from_balises_in_L23_TrackToTrain kcg_comp_struct__14539

#define kcg_copy_Inhibition_of_revocable_TSRs_from_balises_in_L23_TrackToTrain kcg_copy_struct__14539

#define kcg_comp_List_of_Balises_in_SR_Authority_TrackToTrain kcg_comp_struct__14928

#define kcg_copy_List_of_Balises_in_SR_Authority_TrackToTrain kcg_copy_struct__14928

#define kcg_comp_SVar630_TrackToTrain kcg_comp_struct__14923

#define kcg_copy_SVar630_TrackToTrain kcg_copy_struct__14923

#define kcg_comp_AVar630_TrackToTrain kcg_comp_array__14920

#define kcg_copy_AVar630_TrackToTrain kcg_copy_array__14920

#define kcg_comp_Var630_TrackToTrain kcg_comp_struct__14914

#define kcg_copy_Var630_TrackToTrain kcg_copy_struct__14914

#define kcg_comp_Position_Report_Parameters_TrackToTrain kcg_comp_struct__14948

#define kcg_copy_Position_Report_Parameters_TrackToTrain kcg_copy_struct__14948

#define kcg_comp_SVar580_TrackToTrain kcg_comp_struct__14943

#define kcg_copy_SVar580_TrackToTrain kcg_copy_struct__14943

#define kcg_comp_AVar580_TrackToTrain kcg_comp_array__14940

#define kcg_copy_AVar580_TrackToTrain kcg_copy_array__14940

#define kcg_comp_Var580_TrackToTrain kcg_comp_struct__14935

#define kcg_copy_Var580_TrackToTrain kcg_copy_struct__14935

#define kcg_comp_Movement_Authority_Request_Parameters_TrackToTrain kcg_comp_struct__14959

#define kcg_copy_Movement_Authority_Request_Parameters_TrackToTrain kcg_copy_struct__14959

#define kcg_comp_Permitted_Braking_Distance_Information_TrackToTrain kcg_comp_struct__14985

#define kcg_copy_Permitted_Braking_Distance_Information_TrackToTrain kcg_copy_struct__14985

#define kcg_comp_SVar520_TrackToTrain kcg_comp_struct__14980

#define kcg_copy_SVar520_TrackToTrain kcg_copy_struct__14980

#define kcg_comp_AVar520_TrackToTrain kcg_comp_array__14977

#define kcg_copy_AVar520_TrackToTrain kcg_copy_array__14977

#define kcg_comp_Var520_TrackToTrain kcg_comp_struct__14968

#define kcg_copy_Var520_TrackToTrain kcg_copy_struct__14968

#define kcg_comp_Axle_Load_Speed_Profile_TrackToTrain kcg_comp_struct__15029

#define kcg_copy_Axle_Load_Speed_Profile_TrackToTrain kcg_copy_struct__15029

#define kcg_comp_SVar512_TrackToTrain kcg_comp_struct__15009

#define kcg_copy_SVar512_TrackToTrain kcg_copy_struct__15009

#define kcg_comp_AVar512_TrackToTrain kcg_comp_array__15006

#define kcg_copy_AVar512_TrackToTrain kcg_copy_array__15006

#define kcg_comp_Var512_TrackToTrain kcg_comp_struct__15001

#define kcg_copy_Var512_TrackToTrain kcg_copy_struct__15001

#define kcg_comp_SVar511_TrackToTrain kcg_comp_struct__15024

#define kcg_copy_SVar511_TrackToTrain kcg_copy_struct__15024

#define kcg_comp_AVar511_TrackToTrain kcg_comp_array__15021

#define kcg_copy_AVar511_TrackToTrain kcg_copy_array__15021

#define kcg_comp_Var511_TrackToTrain kcg_comp_struct__15014

#define kcg_copy_Var511_TrackToTrain kcg_copy_struct__15014

#define kcg_comp_SVar510_TrackToTrain kcg_comp_struct__15009

#define kcg_copy_SVar510_TrackToTrain kcg_copy_struct__15009

#define kcg_comp_AVar510_TrackToTrain kcg_comp_array__15006

#define kcg_copy_AVar510_TrackToTrain kcg_copy_array__15006

#define kcg_comp_Var510_TrackToTrain kcg_comp_struct__15001

#define kcg_copy_Var510_TrackToTrain kcg_copy_struct__15001

#define kcg_comp_List_of_balises_for_SH_Area_TrackToTrain kcg_comp_struct__15043

#define kcg_copy_List_of_balises_for_SH_Area_TrackToTrain kcg_copy_struct__15043

#define kcg_comp_SVar490_TrackToTrain kcg_comp_struct__14923

#define kcg_copy_SVar490_TrackToTrain kcg_copy_struct__14923

#define kcg_comp_AVar490_TrackToTrain kcg_comp_array__14920

#define kcg_copy_AVar490_TrackToTrain kcg_copy_array__14920

#define kcg_comp_Var490_TrackToTrain kcg_comp_struct__14914

#define kcg_copy_Var490_TrackToTrain kcg_copy_struct__14914

#define kcg_comp_Conditional_Level_Transition_Order_TrackToTrain kcg_comp_struct__15063

#define kcg_copy_Conditional_Level_Transition_Order_TrackToTrain kcg_copy_struct__15063

#define kcg_comp_SVar460_TrackToTrain kcg_comp_struct__15058

#define kcg_copy_SVar460_TrackToTrain kcg_copy_struct__15058

#define kcg_comp_AVar460_TrackToTrain kcg_comp_array__15055

#define kcg_copy_AVar460_TrackToTrain kcg_copy_array__15055

#define kcg_comp_Var460_TrackToTrain kcg_comp_struct__15050

#define kcg_copy_Var460_TrackToTrain kcg_copy_struct__15050

#define kcg_comp_Radio_Network_registration_TrackToTrain kcg_comp_struct__15072

#define kcg_copy_Radio_Network_registration_TrackToTrain kcg_copy_struct__15072

#define kcg_comp_Data_used_by_applications_outside_the_ERTMSETCS_system_TrackToTrain kcg_comp_struct__15079

#define kcg_copy_Data_used_by_applications_outside_the_ERTMSETCS_system_TrackToTrain kcg_copy_struct__15079

#define kcg_comp_Session_Management_TrackToTrain kcg_comp_struct__15088

#define kcg_copy_Session_Management_TrackToTrain kcg_copy_struct__15088

#define kcg_comp_Level_Transition_Order_TrackToTrain kcg_comp_struct__15113

#define kcg_copy_Level_Transition_Order_TrackToTrain kcg_copy_struct__15113

#define kcg_comp_SVar410_TrackToTrain kcg_comp_struct__15108

#define kcg_copy_SVar410_TrackToTrain kcg_copy_struct__15108

#define kcg_comp_AVar410_TrackToTrain kcg_comp_array__15105

#define kcg_copy_AVar410_TrackToTrain kcg_copy_array__15105

#define kcg_comp_Var410_TrackToTrain kcg_comp_struct__15099

#define kcg_copy_Var410_TrackToTrain kcg_copy_struct__15099

#define kcg_comp_Track_Condition_Change_of_allowed_current_consumption_TrackToTrain kcg_comp_struct__15125

#define kcg_copy_Track_Condition_Change_of_allowed_current_consumption_TrackToTrain kcg_copy_struct__15125

#define kcg_comp_Track_Condition_Change_of_traction_system_TrackToTrain kcg_comp_struct__15134

#define kcg_copy_Track_Condition_Change_of_traction_system_TrackToTrain kcg_copy_struct__15134

#define kcg_comp_International_Static_Speed_Profile_TrackToTrain kcg_comp_struct__15174

#define kcg_copy_International_Static_Speed_Profile_TrackToTrain kcg_copy_struct__15174

#define kcg_comp_SVar272_TrackToTrain kcg_comp_struct__15154

#define kcg_copy_SVar272_TrackToTrain kcg_copy_struct__15154

#define kcg_comp_AVar272_TrackToTrain kcg_comp_array__15151

#define kcg_copy_AVar272_TrackToTrain kcg_copy_array__15151

#define kcg_comp_Var272_TrackToTrain kcg_comp_struct__15144

#define kcg_copy_Var272_TrackToTrain kcg_copy_struct__15144

#define kcg_comp_SVar271_TrackToTrain kcg_comp_struct__15169

#define kcg_copy_SVar271_TrackToTrain kcg_copy_struct__15169

#define kcg_comp_AVar271_TrackToTrain kcg_comp_array__15166

#define kcg_copy_AVar271_TrackToTrain kcg_copy_array__15166

#define kcg_comp_Var271_TrackToTrain kcg_comp_struct__15159

#define kcg_copy_Var271_TrackToTrain kcg_copy_struct__15159

#define kcg_comp_SVar270_TrackToTrain kcg_comp_struct__15154

#define kcg_copy_SVar270_TrackToTrain kcg_copy_struct__15154

#define kcg_comp_AVar270_TrackToTrain kcg_comp_array__15151

#define kcg_copy_AVar270_TrackToTrain kcg_copy_array__15151

#define kcg_comp_Var270_TrackToTrain kcg_comp_struct__15144

#define kcg_copy_Var270_TrackToTrain kcg_copy_struct__15144

#define kcg_comp_Gradient_Profile_TrackToTrain kcg_comp_struct__15200

#define kcg_copy_Gradient_Profile_TrackToTrain kcg_copy_struct__15200

#define kcg_comp_SVar210_TrackToTrain kcg_comp_struct__15195

#define kcg_copy_SVar210_TrackToTrain kcg_copy_struct__15195

#define kcg_comp_AVar210_TrackToTrain kcg_comp_array__15192

#define kcg_copy_AVar210_TrackToTrain kcg_copy_array__15192

#define kcg_comp_Var210_TrackToTrain kcg_comp_struct__15186

#define kcg_copy_Var210_TrackToTrain kcg_copy_struct__15186

#define kcg_comp_Repositioning_Information_TrackToTrain kcg_comp_struct__15211

#define kcg_copy_Repositioning_Information_TrackToTrain kcg_copy_struct__15211

#define kcg_comp_Level_23_Movement_Authority_TrackToTrain kcg_comp_struct__15234

#define kcg_copy_Level_23_Movement_Authority_TrackToTrain kcg_copy_struct__15234

#define kcg_comp_SVar150_TrackToTrain kcg_comp_struct__15229

#define kcg_copy_SVar150_TrackToTrain kcg_copy_struct__15229

#define kcg_comp_AVar150_TrackToTrain kcg_comp_array__15226

#define kcg_copy_AVar150_TrackToTrain kcg_copy_array__15226

#define kcg_comp_Var150_TrackToTrain kcg_comp_struct__15219

#define kcg_copy_Var150_TrackToTrain kcg_copy_struct__15219

#define kcg_comp_Staff_Responsible_distance_Information_from_loop_TrackToTrain kcg_comp_struct__15274

#define kcg_copy_Staff_Responsible_distance_Information_from_loop_TrackToTrain kcg_copy_struct__15274

#define kcg_comp_SVar130_TrackToTrain kcg_comp_struct__15269

#define kcg_copy_SVar130_TrackToTrain kcg_copy_struct__15269

#define kcg_comp_AVar130_TrackToTrain kcg_comp_array__15266

#define kcg_copy_AVar130_TrackToTrain kcg_copy_array__15266

#define kcg_comp_Var130_TrackToTrain kcg_comp_struct__15259

#define kcg_copy_Var130_TrackToTrain kcg_copy_struct__15259

#define kcg_comp_Var137_TrackToTrain kcg_comp_struct__14914

#define kcg_copy_Var137_TrackToTrain kcg_copy_struct__14914

#define kcg_comp_Level_1_Movement_Authority_TrackToTrain kcg_comp_struct__15285

#define kcg_copy_Level_1_Movement_Authority_TrackToTrain kcg_copy_struct__15285

#define kcg_comp_SVar120_TrackToTrain kcg_comp_struct__15229

#define kcg_copy_SVar120_TrackToTrain kcg_copy_struct__15229

#define kcg_comp_AVar120_TrackToTrain kcg_comp_array__15226

#define kcg_copy_AVar120_TrackToTrain kcg_copy_array__15226

#define kcg_comp_Var120_TrackToTrain kcg_comp_struct__15219

#define kcg_copy_Var120_TrackToTrain kcg_copy_struct__15219

#define kcg_comp_Virtual_Balise_Cover_order_TrackToTrain kcg_comp_struct__15311

#define kcg_copy_Virtual_Balise_Cover_order_TrackToTrain kcg_copy_struct__15311

#define kcg_comp_Linking_TrackToTrain kcg_comp_struct__15339

#define kcg_copy_Linking_TrackToTrain kcg_copy_struct__15339

#define kcg_comp_SVar50_TrackToTrain kcg_comp_struct__15334

#define kcg_copy_SVar50_TrackToTrain kcg_copy_struct__15334

#define kcg_comp_AVar50_TrackToTrain kcg_comp_array__15331

#define kcg_copy_AVar50_TrackToTrain kcg_copy_array__15331

#define kcg_comp_Var50_TrackToTrain kcg_comp_struct__15321

#define kcg_copy_Var50_TrackToTrain kcg_copy_struct__15321

#define kcg_comp_National_Values_TrackToTrain kcg_comp_struct__15409

#define kcg_copy_National_Values_TrackToTrain kcg_copy_struct__15409

#define kcg_comp_SVar34_TrackToTrain kcg_comp_struct__15362

#define kcg_copy_SVar34_TrackToTrain kcg_copy_struct__15362

#define kcg_comp_AVar34_TrackToTrain kcg_comp_array__15359

#define kcg_copy_AVar34_TrackToTrain kcg_copy_array__15359

#define kcg_comp_Var34_TrackToTrain kcg_comp_struct__15354

#define kcg_copy_Var34_TrackToTrain kcg_copy_struct__15354

#define kcg_comp_SVar33_TrackToTrain kcg_comp_struct__15375

#define kcg_copy_SVar33_TrackToTrain kcg_copy_struct__15375

#define kcg_comp_AVar33_TrackToTrain kcg_comp_array__15372

#define kcg_copy_AVar33_TrackToTrain kcg_copy_array__15372

#define kcg_comp_Var33_TrackToTrain kcg_comp_struct__15367

#define kcg_copy_Var33_TrackToTrain kcg_copy_struct__15367

#define kcg_comp_SVar32_TrackToTrain kcg_comp_struct__15392

#define kcg_copy_SVar32_TrackToTrain kcg_copy_struct__15392

#define kcg_comp_AVar32_TrackToTrain kcg_comp_array__15389

#define kcg_copy_AVar32_TrackToTrain kcg_copy_array__15389

#define kcg_comp_Var32_TrackToTrain kcg_comp_struct__15380

#define kcg_copy_Var32_TrackToTrain kcg_copy_struct__15380

#define kcg_comp_SVar31_TrackToTrain kcg_comp_struct__15375

#define kcg_copy_SVar31_TrackToTrain kcg_copy_struct__15375

#define kcg_comp_AVar31_TrackToTrain kcg_comp_array__15372

#define kcg_copy_AVar31_TrackToTrain kcg_copy_array__15372

#define kcg_comp_Var31_TrackToTrain kcg_comp_struct__15367

#define kcg_copy_Var31_TrackToTrain kcg_copy_struct__15367

#define kcg_comp_SVar30_TrackToTrain kcg_comp_struct__15404

#define kcg_copy_SVar30_TrackToTrain kcg_copy_struct__15404

#define kcg_comp_AVar30_TrackToTrain kcg_comp_array__15401

#define kcg_copy_AVar30_TrackToTrain kcg_copy_array__15401

#define kcg_comp_Var30_TrackToTrain kcg_comp_struct__15397

#define kcg_copy_Var30_TrackToTrain kcg_copy_struct__15397

#define kcg_comp_System_Version_order_TrackToTrain kcg_comp_struct__15459

#define kcg_copy_System_Version_order_TrackToTrain kcg_copy_struct__15459

#define kcg_comp_Virtual_Balise_Cover_marker_TrackToTrain kcg_comp_struct__15466

#define kcg_copy_Virtual_Balise_Cover_marker_TrackToTrain kcg_copy_struct__15466

#define kcg_comp_levelTransitionOrderCmd_T_BG_Types_Pkg kcg_comp_struct__14053

#define kcg_copy_levelTransitionOrderCmd_T_BG_Types_Pkg kcg_copy_struct__14053

#define kcg_comp_levelTransitionOrderBGMsg_T_BG_Types_Pkg kcg_comp_struct__14062

#define kcg_copy_levelTransitionOrderBGMsg_T_BG_Types_Pkg kcg_copy_struct__14062

#define kcg_comp_levelTransitionOrders_T_BG_Types_Pkg kcg_comp_array__14059

#define kcg_copy_levelTransitionOrders_T_BG_Types_Pkg kcg_copy_array__14059

#define kcg_comp_levelTransitionOrder_T_BG_Types_Pkg kcg_comp_struct__14043

#define kcg_copy_levelTransitionOrder_T_BG_Types_Pkg kcg_copy_struct__14043

#define kcg_comp_centerOfBalisePosition_T_BG_Types_Pkg kcg_comp_struct__14068

#define kcg_copy_centerOfBalisePosition_T_BG_Types_Pkg kcg_copy_struct__14068

#define kcg_comp_BG_Message_T_BG_Types_Pkg kcg_comp_struct__14102

#define kcg_copy_BG_Message_T_BG_Types_Pkg kcg_copy_struct__14102

#define kcg_comp_RBCOrientationReport_T_BG_Types_Pkg kcg_comp_struct__14119

#define kcg_copy_RBCOrientationReport_T_BG_Types_Pkg kcg_copy_struct__14119

#define kcg_comp_RBCReport_T_BG_Types_Pkg kcg_comp_struct__14132

#define kcg_copy_RBCReport_T_BG_Types_Pkg kcg_copy_struct__14132

#endif /* _KCG_TYPES_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** kcg_types.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

