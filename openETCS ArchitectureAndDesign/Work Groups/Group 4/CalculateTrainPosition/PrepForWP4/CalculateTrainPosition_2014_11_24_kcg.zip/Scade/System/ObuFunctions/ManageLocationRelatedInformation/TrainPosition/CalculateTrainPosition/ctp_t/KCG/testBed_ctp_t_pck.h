/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _testBed_ctp_t_pck_H_
#define _testBed_ctp_t_pck_H_

#include "kcg_types.h"
#include "observeBG_ctp_t_pck_t_engine.h"
#include "stimulator_ctp_t_pck_t_engine.h"
#include "calculateTrainPosition_CalculateTrainPosition_Pkg.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  trainPosition_T_TrainPosition_Types_Pck /* ctp_t_pck::testBed::trainPosition */ trainPosition;
  trainPositionInfo_T_TrainPosition_Types_Pck /* ctp_t_pck::testBed::trainPositionInfo */ trainPositionInfo;
  positionedBGs_T_TrainPosition_Types_Pck /* ctp_t_pck::testBed::BGs */ BGs;
  positionErrors_T_TrainPosition_Types_Pck /* ctp_t_pck::testBed::errors */ errors;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::pos_ideal */ pos_ideal;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::pos_min */ pos_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::pos_nom */ pos_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::pos_max */ pos_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_001_min */ locBG_001_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_001_nom */ locBG_001_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_001_max */ locBG_001_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_102_min */ locBG_102_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_102_nom */ locBG_102_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_102_max */ locBG_102_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_003_min */ locBG_003_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_003_nom */ locBG_003_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_003_max */ locBG_003_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_104_min */ locBG_104_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_104_nom */ locBG_104_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_104_max */ locBG_104_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_005_min */ locBG_005_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_005_nom */ locBG_005_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::testBed::locBG_005_max */ locBG_005_max;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::testBed::LRBG */ LRBG;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_stimulator_ctp_t_pck_t_engine /* 1 */ _1_Context_1;
  outC_calculateTrainPosition_CalculateTrainPosition_Pkg /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
} outC_testBed_ctp_t_pck;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::testBed */
extern void testBed_ctp_t_pck(outC_testBed_ctp_t_pck *outC);

extern void testBed_reset_ctp_t_pck(outC_testBed_ctp_t_pck *outC);

#endif /* _testBed_ctp_t_pck_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** testBed_ctp_t_pck.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

