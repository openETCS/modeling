/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "genOdometry_ctp_t_pck_t_engine.h"

void genOdometry_reset_ctp_t_pck_t_engine(
  outC_genOdometry_ctp_t_pck_t_engine *outC)
{
  outC->init = kcg_true;
}

/* ctp_t_pck::t_engine::genOdometry */
void genOdometry_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genOdometry::location */L_internal_Type_Obu_BasicTypes_Pkg location,
  /* ctp_t_pck::t_engine::genOdometry::time */T_internal_Type_Obu_BasicTypes_Pkg time,
  outC_genOdometry_ctp_t_pck_t_engine *outC)
{
  kcg_int tmp1;
  kcg_int tmp;
  /* ctp_t_pck::t_engine::genOdometry::_L16 */ kcg_real _L16;
  /* ctp_t_pck::t_engine::genOdometry::_L17 */ kcg_int _L17;
  /* ctp_t_pck::t_engine::genOdometry::_L28 */ kcg_int _L28;
  
  outC->odometry.valid = kcg_true;
  outC->odometry.timestamp = time;
  if (outC->init) {
    _L17 = 100;
  }
  else {
    _L17 = outC->rem_time;
  }
  _L28 = time - _L17;
  _L16 = (kcg_real) location;
  _L17 = (kcg_int) (cOdometryFactors_ctp_t_pck_t_engine.o_nominal * _L16);
  outC->odometry.odo.o_nominal = _L17;
  outC->odometry.odo.o_min = (kcg_int)
      (cOdometryFactors_ctp_t_pck_t_engine.o_min * _L16);
  outC->odometry.odo.o_max = (kcg_int)
      (cOdometryFactors_ctp_t_pck_t_engine.o_max * _L16);
  if (outC->init) {
    tmp1 = 0;
  }
  else {
    tmp1 = outC->rem__L17;
  }
  if (_L28 >= 1) {
    tmp = _L28;
  }
  else {
    tmp = 1;
  }
  outC->odometry.speed = (_L17 - tmp1) * 36 / tmp;
  outC->rem_time = time;
  outC->rem__L17 = _L17;
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** genOdometry_ctp_t_pck_t_engine.c
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

