/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:49
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** kcg_sensors.h
** Generation date: 2014-12-02T12:57:49
*************************************************************$ */

