/* ctp_t_newmapping.c */

#include <stddef.h>

#include "NewSmuTypes.h"
#include "NewSmuMapping.h"
#include "ctp_t_newtype.h"
#include "ctp_t_newmapping.h"

/* iterators */
static const MappingIterator iter_array_1;
static const MappingIterator iter_array_7;
static const MappingIterator iter_array_10;
static const MappingIterator iter_array_8;
static const MappingIterator iter_array_4;
static const MappingIterator iter_mapfold_4;
static const MappingIterator iter_mapw_8;
static const MappingIterator iter_mapfold_8;
static const MappingIterator iter_fold_8;
static const MappingIterator iter_mapwi_8;
static const MappingIterator iter_foldw_8;
static const MappingIterator iter_foldwi_8;
static const MappingIterator iter_foldw_10;
static const MappingIterator iter_array_1 = { "array", 1, 1, NULL};
static const MappingIterator iter_array_7 = { "array", 7, 7, NULL};
static const MappingIterator iter_array_10 = { "array", 10, 10, NULL};
static const MappingIterator iter_array_8 = { "array", 8, 8, NULL};
static const MappingIterator iter_array_4 = { "array", 4, 4, NULL};
static const MappingIterator iter_mapfold_4 = { "mapfold", 4, 4, NULL};
static const MappingIterator iter_mapw_8 = { "mapw", 8, 8, NULL};
static const MappingIterator iter_mapfold_8 = { "mapfold", 8, 8, NULL};
static const MappingIterator iter_fold_8 = { "fold", 8, 8, NULL};
static const MappingIterator iter_mapwi_8 = { "mapwi", 8, 8, NULL};
static const MappingIterator iter_foldw_8 = { "foldw", 8, 8, NULL};
static const MappingIterator iter_foldwi_8 = { "foldwi", 8, 8, NULL};
static const MappingIterator iter_foldw_10 = { "foldw", 10, 10, NULL};

/* clock active helper functions */
static int isActive_kcg_bool_kcg_true (void* pHandle) { return (*(kcg_bool*)pHandle == kcg_true); }
static int isActive_kcg_bool_kcg_false (void* pHandle) { return (*(kcg_bool*)pHandle == kcg_false); }
static int isActive_SSM_TR_SM1_SSM_TR_Standstill_2_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Standstill_2_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Standstill_1_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Standstill_1_SM1); }
static int isActive_SSM_ST_SM1_SSM_st_Standstill_SM1 (void* pHandle) { return (*(SSM_ST_SM1*)pHandle == SSM_st_Standstill_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Increasing_2_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Increasing_2_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Increasing_1_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Increasing_1_SM1); }
static int isActive_SSM_ST_SM1_SSM_st_Increasing_SM1 (void* pHandle) { return (*(SSM_ST_SM1*)pHandle == SSM_st_Increasing_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Decreasing_2_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Decreasing_2_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Decreasing_1_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Decreasing_1_SM1); }
static int isActive_SSM_ST_SM1_SSM_st_Decreasing_SM1 (void* pHandle) { return (*(SSM_ST_SM1*)pHandle == SSM_st_Decreasing_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Unknown_3_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Unknown_3_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Unknown_2_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Unknown_2_SM1); }
static int isActive_SSM_TR_SM1_SSM_TR_Unknown_1_SM1 (void* pHandle) { return (*(SSM_TR_SM1*)pHandle == SSM_TR_Unknown_1_SM1); }
static int isActive_SSM_ST_SM1_SSM_st_Unknown_SM1 (void* pHandle) { return (*(SSM_ST_SM1*)pHandle == SSM_st_Unknown_SM1); }

/* forward declarations */
#define MAP_DECL(ident, nb) static const MappingEntry ident##_entries[nb]; static const MappingScope ident
MAP_DECL(scope_166, 1);
MAP_DECL(scope_165, 1);
MAP_DECL(scope_164, 1);
MAP_DECL(scope_163, 1);
MAP_DECL(scope_162, 1);
MAP_DECL(scope_161, 1);
MAP_DECL(scope_160, 1);
MAP_DECL(scope_159, 1);
MAP_DECL(scope_158, 3);
MAP_DECL(scope_157, 1);
MAP_DECL(scope_156, 2);
MAP_DECL(scope_155, 2);
MAP_DECL(scope_154, 1);
MAP_DECL(scope_153, 5);
MAP_DECL(scope_152, 1);
MAP_DECL(scope_151, 3);
MAP_DECL(scope_150, 6);
MAP_DECL(scope_149, 3);
MAP_DECL(scope_148, 4);
MAP_DECL(scope_147, 8);
MAP_DECL(scope_146, 1);
MAP_DECL(scope_145, 3);
MAP_DECL(scope_144, 14);
MAP_DECL(scope_143, 8);
MAP_DECL(scope_142, 8);
MAP_DECL(scope_141, 10);
MAP_DECL(scope_140, 8);
MAP_DECL(scope_139, 1);
MAP_DECL(scope_138, 3);
MAP_DECL(scope_137, 6);
MAP_DECL(scope_136, 13);
MAP_DECL(scope_135, 3);
MAP_DECL(scope_130, 15);
MAP_DECL(scope_129, 15);
MAP_DECL(scope_128, 15);
MAP_DECL(scope_127, 16);
MAP_DECL(scope_126, 40);
MAP_DECL(scope_125, 51);
MAP_DECL(scope_124, 46);
MAP_DECL(scope_123, 29);
MAP_DECL(scope_122, 2);
MAP_DECL(scope_121, 2);
MAP_DECL(scope_120, 2);
MAP_DECL(scope_119, 3);
MAP_DECL(scope_118, 3);
MAP_DECL(scope_117, 3);
MAP_DECL(scope_116, 2);
MAP_DECL(scope_115, 2);
MAP_DECL(scope_114, 2);
MAP_DECL(scope_113, 3);
MAP_DECL(scope_112, 3);
MAP_DECL(scope_111, 3);
MAP_DECL(scope_110, 35);
MAP_DECL(scope_109, 46);
MAP_DECL(scope_108, 12);
MAP_DECL(scope_107, 12);
MAP_DECL(scope_106, 13);
MAP_DECL(scope_105, 133);
MAP_DECL(scope_104, 182);
MAP_DECL(scope_103, 12);
MAP_DECL(scope_102, 10);
MAP_DECL(scope_101, 36);
MAP_DECL(scope_100, 19);
MAP_DECL(scope_99, 17);
MAP_DECL(scope_98, 10);
MAP_DECL(scope_97, 10);
MAP_DECL(scope_96, 11);
MAP_DECL(scope_95, 28);
MAP_DECL(scope_94, 41);
MAP_DECL(scope_93, 16);
MAP_DECL(scope_92, 8);
MAP_DECL(scope_91, 19);
MAP_DECL(scope_90, 1);
MAP_DECL(scope_89, 1);
MAP_DECL(scope_88, 3);
MAP_DECL(scope_87, 1);
MAP_DECL(scope_86, 1);
MAP_DECL(scope_85, 3);
MAP_DECL(scope_84, 1);
MAP_DECL(scope_83, 1);
MAP_DECL(scope_82, 3);
MAP_DECL(scope_81, 1);
MAP_DECL(scope_80, 1);
MAP_DECL(scope_79, 1);
MAP_DECL(scope_78, 4);
MAP_DECL(scope_75, 11);
MAP_DECL(scope_74, 15);
MAP_DECL(scope_73, 9);
MAP_DECL(scope_72, 12);
MAP_DECL(scope_71, 10);
MAP_DECL(scope_70, 11);
MAP_DECL(scope_69, 8);
MAP_DECL(scope_68, 6);
MAP_DECL(scope_67, 10);
MAP_DECL(scope_66, 27);
MAP_DECL(scope_65, 11);
MAP_DECL(scope_64, 13);
MAP_DECL(scope_63, 2);
MAP_DECL(scope_62, 20);
MAP_DECL(scope_61, 3);
MAP_DECL(scope_60, 3);
MAP_DECL(scope_59, 3);
MAP_DECL(scope_58, 54);
MAP_DECL(scope_57, 16);
MAP_DECL(scope_56, 14);
MAP_DECL(scope_55, 16);
MAP_DECL(scope_54, 18);
MAP_DECL(scope_53, 14);
MAP_DECL(scope_52, 16);
MAP_DECL(scope_51, 5);
MAP_DECL(scope_50, 5);
MAP_DECL(scope_49, 30);
MAP_DECL(scope_48, 6);
MAP_DECL(scope_47, 4);
MAP_DECL(scope_46, 3);
MAP_DECL(scope_45, 2);
MAP_DECL(scope_44, 6);
MAP_DECL(scope_43, 6);
MAP_DECL(scope_42, 1);
MAP_DECL(scope_41, 3);
MAP_DECL(scope_40, 3);
MAP_DECL(scope_39, 23);
MAP_DECL(scope_38, 1);
MAP_DECL(scope_37, 1);
MAP_DECL(scope_36, 5);
MAP_DECL(scope_35, 3);
MAP_DECL(scope_34, 3);
MAP_DECL(scope_33, 1);
MAP_DECL(scope_32, 1);
MAP_DECL(scope_31, 1);
MAP_DECL(scope_30, 3);
MAP_DECL(scope_29, 3);
MAP_DECL(scope_28, 8);
MAP_DECL(scope_27, 12);
MAP_DECL(scope_26, 17);
MAP_DECL(scope_25, 10);
MAP_DECL(scope_24, 26);
MAP_DECL(scope_23, 20);
MAP_DECL(scope_22, 32);
MAP_DECL(scope_21, 17);
MAP_DECL(scope_20, 27);
MAP_DECL(scope_19, 14);
MAP_DECL(scope_18, 5);
MAP_DECL(scope_17, 29);
MAP_DECL(scope_16, 8);
MAP_DECL(scope_15, 8);
MAP_DECL(scope_14, 8);
MAP_DECL(scope_13, 8);
MAP_DECL(scope_12, 30);
MAP_DECL(scope_11, 16);
MAP_DECL(scope_10, 16);
MAP_DECL(scope_9, 3);
MAP_DECL(scope_8, 12);
MAP_DECL(scope_7, 39);
MAP_DECL(scope_6, 54);
MAP_DECL(scope_5, 37);
MAP_DECL(scope_4, 25);
MAP_DECL(scope_3, 18);
MAP_DECL(scope_2, 33);
MAP_DECL(scope_1, 76);
MAP_DECL(scope_0, 1);

/* array_int_10 */
static const MappingEntry scope_166_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_10, sizeof(kcg_int), 0, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_166 = {
  "array_int_10",
  scope_166_entries, 1,
};

/* array__5780 */
static const MappingEntry scope_165_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_8, sizeof(array__5687), 0, &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 0}
};
static const MappingScope scope_165 = {
  "array__5780",
  scope_165_entries, 1,
};

/* array__5777 */
static const MappingEntry scope_164_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_8, sizeof(struct__5690), 0, &_Type_struct__5690_Utils, NULL, NULL, &scope_147, 1, 0}
};
static const MappingScope scope_164 = {
  "array__5777",
  scope_164_entries, 1,
};

/* array_bool_8 */
static const MappingEntry scope_163_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_8, sizeof(kcg_bool), 0, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_163 = {
  "array_bool_8",
  scope_163_entries, 1,
};

/* array__5771 */
static const MappingEntry scope_162_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_1, sizeof(struct__5642), 0, &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 0}
};
static const MappingScope scope_162 = {
  "array__5771",
  scope_162_entries, 1,
};

/* array__5768 */
static const MappingEntry scope_161_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_7, sizeof(struct__5642), 0, &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 0}
};
static const MappingScope scope_161 = {
  "array__5768",
  scope_161_entries, 1,
};

/* array_int_8 */
static const MappingEntry scope_160_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_8, sizeof(kcg_int), 0, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_160 = {
  "array_int_8",
  scope_160_entries, 1,
};

/* array__5762 */
static const MappingEntry scope_159_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(struct__5690), 0, &_Type_struct__5690_Utils, NULL, NULL, &scope_147, 1, 0}
};
static const MappingScope scope_159 = {
  "array__5762",
  scope_159_entries, 1,
};

/* struct__5756 */
static const MappingEntry scope_158_entries[3] = {
  /* 0 */ { MAP_FIELD, ".o_max", NULL, sizeof(kcg_real), offsetof(struct__5756, o_max), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 2},
  /* 1 */ { MAP_FIELD, ".o_min", NULL, sizeof(kcg_real), offsetof(struct__5756, o_min), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_FIELD, ".o_nominal", NULL, sizeof(kcg_real), offsetof(struct__5756, o_nominal), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_158 = {
  "struct__5756",
  scope_158_entries, 3,
};

/* array__5753 */
static const MappingEntry scope_157_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_10, sizeof(struct__5748), 0, &_Type_struct__5748_Utils, NULL, NULL, &scope_156, 1, 0}
};
static const MappingScope scope_157 = {
  "array__5753",
  scope_157_entries, 1,
};

/* struct__5748 */
static const MappingEntry scope_156_entries[2] = {
  /* 0 */ { MAP_FIELD, ".passedBG", NULL, sizeof(struct__5629), offsetof(struct__5748, passedBG), &_Type_struct__5629_Utils, NULL, NULL, &scope_141, 1, 1},
  /* 1 */ { MAP_FIELD, ".trueLocation", NULL, sizeof(kcg_int), offsetof(struct__5748, trueLocation), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_156 = {
  "struct__5748",
  scope_156_entries, 2,
};

/* struct__5743 */
static const MappingEntry scope_155_entries[2] = {
  /* 0 */ { MAP_FIELD, ".BGs", NULL, sizeof(array__5687), offsetof(struct__5743, BGs), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 0},
  /* 1 */ { MAP_FIELD, ".overrun", NULL, sizeof(kcg_bool), offsetof(struct__5743, overrun), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1}
};
static const MappingScope scope_155 = {
  "struct__5743",
  scope_155_entries, 2,
};

/* array__5740 */
static const MappingEntry scope_154_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(struct__5642), 0, &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 0}
};
static const MappingScope scope_154 = {
  "array__5740",
  scope_154_entries, 1,
};

/* struct__5732 */
static const MappingEntry scope_153_entries[5] = {
  /* 0 */ { MAP_FIELD, ".prevLinkedBG", NULL, sizeof(struct__5642), offsetof(struct__5732, prevLinkedBG), &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 1 */ { MAP_FIELD, ".prevUnlinkedBG", NULL, sizeof(struct__5642), offsetof(struct__5732, prevUnlinkedBG), &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 2 */ { MAP_FIELD, ".recalculate", NULL, sizeof(kcg_bool), offsetof(struct__5732, recalculate), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 3 */ { MAP_FIELD, ".refBG", NULL, sizeof(struct__5642), offsetof(struct__5732, refBG), &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 4 */ { MAP_FIELD, ".sumOfBestDistances", NULL, sizeof(struct__5578), offsetof(struct__5732, sumOfBestDistances), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 4}
};
static const MappingScope scope_153 = {
  "struct__5732",
  scope_153_entries, 5,
};

/* array__5729 */
static const MappingEntry scope_152_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_8, sizeof(struct__5723), 0, &_Type_struct__5723_Utils, NULL, NULL, &scope_151, 1, 0}
};
static const MappingScope scope_152 = {
  "array__5729",
  scope_152_entries, 1,
};

/* struct__5723 */
static const MappingEntry scope_151_entries[3] = {
  /* 0 */ { MAP_FIELD, ".currentIndex", NULL, sizeof(kcg_int), offsetof(struct__5723, currentIndex), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_FIELD, ".previousLinkedBG_idx", NULL, sizeof(kcg_int), offsetof(struct__5723, previousLinkedBG_idx), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 2 */ { MAP_FIELD, ".subsequentLinkedBG_idx", NULL, sizeof(kcg_int), offsetof(struct__5723, subsequentLinkedBG_idx), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2}
};
static const MappingScope scope_151 = {
  "struct__5723",
  scope_151_entries, 3,
};

/* struct__5714 */
static const MappingEntry scope_150_entries[6] = {
  /* 0 */ { MAP_FIELD, ".linkedBGsCount", NULL, sizeof(kcg_int), offsetof(struct__5714, linkedBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_FIELD, ".passedLinkedBGsCount", NULL, sizeof(kcg_int), offsetof(struct__5714, passedLinkedBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 2 */ { MAP_FIELD, ".passedTotalBGsCount", NULL, sizeof(kcg_int), offsetof(struct__5714, passedTotalBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 3 */ { MAP_FIELD, ".passedUnlinkedBGsCount", NULL, sizeof(kcg_int), offsetof(struct__5714, passedUnlinkedBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_FIELD, ".totalBGsCount", NULL, sizeof(kcg_int), offsetof(struct__5714, totalBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 5 */ { MAP_FIELD, ".unlinkedBGsCount", NULL, sizeof(kcg_int), offsetof(struct__5714, unlinkedBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_150 = {
  "struct__5714",
  scope_150_entries, 6,
};

/* struct__5708 */
static const MappingEntry scope_149_entries[3] = {
  /* 0 */ { MAP_FIELD, ".BGFound", NULL, sizeof(kcg_bool), offsetof(struct__5708, BGFound), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 1 */ { MAP_FIELD, ".index", NULL, sizeof(kcg_int), offsetof(struct__5708, index), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 2 */ { MAP_FIELD, ".noOfFoundBGs", NULL, sizeof(kcg_int), offsetof(struct__5708, noOfFoundBGs), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1}
};
static const MappingScope scope_149 = {
  "struct__5708",
  scope_149_entries, 3,
};

/* struct__5701 */
static const MappingEntry scope_148_entries[4] = {
  /* 0 */ { MAP_FIELD, ".odo", NULL, sizeof(struct__5609), offsetof(struct__5701, odo), &_Type_struct__5609_Utils, NULL, NULL, &scope_138, 1, 2},
  /* 1 */ { MAP_FIELD, ".speed", NULL, sizeof(kcg_int), offsetof(struct__5701, speed), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 2 */ { MAP_FIELD, ".timestamp", NULL, sizeof(kcg_int), offsetof(struct__5701, timestamp), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 3 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5701, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_148 = {
  "struct__5701",
  scope_148_entries, 4,
};

/* struct__5690 */
static const MappingEntry scope_147_entries[8] = {
  /* 0 */ { MAP_FIELD, ".centerDetectionAcc_DefaultValue", NULL, sizeof(struct__5578), offsetof(struct__5690, centerDetectionAcc_DefaultValue), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 7},
  /* 1 */ { MAP_FIELD, ".d_baliseAntenna_2_frontend", NULL, sizeof(struct__5578), offsetof(struct__5690, d_baliseAntenna_2_frontend), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 2 */ { MAP_FIELD, ".d_frontend_2_rearend", NULL, sizeof(struct__5578), offsetof(struct__5690, d_frontend_2_rearend), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 4},
  /* 3 */ { MAP_FIELD, ".l_train", NULL, sizeof(kcg_int), offsetof(struct__5690, l_train), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 4 */ { MAP_FIELD, ".locationAccuracy_DefaultValue", NULL, sizeof(struct__5578), offsetof(struct__5690, locationAccuracy_DefaultValue), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 6},
  /* 5 */ { MAP_FIELD, ".locationAccuracy_NationalValue", NULL, sizeof(kcg_int), offsetof(struct__5690, locationAccuracy_NationalValue), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_FIELD, ".nid_engine", NULL, sizeof(kcg_int), offsetof(struct__5690, nid_engine), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 7 */ { MAP_FIELD, ".nid_operational", NULL, sizeof(kcg_int), offsetof(struct__5690, nid_operational), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1}
};
static const MappingScope scope_147 = {
  "struct__5690",
  scope_147_entries, 8,
};

/* array__5687 */
static const MappingEntry scope_146_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_8, sizeof(struct__5642), 0, &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 0}
};
static const MappingScope scope_146 = {
  "array__5687",
  scope_146_entries, 1,
};

/* struct__5681 */
static const MappingEntry scope_145_entries[3] = {
  /* 0 */ { MAP_FIELD, ".outOfMemSpace", NULL, sizeof(kcg_bool), offsetof(struct__5681, outOfMemSpace), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0},
  /* 1 */ { MAP_FIELD, ".passedBG_notFoundWhereExpected", NULL, sizeof(kcg_bool), offsetof(struct__5681, passedBG_notFoundWhereExpected), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_FIELD, ".positionCalculation_inconsistent", NULL, sizeof(kcg_bool), offsetof(struct__5681, positionCalculation_inconsistent), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2}
};
static const MappingScope scope_145 = {
  "struct__5681",
  scope_145_entries, 3,
};

/* struct__5664 */
static const MappingEntry scope_144_entries[14] = {
  /* 0 */ { MAP_FIELD, ".estimatedFrontEndPosition", NULL, sizeof(kcg_int), offsetof(struct__5664, estimatedFrontEndPosition), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 1 */ { MAP_FIELD, ".maxSafeFrontEndPostion", NULL, sizeof(kcg_int), offsetof(struct__5664, maxSafeFrontEndPostion), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 2 */ { MAP_FIELD, ".minSafeFrontEndPosition", NULL, sizeof(kcg_int), offsetof(struct__5664, minSafeFrontEndPosition), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 3 */ { MAP_FIELD, ".nid_LRBG", NULL, sizeof(kcg_int), offsetof(struct__5664, nid_LRBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_FIELD, ".nid_PrvLRB", NULL, sizeof(kcg_int), offsetof(struct__5664, nid_PrvLRB), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 5 */ { MAP_FIELD, ".noCoordinateSystemHasBeenAssigned", NULL, sizeof(kcg_bool), offsetof(struct__5664, noCoordinateSystemHasBeenAssigned), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 6 */ { MAP_FIELD, ".nominalOrReverseToLRBG", NULL, sizeof(Q_DLRBG), offsetof(struct__5664, nominalOrReverseToLRBG), &_Type_Q_DLRBG_Utils, NULL, NULL, NULL, 1, 10},
  /* 7 */ { MAP_FIELD, ".speed", NULL, sizeof(kcg_int), offsetof(struct__5664, speed), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 8 */ { MAP_FIELD, ".timestamp", NULL, sizeof(kcg_int), offsetof(struct__5664, timestamp), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 9 */ { MAP_FIELD, ".trainOrientationToLRBG", NULL, sizeof(Q_DIRLRBG), offsetof(struct__5664, trainOrientationToLRBG), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 11},
  /* 10 */ { MAP_FIELD, ".trainPosition", NULL, sizeof(struct__5578), offsetof(struct__5664, trainPosition), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 4},
  /* 11 */ { MAP_FIELD, ".trainPositionIsUnknown", NULL, sizeof(kcg_bool), offsetof(struct__5664, trainPositionIsUnknown), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 12 */ { MAP_FIELD, ".trainRunningDirectionToLRBG", NULL, sizeof(Q_DIRTRAIN), offsetof(struct__5664, trainRunningDirectionToLRBG), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 12},
  /* 13 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5664, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_144 = {
  "struct__5664",
  scope_144_entries, 14,
};

/* struct__5653 */
static const MappingEntry scope_143_entries[8] = {
  /* 0 */ { MAP_FIELD, ".lastPassedLinkedBG", NULL, sizeof(struct__5642), offsetof(struct__5653, lastPassedLinkedBG), &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 5},
  /* 1 */ { MAP_FIELD, ".lastPassedUnlinkedBG", NULL, sizeof(struct__5642), offsetof(struct__5653, lastPassedUnlinkedBG), &_Type_struct__5642_Utils, NULL, NULL, &scope_142, 1, 6},
  /* 2 */ { MAP_FIELD, ".speed", NULL, sizeof(kcg_int), offsetof(struct__5653, speed), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 3 */ { MAP_FIELD, ".timestamp", NULL, sizeof(kcg_int), offsetof(struct__5653, timestamp), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 4 */ { MAP_FIELD, ".trainPosition", NULL, sizeof(struct__5578), offsetof(struct__5653, trainPosition), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 2},
  /* 5 */ { MAP_FIELD, ".trainPositionDerivedFromLastLinkedBG", NULL, sizeof(struct__5578), offsetof(struct__5653, trainPositionDerivedFromLastLinkedBG), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 6 */ { MAP_FIELD, ".trainPositionDerivedFromLastUnlinkedBG", NULL, sizeof(struct__5578), offsetof(struct__5653, trainPositionDerivedFromLastUnlinkedBG), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 4},
  /* 7 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5653, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_143 = {
  "struct__5653",
  scope_143_entries, 8,
};

/* struct__5642 */
static const MappingEntry scope_142_entries[8] = {
  /* 0 */ { MAP_FIELD, ".infoFromLinking", NULL, sizeof(struct__5600), offsetof(struct__5642, infoFromLinking), &_Type_struct__5600_Utils, NULL, NULL, &scope_137, 1, 6},
  /* 1 */ { MAP_FIELD, ".infoFromPassing", NULL, sizeof(struct__5629), offsetof(struct__5642, infoFromPassing), &_Type_struct__5629_Utils, NULL, NULL, &scope_141, 1, 7},
  /* 2 */ { MAP_FIELD, ".location", NULL, sizeof(struct__5578), offsetof(struct__5642, location), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 4},
  /* 3 */ { MAP_FIELD, ".nid_bg", NULL, sizeof(kcg_int), offsetof(struct__5642, nid_bg), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 4 */ { MAP_FIELD, ".nid_c", NULL, sizeof(kcg_int), offsetof(struct__5642, nid_c), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 5 */ { MAP_FIELD, ".q_link", NULL, sizeof(Q_LINK), offsetof(struct__5642, q_link), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 3},
  /* 6 */ { MAP_FIELD, ".seqNoOnTrack", NULL, sizeof(kcg_int), offsetof(struct__5642, seqNoOnTrack), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 7 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5642, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_142 = {
  "struct__5642",
  scope_142_entries, 8,
};

/* struct__5629 */
static const MappingEntry scope_141_entries[10] = {
  /* 0 */ { MAP_FIELD, ".BG_Header", NULL, sizeof(struct__5618), offsetof(struct__5629, BG_Header), &_Type_struct__5618_Utils, NULL, NULL, &scope_140, 1, 4},
  /* 1 */ { MAP_FIELD, ".BG_centerDetectionInaccuraccuracies", NULL, sizeof(struct__5578), offsetof(struct__5629, BG_centerDetectionInaccuraccuracies), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 2 */ { MAP_FIELD, ".linkedBGs", NULL, sizeof(array__5615), offsetof(struct__5629, linkedBGs), &_Type_array__5615_Utils, NULL, NULL, &scope_139, 1, 5},
  /* 3 */ { MAP_FIELD, ".noCoordinateSystemHasBeenAssigned", NULL, sizeof(kcg_bool), offsetof(struct__5629, noCoordinateSystemHasBeenAssigned), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 4 */ { MAP_FIELD, ".odometrystamp", NULL, sizeof(struct__5609), offsetof(struct__5629, odometrystamp), &_Type_struct__5609_Utils, NULL, NULL, &scope_138, 1, 2},
  /* 5 */ { MAP_FIELD, ".passingSpeed", NULL, sizeof(kcg_int), offsetof(struct__5629, passingSpeed), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 6 */ { MAP_FIELD, ".timestamp", NULL, sizeof(kcg_int), offsetof(struct__5629, timestamp), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 7 */ { MAP_FIELD, ".trainOrientationToBG", NULL, sizeof(Q_DIRLRBG), offsetof(struct__5629, trainOrientationToBG), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 7},
  /* 8 */ { MAP_FIELD, ".trainRunningDirectionToBG", NULL, sizeof(Q_DIRTRAIN), offsetof(struct__5629, trainRunningDirectionToBG), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 8},
  /* 9 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5629, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_141 = {
  "struct__5629",
  scope_141_entries, 10,
};

/* struct__5618 */
static const MappingEntry scope_140_entries[8] = {
  /* 0 */ { MAP_FIELD, ".m_mcount", NULL, sizeof(kcg_int), offsetof(struct__5618, m_mcount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 1 */ { MAP_FIELD, ".m_version", NULL, sizeof(M_VERSION), offsetof(struct__5618, m_version), &_Type_M_VERSION_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_FIELD, ".n_total", NULL, sizeof(N_TOTAL), offsetof(struct__5618, n_total), &_Type_N_TOTAL_Utils, NULL, NULL, NULL, 1, 3},
  /* 3 */ { MAP_FIELD, ".nid_bg", NULL, sizeof(kcg_int), offsetof(struct__5618, nid_bg), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 4 */ { MAP_FIELD, ".nid_c", NULL, sizeof(kcg_int), offsetof(struct__5618, nid_c), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 5 */ { MAP_FIELD, ".q_link", NULL, sizeof(Q_LINK), offsetof(struct__5618, q_link), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 7},
  /* 6 */ { MAP_FIELD, ".q_media", NULL, sizeof(Q_MEDIA), offsetof(struct__5618, q_media), &_Type_Q_MEDIA_Utils, NULL, NULL, NULL, 1, 2},
  /* 7 */ { MAP_FIELD, ".q_updown", NULL, sizeof(Q_UPDOWN), offsetof(struct__5618, q_updown), &_Type_Q_UPDOWN_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_140 = {
  "struct__5618",
  scope_140_entries, 8,
};

/* array__5615 */
static const MappingEntry scope_139_entries[1] = {
  /* 0 */ { MAP_ARRAY, "", &iter_array_4, sizeof(struct__5584), 0, &_Type_struct__5584_Utils, NULL, NULL, &scope_136, 1, 0}
};
static const MappingScope scope_139 = {
  "array__5615",
  scope_139_entries, 1,
};

/* struct__5609 */
static const MappingEntry scope_138_entries[3] = {
  /* 0 */ { MAP_FIELD, ".o_max", NULL, sizeof(kcg_int), offsetof(struct__5609, o_max), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 1 */ { MAP_FIELD, ".o_min", NULL, sizeof(kcg_int), offsetof(struct__5609, o_min), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_FIELD, ".o_nominal", NULL, sizeof(kcg_int), offsetof(struct__5609, o_nominal), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_138 = {
  "struct__5609",
  scope_138_entries, 3,
};

/* struct__5600 */
static const MappingEntry scope_137_entries[6] = {
  /* 0 */ { MAP_FIELD, ".d_link", NULL, sizeof(struct__5578), offsetof(struct__5600, d_link), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 4},
  /* 1 */ { MAP_FIELD, ".expectedLocation", NULL, sizeof(struct__5578), offsetof(struct__5600, expectedLocation), &_Type_struct__5578_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 2 */ { MAP_FIELD, ".linkingInfo", NULL, sizeof(struct__5584), offsetof(struct__5600, linkingInfo), &_Type_struct__5584_Utils, NULL, NULL, &scope_136, 1, 5},
  /* 3 */ { MAP_FIELD, ".nid_bg_fromLinkingBG", NULL, sizeof(kcg_int), offsetof(struct__5600, nid_bg_fromLinkingBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 4 */ { MAP_FIELD, ".nid_c_fromLinkingBG", NULL, sizeof(kcg_int), offsetof(struct__5600, nid_c_fromLinkingBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 5 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5600, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_137 = {
  "struct__5600",
  scope_137_entries, 6,
};

/* struct__5584 */
static const MappingEntry scope_136_entries[13] = {
  /* 0 */ { MAP_FIELD, ".d_link", NULL, sizeof(kcg_int), offsetof(struct__5584, d_link), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 1 */ { MAP_FIELD, ".l_packet", NULL, sizeof(kcg_int), offsetof(struct__5584, l_packet), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 2 */ { MAP_FIELD, ".nid_LRBG", NULL, sizeof(kcg_int), offsetof(struct__5584, nid_LRBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 3 */ { MAP_FIELD, ".nid_bg", NULL, sizeof(kcg_int), offsetof(struct__5584, nid_bg), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 4 */ { MAP_FIELD, ".nid_c", NULL, sizeof(kcg_int), offsetof(struct__5584, nid_c), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 5 */ { MAP_FIELD, ".nid_packet", NULL, sizeof(kcg_int), offsetof(struct__5584, nid_packet), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 6 */ { MAP_FIELD, ".q_dir", NULL, sizeof(Q_DIR), offsetof(struct__5584, q_dir), &_Type_Q_DIR_Utils, NULL, NULL, NULL, 1, 3},
  /* 7 */ { MAP_FIELD, ".q_linkorientation", NULL, sizeof(Q_LINKORIENTATION), offsetof(struct__5584, q_linkorientation), &_Type_Q_LINKORIENTATION_Utils, NULL, NULL, NULL, 1, 10},
  /* 8 */ { MAP_FIELD, ".q_linkreaction", NULL, sizeof(Q_LINKREACTION), offsetof(struct__5584, q_linkreaction), &_Type_Q_LINKREACTION_Utils, NULL, NULL, NULL, 1, 11},
  /* 9 */ { MAP_FIELD, ".q_locacc", NULL, sizeof(kcg_int), offsetof(struct__5584, q_locacc), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 10 */ { MAP_FIELD, ".q_newcountry", NULL, sizeof(Q_NEWCOUNTRY), offsetof(struct__5584, q_newcountry), &_Type_Q_NEWCOUNTRY_Utils, NULL, NULL, NULL, 1, 7},
  /* 11 */ { MAP_FIELD, ".q_scale", NULL, sizeof(Q_SCALE), offsetof(struct__5584, q_scale), &_Type_Q_SCALE_Utils, NULL, NULL, NULL, 1, 5},
  /* 12 */ { MAP_FIELD, ".valid", NULL, sizeof(kcg_bool), offsetof(struct__5584, valid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_136 = {
  "struct__5584",
  scope_136_entries, 13,
};

/* struct__5578 */
static const MappingEntry scope_135_entries[3] = {
  /* 0 */ { MAP_FIELD, ".d_max", NULL, sizeof(kcg_int), offsetof(struct__5578, d_max), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 1 */ { MAP_FIELD, ".d_min", NULL, sizeof(kcg_int), offsetof(struct__5578, d_min), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_FIELD, ".nominal", NULL, sizeof(kcg_int), offsetof(struct__5578, nominal), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_135 = {
  "struct__5578",
  scope_135_entries, 3,
};

/* BasicLocationFunctions_Pkg::odoLoc_2_refLocations/ odoLoc_2_refLocations_BasicLocationFunctions_Pkg */
static const MappingEntry scope_130_entries[15] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_odo_2_Location 1", NULL, sizeof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, Context_1), NULL, NULL, NULL, &scope_92, 1, 0},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_odo_2_Location 2", NULL, sizeof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, Context_2), NULL, NULL, NULL, &scope_92, 1, 1},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 1", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_49, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L10", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L10), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 12},
  /* 5 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 6 */ { MAP_LOCAL, "_L12", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L12), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 13},
  /* 7 */ { MAP_LOCAL, "_L2", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L2), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 4},
  /* 8 */ { MAP_LOCAL, "_L3", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L3), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 5},
  /* 9 */ { MAP_LOCAL, "_L4", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L4), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 6},
  /* 10 */ { MAP_LOCAL, "_L6", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L6), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 7},
  /* 11 */ { MAP_LOCAL, "_L7", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L7), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 8},
  /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L8), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 9},
  /* 13 */ { MAP_LOCAL, "_L9", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, _L9), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 10},
  /* 14 */ { MAP_OUTPUT, "location", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg, location), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14}
};
static const MappingScope scope_130 = {
  "BasicLocationFunctions_Pkg::odoLoc_2_refLocations/ odoLoc_2_refLocations_BasicLocationFunctions_Pkg",
  scope_130_entries, 15,
};

/* BasicLocationFunctions_Pkg::scaledDLINK_2_dlink/ scaledDLINK_2_dlink_BasicLocationFunctions_Pkg */
static const MappingEntry scope_129_entries[15] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(Q_SCALE), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L1), &_Type_Q_SCALE_Utils, NULL, NULL, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L10), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 6},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L11), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 7},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L12), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L13), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_int), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L14), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 11},
  /* 7 */ { MAP_LOCAL, "_L2", NULL, sizeof(D_LINK), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L2), &_Type_D_LINK_Utils, NULL, NULL, NULL, 1, 1},
  /* 8 */ { MAP_LOCAL, "_L22", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L22), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L25), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 10 */ { MAP_LOCAL, "_L3", NULL, sizeof(Q_LOCACC), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L3), &_Type_Q_LOCACC_Utils, NULL, NULL, NULL, 1, 2},
  /* 11 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L8), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 4},
  /* 13 */ { MAP_LOCAL, "_L9", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, _L9), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 5},
  /* 14 */ { MAP_OUTPUT, "distance", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg, distance), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14}
};
static const MappingScope scope_129 = {
  "BasicLocationFunctions_Pkg::scaledDLINK_2_dlink/ scaledDLINK_2_dlink_BasicLocationFunctions_Pkg",
  scope_129_entries, 15,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_bckwd_itr/ findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_128_entries[15] = {
  /* 0 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 1 */ { MAP_LOCAL, "_L12", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L12), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 6},
  /* 2 */ { MAP_LOCAL, "_L19", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L19), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 7},
  /* 3 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L25", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L25), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L26), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L27), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 11},
  /* 7 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L28), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 8 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L5), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 9 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 10 */ { MAP_LOCAL, "_L7", NULL, sizeof(Q_LINK), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L7), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 2},
  /* 11 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 12 */ { MAP_LOCAL, "_L9", NULL, sizeof(Q_LINK), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 4},
  /* 13 */ { MAP_OUTPUT, "index_acc_out", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, index_acc_out), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 13},
  /* 14 */ { MAP_OUTPUT, "index_out", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, index_out), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 14}
};
static const MappingScope scope_128 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_bckwd_itr/ findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_128_entries, 15,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_fwd_itr/ findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_127_entries[16] = {
  /* 0 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 1 */ { MAP_LOCAL, "_L12", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L12), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 6},
  /* 2 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 3 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 5 */ { MAP_LOCAL, "_L19", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L19), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 11},
  /* 7 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L21), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L22), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L5), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 10 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 11 */ { MAP_LOCAL, "_L7", NULL, sizeof(Q_LINK), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L7), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 2},
  /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 13 */ { MAP_LOCAL, "_L9", NULL, sizeof(Q_LINK), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 4},
  /* 14 */ { MAP_OUTPUT, "index_acc", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, index_acc), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 14},
  /* 15 */ { MAP_OUTPUT, "index_out", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, index_out), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 15}
};
static const MappingScope scope_127 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_fwd_itr/ findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_127_entries, 16,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocation/ improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_126_entries[40] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::odoLoc_2_refLocations 1", NULL, sizeof(outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_130, 1, 0},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 1", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_49, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(Q_LINK), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L11), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(Q_LINK), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L12), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 12},
  /* 6 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 7 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 8 */ { MAP_LOCAL, "_L19", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L19), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 15},
  /* 9 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 10 */ { MAP_LOCAL, "_L20", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L20), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 16},
  /* 11 */ { MAP_LOCAL, "_L21", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L21), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 17},
  /* 12 */ { MAP_LOCAL, "_L23", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L23), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18},
  /* 13 */ { MAP_LOCAL, "_L24", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L24), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19},
  /* 14 */ { MAP_LOCAL, "_L25", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L25), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 20},
  /* 15 */ { MAP_LOCAL, "_L27", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L27), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 21},
  /* 16 */ { MAP_LOCAL, "_L28", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L28), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 22},
  /* 17 */ { MAP_LOCAL, "_L29", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L29), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 23},
  /* 18 */ { MAP_LOCAL, "_L3", NULL, sizeof(Q_LINK), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L3), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 4},
  /* 19 */ { MAP_LOCAL, "_L30", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L30), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 25},
  /* 20 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 21 */ { MAP_LOCAL, "_L32", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L32), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 26},
  /* 22 */ { MAP_LOCAL, "_L34", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L34), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 27},
  /* 23 */ { MAP_LOCAL, "_L35", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L35), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 28},
  /* 24 */ { MAP_LOCAL, "_L36", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L36), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 29},
  /* 25 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L37), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 26 */ { MAP_LOCAL, "_L38", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L38), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 34},
  /* 27 */ { MAP_LOCAL, "_L39", NULL, sizeof(Q_LINK), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L39), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 33},
  /* 28 */ { MAP_LOCAL, "_L4", NULL, sizeof(Q_LINK), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L4), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 5},
  /* 29 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L40), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32},
  /* 30 */ { MAP_LOCAL, "_L41", NULL, sizeof(Q_LINK), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L41), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 31},
  /* 31 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35},
  /* 32 */ { MAP_LOCAL, "_L44", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L44), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36},
  /* 33 */ { MAP_LOCAL, "_L45", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L45), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 37},
  /* 34 */ { MAP_LOCAL, "_L47", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L47), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 38},
  /* 35 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 36 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L7), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 7},
  /* 37 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 38 */ { MAP_LOCAL, "_L9", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 39 */ { MAP_OUTPUT, "unlinkedBG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg, unlinkedBG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 39}
};
static const MappingScope scope_126 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocation/ improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_126_entries, 40,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern/ recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_125_entries[51] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 50},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 1", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_26, 1, 0},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 3", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_3), NULL, NULL, NULL, &scope_26, 1, 4},
  /* 3 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 1", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _5_Context_1), NULL, NULL, NULL, &scope_49, 1, 6},
  /* 4 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 1", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_21, 1, 1},
  /* 5 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 3", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _4_Context_3), NULL, NULL, NULL, &scope_21, 1, 5},
  /* 6 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 1", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _3_Context_1), NULL, NULL, NULL, &scope_91, 1, 3},
  /* 7 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies 1", NULL, sizeof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_123, 1, 2},
  /* 8 */ { MAP_LOCAL, "_L162", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L162), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 7},
  /* 9 */ { MAP_LOCAL, "_L164", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L164), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 8},
  /* 10 */ { MAP_LOCAL, "_L165", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L165), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 11 */ { MAP_LOCAL, "_L166", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L166), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 12 */ { MAP_LOCAL, "_L168", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L168), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 13 */ { MAP_LOCAL, "_L171", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L171), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 14 */ { MAP_LOCAL, "_L172", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L172), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 15 */ { MAP_LOCAL, "_L174", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L174), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 16 */ { MAP_LOCAL, "_L175", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L175), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 15},
  /* 17 */ { MAP_LOCAL, "_L176", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L176), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 14},
  /* 18 */ { MAP_LOCAL, "_L177", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L177), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 17},
  /* 19 */ { MAP_LOCAL, "_L178", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L178), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 18},
  /* 20 */ { MAP_LOCAL, "_L179", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L179), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 19},
  /* 21 */ { MAP_LOCAL, "_L180", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L180), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 20},
  /* 22 */ { MAP_LOCAL, "_L181", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L181), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 21},
  /* 23 */ { MAP_LOCAL, "_L182", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L182), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 24 */ { MAP_LOCAL, "_L183", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L183), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 23},
  /* 25 */ { MAP_LOCAL, "_L184", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L184), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 24},
  /* 26 */ { MAP_LOCAL, "_L185", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L185), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 25},
  /* 27 */ { MAP_LOCAL, "_L186", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L186), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 26},
  /* 28 */ { MAP_LOCAL, "_L187", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L187), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 27},
  /* 29 */ { MAP_LOCAL, "_L188", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L188), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 28},
  /* 30 */ { MAP_LOCAL, "_L189", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L189), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 31 */ { MAP_LOCAL, "_L190", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L190), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 30},
  /* 32 */ { MAP_LOCAL, "_L191", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L191), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 31},
  /* 33 */ { MAP_LOCAL, "_L192", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L192), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 34},
  /* 34 */ { MAP_LOCAL, "_L193", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L193), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 33},
  /* 35 */ { MAP_LOCAL, "_L194", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L194), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 32},
  /* 36 */ { MAP_LOCAL, "_L195", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L195), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35},
  /* 37 */ { MAP_LOCAL, "_L196", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L196), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 36},
  /* 38 */ { MAP_LOCAL, "_L197", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L197), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 37},
  /* 39 */ { MAP_LOCAL, "_L198", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L198), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 38},
  /* 40 */ { MAP_LOCAL, "_L199", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L199), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 39},
  /* 41 */ { MAP_LOCAL, "_L200", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L200), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 40},
  /* 42 */ { MAP_LOCAL, "_L203", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L203), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 41},
  /* 43 */ { MAP_LOCAL, "_L204", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L204), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 42},
  /* 44 */ { MAP_LOCAL, "_L205", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L205), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 43},
  /* 45 */ { MAP_LOCAL, "_L208", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L208), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 44},
  /* 46 */ { MAP_LOCAL, "_L210", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L210), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 45},
  /* 47 */ { MAP_LOCAL, "_L211", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L211), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 47},
  /* 48 */ { MAP_LOCAL, "_L212", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L212), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 46},
  /* 49 */ { MAP_LOCAL, "_L213", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L213), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 48},
  /* 50 */ { MAP_LOCAL, "_L214", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L214), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 49}
};
static const MappingScope scope_125 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern/ recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_125_entries, 51,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_ahead/ recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_124_entries[46] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 45},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 3", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_3), NULL, NULL, NULL, &scope_26, 1, 0},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 4", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_4), NULL, NULL, NULL, &scope_26, 1, 1},
  /* 3 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 5", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_5), NULL, NULL, NULL, &scope_26, 1, 4},
  /* 4 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 6", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_6), NULL, NULL, NULL, &scope_26, 1, 5},
  /* 5 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 2", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_2), NULL, NULL, NULL, &scope_91, 1, 3},
  /* 6 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies 1", NULL, sizeof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_123, 1, 2},
  /* 7 */ { MAP_LOCAL, "_L162", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L162), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 6},
  /* 8 */ { MAP_LOCAL, "_L163", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L163), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 7},
  /* 9 */ { MAP_LOCAL, "_L164", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L164), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 8},
  /* 10 */ { MAP_LOCAL, "_L165", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L165), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 11 */ { MAP_LOCAL, "_L166", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L166), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 12 */ { MAP_LOCAL, "_L167", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L167), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 13 */ { MAP_LOCAL, "_L168", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L168), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 14 */ { MAP_LOCAL, "_L171", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L171), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 15 */ { MAP_LOCAL, "_L172", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L172), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 14},
  /* 16 */ { MAP_LOCAL, "_L174", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L174), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 17 */ { MAP_LOCAL, "_L175", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L175), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 16},
  /* 18 */ { MAP_LOCAL, "_L176", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L176), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 15},
  /* 19 */ { MAP_LOCAL, "_L177", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L177), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18},
  /* 20 */ { MAP_LOCAL, "_L178", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L178), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19},
  /* 21 */ { MAP_LOCAL, "_L179", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L179), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 20},
  /* 22 */ { MAP_LOCAL, "_L180", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L180), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 21},
  /* 23 */ { MAP_LOCAL, "_L181", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L181), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 22},
  /* 24 */ { MAP_LOCAL, "_L182", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L182), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 23},
  /* 25 */ { MAP_LOCAL, "_L183", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L183), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 24},
  /* 26 */ { MAP_LOCAL, "_L184", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L184), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 25},
  /* 27 */ { MAP_LOCAL, "_L185", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L185), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 26},
  /* 28 */ { MAP_LOCAL, "_L186", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L186), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 27},
  /* 29 */ { MAP_LOCAL, "_L187", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L187), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 28},
  /* 30 */ { MAP_LOCAL, "_L188", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L188), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 29},
  /* 31 */ { MAP_LOCAL, "_L189", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L189), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 32 */ { MAP_LOCAL, "_L190", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L190), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 31},
  /* 33 */ { MAP_LOCAL, "_L191", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L191), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 32},
  /* 34 */ { MAP_LOCAL, "_L192", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L192), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35},
  /* 35 */ { MAP_LOCAL, "_L193", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L193), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 34},
  /* 36 */ { MAP_LOCAL, "_L194", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L194), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 33},
  /* 37 */ { MAP_LOCAL, "_L195", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L195), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36},
  /* 38 */ { MAP_LOCAL, "_L196", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L196), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 37},
  /* 39 */ { MAP_LOCAL, "_L197", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L197), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 38},
  /* 40 */ { MAP_LOCAL, "_L198", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L198), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 39},
  /* 41 */ { MAP_LOCAL, "_L199", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L199), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 40},
  /* 42 */ { MAP_LOCAL, "_L200", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L200), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 41},
  /* 43 */ { MAP_LOCAL, "_L203", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L203), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 42},
  /* 44 */ { MAP_LOCAL, "_L204", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L204), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 43},
  /* 45 */ { MAP_LOCAL, "_L205", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L205), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 44}
};
static const MappingScope scope_124 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_ahead/ recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_124_entries, 46,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies/ calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_123_entries[29] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 5", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_5), NULL, NULL, NULL, &scope_26, 1, 2},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::scaledDLINK_2_dlink 3", NULL, sizeof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_3), NULL, NULL, NULL, &scope_129, 1, 0},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::scaledDLINK_2_dlink 4", NULL, sizeof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_4), NULL, NULL, NULL, &scope_129, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 4},
  /* 4 */ { MAP_LOCAL, "_L10", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L10), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 12},
  /* 5 */ { MAP_LOCAL, "_L11", NULL, sizeof(Q_NVLOCACC), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L11), &_Type_Q_NVLOCACC_Utils, NULL, NULL, NULL, 1, 13},
  /* 6 */ { MAP_LOCAL, "_L12", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L12), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14},
  /* 7 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L13), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15},
  /* 8 */ { MAP_LOCAL, "_L14", NULL, sizeof(Q_SCALE), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L14), &_Type_Q_SCALE_Utils, NULL, NULL, NULL, 1, 16},
  /* 9 */ { MAP_LOCAL, "_L15", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L15), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 17},
  /* 10 */ { MAP_LOCAL, "_L16", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L16), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18},
  /* 11 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_bool), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L17), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19},
  /* 12 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 20},
  /* 13 */ { MAP_LOCAL, "_L19", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L19), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 21},
  /* 14 */ { MAP_LOCAL, "_L2", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 3},
  /* 15 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 16 */ { MAP_LOCAL, "_L21", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L21), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 23},
  /* 17 */ { MAP_LOCAL, "_L23", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L23), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 24},
  /* 18 */ { MAP_LOCAL, "_L24", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L24), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 25},
  /* 19 */ { MAP_LOCAL, "_L25", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L25), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 26},
  /* 20 */ { MAP_LOCAL, "_L26", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L26), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 27},
  /* 21 */ { MAP_LOCAL, "_L3", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L3), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 5},
  /* 22 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 23 */ { MAP_LOCAL, "_L5", NULL, sizeof(Q_SCALE), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L5), &_Type_Q_SCALE_Utils, NULL, NULL, NULL, 1, 7},
  /* 24 */ { MAP_LOCAL, "_L6", NULL, sizeof(LinkedBG_T_BG_Types_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L6), &_Type_LinkedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_136, 1, 8},
  /* 25 */ { MAP_LOCAL, "_L7", NULL, sizeof(Q_LOCACC), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L7), &_Type_Q_LOCACC_Utils, NULL, NULL, NULL, 1, 9},
  /* 26 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 27 */ { MAP_LOCAL, "_L9", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 11},
  /* 28 */ { MAP_OUTPUT, "localInaccuracies", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg, localInaccuracies), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 28}
};
static const MappingScope scope_123 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies/ calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_123_entries, 29,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:then: */
static const MappingEntry scope_122_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_118_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2_IfBlock1), &_Type_kcg_bool_Utils, &scope_118_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1}
};
static const MappingScope scope_122 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:then:",
  scope_122_entries, 2,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:then: */
static const MappingEntry scope_121_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21_IfBlock1), &_Type_kcg_bool_Utils, &scope_119_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L3", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_119_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 1}
};
static const MappingScope scope_121 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:then:",
  scope_121_entries, 2,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:else: */
static const MappingEntry scope_120_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_119_entries[0], isActive_kcg_bool_kcg_false, &scope_142, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22_IfBlock1), &_Type_kcg_bool_Utils, &scope_119_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1}
};
static const MappingScope scope_120 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:else:",
  scope_120_entries, 2,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else: */
static const MappingEntry scope_119_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, else_clock_IfBlock1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_119_entries[0], isActive_kcg_bool_kcg_false, &scope_120, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_119_entries[0], isActive_kcg_bool_kcg_true, &scope_121, 1, 2}
};
static const MappingScope scope_119 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:",
  scope_119_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1: */
static const MappingEntry scope_118_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_118_entries[0], isActive_kcg_bool_kcg_false, &scope_119, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_118_entries[0], isActive_kcg_bool_kcg_true, &scope_122, 1, 2}
};
static const MappingScope scope_118 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:",
  scope_118_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_117_entries[3] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 1 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_118, 1, 0},
  /* 2 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1}
};
static const MappingScope scope_117 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_117_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:then: */
static const MappingEntry scope_116_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_112_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2_IfBlock1), &_Type_kcg_bool_Utils, &scope_112_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1}
};
static const MappingScope scope_116 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:then:",
  scope_116_entries, 2,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:then: */
static const MappingEntry scope_115_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_113_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21_IfBlock1), &_Type_kcg_bool_Utils, &scope_113_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1}
};
static const MappingScope scope_115 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:then:",
  scope_115_entries, 2,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:else: */
static const MappingEntry scope_114_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_113_entries[0], isActive_kcg_bool_kcg_false, &scope_142, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23_IfBlock1), &_Type_kcg_bool_Utils, &scope_113_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1}
};
static const MappingScope scope_114 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:else:",
  scope_114_entries, 2,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else: */
static const MappingEntry scope_113_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, else_clock_IfBlock1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_113_entries[0], isActive_kcg_bool_kcg_false, &scope_114, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_113_entries[0], isActive_kcg_bool_kcg_true, &scope_115, 1, 2}
};
static const MappingScope scope_113 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:",
  scope_113_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1: */
static const MappingEntry scope_112_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_112_entries[0], isActive_kcg_bool_kcg_false, &scope_113, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_112_entries[0], isActive_kcg_bool_kcg_true, &scope_116, 1, 2}
};
static const MappingScope scope_112 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:",
  scope_112_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_111_entries[3] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 1 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_112, 1, 0},
  /* 2 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1}
};
static const MappingScope scope_111 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_111_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack_itr/ indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_110_entries[35] = {
  /* 0 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 1 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 2 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 3 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L19", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L21", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 8},
  /* 6 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 7 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L24), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 8 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L26), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 10 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 11 */ { MAP_LOCAL, "_L28", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L28), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 15},
  /* 12 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L29), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 13 */ { MAP_LOCAL, "_L30", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L30), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 17},
  /* 14 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18},
  /* 15 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L32), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 19},
  /* 16 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L33), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 20},
  /* 17 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L34), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21},
  /* 18 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 19 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L37), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 23},
  /* 20 */ { MAP_LOCAL, "_L38", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L38), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 21 */ { MAP_LOCAL, "_L39", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L39), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25},
  /* 22 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L40), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26},
  /* 23 */ { MAP_LOCAL, "_L41", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L41), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 27},
  /* 24 */ { MAP_LOCAL, "_L42", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L42), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 28},
  /* 25 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 26 */ { MAP_LOCAL, "_L44", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L44), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 27 */ { MAP_LOCAL, "_L45", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L45), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31},
  /* 28 */ { MAP_LOCAL, "_L46", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L46), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 32},
  /* 29 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 30 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 31 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33},
  /* 32 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 34},
  /* 33 */ { MAP_LOCAL, "invalidateIndex", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, invalidateIndex), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 34 */ { MAP_LOCAL, "stopIteration", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, stopIteration), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0}
};
static const MappingScope scope_110 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack_itr/ indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_110_entries, 35,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs_itr/ positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_109_entries[46] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 1", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_26, 1, 1},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 2", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _1_Context_2), NULL, NULL, NULL, &scope_26, 1, 3},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 3", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_3), NULL, NULL, NULL, &scope_26, 1, 4},
  /* 3 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 4", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_4), NULL, NULL, NULL, &scope_26, 1, 5},
  /* 4 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::scaledDLINK_2_dlink 1", NULL, sizeof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_129, 1, 0},
  /* 5 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::scaledDLINK_2_dlink 2", NULL, sizeof(outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_2), NULL, NULL, NULL, &scope_129, 1, 2},
  /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L104", NULL, sizeof(Q_LOCACC), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L104), &_Type_Q_LOCACC_Utils, NULL, NULL, NULL, 1, 35},
  /* 8 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 9 */ { MAP_LOCAL, "_L113", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L113), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 36},
  /* 10 */ { MAP_LOCAL, "_L114", NULL, sizeof(kcg_int), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L114), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 37},
  /* 11 */ { MAP_LOCAL, "_L117", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L117), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 38},
  /* 12 */ { MAP_LOCAL, "_L119", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L119), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 39},
  /* 13 */ { MAP_LOCAL, "_L12", NULL, sizeof(NID_C), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 14},
  /* 14 */ { MAP_LOCAL, "_L120", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L120), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 40},
  /* 15 */ { MAP_LOCAL, "_L121", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L121), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 41},
  /* 16 */ { MAP_LOCAL, "_L122", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L122), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 42},
  /* 17 */ { MAP_LOCAL, "_L123", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L123), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 43},
  /* 18 */ { MAP_LOCAL, "_L13", NULL, sizeof(NID_BG), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 13},
  /* 19 */ { MAP_LOCAL, "_L14", NULL, sizeof(Q_LINK), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 12},
  /* 20 */ { MAP_LOCAL, "_L15", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 11},
  /* 21 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 22 */ { MAP_LOCAL, "_L17", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 9},
  /* 23 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 7},
  /* 24 */ { MAP_LOCAL, "_L3", NULL, sizeof(LinkedBG_T_BG_Types_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_LinkedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_136, 1, 8},
  /* 25 */ { MAP_LOCAL, "_L32", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L32), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 16},
  /* 26 */ { MAP_LOCAL, "_L65", NULL, sizeof(kcg_bool), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L65), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28},
  /* 27 */ { MAP_LOCAL, "_L66", NULL, sizeof(NID_LRBG), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L66), &_Type_NID_LRBG_Utils, NULL, NULL, NULL, 1, 27},
  /* 28 */ { MAP_LOCAL, "_L67", NULL, sizeof(NID_PACKET), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L67), &_Type_NID_PACKET_Utils, NULL, NULL, NULL, 1, 26},
  /* 29 */ { MAP_LOCAL, "_L68", NULL, sizeof(Q_DIR), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L68), &_Type_Q_DIR_Utils, NULL, NULL, NULL, 1, 25},
  /* 30 */ { MAP_LOCAL, "_L69", NULL, sizeof(L_PACKET), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L69), &_Type_L_PACKET_Utils, NULL, NULL, NULL, 1, 24},
  /* 31 */ { MAP_LOCAL, "_L70", NULL, sizeof(Q_SCALE), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L70), &_Type_Q_SCALE_Utils, NULL, NULL, NULL, 1, 23},
  /* 32 */ { MAP_LOCAL, "_L71", NULL, sizeof(D_LINK), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L71), &_Type_D_LINK_Utils, NULL, NULL, NULL, 1, 22},
  /* 33 */ { MAP_LOCAL, "_L72", NULL, sizeof(Q_NEWCOUNTRY), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L72), &_Type_Q_NEWCOUNTRY_Utils, NULL, NULL, NULL, 1, 21},
  /* 34 */ { MAP_LOCAL, "_L73", NULL, sizeof(NID_C), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L73), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 20},
  /* 35 */ { MAP_LOCAL, "_L74", NULL, sizeof(NID_BG), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L74), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 19},
  /* 36 */ { MAP_LOCAL, "_L75", NULL, sizeof(Q_LINKORIENTATION), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L75), &_Type_Q_LINKORIENTATION_Utils, NULL, NULL, NULL, 1, 18},
  /* 37 */ { MAP_LOCAL, "_L76", NULL, sizeof(Q_LINKREACTION), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L76), &_Type_Q_LINKREACTION_Utils, NULL, NULL, NULL, 1, 17},
  /* 38 */ { MAP_LOCAL, "_L84", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L84), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 29},
  /* 39 */ { MAP_LOCAL, "_L85", NULL, sizeof(kcg_bool), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L85), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 40 */ { MAP_LOCAL, "_L86", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L86), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 31},
  /* 41 */ { MAP_LOCAL, "_L87", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L87), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 32},
  /* 42 */ { MAP_LOCAL, "_L89", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L89), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 33},
  /* 43 */ { MAP_LOCAL, "_L90", NULL, sizeof(LinkedBG_T_BG_Types_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L90), &_Type_LinkedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_136, 1, 34},
  /* 44 */ { MAP_OUTPUT, "linkedPositionedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, linkedPositionedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 45},
  /* 45 */ { MAP_OUTPUT, "sumOfLinkingDistances", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, sumOfLinkingDistances), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 44}
};
static const MappingScope scope_109 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs_itr/ positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_109_entries, 46,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal/ positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_108_entries[12] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal 1", NULL, sizeof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_69, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(NID_C), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 4},
  /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(NID_BG), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 5},
  /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(NID_C), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 6},
  /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(NID_BG), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 7},
  /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 11 */ { MAP_OUTPUT, "idsEqual", NULL, sizeof(kcg_bool), offsetof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, idsEqual), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11}
};
static const MappingScope scope_108 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal/ positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_108_entries, 12,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBGs/ findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_107_entries[12] = {
  /* 0 */ { MAP_OUTPUT, "BGs_indices", NULL, sizeof(linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGs_indices), &_Type_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_152, 1, 11},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_bckwd_itr 1", &iter_mapfold_8, sizeof(outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_128, 1, 1},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_fwd_itr 1", &iter_mapfold_8, sizeof(outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_127, 1, 0},
  /* 3 */ { MAP_LOCAL, "_L23", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L23), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L24", NULL, sizeof(array__5729), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L24), &_Type_array__5729_Utils, NULL, NULL, &scope_152, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L25", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L25), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 4},
  /* 6 */ { MAP_LOCAL, "_L26", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L26), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 5},
  /* 7 */ { MAP_LOCAL, "_L28", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L28), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 7},
  /* 8 */ { MAP_LOCAL, "_L29", NULL, sizeof(array__5729), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L29), &_Type_array__5729_Utils, NULL, NULL, &scope_152, 1, 6},
  /* 9 */ { MAP_LOCAL, "_L30", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L30), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 8},
  /* 10 */ { MAP_LOCAL, "_L31", NULL, sizeof(array__5729), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L31), &_Type_array__5729_Utils, NULL, NULL, &scope_152, 1, 9},
  /* 11 */ { MAP_LOCAL, "_L32", NULL, sizeof(array__5729), offsetof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L32), &_Type_array__5729_Utils, NULL, NULL, &scope_152, 1, 10}
};
static const MappingScope scope_107 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBGs/ findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_107_entries, 12,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations_itr/ improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_106_entries[13] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocation 1", NULL, sizeof(outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_126, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L10), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L15", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L15), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 8},
  /* 5 */ { MAP_LOCAL, "_L16", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L16), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 6 */ { MAP_LOCAL, "_L17", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L17), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 7 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 8 */ { MAP_LOCAL, "_L4", NULL, sizeof(linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L4), &_Type_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_151, 1, 3},
  /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 11 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 12 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11}
};
static const MappingScope scope_106 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations_itr/ improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_106_entries, 13,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern_itr/ recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_105_entries[133] = {
  /* 0 */ { MAP_LOCAL, "@kcg13", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, tmp), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 130},
  /* 1 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 132},
  /* 2 */ { MAP_LOCAL, "BGin_is_refBG", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGin_is_refBG), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 3 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 1", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_21, 1, 2},
  /* 4 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 2", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _3_Context_2), NULL, NULL, NULL, &scope_21, 1, 4},
  /* 5 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 3", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_3), NULL, NULL, NULL, &scope_21, 1, 6},
  /* 6 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 1", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_91, 1, 3},
  /* 7 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 2", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_2), NULL, NULL, NULL, &scope_91, 1, 5},
  /* 8 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern 1", NULL, sizeof(outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _4_Context_1), NULL, &scope_105_entries[0], isActive_kcg_bool_kcg_true, &scope_125, 1, 1},
  /* 9 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal 1", NULL, sizeof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_108, 1, 0},
  /* 10 */ { MAP_LOCAL, "_L105", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L105), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 27},
  /* 11 */ { MAP_LOCAL, "_L106", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L106), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 28},
  /* 12 */ { MAP_LOCAL, "_L107", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L107), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 29},
  /* 13 */ { MAP_LOCAL, "_L108", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L108), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 30},
  /* 14 */ { MAP_LOCAL, "_L109", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L109), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31},
  /* 15 */ { MAP_LOCAL, "_L110", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L110), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 32},
  /* 16 */ { MAP_LOCAL, "_L111", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L111), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 33},
  /* 17 */ { MAP_LOCAL, "_L112", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L112), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 35},
  /* 18 */ { MAP_LOCAL, "_L113", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L113), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 34},
  /* 19 */ { MAP_LOCAL, "_L114", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L114), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 51},
  /* 20 */ { MAP_LOCAL, "_L115", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L115), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 50},
  /* 21 */ { MAP_LOCAL, "_L116", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L116), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 49},
  /* 22 */ { MAP_LOCAL, "_L117", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L117), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 48},
  /* 23 */ { MAP_LOCAL, "_L119", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L119), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 47},
  /* 24 */ { MAP_LOCAL, "_L120", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L120), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 46},
  /* 25 */ { MAP_LOCAL, "_L121", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L121), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 45},
  /* 26 */ { MAP_LOCAL, "_L136", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L136), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 44},
  /* 27 */ { MAP_LOCAL, "_L137", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L137), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 43},
  /* 28 */ { MAP_LOCAL, "_L138", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L138), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 42},
  /* 29 */ { MAP_LOCAL, "_L139", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L139), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 41},
  /* 30 */ { MAP_LOCAL, "_L140", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L140), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 40},
  /* 31 */ { MAP_LOCAL, "_L141", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L141), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 39},
  /* 32 */ { MAP_LOCAL, "_L142", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L142), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 38},
  /* 33 */ { MAP_LOCAL, "_L143", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L143), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 37},
  /* 34 */ { MAP_LOCAL, "_L144", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L144), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 36},
  /* 35 */ { MAP_LOCAL, "_L147", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L147), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 52},
  /* 36 */ { MAP_LOCAL, "_L148", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L148), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 53},
  /* 37 */ { MAP_LOCAL, "_L149", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L149), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 54},
  /* 38 */ { MAP_LOCAL, "_L150", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L150), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 55},
  /* 39 */ { MAP_LOCAL, "_L152", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L152), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 56},
  /* 40 */ { MAP_LOCAL, "_L153", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L153), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 57},
  /* 41 */ { MAP_LOCAL, "_L154", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L154), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 58},
  /* 42 */ { MAP_LOCAL, "_L155", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L155), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 59},
  /* 43 */ { MAP_LOCAL, "_L156", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L156), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 60},
  /* 44 */ { MAP_LOCAL, "_L157", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L157), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 61},
  /* 45 */ { MAP_LOCAL, "_L158", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L158), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 62},
  /* 46 */ { MAP_LOCAL, "_L159", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L159), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 63},
  /* 47 */ { MAP_LOCAL, "_L160", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L160), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 64},
  /* 48 */ { MAP_LOCAL, "_L161", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L161), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 65},
  /* 49 */ { MAP_LOCAL, "_L162", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L162), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 66},
  /* 50 */ { MAP_LOCAL, "_L172", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L172), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 67},
  /* 51 */ { MAP_LOCAL, "_L173", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L173), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 68},
  /* 52 */ { MAP_LOCAL, "_L174", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L174), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 69},
  /* 53 */ { MAP_LOCAL, "_L175", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L175), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 70},
  /* 54 */ { MAP_LOCAL, "_L181", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L181), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 71},
  /* 55 */ { MAP_LOCAL, "_L182", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L182), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 72},
  /* 56 */ { MAP_LOCAL, "_L183", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L183), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 73},
  /* 57 */ { MAP_LOCAL, "_L184", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L184), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 74},
  /* 58 */ { MAP_LOCAL, "_L185", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L185), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 77},
  /* 59 */ { MAP_LOCAL, "_L186", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L186), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 76},
  /* 60 */ { MAP_LOCAL, "_L187", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L187), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 75},
  /* 61 */ { MAP_LOCAL, "_L190", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L190), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 78},
  /* 62 */ { MAP_LOCAL, "_L193", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L193), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 79},
  /* 63 */ { MAP_LOCAL, "_L194", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L194), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 80},
  /* 64 */ { MAP_LOCAL, "_L195", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L195), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 81},
  /* 65 */ { MAP_LOCAL, "_L196", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L196), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 82},
  /* 66 */ { MAP_LOCAL, "_L197", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L197), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 83},
  /* 67 */ { MAP_LOCAL, "_L198", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L198), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 84},
  /* 68 */ { MAP_LOCAL, "_L199", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L199), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 85},
  /* 69 */ { MAP_LOCAL, "_L203", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L203), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 86},
  /* 70 */ { MAP_LOCAL, "_L204", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L204), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 87},
  /* 71 */ { MAP_LOCAL, "_L205", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L205), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 88},
  /* 72 */ { MAP_LOCAL, "_L206", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L206), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 89},
  /* 73 */ { MAP_LOCAL, "_L207", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L207), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 90},
  /* 74 */ { MAP_LOCAL, "_L208", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L208), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 92},
  /* 75 */ { MAP_LOCAL, "_L209", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L209), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 91},
  /* 76 */ { MAP_LOCAL, "_L210", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L210), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 93},
  /* 77 */ { MAP_LOCAL, "_L213", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L213), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 94},
  /* 78 */ { MAP_LOCAL, "_L214", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L214), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 95},
  /* 79 */ { MAP_LOCAL, "_L215", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L215), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 96},
  /* 80 */ { MAP_LOCAL, "_L216", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L216), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 97},
  /* 81 */ { MAP_LOCAL, "_L217", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L217), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 98},
  /* 82 */ { MAP_LOCAL, "_L218", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L218), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 99},
  /* 83 */ { MAP_LOCAL, "_L219", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L219), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 101},
  /* 84 */ { MAP_LOCAL, "_L220", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L220), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 100},
  /* 85 */ { MAP_LOCAL, "_L221", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L221), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 102},
  /* 86 */ { MAP_LOCAL, "_L222", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L222), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 105},
  /* 87 */ { MAP_LOCAL, "_L223", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L223), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 104},
  /* 88 */ { MAP_LOCAL, "_L224", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L224), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 103},
  /* 89 */ { MAP_LOCAL, "_L225", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L225), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 107},
  /* 90 */ { MAP_LOCAL, "_L226", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L226), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 106},
  /* 91 */ { MAP_LOCAL, "_L227", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L227), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 110},
  /* 92 */ { MAP_LOCAL, "_L228", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L228), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 109},
  /* 93 */ { MAP_LOCAL, "_L229", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L229), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 108},
  /* 94 */ { MAP_LOCAL, "_L230", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L230), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 111},
  /* 95 */ { MAP_LOCAL, "_L231", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L231), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 112},
  /* 96 */ { MAP_LOCAL, "_L232", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L232), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 113},
  /* 97 */ { MAP_LOCAL, "_L233", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L233), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 114},
  /* 98 */ { MAP_LOCAL, "_L234", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L234), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 116},
  /* 99 */ { MAP_LOCAL, "_L235", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L235), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 115},
  /* 100 */ { MAP_LOCAL, "_L236", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L236), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 117},
  /* 101 */ { MAP_LOCAL, "_L240", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L240), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 120},
  /* 102 */ { MAP_LOCAL, "_L241", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L241), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 119},
  /* 103 */ { MAP_LOCAL, "_L242", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L242), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 118},
  /* 104 */ { MAP_LOCAL, "_L243", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L243), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 121},
  /* 105 */ { MAP_LOCAL, "_L244", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L244), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 122},
  /* 106 */ { MAP_LOCAL, "_L245", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L245), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 123},
  /* 107 */ { MAP_LOCAL, "_L246", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L246), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 124},
  /* 108 */ { MAP_LOCAL, "_L247", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L247), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 125},
  /* 109 */ { MAP_LOCAL, "_L248", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L248), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 126},
  /* 110 */ { MAP_LOCAL, "_L249", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L249), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 127},
  /* 111 */ { MAP_LOCAL, "_L250", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L250), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 128},
  /* 112 */ { MAP_LOCAL, "_L251", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L251), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 129},
  /* 113 */ { MAP_LOCAL, "_L36", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L36), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 14},
  /* 114 */ { MAP_LOCAL, "_L64", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L64), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 18},
  /* 115 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L67), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 116 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L69), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 117 */ { MAP_LOCAL, "_L71", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L71), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 15},
  /* 118 */ { MAP_LOCAL, "_L74", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L74), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19},
  /* 119 */ { MAP_LOCAL, "_L77", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L77), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 120 */ { MAP_LOCAL, "_L78", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L78), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 21},
  /* 121 */ { MAP_LOCAL, "_L80", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L80), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 122 */ { MAP_LOCAL, "_L81", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L81), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 23},
  /* 123 */ { MAP_LOCAL, "_L83", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L83), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 124 */ { MAP_LOCAL, "_L84", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L84), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25},
  /* 125 */ { MAP_LOCAL, "_L85", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L85), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 26},
  /* 126 */ { MAP_LOCAL, "prevLinkedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, prevLinkedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 127 */ { MAP_LOCAL, "prevUnlinkedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, prevUnlinkedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 11},
  /* 128 */ { MAP_LOCAL, "recalculateSubsequentBGs", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, recalculateSubsequentBGs), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 129 */ { MAP_LOCAL, "refBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, refBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 130 */ { MAP_OUTPUT, "refBGs_out", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, refBGs_out), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 131},
  /* 131 */ { MAP_LOCAL, "relocatedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, relocatedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 132 */ { MAP_LOCAL, "sumOfBestDistances", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, sumOfBestDistances), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 13}
};
static const MappingScope scope_105 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern_itr/ recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_105_entries, 133,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead_itr/ recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_104_entries[182] = {
  /* 0 */ { MAP_LOCAL, "@kcg12", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, tmp), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 179},
  /* 1 */ { MAP_LOCAL, "BG_loc_inacc", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BG_loc_inacc), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 22},
  /* 2 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 181},
  /* 3 */ { MAP_LOCAL, "BGin_is_refBG", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGin_is_refBG), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 4 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 12", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_12), NULL, NULL, NULL, &scope_26, 1, 13},
  /* 5 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 6", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_6), NULL, NULL, NULL, &scope_26, 1, 5},
  /* 6 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 7", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_7), NULL, NULL, NULL, &scope_26, 1, 7},
  /* 7 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 8", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_8), NULL, NULL, NULL, &scope_26, 1, 9},
  /* 8 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 9", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_9), NULL, NULL, NULL, &scope_26, 1, 12},
  /* 9 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 1", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_49, 1, 14},
  /* 10 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 2", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _5_Context_2), NULL, NULL, NULL, &scope_21, 1, 2},
  /* 11 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 3", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _4_Context_3), NULL, NULL, NULL, &scope_21, 1, 3},
  /* 12 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 4", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_4), NULL, NULL, NULL, &scope_21, 1, 10},
  /* 13 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 2", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_2), NULL, NULL, NULL, &scope_91, 1, 1},
  /* 14 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 3", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _2_Context_3), NULL, NULL, NULL, &scope_91, 1, 4},
  /* 15 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 4", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_4), NULL, NULL, NULL, &scope_91, 1, 8},
  /* 16 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies", NULL, sizeof(outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_calculateLocalBGInaccuracies), NULL, NULL, NULL, &scope_123, 1, 6},
  /* 17 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_ahead 1", NULL, sizeof(outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _3_Context_1), NULL, &scope_104_entries[0], isActive_kcg_bool_kcg_true, &scope_124, 1, 11},
  /* 18 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal 3", NULL, sizeof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_3), NULL, NULL, NULL, &scope_108, 1, 0},
  /* 19 */ { MAP_LOCAL, "_L105", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L105), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 57},
  /* 20 */ { MAP_LOCAL, "_L106", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L106), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 58},
  /* 21 */ { MAP_LOCAL, "_L107", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L107), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 59},
  /* 22 */ { MAP_LOCAL, "_L108", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L108), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 60},
  /* 23 */ { MAP_LOCAL, "_L109", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L109), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 61},
  /* 24 */ { MAP_LOCAL, "_L110", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L110), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 62},
  /* 25 */ { MAP_LOCAL, "_L111", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L111), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 63},
  /* 26 */ { MAP_LOCAL, "_L112", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L112), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 65},
  /* 27 */ { MAP_LOCAL, "_L113", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L113), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 64},
  /* 28 */ { MAP_LOCAL, "_L114", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L114), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 95},
  /* 29 */ { MAP_LOCAL, "_L115", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L115), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 94},
  /* 30 */ { MAP_LOCAL, "_L116", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L116), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 93},
  /* 31 */ { MAP_LOCAL, "_L117", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L117), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 92},
  /* 32 */ { MAP_LOCAL, "_L118", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L118), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 91},
  /* 33 */ { MAP_LOCAL, "_L119", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L119), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 90},
  /* 34 */ { MAP_LOCAL, "_L120", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L120), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 89},
  /* 35 */ { MAP_LOCAL, "_L121", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L121), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 88},
  /* 36 */ { MAP_LOCAL, "_L122", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L122), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 87},
  /* 37 */ { MAP_LOCAL, "_L123", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L123), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 86},
  /* 38 */ { MAP_LOCAL, "_L124", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L124), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 85},
  /* 39 */ { MAP_LOCAL, "_L125", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L125), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 84},
  /* 40 */ { MAP_LOCAL, "_L126", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L126), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 83},
  /* 41 */ { MAP_LOCAL, "_L127", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L127), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 82},
  /* 42 */ { MAP_LOCAL, "_L128", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L128), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 81},
  /* 43 */ { MAP_LOCAL, "_L129", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L129), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 80},
  /* 44 */ { MAP_LOCAL, "_L130", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L130), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 79},
  /* 45 */ { MAP_LOCAL, "_L131", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L131), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 78},
  /* 46 */ { MAP_LOCAL, "_L132", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L132), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 77},
  /* 47 */ { MAP_LOCAL, "_L133", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L133), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 76},
  /* 48 */ { MAP_LOCAL, "_L134", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L134), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 75},
  /* 49 */ { MAP_LOCAL, "_L136", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L136), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 74},
  /* 50 */ { MAP_LOCAL, "_L137", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L137), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 73},
  /* 51 */ { MAP_LOCAL, "_L138", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L138), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 72},
  /* 52 */ { MAP_LOCAL, "_L139", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L139), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 71},
  /* 53 */ { MAP_LOCAL, "_L140", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L140), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 70},
  /* 54 */ { MAP_LOCAL, "_L141", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L141), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 69},
  /* 55 */ { MAP_LOCAL, "_L142", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L142), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 68},
  /* 56 */ { MAP_LOCAL, "_L143", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L143), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 67},
  /* 57 */ { MAP_LOCAL, "_L144", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L144), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 66},
  /* 58 */ { MAP_LOCAL, "_L147", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L147), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 120},
  /* 59 */ { MAP_LOCAL, "_L148", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L148), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 96},
  /* 60 */ { MAP_LOCAL, "_L149", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L149), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 97},
  /* 61 */ { MAP_LOCAL, "_L152", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L152), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 98},
  /* 62 */ { MAP_LOCAL, "_L154", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L154), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 99},
  /* 63 */ { MAP_LOCAL, "_L155", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L155), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 100},
  /* 64 */ { MAP_LOCAL, "_L156", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L156), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 101},
  /* 65 */ { MAP_LOCAL, "_L157", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L157), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 102},
  /* 66 */ { MAP_LOCAL, "_L158", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L158), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 103},
  /* 67 */ { MAP_LOCAL, "_L159", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L159), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 104},
  /* 68 */ { MAP_LOCAL, "_L160", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L160), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 105},
  /* 69 */ { MAP_LOCAL, "_L161", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L161), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 106},
  /* 70 */ { MAP_LOCAL, "_L162", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L162), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 107},
  /* 71 */ { MAP_LOCAL, "_L163", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L163), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 108},
  /* 72 */ { MAP_LOCAL, "_L164", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L164), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 109},
  /* 73 */ { MAP_LOCAL, "_L165", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L165), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 110},
  /* 74 */ { MAP_LOCAL, "_L167", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L167), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 111},
  /* 75 */ { MAP_LOCAL, "_L168", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L168), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 112},
  /* 76 */ { MAP_LOCAL, "_L169", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L169), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 113},
  /* 77 */ { MAP_LOCAL, "_L172", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L172), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 114},
  /* 78 */ { MAP_LOCAL, "_L173", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L173), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 115},
  /* 79 */ { MAP_LOCAL, "_L174", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L174), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 116},
  /* 80 */ { MAP_LOCAL, "_L175", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L175), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 117},
  /* 81 */ { MAP_LOCAL, "_L188", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L188), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 121},
  /* 82 */ { MAP_LOCAL, "_L197", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L197), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 122},
  /* 83 */ { MAP_LOCAL, "_L216", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L216), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 123},
  /* 84 */ { MAP_LOCAL, "_L217", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L217), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 124},
  /* 85 */ { MAP_LOCAL, "_L218", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L218), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 125},
  /* 86 */ { MAP_LOCAL, "_L219", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L219), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 126},
  /* 87 */ { MAP_LOCAL, "_L220", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L220), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 127},
  /* 88 */ { MAP_LOCAL, "_L229", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L229), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 128},
  /* 89 */ { MAP_LOCAL, "_L230", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L230), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 129},
  /* 90 */ { MAP_LOCAL, "_L236", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L236), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 130},
  /* 91 */ { MAP_LOCAL, "_L237", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L237), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 134},
  /* 92 */ { MAP_LOCAL, "_L238", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L238), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 133},
  /* 93 */ { MAP_LOCAL, "_L239", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L239), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 132},
  /* 94 */ { MAP_LOCAL, "_L240", NULL, sizeof(Q_LINK), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L240), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 131},
  /* 95 */ { MAP_LOCAL, "_L243", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L243), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 135},
  /* 96 */ { MAP_LOCAL, "_L244", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L244), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 136},
  /* 97 */ { MAP_LOCAL, "_L253", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L253), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 137},
  /* 98 */ { MAP_LOCAL, "_L254", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L254), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 138},
  /* 99 */ { MAP_LOCAL, "_L255", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L255), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 139},
  /* 100 */ { MAP_LOCAL, "_L256", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L256), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 140},
  /* 101 */ { MAP_LOCAL, "_L257", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L257), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 141},
  /* 102 */ { MAP_LOCAL, "_L258", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L258), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 142},
  /* 103 */ { MAP_LOCAL, "_L259", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L259), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 143},
  /* 104 */ { MAP_LOCAL, "_L260", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L260), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 144},
  /* 105 */ { MAP_LOCAL, "_L265", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L265), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 145},
  /* 106 */ { MAP_LOCAL, "_L267", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L267), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 146},
  /* 107 */ { MAP_LOCAL, "_L268", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L268), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 147},
  /* 108 */ { MAP_LOCAL, "_L269", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L269), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 148},
  /* 109 */ { MAP_LOCAL, "_L270", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L270), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 149},
  /* 110 */ { MAP_LOCAL, "_L271", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L271), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 150},
  /* 111 */ { MAP_LOCAL, "_L273", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L273), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 151},
  /* 112 */ { MAP_LOCAL, "_L274", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L274), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 152},
  /* 113 */ { MAP_LOCAL, "_L275", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L275), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 153},
  /* 114 */ { MAP_LOCAL, "_L276", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L276), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 154},
  /* 115 */ { MAP_LOCAL, "_L277", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L277), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 155},
  /* 116 */ { MAP_LOCAL, "_L278", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L278), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 156},
  /* 117 */ { MAP_LOCAL, "_L279", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L279), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 157},
  /* 118 */ { MAP_LOCAL, "_L280", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L280), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 158},
  /* 119 */ { MAP_LOCAL, "_L281", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L281), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 159},
  /* 120 */ { MAP_LOCAL, "_L282", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L282), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 160},
  /* 121 */ { MAP_LOCAL, "_L285", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L285), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 161},
  /* 122 */ { MAP_LOCAL, "_L286", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L286), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 162},
  /* 123 */ { MAP_LOCAL, "_L287", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L287), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 163},
  /* 124 */ { MAP_LOCAL, "_L288", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L288), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 164},
  /* 125 */ { MAP_LOCAL, "_L289", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L289), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 165},
  /* 126 */ { MAP_LOCAL, "_L290", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L290), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 166},
  /* 127 */ { MAP_LOCAL, "_L291", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L291), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 167},
  /* 128 */ { MAP_LOCAL, "_L292", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L292), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 168},
  /* 129 */ { MAP_LOCAL, "_L293", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L293), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 169},
  /* 130 */ { MAP_LOCAL, "_L294", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L294), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 170},
  /* 131 */ { MAP_LOCAL, "_L296", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L296), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 171},
  /* 132 */ { MAP_LOCAL, "_L297", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L297), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 172},
  /* 133 */ { MAP_LOCAL, "_L300", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L300), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 173},
  /* 134 */ { MAP_LOCAL, "_L301", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L301), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 174},
  /* 135 */ { MAP_LOCAL, "_L302", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L302), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 176},
  /* 136 */ { MAP_LOCAL, "_L303", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L303), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 175},
  /* 137 */ { MAP_LOCAL, "_L304", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L304), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 177},
  /* 138 */ { MAP_LOCAL, "_L305", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L305), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 178},
  /* 139 */ { MAP_LOCAL, "_L36", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L36), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 25},
  /* 140 */ { MAP_LOCAL, "_L51", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L51), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 28},
  /* 141 */ { MAP_LOCAL, "_L52", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L52), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 27},
  /* 142 */ { MAP_LOCAL, "_L59", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L59), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 26},
  /* 143 */ { MAP_LOCAL, "_L61", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L61), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 144 */ { MAP_LOCAL, "_L62", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L62), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 118},
  /* 145 */ { MAP_LOCAL, "_L64", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L64), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 33},
  /* 146 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L67), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32},
  /* 147 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L69), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31},
  /* 148 */ { MAP_LOCAL, "_L71", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L71), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 30},
  /* 149 */ { MAP_LOCAL, "_L74", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L74), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 119},
  /* 150 */ { MAP_LOCAL, "_L75", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L75), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 34},
  /* 151 */ { MAP_LOCAL, "_L76", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L76), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 35},
  /* 152 */ { MAP_LOCAL, "_L77", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L77), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36},
  /* 153 */ { MAP_LOCAL, "_L78", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L78), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 37},
  /* 154 */ { MAP_LOCAL, "_L80", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L80), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 38},
  /* 155 */ { MAP_LOCAL, "_L81", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L81), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 39},
  /* 156 */ { MAP_LOCAL, "_L82", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L82), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 40},
  /* 157 */ { MAP_LOCAL, "_L83", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L83), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 41},
  /* 158 */ { MAP_LOCAL, "_L84", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L84), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 42},
  /* 159 */ { MAP_LOCAL, "_L85", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L85), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 43},
  /* 160 */ { MAP_LOCAL, "_L86", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L86), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 44},
  /* 161 */ { MAP_LOCAL, "_L87", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L87), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 45},
  /* 162 */ { MAP_LOCAL, "_L88", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L88), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 46},
  /* 163 */ { MAP_LOCAL, "_L89", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L89), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 47},
  /* 164 */ { MAP_LOCAL, "_L90", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L90), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 48},
  /* 165 */ { MAP_LOCAL, "_L92", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L92), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 49},
  /* 166 */ { MAP_LOCAL, "_L93", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L93), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 50},
  /* 167 */ { MAP_LOCAL, "_L94", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L94), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 51},
  /* 168 */ { MAP_LOCAL, "_L95", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L95), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 52},
  /* 169 */ { MAP_LOCAL, "_L96", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L96), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 53},
  /* 170 */ { MAP_LOCAL, "_L97", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L97), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 54},
  /* 171 */ { MAP_LOCAL, "_L98", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L98), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 55},
  /* 172 */ { MAP_LOCAL, "_L99", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L99), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 56},
  /* 173 */ { MAP_LOCAL, "d_prevLinkedBG_refBG", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, d_prevLinkedBG_refBG), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 24},
  /* 174 */ { MAP_LOCAL, "prevLinkedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, prevLinkedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19},
  /* 175 */ { MAP_LOCAL, "prevUnlinkedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, prevUnlinkedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 20},
  /* 176 */ { MAP_LOCAL, "recalculateSubsequentBGs", NULL, sizeof(kcg_bool), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, recalculateSubsequentBGs), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 177 */ { MAP_LOCAL, "refBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, refBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 18},
  /* 178 */ { MAP_OUTPUT, "refBGs_out", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, refBGs_out), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 180},
  /* 179 */ { MAP_LOCAL, "refLocation", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, refLocation), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 17},
  /* 180 */ { MAP_LOCAL, "relocatedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, relocatedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 21},
  /* 181 */ { MAP_LOCAL, "sumOfBestDistances", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg, sumOfBestDistances), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 23}
};
static const MappingScope scope_104 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead_itr/ recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_104_entries, 182,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack_itr/ trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_103_entries[12] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 11},
  /* 1 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 2 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 3 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L16", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 6 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 7 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 11 */ { MAP_OUTPUT, "seqNo", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, seqNo), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10}
};
static const MappingScope scope_103 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack_itr/ trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_103_entries, 12,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack_itr/ mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_102_entries[10] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, NULL, NULL, &scope_155, 1, 9},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack 1", NULL, sizeof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_66, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 4},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 5 */ { MAP_LOCAL, "_L14", NULL, sizeof(positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, NULL, NULL, &scope_155, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L17", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 7},
  /* 7 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 8 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 9 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg), offsetof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, NULL, NULL, &scope_155, 1, 2}
};
static const MappingScope scope_102 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack_itr/ mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_102_entries, 10,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex/ insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_101_entries[36] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 34},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr 1", &iter_mapwi_8, sizeof(outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_117, 1, 0},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal 1", NULL, sizeof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_108, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 4 */ { MAP_LOCAL, "_L10", NULL, sizeof(array__5768), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_array__5768_Utils, NULL, NULL, &scope_161, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L11", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 6 */ { MAP_LOCAL, "_L12", NULL, sizeof(array__5771), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_array__5771_Utils, NULL, NULL, &scope_162, 1, 13},
  /* 7 */ { MAP_LOCAL, "_L13", NULL, sizeof(array__5687), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 14},
  /* 8 */ { MAP_LOCAL, "_L15", NULL, sizeof(array__5687), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 15},
  /* 9 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16},
  /* 10 */ { MAP_LOCAL, "_L17", NULL, sizeof(array__5687), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 17},
  /* 11 */ { MAP_LOCAL, "_L18", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 18},
  /* 12 */ { MAP_LOCAL, "_L19", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19},
  /* 13 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 14 */ { MAP_LOCAL, "_L20", NULL, sizeof(array__5687), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 20},
  /* 15 */ { MAP_LOCAL, "_L21", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 21},
  /* 16 */ { MAP_LOCAL, "_L22", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 22},
  /* 17 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 23},
  /* 18 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 19 */ { MAP_LOCAL, "_L26", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L26), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 25},
  /* 20 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26},
  /* 21 */ { MAP_LOCAL, "_L28", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L28), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 27},
  /* 22 */ { MAP_LOCAL, "_L29", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L29), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 28},
  /* 23 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 24 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L30), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 25 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L31), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 26 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L32), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31},
  /* 27 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L33), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32},
  /* 28 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L34), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33},
  /* 29 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 30 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 31 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 32 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 33 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 34 */ { MAP_LOCAL, "_L9", NULL, sizeof(array_int_8), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_array_int_8_Utils, NULL, NULL, &scope_160, 1, 10},
  /* 35 */ { MAP_OUTPUT, "overrun", NULL, sizeof(kcg_bool), offsetof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, overrun), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35}
};
static const MappingScope scope_101 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex/ insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_101_entries, 36,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex/ deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_100_entries[19] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 18},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr 1", &iter_mapwi_8, sizeof(outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_111, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(array__5768), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_array__5768_Utils, NULL, NULL, &scope_161, 1, 10},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(array__5771), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_array__5771_Utils, NULL, NULL, &scope_162, 1, 12},
  /* 6 */ { MAP_LOCAL, "_L13", NULL, sizeof(array__5687), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 13},
  /* 7 */ { MAP_LOCAL, "_L15", NULL, sizeof(array__5687), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 14},
  /* 8 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15},
  /* 9 */ { MAP_LOCAL, "_L17", NULL, sizeof(array__5687), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 16},
  /* 10 */ { MAP_LOCAL, "_L18", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 17},
  /* 11 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 12 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 13 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 14 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 15 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 16 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 17 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 18 */ { MAP_LOCAL, "_L9", NULL, sizeof(array_int_8), offsetof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_array_int_8_Utils, NULL, NULL, &scope_160, 1, 9}
};
static const MappingScope scope_100 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex/ deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_100_entries, 19,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack/ indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_99_entries[17] = {
  /* 0 */ { MAP_OUTPUT, "BG_found", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_found), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack_itr 1", &iter_foldwi_8, sizeof(outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_110, 1, 0},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal 1", NULL, sizeof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_108, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(array__5687), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 8},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 6 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 7 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 8 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 10 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 11 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 12 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 13 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 14 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 15 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 14},
  /* 16 */ { MAP_OUTPUT, "indexValid", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexValid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16}
};
static const MappingScope scope_99 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack/ indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_99_entries, 17,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs/ positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_98_entries[10] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs_itr 1", &iter_mapfold_4, sizeof(outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_109, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(LinkedBGs_T_BG_Types_Pkg), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_LinkedBGs_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_139, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(array__5740), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_array__5740_Utils, NULL, NULL, &scope_154, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(array__5740), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_array__5740_Utils, NULL, NULL, &scope_154, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 7},
  /* 8 */ { MAP_LOCAL, "_L9", NULL, sizeof(array__5762), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_array__5762_Utils, NULL, NULL, &scope_159, 1, 8},
  /* 9 */ { MAP_OUTPUT, "linkedPositionedBGs", NULL, sizeof(linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, linkedPositionedBGs), &_Type_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_154, 1, 9}
};
static const MappingScope scope_98 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs/ positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_98_entries, 10,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id_itr/ indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_97_entries[10] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal 1", NULL, sizeof(outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_108, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 2 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 3 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 2},
  /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 8 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 9 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9}
};
static const MappingScope scope_97 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id_itr/ indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_97_entries, 10,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex_itr/ deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_96_entries[11] = {
  /* 0 */ { MAP_OUTPUT, "BG_out", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_out), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 8},
  /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 8 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 9 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 10 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9}
};
static const MappingScope scope_96 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex_itr/ deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_96_entries, 11,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG_itr/ indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_95_entries[28] = {
  /* 0 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_LOCAL, "_L20", NULL, sizeof(Q_LINK), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 2},
  /* 2 */ { MAP_LOCAL, "_L21", NULL, sizeof(Q_LINK), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 3},
  /* 3 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 5 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 6 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L26), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 7 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L27), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 8 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L28), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 9 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L30), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 10 */ { MAP_LOCAL, "_L31", NULL, sizeof(Q_LINK), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L31), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 11},
  /* 11 */ { MAP_LOCAL, "_L32", NULL, sizeof(Q_LINK), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L32), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 12},
  /* 12 */ { MAP_LOCAL, "_L33", NULL, sizeof(BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L33), &_Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_149, 1, 13},
  /* 13 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L37), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 14},
  /* 14 */ { MAP_LOCAL, "_L38", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L38), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15},
  /* 15 */ { MAP_LOCAL, "_L39", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L39), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16},
  /* 16 */ { MAP_LOCAL, "_L4", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 17 */ { MAP_LOCAL, "_L40", NULL, sizeof(BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L40), &_Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_149, 1, 17},
  /* 18 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L42), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 18},
  /* 19 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19},
  /* 20 */ { MAP_LOCAL, "_L44", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L44), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 21 */ { MAP_LOCAL, "_L51", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L51), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 23},
  /* 22 */ { MAP_LOCAL, "_L52", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L52), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 22},
  /* 23 */ { MAP_LOCAL, "_L53", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L53), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21},
  /* 24 */ { MAP_LOCAL, "_L54", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L54), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 25 */ { MAP_LOCAL, "_L55", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L55), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25},
  /* 26 */ { MAP_OUTPUT, "acc_out", NULL, sizeof(BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, acc_out), &_Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_149, 1, 27},
  /* 27 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26}
};
static const MappingScope scope_95 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG_itr/ indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_95_entries, 28,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs_itr/ countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_94_entries[41] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 6},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(Q_LINK), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 7},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(Q_LINK), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 7 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 8 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 9 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 14},
  /* 10 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 11 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 17},
  /* 12 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16},
  /* 13 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15},
  /* 14 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 20},
  /* 15 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L24), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 19},
  /* 16 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L25), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 18},
  /* 17 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L29), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 21},
  /* 18 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L30), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 22},
  /* 19 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L31), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 23},
  /* 20 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L32), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 25},
  /* 21 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L33), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 24},
  /* 22 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L34), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 27},
  /* 23 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L35), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 26},
  /* 24 */ { MAP_LOCAL, "_L36", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L36), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 29},
  /* 25 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L37), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 28},
  /* 26 */ { MAP_LOCAL, "_L40", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L40), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 30},
  /* 27 */ { MAP_LOCAL, "_L41", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L41), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 31},
  /* 28 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L42), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 32},
  /* 29 */ { MAP_LOCAL, "_L43", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L43), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 34},
  /* 30 */ { MAP_LOCAL, "_L44", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L44), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 33},
  /* 31 */ { MAP_LOCAL, "_L45", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L45), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 35},
  /* 32 */ { MAP_LOCAL, "_L46", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L46), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 36},
  /* 33 */ { MAP_LOCAL, "_L47", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L47), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 37},
  /* 34 */ { MAP_LOCAL, "_L48", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L48), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 38},
  /* 35 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 36 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 37 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 38 */ { MAP_LOCAL, "_L9", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 5},
  /* 39 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 39},
  /* 40 */ { MAP_OUTPUT, "counters_out", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, counters_out), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 40}
};
static const MappingScope scope_94 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs_itr/ countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_94_entries, 41,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG_itr/ indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_93_entries[16] = {
  /* 0 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_LOCAL, "_L20", NULL, sizeof(Q_LINK), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 2},
  /* 2 */ { MAP_LOCAL, "_L21", NULL, sizeof(Q_LINK), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 3},
  /* 3 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 4 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 5 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 6 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L26), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 7 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L27), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 8 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L28), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 9 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L29), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 10 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L30), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 11 */ { MAP_LOCAL, "_L31", NULL, sizeof(Q_LINK), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L31), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 12},
  /* 12 */ { MAP_LOCAL, "_L32", NULL, sizeof(Q_LINK), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L32), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 13},
  /* 13 */ { MAP_LOCAL, "_L4", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 0},
  /* 14 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 15 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15}
};
static const MappingScope scope_93 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG_itr/ indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_93_entries, 16,
};

/* BasicLocationFunctions_Pkg::add_odo_2_Location/ add_odo_2_Location_BasicLocationFunctions_Pkg */
static const MappingEntry scope_92_entries[8] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 1", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_26, 1, 1},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 1", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, Context_1), NULL, NULL, NULL, &scope_91, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, _L1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, _L2), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, _L3), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, _L4), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, _L5), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 6},
  /* 7 */ { MAP_OUTPUT, "location", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg, location), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 7}
};
static const MappingScope scope_92 = {
  "BasicLocationFunctions_Pkg::add_odo_2_Location/ add_odo_2_Location_BasicLocationFunctions_Pkg",
  scope_92_entries, 8,
};

/* BasicLocationFunctions_Pkg::sub_2_odoDistances/ sub_2_odoDistances_BasicLocationFunctions_Pkg */
static const MappingEntry scope_91_entries[19] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L1), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L13", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L13), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 9},
  /* 2 */ { MAP_LOCAL, "_L14", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L14), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 8},
  /* 3 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L16", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L16), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L17", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L17), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L18", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L18), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 14},
  /* 7 */ { MAP_LOCAL, "_L19", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L19), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L2), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 1},
  /* 9 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 10 */ { MAP_LOCAL, "_L21", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L21), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 11},
  /* 11 */ { MAP_LOCAL, "_L22", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L22), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 10},
  /* 12 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L23), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L24), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16},
  /* 14 */ { MAP_LOCAL, "_L3", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L3), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 2},
  /* 15 */ { MAP_LOCAL, "_L31", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L31), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 17},
  /* 16 */ { MAP_LOCAL, "_L4", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L4), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 17 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 18 */ { MAP_OUTPUT, "distance", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg, distance), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18}
};
static const MappingScope scope_91 = {
  "BasicLocationFunctions_Pkg::sub_2_odoDistances/ sub_2_odoDistances_BasicLocationFunctions_Pkg",
  scope_91_entries, 19,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Standstill:<2 */
static const MappingEntry scope_90_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Standstill_2_SM1, NULL, 1, 0}
};
static const MappingScope scope_90 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Standstill:<2",
  scope_90_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Standstill:<1 */
static const MappingEntry scope_89_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Standstill_1_SM1, NULL, 1, 0}
};
static const MappingScope scope_89 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Standstill:<1",
  scope_89_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Standstill: */
static const MappingEntry scope_88_entries[3] = {
  /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Standstill_1_SM1, &scope_89, 1, 1},
  /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Standstill_2_SM1, &scope_90, 1, 2},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_SM1_Standstill), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Standstill_SM1, NULL, 1, 0}
};
static const MappingScope scope_88 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Standstill:",
  scope_88_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Increasing:<2 */
static const MappingEntry scope_87_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Increasing_2_SM1, NULL, 1, 0}
};
static const MappingScope scope_87 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Increasing:<2",
  scope_87_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Increasing:<1 */
static const MappingEntry scope_86_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Increasing_1_SM1, NULL, 1, 0}
};
static const MappingScope scope_86 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Increasing:<1",
  scope_86_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Increasing: */
static const MappingEntry scope_85_entries[3] = {
  /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Increasing_1_SM1, &scope_86, 1, 1},
  /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Increasing_2_SM1, &scope_87, 1, 2},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_SM1_Increasing), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Increasing_SM1, NULL, 1, 0}
};
static const MappingScope scope_85 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Increasing:",
  scope_85_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Decreasing:<2 */
static const MappingEntry scope_84_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Decreasing_2_SM1, NULL, 1, 0}
};
static const MappingScope scope_84 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Decreasing:<2",
  scope_84_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Decreasing:<1 */
static const MappingEntry scope_83_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Decreasing_1_SM1, NULL, 1, 0}
};
static const MappingScope scope_83 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Decreasing:<1",
  scope_83_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Decreasing: */
static const MappingEntry scope_82_entries[3] = {
  /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Decreasing_1_SM1, &scope_83, 1, 1},
  /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Decreasing_2_SM1, &scope_84, 1, 2},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_SM1_Decreasing), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Decreasing_SM1, NULL, 1, 0}
};
static const MappingScope scope_82 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Decreasing:",
  scope_82_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:<3 */
static const MappingEntry scope_81_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Unknown_3_SM1, NULL, 1, 0}
};
static const MappingScope scope_81 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:<3",
  scope_81_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:<2 */
static const MappingEntry scope_80_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Unknown_2_SM1, NULL, 1, 0}
};
static const MappingScope scope_80 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:<2",
  scope_80_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:<1 */
static const MappingEntry scope_79_entries[1] = {
  /* 0 */ { MAP_STRONG_TRANSITION, ">:", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Unknown_1_SM1, NULL, 1, 0}
};
static const MappingScope scope_79 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:<1",
  scope_79_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown: */
static const MappingEntry scope_78_entries[4] = {
  /* 0 */ { MAP_FORK, "<1", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Unknown_1_SM1, &scope_79, 1, 1},
  /* 1 */ { MAP_FORK, "<2", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Unknown_2_SM1, &scope_80, 1, 2},
  /* 2 */ { MAP_FORK, "<3", NULL, 0, 0, NULL, &scope_75_entries[1], isActive_SSM_TR_SM1_SSM_TR_Unknown_3_SM1, &scope_81, 1, 3},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_SM1_Unknown), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Unknown_SM1, NULL, 1, 0}
};
static const MappingScope scope_78 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:Unknown:",
  scope_78_entries, 4,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1: */
static const MappingEntry scope_75_entries[11] = {
  /* 0 */ { MAP_LOCAL, "@active_state", NULL, sizeof(SSM_ST_SM1), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_state_act), &_Type_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_LOCAL, "@active_strong_transition", NULL, sizeof(SSM_TR_SM1), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_fired_strong), &_Type_SSM_TR_SM1_Utils, NULL, NULL, NULL, 0, 5},
  /* 2 */ { MAP_LOCAL, "@active_weak_transition", NULL, sizeof(SSM_TR_SM1), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_fired), &_Type_SSM_TR_SM1_Utils, NULL, NULL, NULL, 0, 6},
  /* 3 */ { MAP_LOCAL, "@next_state", NULL, sizeof(SSM_ST_SM1), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_state_nxt), &_Type_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 2},
  /* 4 */ { MAP_LOCAL, "@reset_active_state", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_reset_act), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1},
  /* 5 */ { MAP_LOCAL, "@reset_next_state", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_reset_nxt), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 3},
  /* 6 */ { MAP_LOCAL, "@selected_state", NULL, sizeof(SSM_ST_SM1), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, SM1_state_sel), &_Type_SSM_ST_SM1_Utils, NULL, NULL, NULL, 0, 4},
  /* 7 */ { MAP_STATE, "Decreasing:", NULL, 0, 0, NULL, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Decreasing_SM1, &scope_82, 1, 8},
  /* 8 */ { MAP_STATE, "Increasing:", NULL, 0, 0, NULL, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Increasing_SM1, &scope_85, 1, 9},
  /* 9 */ { MAP_STATE, "Standstill:", NULL, 0, 0, NULL, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Standstill_SM1, &scope_88, 1, 10},
  /* 10 */ { MAP_STATE, "Unknown:", NULL, 0, 0, NULL, &scope_75_entries[0], isActive_SSM_ST_SM1_SSM_st_Unknown_SM1, &scope_78, 1, 7}
};
static const MappingScope scope_75 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_PkgSM1:",
  scope_75_entries, 11,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg */
static const MappingEntry scope_74_entries[15] = {
  /* 0 */ { MAP_LOCAL, "@kcg11", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, init), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1},
  /* 1 */ { MAP_AUTOMATON, "SM1:", NULL, 0, 0, NULL, NULL, NULL, &scope_75, 1, 2},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L10), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 9},
  /* 3 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L12), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L14), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, NULL, NULL, NULL, 1, 13},
  /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L5), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 5},
  /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L6), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 6},
  /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L7), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 7},
  /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 11 */ { MAP_LOCAL, "currentOdometry@mem", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, rem_currentOdometry), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 0, 0},
  /* 12 */ { MAP_OUTPUT, "direction", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, direction), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, NULL, NULL, NULL, 1, 14},
  /* 13 */ { MAP_LOCAL, "direction_loc", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, direction_loc), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 14 */ { MAP_LOCAL, "standstillDetected", NULL, sizeof(kcg_bool), offsetof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg, standstillDetected), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4}
};
static const MappingScope scope_74 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg",
  scope_74_entries, 15,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations/ improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_73_entries[9] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 8},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBGs 1", NULL, sizeof(outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_107, 1, 1},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations_itr 1", &iter_mapw_8, sizeof(outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_106, 1, 0},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_152, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L3), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(array__5687), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L5), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 4},
  /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 8 */ { MAP_LOCAL, "_L8", NULL, sizeof(array__5780), offsetof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_array__5780_Utils, NULL, NULL, &scope_165, 1, 6}
};
static const MappingScope scope_73 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations/ improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_73_entries, 9,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern/ recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_72_entries[12] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 11},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern_itr 1", &iter_mapfold_8, sizeof(outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_105, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(array__5687), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L10), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L11), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(array__5777), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L12), &_Type_array__5777_Utils, NULL, NULL, &scope_164, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 7 */ { MAP_LOCAL, "_L3", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L3), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 3},
  /* 8 */ { MAP_LOCAL, "_L4", NULL, sizeof(array__5687), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L4), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 4},
  /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L7), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 5},
  /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 6},
  /* 11 */ { MAP_LOCAL, "_L9", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 7}
};
static const MappingScope scope_72 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern/ recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_72_entries, 12,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead/ recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_71_entries[10] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 9},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead_itr 1", &iter_mapfold_8, sizeof(outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_104, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(array__5777), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L10), &_Type_array__5777_Utils, NULL, NULL, &scope_164, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L3), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 3},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(array__5687), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L4), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 4},
  /* 7 */ { MAP_LOCAL, "_L7", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L7), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 5},
  /* 8 */ { MAP_LOCAL, "_L8", NULL, sizeof(refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L8), &_Type_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, NULL, NULL, &scope_153, 1, 6},
  /* 9 */ { MAP_LOCAL, "_L9", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L9), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 7}
};
static const MappingScope scope_71 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead/ recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_71_entries, 10,
};

/* CalculateTrainPosition_Pkg::gp_functions_Pkg::countUp/ countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg */
static const MappingEntry scope_70_entries[11] = {
  /* 0 */ { MAP_LOCAL, "@kcg10", NULL, sizeof(kcg_bool), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, init), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L10), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 2 */ { MAP_LOCAL, "_L11@mem", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L11), &_Type_kcg_int_Utils, NULL, NULL, NULL, 0, 0},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L12), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L2), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 9 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 10 */ { MAP_OUTPUT, "counter", NULL, sizeof(kcg_int), offsetof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg, counter), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10}
};
static const MappingScope scope_70 = {
  "CalculateTrainPosition_Pkg::gp_functions_Pkg::countUp/ countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg",
  scope_70_entries, 11,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal/ nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_69_entries[8] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(NID_C), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(NID_C), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(NID_BG), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(NID_BG), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 7 */ { MAP_OUTPUT, "isEqual", NULL, sizeof(kcg_bool), offsetof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg, isEqual), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7}
};
static const MappingScope scope_69 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal/ nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_69_entries, 8,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack/ trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_68_entries[6] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 5},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack_itr 1", &iter_mapfold_8, sizeof(outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_103, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(array__5687), offsetof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4}
};
static const MappingScope scope_68 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack/ trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_68_entries, 6,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack/ mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_67_entries[10] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 8},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack_itr 1", &iter_fold_8, sizeof(outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_102, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 6 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, NULL, NULL, &scope_155, 1, 3},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, NULL, NULL, &scope_155, 1, 4},
  /* 8 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 9 */ { MAP_OUTPUT, "overrun", NULL, sizeof(kcg_bool), offsetof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, overrun), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9}
};
static const MappingScope scope_67 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack/ mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_67_entries, 10,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack/ mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_66_entries[27] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 25},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex 1", NULL, sizeof(outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_100, 1, 2},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id 2", NULL, sizeof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_2), NULL, NULL, NULL, &scope_57, 1, 0},
  /* 3 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack 1", NULL, sizeof(outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_99, 1, 1},
  /* 4 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex 1", NULL, sizeof(outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_101, 1, 3},
  /* 5 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 6 */ { MAP_LOCAL, "_L10", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 7 */ { MAP_LOCAL, "_L11", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 14},
  /* 8 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 9 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 10 */ { MAP_LOCAL, "_L15", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 17},
  /* 11 */ { MAP_LOCAL, "_L16", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 18},
  /* 12 */ { MAP_LOCAL, "_L17", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 19},
  /* 13 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 14 */ { MAP_LOCAL, "_L19", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 21},
  /* 15 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 16 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 17 */ { MAP_LOCAL, "_L21", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 23},
  /* 18 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 19 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 20 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 21 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 22 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 23 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 24 */ { MAP_LOCAL, "_L8", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 11},
  /* 25 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 26 */ { MAP_OUTPUT, "overrun", NULL, sizeof(kcg_bool), offsetof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg, overrun), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26}
};
static const MappingScope scope_66 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack/ mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_66_entries, 27,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:then: */
static const MappingEntry scope_65_entries[11] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 9", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_9), NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_26, 1, 0},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 4", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_4), NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_49, 1, 2},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 8", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_8), NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_91, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L20", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L20_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_138, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L21", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L21_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_138, 1, 7},
  /* 5 */ { MAP_LOCAL, "_L22", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L22_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 6},
  /* 6 */ { MAP_LOCAL, "_L23", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L23_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_passedBG_T_BG_Types_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_141, 1, 5},
  /* 7 */ { MAP_LOCAL, "_L24", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L24_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 4},
  /* 8 */ { MAP_LOCAL, "_L25", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L25_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 3},
  /* 9 */ { MAP_LOCAL, "_L26", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L26_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 10},
  /* 10 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L27_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, &scope_59_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 9}
};
static const MappingScope scope_65 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:then:",
  scope_65_entries, 11,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:then: */
static const MappingEntry scope_64_entries[13] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 13", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_13), NULL, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_26, 1, 1},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_odo_2_Location 5", NULL, sizeof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_5), NULL, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_92, 1, 0},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 5", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _2_Context_5), NULL, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_49, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L10_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_passedBG_T_BG_Types_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_141, 1, 6},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L11_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_138, 1, 5},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L12_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 4},
  /* 6 */ { MAP_LOCAL, "_L13", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L13_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 3},
  /* 7 */ { MAP_LOCAL, "_L14", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L14_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 11},
  /* 8 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L15_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L6", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L6_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 10},
  /* 10 */ { MAP_LOCAL, "_L7", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L7_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 9},
  /* 11 */ { MAP_LOCAL, "_L8", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L8_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 8},
  /* 12 */ { MAP_LOCAL, "_L9", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L9_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_138, 1, 7}
};
static const MappingScope scope_64 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:then:",
  scope_64_entries, 13,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:else:then: */
static const MappingEntry scope_63_entries[2] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L1_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 1},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L2_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 0}
};
static const MappingScope scope_63 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:else:then:",
  scope_63_entries, 2,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:else:else: */
static const MappingEntry scope_62_entries[20] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 14", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_14), NULL, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_26, 1, 0},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_odo_2_Location 6", NULL, sizeof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_6), NULL, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_92, 1, 1},
  /* 2 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 3", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_3), NULL, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_49, 1, 2},
  /* 3 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 6", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _1_Context_6), NULL, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_49, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L17_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 17},
  /* 5 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L1012_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 9},
  /* 6 */ { MAP_LOCAL, "_L11", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L1114_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_142, 1, 7},
  /* 7 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L1215_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 6},
  /* 8 */ { MAP_LOCAL, "_L13", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L1316_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_passedBG_T_BG_Types_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_141, 1, 5},
  /* 9 */ { MAP_LOCAL, "_L14", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L1417_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 4},
  /* 10 */ { MAP_LOCAL, "_L15", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L154_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 18},
  /* 11 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L16_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 19},
  /* 12 */ { MAP_LOCAL, "_L2", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L28_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 16},
  /* 13 */ { MAP_LOCAL, "_L3", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L3_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_138, 1, 15},
  /* 14 */ { MAP_LOCAL, "_L4", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L4_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 14},
  /* 15 */ { MAP_LOCAL, "_L5", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L5_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 13},
  /* 16 */ { MAP_LOCAL, "_L6", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L69_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_138, 1, 12},
  /* 17 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L710_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_142, 1, 11},
  /* 18 */ { MAP_LOCAL, "_L8", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L811_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 10},
  /* 19 */ { MAP_LOCAL, "_L9", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L913_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 8}
};
static const MappingScope scope_62 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:else:else:",
  scope_62_entries, 20,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:else: */
static const MappingEntry scope_61_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, else_clock_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_61_entries[0], isActive_kcg_bool_kcg_false, &scope_62, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_61_entries[0], isActive_kcg_bool_kcg_true, &scope_63, 1, 2}
};
static const MappingScope scope_61 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:else:",
  scope_61_entries, 3,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else: */
static const MappingEntry scope_60_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_60_entries[0], isActive_kcg_bool_kcg_false, &scope_61, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_60_entries[0], isActive_kcg_bool_kcg_true, &scope_64, 1, 2}
};
static const MappingScope scope_60 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:else:",
  scope_60_entries, 3,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed: */
static const MappingEntry scope_59_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, ifAnnouncedOrABGWasPreviouslyPassed_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_false, &scope_60, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_59_entries[0], isActive_kcg_bool_kcg_true, &scope_65, 1, 2}
};
static const MappingScope scope_59 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_PkgifAnnouncedOrABGWasPreviouslyPassed:",
  scope_59_entries, 3,
};

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_Pkg */
static const MappingEntry scope_58_entries[54] = {
  /* 0 */ { MAP_LOCAL, "BG_wasAnnounced", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, BG_wasAnnounced), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs 1", NULL, sizeof(outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_98, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L10), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 9},
  /* 3 */ { MAP_LOCAL, "_L11", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L11), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(BG_Header_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L12), &_Type_BG_Header_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_140, 1, 7},
  /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(LinkedBGs_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L13), &_Type_LinkedBGs_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_139, 1, 6},
  /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L14), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 7 */ { MAP_LOCAL, "_L15", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L15), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L16", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L16), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 14},
  /* 9 */ { MAP_LOCAL, "_L181", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L181), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33},
  /* 10 */ { MAP_LOCAL, "_L182", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L182), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 34},
  /* 11 */ { MAP_LOCAL, "_L183", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L183), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 35},
  /* 12 */ { MAP_LOCAL, "_L184", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L184), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 36},
  /* 13 */ { MAP_LOCAL, "_L185", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L185), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 37},
  /* 14 */ { MAP_LOCAL, "_L262", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L262), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 38},
  /* 15 */ { MAP_LOCAL, "_L263", NULL, sizeof(LinkedBGs_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L263), &_Type_LinkedBGs_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_139, 1, 40},
  /* 16 */ { MAP_LOCAL, "_L264", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L264), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 39},
  /* 17 */ { MAP_LOCAL, "_L265", NULL, sizeof(linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L265), &_Type_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_154, 1, 41},
  /* 18 */ { MAP_LOCAL, "_L276", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L276), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 45},
  /* 19 */ { MAP_LOCAL, "_L277", NULL, sizeof(Q_DIRLRBG), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L277), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 44},
  /* 20 */ { MAP_LOCAL, "_L278", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L278), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 43},
  /* 21 */ { MAP_LOCAL, "_L279", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L279), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 42},
  /* 22 */ { MAP_LOCAL, "_L281", NULL, sizeof(kcg_int), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L281), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 46},
  /* 23 */ { MAP_LOCAL, "_L282", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L282), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 47},
  /* 24 */ { MAP_LOCAL, "_L283", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L283), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 48},
  /* 25 */ { MAP_LOCAL, "_L284", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L284), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 49},
  /* 26 */ { MAP_LOCAL, "_L285", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L285), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 50},
  /* 27 */ { MAP_LOCAL, "_L37", NULL, sizeof(NID_C), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L37), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 15},
  /* 28 */ { MAP_LOCAL, "_L38", NULL, sizeof(NID_BG), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L38), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 16},
  /* 29 */ { MAP_LOCAL, "_L39", NULL, sizeof(Q_LINK), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L39), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 17},
  /* 30 */ { MAP_LOCAL, "_L40", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L40), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 18},
  /* 31 */ { MAP_LOCAL, "_L41", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L41), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19},
  /* 32 */ { MAP_LOCAL, "_L56", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L56), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 33 */ { MAP_LOCAL, "_L57", NULL, sizeof(NID_BG), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L57), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 21},
  /* 34 */ { MAP_LOCAL, "_L58", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L58), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 22},
  /* 35 */ { MAP_LOCAL, "_L59", NULL, sizeof(NID_BG), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L59), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 23},
  /* 36 */ { MAP_LOCAL, "_L60", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L60), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 37 */ { MAP_LOCAL, "_L61", NULL, sizeof(NID_C), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L61), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 25},
  /* 38 */ { MAP_LOCAL, "_L62", NULL, sizeof(NID_C), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L62), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 26},
  /* 39 */ { MAP_LOCAL, "_L63", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L63), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 27},
  /* 40 */ { MAP_LOCAL, "_L64", NULL, sizeof(Q_LINK), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L64), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 28},
  /* 41 */ { MAP_LOCAL, "_L65", NULL, sizeof(Q_LINK), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L65), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 29},
  /* 42 */ { MAP_LOCAL, "_L66", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L66), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 43 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L67), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31},
  /* 44 */ { MAP_LOCAL, "_L68", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L68), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32},
  /* 45 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 46 */ { MAP_LOCAL, "_L9", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, _L9), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 10},
  /* 47 */ { MAP_IF, "ifAnnouncedOrABGWasPreviouslyPassed:", NULL, 0, 0, NULL, NULL, NULL, &scope_59, 1, 1},
  /* 48 */ { MAP_OUTPUT, "linkedBGs", NULL, sizeof(linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, linkedBGs), &_Type_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_154, 1, 53},
  /* 49 */ { MAP_LOCAL, "location", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, location), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 50 */ { MAP_OUTPUT, "notFoundWhereAnnounced", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, notFoundWhereAnnounced), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 52},
  /* 51 */ { MAP_LOCAL, "notFoundWhereAnnounced_loc", NULL, sizeof(kcg_bool), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, notFoundWhereAnnounced_loc), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 52 */ { MAP_OUTPUT, "passedPositionedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, passedPositionedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 51},
  /* 53 */ { MAP_LOCAL, "passedPositionedBG_loc", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg, passedPositionedBG_loc), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 4}
};
static const MappingScope scope_58 = {
  "CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ passedBG_2_positionedBG_CalculateTrainPosition_Pkg",
  scope_58_entries, 54,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id/ indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_57_entries[16] = {
  /* 0 */ { MAP_OUTPUT, "BG_found", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_found), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id_itr 1", &iter_foldwi_8, sizeof(outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_97, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L11", NULL, sizeof(array__5687), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 8},
  /* 5 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 6 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 7 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 8 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 10 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 11 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 13 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 14 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 15 */ { MAP_OUTPUT, "indexValid", NULL, sizeof(kcg_bool), offsetof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexValid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15}
};
static const MappingScope scope_57 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id/ indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_57_entries, 16,
};

/* ctp_t_pck::t_engine::genPassedBG_itr/ genPassedBG_itr_ctp_t_pck_t_engine */
static const MappingEntry scope_56_entries[14] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L1), &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L10), &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 9},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L11), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 10},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L12), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 11},
  /* 4 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 5 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L4), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L5), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 4},
  /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L8), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 7},
  /* 11 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 12 */ { MAP_OUTPUT, "cont", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, cont), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 13 */ { MAP_OUTPUT, "passedBG", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_itr_ctp_t_pck_t_engine, passedBG), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 13}
};
static const MappingScope scope_56 = {
  "ctp_t_pck::t_engine::genPassedBG_itr/ genPassedBG_itr_ctp_t_pck_t_engine",
  scope_56_entries, 14,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex/ deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_55_entries[16] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 15},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex_itr 1", &iter_mapwi_8, sizeof(outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_96, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L17", NULL, sizeof(array__5687), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 10},
  /* 4 */ { MAP_LOCAL, "_L18", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 2},
  /* 6 */ { MAP_LOCAL, "_L20", NULL, sizeof(array__5687), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 12},
  /* 7 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L22", NULL, sizeof(array__5780), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_array__5780_Utils, NULL, NULL, &scope_165, 1, 14},
  /* 9 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 11 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 5},
  /* 12 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 13 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 14 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 15 */ { MAP_LOCAL, "_L9", NULL, sizeof(array_int_8), offsetof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_array_int_8_Utils, NULL, NULL, &scope_160, 1, 9}
};
static const MappingScope scope_55 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex/ deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_55_entries, 16,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG/ indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_54_entries[18] = {
  /* 0 */ { MAP_OUTPUT, "BG_found", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_found), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG_itr 1", &iter_foldwi_8, sizeof(outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_95, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_149, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 4 */ { MAP_LOCAL, "_L14", NULL, sizeof(array_bool_8), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_array_bool_8_Utils, NULL, NULL, &scope_163, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L15", NULL, sizeof(BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_149, 1, 7},
  /* 6 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 7 */ { MAP_LOCAL, "_L17", NULL, sizeof(array_int_8), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_array_int_8_Utils, NULL, NULL, &scope_160, 1, 9},
  /* 8 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 9 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 10 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 11 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 12 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 14},
  /* 13 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 14 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 15 */ { MAP_LOCAL, "_L4", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 16 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 17 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16}
};
static const MappingScope scope_54 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG/ indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_54_entries, 18,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs/ countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_53_entries[14] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs_itr 1", &iter_foldw_8, sizeof(outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_94, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 3 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 4 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 5 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 6 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 7 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L24), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 8 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 9 */ { MAP_LOCAL, "_L4", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 3},
  /* 10 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 4},
  /* 11 */ { MAP_OUTPUT, "counters", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, counters), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 13},
  /* 12 */ { MAP_OUTPUT, "empty", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, empty), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 13 */ { MAP_OUTPUT, "full", NULL, sizeof(kcg_bool), offsetof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg, full), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12}
};
static const MappingScope scope_53 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs/ countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_53_entries, 14,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG/ indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_52_entries[16] = {
  /* 0 */ { MAP_OUTPUT, "BG_found", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_found), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG_itr 1", &iter_foldwi_8, sizeof(outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_93, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(array_bool_8), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_array_bool_8_Utils, NULL, NULL, &scope_163, 1, 12},
  /* 7 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 8 */ { MAP_LOCAL, "_L4", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 9 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 10 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 11 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 12 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 13 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 14 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 15 */ { MAP_OUTPUT, "indexValid", NULL, sizeof(kcg_bool), offsetof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexValid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15}
};
static const MappingScope scope_52 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG/ indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_52_entries, 16,
};

/* BasicLocationFunctions_Pkg::overlapOf_2_Locations/ overlapOf_2_Locations_BasicLocationFunctions_Pkgmath::Max 1/ */
static const MappingEntry scope_51_entries[5] = {
  /* 0 */ { MAP_OUTPUT, "Ma_Output", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, Ma_Output_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L1_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L2_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L3_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L4_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4}
};
static const MappingScope scope_51 = {
  "BasicLocationFunctions_Pkg::overlapOf_2_Locations/ overlapOf_2_Locations_BasicLocationFunctions_Pkgmath::Max 1/",
  scope_51_entries, 5,
};

/* BasicLocationFunctions_Pkg::overlapOf_2_Locations/ overlapOf_2_Locations_BasicLocationFunctions_Pkgmath::Min 1/ */
static const MappingEntry scope_50_entries[5] = {
  /* 0 */ { MAP_OUTPUT, "Mi_Output", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, Mi_Output_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L21_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L22_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L24_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_bool), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L25_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4}
};
static const MappingScope scope_50 = {
  "BasicLocationFunctions_Pkg::overlapOf_2_Locations/ overlapOf_2_Locations_BasicLocationFunctions_Pkgmath::Min 1/",
  scope_50_entries, 5,
};

/* BasicLocationFunctions_Pkg::overlapOf_2_Locations/ overlapOf_2_Locations_BasicLocationFunctions_Pkg */
static const MappingEntry scope_49_entries[30] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 2},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L10), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L11), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 19},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L12), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L13), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 17},
  /* 5 */ { MAP_LOCAL, "_L14", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L14), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 16},
  /* 6 */ { MAP_LOCAL, "_L15", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L15), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 15},
  /* 7 */ { MAP_LOCAL, "_L16", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L16), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 14},
  /* 8 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 9 */ { MAP_LOCAL, "_L18", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L18), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 12},
  /* 10 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L19), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 11},
  /* 11 */ { MAP_LOCAL, "_L2", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L2), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 3},
  /* 12 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_bool), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L20), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 13 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L21), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 21},
  /* 14 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L22), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 22},
  /* 15 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L23), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 23},
  /* 16 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L24), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 24},
  /* 17 */ { MAP_LOCAL, "_L3", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L3), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 4},
  /* 18 */ { MAP_LOCAL, "_L31", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L31), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 25},
  /* 19 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L32), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 26},
  /* 20 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L33), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 27},
  /* 21 */ { MAP_LOCAL, "_L5", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L5), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 5},
  /* 22 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L6), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 23 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 24 */ { MAP_LOCAL, "_L8", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L8), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 8},
  /* 25 */ { MAP_LOCAL, "_L9", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, _L9), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 7},
  /* 26 */ { MAP_OUTPUT, "loc", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, loc), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 28},
  /* 27 */ { MAP_EXPANDED, "math::Max 1", NULL, 0, 0, NULL, NULL, NULL, &scope_51, 1, 1},
  /* 28 */ { MAP_EXPANDED, "math::Min 1", NULL, 0, 0, NULL, NULL, NULL, &scope_50, 1, 0},
  /* 29 */ { MAP_OUTPUT, "overlap", NULL, sizeof(kcg_bool), offsetof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg, overlap), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29}
};
static const MappingScope scope_49 = {
  "BasicLocationFunctions_Pkg::overlapOf_2_Locations/ overlapOf_2_Locations_BasicLocationFunctions_Pkg",
  scope_49_entries, 30,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:then: */
static const MappingEntry scope_48_entries[6] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_odo_2_Location 6", NULL, sizeof(outC_add_odo_2_Location_BasicLocationFunctions_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_6), NULL, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_92, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L15", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15_IfBlock1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 5},
  /* 2 */ { MAP_LOCAL, "_L16", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16_IfBlock1), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_138, 1, 4},
  /* 3 */ { MAP_LOCAL, "_L17", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17_IfBlock1), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_138, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L18", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18_IfBlock1), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_142, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L19", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19_IfBlock1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_135, 1, 1}
};
static const MappingScope scope_48 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:then:",
  scope_48_entries, 6,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else: */
static const MappingEntry scope_47_entries[4] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_odoDistances 1", NULL, sizeof(outC_sub_2_odoDistances_BasicLocationFunctions_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, &scope_46_entries[0], isActive_kcg_bool_kcg_false, &scope_91, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L3", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3_IfBlock1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_false, &scope_135, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L4", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4_IfBlock1), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_false, &scope_138, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L5", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5_IfBlock1), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, &scope_46_entries[0], isActive_kcg_bool_kcg_false, &scope_138, 1, 3}
};
static const MappingScope scope_47 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:else:",
  scope_47_entries, 4,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1: */
static const MappingEntry scope_46_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_46_entries[0], isActive_kcg_bool_kcg_false, &scope_47, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_46_entries[0], isActive_kcg_bool_kcg_true, &scope_48, 1, 2}
};
static const MappingScope scope_46 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_PkgIfBlock1:",
  scope_46_entries, 3,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_45_entries[2] = {
  /* 0 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_46, 1, 0},
  /* 1 */ { MAP_OUTPUT, "position", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, position), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 1}
};
static const MappingScope scope_45 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_45_entries, 2,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:then: */
static const MappingEntry scope_44_entries[6] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_IfBlock1), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, &scope_40_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L2_IfBlock1), &_Type_kcg_bool_Utils, &scope_40_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L3_IfBlock1), &_Type_kcg_int_Utils, &scope_40_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L4_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_40_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L5_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_40_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L6", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L6_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_40_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5}
};
static const MappingScope scope_44 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:then:",
  scope_44_entries, 6,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:then: */
static const MappingEntry scope_43_entries[6] = {
  /* 0 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L10_IfBlock1), &_Type_kcg_bool_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L5", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L52_IfBlock1), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5},
  /* 2 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L63_IfBlock1), &_Type_kcg_int_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4},
  /* 3 */ { MAP_LOCAL, "_L7", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L7_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L8", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L8_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2},
  /* 5 */ { MAP_LOCAL, "_L9", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L9_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 1}
};
static const MappingScope scope_43 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:then:",
  scope_43_entries, 6,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:else: */
static const MappingEntry scope_42_entries[1] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L14_IfBlock1), &_Type_Q_DLRBG_Utils, &scope_41_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0}
};
static const MappingScope scope_42 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:else:",
  scope_42_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else: */
static const MappingEntry scope_41_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, else_clock_IfBlock1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_41_entries[0], isActive_kcg_bool_kcg_false, &scope_42, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_41_entries[0], isActive_kcg_bool_kcg_true, &scope_43, 1, 2}
};
static const MappingScope scope_41 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:",
  scope_41_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1: */
static const MappingEntry scope_40_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_40_entries[0], isActive_kcg_bool_kcg_false, &scope_41, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_40_entries[0], isActive_kcg_bool_kcg_true, &scope_44, 1, 2}
};
static const MappingScope scope_40 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:",
  scope_40_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg */
static const MappingEntry scope_39_entries[23] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 1", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, Context_1), NULL, NULL, NULL, &scope_26, 1, 0},
  /* 1 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 1", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_21, 1, 1},
  /* 2 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_40, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L1), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 5},
  /* 4 */ { MAP_LOCAL, "_L10", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L10), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14},
  /* 5 */ { MAP_LOCAL, "_L11", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L11), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 15},
  /* 6 */ { MAP_LOCAL, "_L12", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L12), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 16},
  /* 7 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 8 */ { MAP_LOCAL, "_L14", NULL, sizeof(Q_DIRLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L14), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 18},
  /* 9 */ { MAP_LOCAL, "_L17", NULL, sizeof(Q_DIRLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L17), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 19},
  /* 10 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 11 */ { MAP_LOCAL, "_L19", NULL, sizeof(Q_DIRLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L19), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 21},
  /* 12 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 13 */ { MAP_LOCAL, "_L3", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L3), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 7},
  /* 14 */ { MAP_LOCAL, "_L4", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L4), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 8},
  /* 15 */ { MAP_LOCAL, "_L5", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L5), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 9},
  /* 16 */ { MAP_LOCAL, "_L6", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L6), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 10},
  /* 17 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L7), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 11},
  /* 18 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 19 */ { MAP_LOCAL, "_L9", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, _L9), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 13},
  /* 20 */ { MAP_LOCAL, "estimated_d_LRBGToFrontend", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, estimated_d_LRBGToFrontend), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 21 */ { MAP_OUTPUT, "nominalOrReverseToLRBG", NULL, sizeof(Q_DLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, nominalOrReverseToLRBG), &_Type_Q_DLRBG_Utils, NULL, NULL, NULL, 1, 22},
  /* 22 */ { MAP_LOCAL, "trainOrientationToLRBG", NULL, sizeof(Q_DIRLRBG), offsetof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg, trainOrientationToLRBG), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 4}
};
static const MappingScope scope_39 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg",
  scope_39_entries, 23,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:then: */
static const MappingEntry scope_38_entries[1] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_IfBlock2), &_Type_Q_DIRTRAIN_Utils, &scope_34_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0}
};
static const MappingScope scope_38 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:then:",
  scope_38_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:else:then: */
static const MappingEntry scope_37_entries[1] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L11_IfBlock2), &_Type_Q_DIRTRAIN_Utils, &scope_35_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0}
};
static const MappingScope scope_37 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:else:then:",
  scope_37_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:else:else: */
static const MappingEntry scope_36_entries[5] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L12_IfBlock2), &_Type_Q_DIRTRAIN_Utils, &scope_35_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L2_IfBlock2), &_Type_kcg_bool_Utils, &scope_35_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L3", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L3_IfBlock2), &_Type_Q_DIRTRAIN_Utils, &scope_35_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L4_IfBlock2), &_Type_Q_DIRTRAIN_Utils, &scope_35_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L6", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L6_IfBlock2), &_Type_Q_DIRTRAIN_Utils, &scope_35_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 4}
};
static const MappingScope scope_36 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:else:else:",
  scope_36_entries, 5,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:else: */
static const MappingEntry scope_35_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, else_clock_IfBlock2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_35_entries[0], isActive_kcg_bool_kcg_false, &scope_36, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_35_entries[0], isActive_kcg_bool_kcg_true, &scope_37, 1, 2}
};
static const MappingScope scope_35 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:else:",
  scope_35_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2: */
static const MappingEntry scope_34_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, IfBlock2_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_34_entries[0], isActive_kcg_bool_kcg_false, &scope_35, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_34_entries[0], isActive_kcg_bool_kcg_true, &scope_38, 1, 2}
};
static const MappingScope scope_34 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock2:",
  scope_34_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:then: */
static const MappingEntry scope_33_entries[1] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L1_IfBlock1), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_29_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0}
};
static const MappingScope scope_33 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:then:",
  scope_33_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:then: */
static const MappingEntry scope_32_entries[1] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L13_IfBlock1), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_30_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 0}
};
static const MappingScope scope_32 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:then:",
  scope_32_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:else: */
static const MappingEntry scope_31_entries[1] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L14_IfBlock1), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, &scope_30_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 0}
};
static const MappingScope scope_31 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:else:",
  scope_31_entries, 1,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else: */
static const MappingEntry scope_30_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, else_clock_IfBlock1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_30_entries[0], isActive_kcg_bool_kcg_false, &scope_31, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_30_entries[0], isActive_kcg_bool_kcg_true, &scope_32, 1, 2}
};
static const MappingScope scope_30 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:else:",
  scope_30_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1: */
static const MappingEntry scope_29_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_IF, "else:", NULL, 0, 0, NULL, &scope_29_entries[0], isActive_kcg_bool_kcg_false, &scope_30, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_29_entries[0], isActive_kcg_bool_kcg_true, &scope_33, 1, 2}
};
static const MappingScope scope_29 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_PkgIfBlock1:",
  scope_29_entries, 3,
};

/* CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg */
static const MappingEntry scope_28_entries[8] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor 1", NULL, sizeof(outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, Context_1), NULL, NULL, NULL, &scope_74, 1, 0},
  /* 1 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_29, 1, 1},
  /* 2 */ { MAP_IF, "IfBlock2:", NULL, 0, 0, NULL, NULL, NULL, &scope_34, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L4", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L4), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, NULL, NULL, NULL, 1, 5},
  /* 4 */ { MAP_LOCAL, "_L5", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, _L5), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 6},
  /* 5 */ { MAP_LOCAL, "currentDir", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, currentDir), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 6 */ { MAP_LOCAL, "refDir", NULL, sizeof(trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, refDir), &_Type_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, NULL, NULL, NULL, 1, 4},
  /* 7 */ { MAP_OUTPUT, "trainRunningDirection", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg, trainRunningDirection), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 7}
};
static const MappingScope scope_28 = {
  "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg",
  scope_28_entries, 8,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG/ nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_27_entries[12] = {
  /* 0 */ { MAP_LOCAL, "_L10", NULL, sizeof(NID_BG), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L10), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 5},
  /* 1 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 2 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 3 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 4 */ { MAP_LOCAL, "_L15", NULL, sizeof(NID_C), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L16", NULL, sizeof(NID_BG), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(NID_LRBG), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_NID_LRBG_Utils, NULL, NULL, NULL, 1, 1},
  /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L8), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 11 */ { MAP_OUTPUT, "nidLRBG", NULL, sizeof(NID_LRBG), offsetof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg, nidLRBG), &_Type_NID_LRBG_Utils, NULL, NULL, NULL, 1, 11}
};
static const MappingScope scope_27 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG/ nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_27_entries, 12,
};

/* BasicLocationFunctions_Pkg::add_2_Distances/ add_2_Distances_BasicLocationFunctions_Pkg */
static const MappingEntry scope_26_entries[17] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L13", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L13), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 9},
  /* 2 */ { MAP_LOCAL, "_L14", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L14), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 8},
  /* 3 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L16", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L16), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L17", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L17), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L18", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L18), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14},
  /* 7 */ { MAP_LOCAL, "_L19", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L19), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L2), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 1},
  /* 9 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 10 */ { MAP_LOCAL, "_L21", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L21), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 11},
  /* 11 */ { MAP_LOCAL, "_L22", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L22), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 10},
  /* 12 */ { MAP_LOCAL, "_L23", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L23), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L3", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L3), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 2},
  /* 14 */ { MAP_LOCAL, "_L4", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L4), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 15 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 16 */ { MAP_OUTPUT, "distance", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_add_2_Distances_BasicLocationFunctions_Pkg, distance), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 16}
};
static const MappingScope scope_26 = {
  "BasicLocationFunctions_Pkg::add_2_Distances/ add_2_Distances_BasicLocationFunctions_Pkg",
  scope_26_entries, 17,
};

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::improve_BG_locations/ improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg */
static const MappingEntry scope_25_entries[10] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 9},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations 1", NULL, sizeof(outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_73, 1, 2},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead 1", NULL, sizeof(outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, Context_1), NULL, NULL, NULL, &scope_71, 1, 0},
  /* 3 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern 1", NULL, sizeof(outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_72, 1, 1},
  /* 4 */ { MAP_LOCAL, "_L1", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 3},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L2), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 4},
  /* 6 */ { MAP_LOCAL, "_L33", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L33), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 5},
  /* 7 */ { MAP_LOCAL, "_L34", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L34), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 6},
  /* 8 */ { MAP_LOCAL, "_L38", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L38), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 7},
  /* 9 */ { MAP_LOCAL, "_L39", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg, _L39), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 8}
};
static const MappingScope scope_25 = {
  "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improve_BG_locations/ improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg",
  scope_25_entries, 10,
};

/* CalculateTrainPosition_Pkg::genPassedBG_SeqNo/ genPassedBG_SeqNo_CalculateTrainPosition_Pkg */
static const MappingEntry scope_24_entries[26] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id 1", NULL, sizeof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_20, 1, 0},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::gp_functions_Pkg::countUp 1", NULL, sizeof(outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_70, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L1), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 4},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 6 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 7 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L14), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 8 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 9 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L16), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18},
  /* 10 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L17), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19},
  /* 11 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 12 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_int), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L19), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 21},
  /* 13 */ { MAP_LOCAL, "_L2", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L2), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 5},
  /* 14 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 22},
  /* 15 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L21), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 23},
  /* 16 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L22), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 17 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 18 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 19 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 20 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 21 */ { MAP_LOCAL, "_L8", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L8), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 22 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 23 */ { MAP_LOCAL, "incrPassedBGSeqNo", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, incrPassedBGSeqNo), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 24 */ { MAP_LOCAL, "keepPassedBGSeqNo", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, keepPassedBGSeqNo), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 25 */ { MAP_OUTPUT, "seqNo", NULL, sizeof(kcg_int), offsetof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg, seqNo), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 25}
};
static const MappingScope scope_24 = {
  "CalculateTrainPosition_Pkg::genPassedBG_SeqNo/ genPassedBG_SeqNo_CalculateTrainPosition_Pkg",
  scope_24_entries, 26,
};

/* CalculateTrainPosition_Pkg::prevPassedLinkedBG/ prevPassedLinkedBG_CalculateTrainPosition_Pkg */
static const MappingEntry scope_23_entries[20] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG 1", NULL, sizeof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_52, 1, 1},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal 1", NULL, sizeof(outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_69, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L42", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L42), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L45", NULL, sizeof(NID_C), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L45), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L46", NULL, sizeof(NID_BG), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L46), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L49", NULL, sizeof(NID_C), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L49), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L50", NULL, sizeof(NID_BG), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L50), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L55", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L55), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 8 */ { MAP_LOCAL, "_L60", NULL, sizeof(kcg_int), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L60), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 9 */ { MAP_LOCAL, "_L61", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L61), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 10 */ { MAP_LOCAL, "_L62", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L62), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 11 */ { MAP_LOCAL, "_L63", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L63), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 11},
  /* 12 */ { MAP_LOCAL, "_L64", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L64), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 13 */ { MAP_LOCAL, "_L67", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L67), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 14 */ { MAP_LOCAL, "_L68", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L68), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 13},
  /* 15 */ { MAP_LOCAL, "_L69", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L69), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 16 */ { MAP_LOCAL, "_L70", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L70), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 16},
  /* 17 */ { MAP_LOCAL, "_L71", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L71), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 17},
  /* 18 */ { MAP_LOCAL, "_L72", NULL, sizeof(kcg_bool), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, _L72), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18},
  /* 19 */ { MAP_OUTPUT, "previouslyPassedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg, previouslyPassedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 19}
};
static const MappingScope scope_23 = {
  "CalculateTrainPosition_Pkg::prevPassedLinkedBG/ prevPassedLinkedBG_CalculateTrainPosition_Pkg",
  scope_23_entries, 20,
};

/* CalculateTrainPosition_Pkg::passing_a_BG/ passing_a_BG_CalculateTrainPosition_Pkg */
static const MappingEntry scope_22_entries[32] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 29},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id 1", NULL, sizeof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_20, 1, 1},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack 2", NULL, sizeof(outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, Context_2), NULL, NULL, NULL, &scope_66, 1, 2},
  /* 3 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack 1", NULL, sizeof(outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_67, 1, 3},
  /* 4 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack 1", NULL, sizeof(outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _3_Context_1), NULL, NULL, NULL, &scope_68, 1, 4},
  /* 5 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::passedBG_2_positionedBG 1", NULL, sizeof(outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_58, 1, 0},
  /* 6 */ { MAP_LOCAL, "_L1", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L1), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 5},
  /* 7 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L10), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 8 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 9 */ { MAP_LOCAL, "_L12", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L12), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 12},
  /* 10 */ { MAP_LOCAL, "_L13", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L13), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 11 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L15), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 14},
  /* 12 */ { MAP_LOCAL, "_L16", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L16), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L17), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 14 */ { MAP_LOCAL, "_L18", NULL, sizeof(array__5687), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L18), &_Type_array__5687_Utils, NULL, NULL, &scope_146, 1, 17},
  /* 15 */ { MAP_LOCAL, "_L19", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L19), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 18},
  /* 16 */ { MAP_LOCAL, "_L20", NULL, sizeof(array__5740), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L20), &_Type_array__5740_Utils, NULL, NULL, &scope_154, 1, 19},
  /* 17 */ { MAP_LOCAL, "_L21", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L21), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 20},
  /* 18 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L22), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21},
  /* 19 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L23), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 20 */ { MAP_LOCAL, "_L24", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L24), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 23},
  /* 21 */ { MAP_LOCAL, "_L25", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L25), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 24},
  /* 22 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_int), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L26), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 25},
  /* 23 */ { MAP_LOCAL, "_L30", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L30), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 26},
  /* 24 */ { MAP_LOCAL, "_L31", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L31), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 27},
  /* 25 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L5), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 6},
  /* 26 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 27 */ { MAP_LOCAL, "_L7", NULL, sizeof(linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L7), &_Type_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_154, 1, 8},
  /* 28 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 29 */ { MAP_OUTPUT, "notFoundWhereAnnounced", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, notFoundWhereAnnounced), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 31},
  /* 30 */ { MAP_OUTPUT, "overrun", NULL, sizeof(kcg_bool), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, overrun), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 31 */ { MAP_OUTPUT, "passedPositionedBG", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_passing_a_BG_CalculateTrainPosition_Pkg, passedPositionedBG), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 28}
};
static const MappingScope scope_22 = {
  "CalculateTrainPosition_Pkg::passing_a_BG/ passing_a_BG_CalculateTrainPosition_Pkg",
  scope_22_entries, 32,
};

/* BasicLocationFunctions_Pkg::sub_2_distances/ sub_2_distances_BasicLocationFunctions_Pkg */
static const MappingEntry scope_21_entries[17] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L1), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L13", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L13), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 9},
  /* 2 */ { MAP_LOCAL, "_L14", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L14), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 8},
  /* 3 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L16", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L16), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L17", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L17), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L18", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L18), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14},
  /* 7 */ { MAP_LOCAL, "_L19", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L19), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L2), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 1},
  /* 9 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 12},
  /* 10 */ { MAP_LOCAL, "_L21", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L21), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 11},
  /* 11 */ { MAP_LOCAL, "_L22", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L22), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 10},
  /* 12 */ { MAP_LOCAL, "_L23", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L23), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L3", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L3), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 2},
  /* 14 */ { MAP_LOCAL, "_L4", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L4), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 3},
  /* 15 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 16 */ { MAP_OUTPUT, "distance", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_sub_2_distances_BasicLocationFunctions_Pkg, distance), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 16}
};
static const MappingScope scope_21 = {
  "BasicLocationFunctions_Pkg::sub_2_distances/ sub_2_distances_BasicLocationFunctions_Pkg",
  scope_21_entries, 17,
};

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id/ indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg */
static const MappingEntry scope_20_entries[27] = {
  /* 0 */ { MAP_OUTPUT, "BG_found", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, BG_found), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id 1", NULL, sizeof(outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, Context_1), NULL, NULL, NULL, &scope_57, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3},
  /* 3 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L13), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 4 */ { MAP_LOCAL, "_L14", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L14), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L15", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L15), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L16", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L16), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 9},
  /* 7 */ { MAP_LOCAL, "_L17", NULL, sizeof(BG_Header_T_BG_Types_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L17), &_Type_BG_Header_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_140, 1, 8},
  /* 8 */ { MAP_LOCAL, "_L18", NULL, sizeof(LinkedBGs_T_BG_Types_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L18), &_Type_LinkedBGs_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_139, 1, 7},
  /* 9 */ { MAP_LOCAL, "_L19", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L19), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 10 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 2},
  /* 11 */ { MAP_LOCAL, "_L20", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L20), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14},
  /* 12 */ { MAP_LOCAL, "_L21", NULL, sizeof(NID_C), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L21), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L22", NULL, sizeof(NID_BG), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L22), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 16},
  /* 14 */ { MAP_LOCAL, "_L23", NULL, sizeof(Q_LINK), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L23), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 17},
  /* 15 */ { MAP_LOCAL, "_L25", NULL, sizeof(infoFromLinking_T_TrainPosition_Types_Pck), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L25), &_Type_infoFromLinking_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_137, 1, 18},
  /* 16 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 17 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 18 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L5), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 5},
  /* 19 */ { MAP_LOCAL, "_L6", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L6), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 6},
  /* 20 */ { MAP_LOCAL, "_L66", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L66), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 21 */ { MAP_LOCAL, "_L67", NULL, sizeof(Q_DIRLRBG), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L67), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 21},
  /* 22 */ { MAP_LOCAL, "_L68", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L68), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 20},
  /* 23 */ { MAP_LOCAL, "_L69", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L69), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 19},
  /* 24 */ { MAP_LOCAL, "_L86", NULL, sizeof(kcg_int), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, _L86), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 23},
  /* 25 */ { MAP_OUTPUT, "indexOfBG", NULL, sizeof(kcg_int), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexOfBG), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 24},
  /* 26 */ { MAP_OUTPUT, "indexValid", NULL, sizeof(kcg_bool), offsetof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg, indexValid), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 26}
};
static const MappingScope scope_20 = {
  "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id/ indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg",
  scope_20_entries, 27,
};

/* ctp_t_pck::t_engine::genPassedBG/ genPassedBG_ctp_t_pck_t_engine */
static const MappingEntry scope_19_entries[14] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L1), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L10), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 9},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L11), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 10},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L12), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 11},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L13), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 12},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L2), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 2},
  /* 6 */ { MAP_LOCAL, "_L3", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L3), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 3},
  /* 7 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L5), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 8 */ { MAP_LOCAL, "_L6", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L6), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 5},
  /* 9 */ { MAP_LOCAL, "_L7", NULL, sizeof(array_int_10), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L7), &_Type_array_int_10_Utils, NULL, NULL, &scope_166, 1, 6},
  /* 10 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 11 */ { MAP_LOCAL, "_L9", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, _L9), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 8},
  /* 12 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::genPassedBG_itr 1", &iter_foldw_10, sizeof(outC_genPassedBG_itr_ctp_t_pck_t_engine), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, Context_1), NULL, NULL, NULL, &scope_56, 1, 0},
  /* 13 */ { MAP_OUTPUT, "passedBG", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_genPassedBG_ctp_t_pck_t_engine, passedBG), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 13}
};
static const MappingScope scope_19 = {
  "ctp_t_pck::t_engine::genPassedBG/ genPassedBG_ctp_t_pck_t_engine",
  scope_19_entries, 14,
};

/* ctp_t_pck::t_engine::genOdometry/ genOdometry_ctp_t_pck_t_enginemath::Max 1/ */
static const MappingEntry scope_18_entries[5] = {
  /* 0 */ { MAP_OUTPUT, "Ma_Output", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, Ma_Output_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 0},
  /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L1_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 1},
  /* 2 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L2_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L3_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L4_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4}
};
static const MappingScope scope_18 = {
  "ctp_t_pck::t_engine::genOdometry/ genOdometry_ctp_t_pck_t_enginemath::Max 1/",
  scope_18_entries, 5,
};

/* ctp_t_pck::t_engine::genOdometry/ genOdometry_ctp_t_pck_t_engine */
static const MappingEntry scope_17_entries[29] = {
  /* 0 */ { MAP_LOCAL, "@kcg9", NULL, sizeof(kcg_bool), offsetof(outC_genOdometry_ctp_t_pck_t_engine, init), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 2},
  /* 1 */ { MAP_LOCAL, "_L1", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L1), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 4},
  /* 2 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L13), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 11},
  /* 3 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L14), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 10},
  /* 4 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L15), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 9},
  /* 5 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L16), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 12},
  /* 6 */ { MAP_LOCAL, "_L17@mem", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 0, 0},
  /* 7 */ { MAP_LOCAL, "_L18", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L18), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 13},
  /* 8 */ { MAP_LOCAL, "_L19", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L19), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 14},
  /* 9 */ { MAP_LOCAL, "_L2", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L2), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 5},
  /* 10 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L20), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 15},
  /* 11 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L21), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 16},
  /* 12 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_real), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L22), &_Type_kcg_real_Utils, NULL, NULL, NULL, 1, 17},
  /* 13 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L23), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 18},
  /* 14 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L24), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 19},
  /* 15 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L25), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 20},
  /* 16 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L26), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 21},
  /* 17 */ { MAP_LOCAL, "_L27@mem", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L27), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 0, 1},
  /* 18 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L28), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 22},
  /* 19 */ { MAP_LOCAL, "_L29", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L29), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 23},
  /* 20 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_bool), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 21 */ { MAP_LOCAL, "_L30", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L30), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 24},
  /* 22 */ { MAP_LOCAL, "_L31", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L31), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 25},
  /* 23 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_int), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L32), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 26},
  /* 24 */ { MAP_LOCAL, "_L33", NULL, sizeof(odometryFactors_T_ctp_t_pck_t_engine), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L33), &_Type_odometryFactors_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_158, 1, 27},
  /* 25 */ { MAP_LOCAL, "_L4", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L4), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 7},
  /* 26 */ { MAP_LOCAL, "_L8", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, _L8), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 8},
  /* 27 */ { MAP_EXPANDED, "math::Max 1", NULL, 0, 0, NULL, NULL, NULL, &scope_18, 1, 3},
  /* 28 */ { MAP_OUTPUT, "odometry", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_genOdometry_ctp_t_pck_t_engine, odometry), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 28}
};
static const MappingScope scope_17 = {
  "ctp_t_pck::t_engine::genOdometry/ genOdometry_ctp_t_pck_t_engine",
  scope_17_entries, 29,
};

/* ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 4/ */
static const MappingEntry scope_16_entries[8] = {
  /* 0 */ { MAP_ASSUME, "A1", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, A1_4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_OUTPUT, "IRII_Output", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, IRII_Output_4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L10_4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L12_4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L13_4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L2_4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L4_4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L8_4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7}
};
static const MappingScope scope_16 = {
  "ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 4/",
  scope_16_entries, 8,
};

/* ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 3/ */
static const MappingEntry scope_15_entries[8] = {
  /* 0 */ { MAP_ASSUME, "A1", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, A1_3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_OUTPUT, "IRII_Output", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, IRII_Output_3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L10_3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L12_3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L13_3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L2_3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L4_3), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L8_3), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7}
};
static const MappingScope scope_15 = {
  "ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 3/",
  scope_15_entries, 8,
};

/* ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 2/ */
static const MappingEntry scope_14_entries[8] = {
  /* 0 */ { MAP_ASSUME, "A1", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, A1_2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_OUTPUT, "IRII_Output", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, IRII_Output_2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L10_2), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L12_2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L13_2), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L2_2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L4_2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L8_2), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7}
};
static const MappingScope scope_14 = {
  "ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 2/",
  scope_14_entries, 8,
};

/* ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 1/ */
static const MappingEntry scope_13_entries[8] = {
  /* 0 */ { MAP_ASSUME, "A1", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, A1_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 1},
  /* 1 */ { MAP_OUTPUT, "IRII_Output", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, IRII_Output_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L10_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L12_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 3},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L13_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 4},
  /* 5 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L2_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L4_1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L8_1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 7}
};
static const MappingScope scope_13 = {
  "ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_enginemath::InRangeInIn 1/",
  scope_13_entries, 8,
};

/* ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_engine */
static const MappingEntry scope_12_entries[30] = {
  /* 0 */ { MAP_LOCAL, "@kcg8", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, init), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 2},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L10), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 15},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L11), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16},
  /* 3 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L12), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 17},
  /* 4 */ { MAP_LOCAL, "_L13", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L13), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 18},
  /* 5 */ { MAP_LOCAL, "_L14", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L14), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 19},
  /* 6 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 20},
  /* 7 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 21},
  /* 8 */ { MAP_LOCAL, "_L17", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L17), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 9 */ { MAP_LOCAL, "_L19", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L19), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 23},
  /* 10 */ { MAP_LOCAL, "_L1@mem", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L1), &_Type_kcg_int_Utils, NULL, NULL, NULL, 0, 1},
  /* 11 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L2), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 8},
  /* 12 */ { MAP_LOCAL, "_L20", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L20), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 24},
  /* 13 */ { MAP_LOCAL, "_L21", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L21), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 25},
  /* 14 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L22), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 26},
  /* 15 */ { MAP_LOCAL, "_L23", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L23), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 27},
  /* 16 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L4), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 17 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L5), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 18 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L6), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 11},
  /* 19 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L7), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 20 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 21 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_int), offsetof(outC_genLocation_ctp_t_pck_t_engine, _L9), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 14},
  /* 22 */ { MAP_LOCAL, "incr", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genLocation_ctp_t_pck_t_engine, incr), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 7},
  /* 23 */ { MAP_OUTPUT, "location", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genLocation_ctp_t_pck_t_engine, location), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 28},
  /* 24 */ { MAP_LOCAL, "location_loc@mem", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genLocation_ctp_t_pck_t_engine, location_loc), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 0, 0},
  /* 25 */ { MAP_EXPANDED, "math::InRangeInIn 1", NULL, 0, 0, NULL, NULL, NULL, &scope_13, 1, 3},
  /* 26 */ { MAP_EXPANDED, "math::InRangeInIn 2", NULL, 0, 0, NULL, NULL, NULL, &scope_14, 1, 4},
  /* 27 */ { MAP_EXPANDED, "math::InRangeInIn 3", NULL, 0, 0, NULL, NULL, NULL, &scope_15, 1, 5},
  /* 28 */ { MAP_EXPANDED, "math::InRangeInIn 4", NULL, 0, 0, NULL, NULL, NULL, &scope_16, 1, 6},
  /* 29 */ { MAP_OUTPUT, "time", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_genLocation_ctp_t_pck_t_engine, time), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 29}
};
static const MappingScope scope_12 = {
  "ctp_t_pck::t_engine::genLocation/ genLocation_ctp_t_pck_t_engine",
  scope_12_entries, 30,
};

/* CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_PkgIfBlock1:then: */
static const MappingEntry scope_11_entries[16] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex 2", NULL, sizeof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _1_Context_2), NULL, &scope_9_entries[0], isActive_kcg_bool_kcg_true, &scope_55, 1, 1},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG 2", NULL, sizeof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, Context_2), NULL, &scope_9_entries[0], isActive_kcg_bool_kcg_true, &scope_54, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L1_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L10_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 11},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L11_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 12},
  /* 5 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L12_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 13},
  /* 6 */ { MAP_LOCAL, "_L13", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L13_IfBlock1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, &scope_146, 1, 14},
  /* 7 */ { MAP_LOCAL, "_L14", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L14_IfBlock1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, &scope_146, 1, 15},
  /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L2_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 3},
  /* 9 */ { MAP_LOCAL, "_L3", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L3_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 4},
  /* 10 */ { MAP_LOCAL, "_L4", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L4_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 5},
  /* 11 */ { MAP_LOCAL, "_L5", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L5_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 6},
  /* 12 */ { MAP_LOCAL, "_L6", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L6_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 8},
  /* 13 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L7_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 7},
  /* 14 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L8_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, NULL, 1, 9},
  /* 15 */ { MAP_LOCAL, "_L9", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L9_IfBlock1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_true, &scope_146, 1, 10}
};
static const MappingScope scope_11 = {
  "CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_PkgIfBlock1:then:",
  scope_11_entries, 16,
};

/* CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_PkgIfBlock1:else: */
static const MappingEntry scope_10_entries[16] = {
  /* 0 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex 9", NULL, sizeof(outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _2_Context_9), NULL, &scope_9_entries[0], isActive_kcg_bool_kcg_false, &scope_55, 1, 1},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG 9", NULL, sizeof(outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, Context_9), NULL, &scope_9_entries[0], isActive_kcg_bool_kcg_false, &scope_54, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L47", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L47_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 13},
  /* 3 */ { MAP_LOCAL, "_L49", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L49_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 12},
  /* 4 */ { MAP_LOCAL, "_L51", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L51_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 11},
  /* 5 */ { MAP_LOCAL, "_L52", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L52_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 10},
  /* 6 */ { MAP_LOCAL, "_L53", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L53_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 9},
  /* 7 */ { MAP_LOCAL, "_L54", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L54_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 7},
  /* 8 */ { MAP_LOCAL, "_L55", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L55_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 8},
  /* 9 */ { MAP_LOCAL, "_L56", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L56_IfBlock1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, &scope_146, 1, 6},
  /* 10 */ { MAP_LOCAL, "_L57", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L57_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 5},
  /* 11 */ { MAP_LOCAL, "_L58", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L58_IfBlock1), &_Type_kcg_bool_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 4},
  /* 12 */ { MAP_LOCAL, "_L59", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L59_IfBlock1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, &scope_146, 1, 3},
  /* 13 */ { MAP_LOCAL, "_L60", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L60_IfBlock1), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, &scope_146, 1, 2},
  /* 14 */ { MAP_LOCAL, "_L61", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L61_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 14},
  /* 15 */ { MAP_LOCAL, "_L62", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L62_IfBlock1), &_Type_kcg_int_Utils, &scope_9_entries[0], isActive_kcg_bool_kcg_false, NULL, 1, 15}
};
static const MappingScope scope_10 = {
  "CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_PkgIfBlock1:else:",
  scope_10_entries, 16,
};

/* CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_PkgIfBlock1: */
static const MappingEntry scope_9_entries[3] = {
  /* 0 */ { MAP_LOCAL, "@condition", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, IfBlock1_clock), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 0},
  /* 1 */ { MAP_ACTION, "else:", NULL, 0, 0, NULL, &scope_9_entries[0], isActive_kcg_bool_kcg_false, &scope_10, 1, 1},
  /* 2 */ { MAP_ACTION, "then:", NULL, 0, 0, NULL, &scope_9_entries[0], isActive_kcg_bool_kcg_true, &scope_11, 1, 2}
};
static const MappingScope scope_9 = {
  "CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_PkgIfBlock1:",
  scope_9_entries, 3,
};

/* CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_Pkg */
static const MappingEntry scope_8_entries[12] = {
  /* 0 */ { MAP_OUTPUT, "BGs_out", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, BGs_out), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 11},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs 1", NULL, sizeof(outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_53, 1, 0},
  /* 2 */ { MAP_IF, "IfBlock1:", NULL, 0, 0, NULL, NULL, NULL, &scope_9, 1, 1},
  /* 3 */ { MAP_LOCAL, "_L1", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L1), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 6},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 5 */ { MAP_LOCAL, "_L15", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L15), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 9},
  /* 6 */ { MAP_LOCAL, "_L16", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L16), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 10},
  /* 7 */ { MAP_LOCAL, "_L2", NULL, sizeof(kcg_bool), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L2), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 8 */ { MAP_LOCAL, "_L3", NULL, sizeof(BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L3), &_Type_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, NULL, NULL, &scope_150, 1, 4},
  /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, _L8), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 7},
  /* 10 */ { MAP_LOCAL, "passedLinkedBGsCount", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, passedLinkedBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 2},
  /* 11 */ { MAP_LOCAL, "passedUnlinkedBGsCount", NULL, sizeof(kcg_int), offsetof(outC_delDispensableBGs_CalculateTrainPosition_Pkg, passedUnlinkedBGsCount), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 3}
};
static const MappingScope scope_8 = {
  "CalculateTrainPosition_Pkg::delDispensableBGs/ delDispensableBGs_CalculateTrainPosition_Pkg",
  scope_8_entries, 12,
};

/* CalculateTrainPosition_Pkg::calculateTrainPositionInfo/ calculateTrainPositionInfo_CalculateTrainPosition_Pkg */
static const MappingEntry scope_7_entries[39] = {
  /* 0 */ { MAP_LOCAL, "@kcg5", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, init), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 6},
  /* 1 */ { MAP_LOCAL, "@kcg6", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, tmp4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 35},
  /* 2 */ { MAP_LOCAL, "@kcg7", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, tmp), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 36},
  /* 3 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::overlapOf_2_Locations 1", NULL, sizeof(outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _3_Context_1), NULL, NULL, NULL, &scope_49, 1, 9},
  /* 4 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG 1", NULL, sizeof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, Context_1), NULL, &scope_7_entries[1], isActive_kcg_bool_kcg_true, &scope_52, 1, 10},
  /* 5 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG 2", NULL, sizeof(outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, Context_2), NULL, &scope_7_entries[2], isActive_kcg_bool_kcg_true, &scope_52, 1, 11},
  /* 6 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG 1", NULL, sizeof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_45, 1, 7},
  /* 7 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG 2", NULL, sizeof(outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _2_Context_2), NULL, NULL, NULL, &scope_45, 1, 8},
  /* 8 */ { MAP_LOCAL, "_L1", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L1), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 12},
  /* 9 */ { MAP_LOCAL, "_L10", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L10), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 16},
  /* 10 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 11 */ { MAP_LOCAL, "_L12", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L12), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18},
  /* 12 */ { MAP_LOCAL, "_L13", NULL, sizeof(OdometryLocations_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L13), &_Type_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_138, 1, 19},
  /* 13 */ { MAP_LOCAL, "_L14", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L14), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 20},
  /* 14 */ { MAP_LOCAL, "_L15", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L15), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 21},
  /* 15 */ { MAP_LOCAL, "_L17@mem", NULL, sizeof(kcg_int), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L17), &_Type_kcg_int_Utils, NULL, NULL, NULL, 0, 0},
  /* 16 */ { MAP_LOCAL, "_L18@mem", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L18), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1},
  /* 17 */ { MAP_LOCAL, "_L19@mem", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L19), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 2},
  /* 18 */ { MAP_LOCAL, "_L20", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L20), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 22},
  /* 19 */ { MAP_LOCAL, "_L22", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L22), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 23},
  /* 20 */ { MAP_LOCAL, "_L23@mem", NULL, sizeof(kcg_int), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L23), &_Type_kcg_int_Utils, NULL, NULL, NULL, 0, 3},
  /* 21 */ { MAP_LOCAL, "_L24@mem", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L24), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 4},
  /* 22 */ { MAP_LOCAL, "_L25@mem", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L25), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 5},
  /* 23 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L26), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 24 */ { MAP_LOCAL, "_L27", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L27), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25},
  /* 25 */ { MAP_LOCAL, "_L28", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L28), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 26},
  /* 26 */ { MAP_LOCAL, "_L30", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L30), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 27},
  /* 27 */ { MAP_LOCAL, "_L31", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L31), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 28},
  /* 28 */ { MAP_LOCAL, "_L32", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L32), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 29 */ { MAP_LOCAL, "_L33", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L33), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 30 */ { MAP_LOCAL, "_L34", NULL, sizeof(kcg_int), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L34), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 31},
  /* 31 */ { MAP_LOCAL, "_L35", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L35), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32},
  /* 32 */ { MAP_LOCAL, "_L36", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L36), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 34},
  /* 33 */ { MAP_LOCAL, "_L37", NULL, sizeof(kcg_int), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L37), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 33},
  /* 34 */ { MAP_LOCAL, "_L7", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L7), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 13},
  /* 35 */ { MAP_LOCAL, "_L8", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L8), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 14},
  /* 36 */ { MAP_LOCAL, "_L9", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, _L9), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 15},
  /* 37 */ { MAP_OUTPUT, "positionCalculationNotConsistent", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, positionCalculationNotConsistent), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 38},
  /* 38 */ { MAP_OUTPUT, "trainPositionInfo", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg, trainPositionInfo), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 37}
};
static const MappingScope scope_7 = {
  "CalculateTrainPosition_Pkg::calculateTrainPositionInfo/ calculateTrainPositionInfo_CalculateTrainPosition_Pkg",
  scope_7_entries, 39,
};

/* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes/ calculateTrainpositionAttributes_CalculateTrainPosition_Pkg */
static const MappingEntry scope_6_entries[54] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::add_2_Distances 1", NULL, sizeof(outC_add_2_Distances_BasicLocationFunctions_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_26, 1, 0},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG", NULL, sizeof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, Context_nidC_nidBG_2_NIDLRBG), NULL, NULL, NULL, &scope_27, 1, 1},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG 1", NULL, sizeof(outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _3_Context_1), NULL, NULL, NULL, &scope_27, 1, 2},
  /* 3 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG 1", NULL, sizeof(outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_39, 1, 4},
  /* 4 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef 1", NULL, sizeof(outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_28, 1, 3},
  /* 5 */ { MAP_LOCAL, "_L205", NULL, sizeof(trainPosition_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L205), &_Type_trainPosition_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_144, 1, 5},
  /* 6 */ { MAP_LOCAL, "_L218", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L218), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 6},
  /* 7 */ { MAP_LOCAL, "_L219", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L219), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 7},
  /* 8 */ { MAP_LOCAL, "_L220", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L220), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 9 */ { MAP_LOCAL, "_L221", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L221), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 10 */ { MAP_LOCAL, "_L223", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L223), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 11 */ { MAP_LOCAL, "_L224", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L224), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 11},
  /* 12 */ { MAP_LOCAL, "_L225", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L225), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 12},
  /* 13 */ { MAP_LOCAL, "_L227", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L227), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 14 */ { MAP_LOCAL, "_L229", NULL, sizeof(NID_BG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L229), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 14},
  /* 15 */ { MAP_LOCAL, "_L230", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L230), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 15},
  /* 16 */ { MAP_LOCAL, "_L234", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L234), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 16},
  /* 17 */ { MAP_LOCAL, "_L237", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L237), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 17},
  /* 18 */ { MAP_LOCAL, "_L242", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L242), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18},
  /* 19 */ { MAP_LOCAL, "_L243", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L243), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 19},
  /* 20 */ { MAP_LOCAL, "_L247", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L247), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 22},
  /* 21 */ { MAP_LOCAL, "_L248", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L248), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 21},
  /* 22 */ { MAP_LOCAL, "_L249", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L249), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 20},
  /* 23 */ { MAP_LOCAL, "_L260", NULL, sizeof(NID_LRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L260), &_Type_NID_LRBG_Utils, NULL, NULL, NULL, 1, 23},
  /* 24 */ { MAP_LOCAL, "_L261", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L261), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 25 */ { MAP_LOCAL, "_L262", NULL, sizeof(NID_C), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L262), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 25},
  /* 26 */ { MAP_LOCAL, "_L263", NULL, sizeof(NID_BG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L263), &_Type_NID_BG_Utils, NULL, NULL, NULL, 1, 26},
  /* 27 */ { MAP_LOCAL, "_L264", NULL, sizeof(NID_LRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L264), &_Type_NID_LRBG_Utils, NULL, NULL, NULL, 1, 27},
  /* 28 */ { MAP_LOCAL, "_L265", NULL, sizeof(NID_C), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L265), &_Type_NID_C_Utils, NULL, NULL, NULL, 1, 28},
  /* 29 */ { MAP_LOCAL, "_L266", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L266), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 30 */ { MAP_LOCAL, "_L267", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L267), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 30},
  /* 31 */ { MAP_LOCAL, "_L268", NULL, sizeof(NID_LRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L268), &_Type_NID_LRBG_Utils, NULL, NULL, NULL, 1, 31},
  /* 32 */ { MAP_LOCAL, "_L269", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L269), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 32},
  /* 33 */ { MAP_LOCAL, "_L270", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L270), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 33},
  /* 34 */ { MAP_LOCAL, "_L274", NULL, sizeof(Q_DIRLRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L274), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 34},
  /* 35 */ { MAP_LOCAL, "_L275", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L275), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 35},
  /* 36 */ { MAP_LOCAL, "_L276", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L276), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 36},
  /* 37 */ { MAP_LOCAL, "_L301", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L301), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 37},
  /* 38 */ { MAP_LOCAL, "_L302", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L302), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 38},
  /* 39 */ { MAP_LOCAL, "_L303", NULL, sizeof(Speed_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L303), &_Type_Speed_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 39},
  /* 40 */ { MAP_LOCAL, "_L304", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L304), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 40},
  /* 41 */ { MAP_LOCAL, "_L305", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L305), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 41},
  /* 42 */ { MAP_LOCAL, "_L306", NULL, sizeof(Q_DLRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L306), &_Type_Q_DLRBG_Utils, NULL, NULL, NULL, 1, 42},
  /* 43 */ { MAP_LOCAL, "_L307", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L307), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 43},
  /* 44 */ { MAP_LOCAL, "_L308", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L308), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 44},
  /* 45 */ { MAP_LOCAL, "_L309", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L309), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 45},
  /* 46 */ { MAP_LOCAL, "_L310", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L310), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 46},
  /* 47 */ { MAP_LOCAL, "_L311", NULL, sizeof(Q_DIRLRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L311), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 47},
  /* 48 */ { MAP_LOCAL, "_L312", NULL, sizeof(Q_DIRLRBG), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L312), &_Type_Q_DIRLRBG_Utils, NULL, NULL, NULL, 1, 48},
  /* 49 */ { MAP_LOCAL, "_L313", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L313), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 49},
  /* 50 */ { MAP_LOCAL, "_L314", NULL, sizeof(Q_DIRTRAIN), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L314), &_Type_Q_DIRTRAIN_Utils, NULL, NULL, NULL, 1, 50},
  /* 51 */ { MAP_LOCAL, "_L315", NULL, sizeof(kcg_int), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L315), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 51},
  /* 52 */ { MAP_LOCAL, "_L316", NULL, sizeof(kcg_int), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, _L316), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 52},
  /* 53 */ { MAP_OUTPUT, "trainPosition", NULL, sizeof(trainPosition_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg, trainPosition), &_Type_trainPosition_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_144, 1, 53}
};
static const MappingScope scope_6 = {
  "CalculateTrainPosition_Pkg::calculateTrainpositionAttributes/ calculateTrainpositionAttributes_CalculateTrainPosition_Pkg",
  scope_6_entries, 54,
};

/* CalculateTrainPosition_Pkg::calculateBGLocations/ calculateBGLocations_CalculateTrainPosition_Pkg */
static const MappingEntry scope_5_entries[37] = {
  /* 0 */ { MAP_LOCAL, "@kcg4", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, tmp), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 34},
  /* 1 */ { MAP_OUTPUT, "BGs", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, BGs), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 35},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_relocation_Pkg::improve_BG_locations 1", NULL, sizeof(outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _2_Context_1), NULL, &scope_5_entries[0], isActive_kcg_bool_kcg_true, &scope_25, 1, 3},
  /* 3 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::genPassedBG_SeqNo 2", NULL, sizeof(outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, Context_2), NULL, NULL, NULL, &scope_24, 1, 2},
  /* 4 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::passing_a_BG 1", NULL, sizeof(outC_passing_a_BG_CalculateTrainPosition_Pkg), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _1_Context_1), NULL, NULL, NULL, &scope_22, 1, 0},
  /* 5 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::prevPassedLinkedBG 1", NULL, sizeof(outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, Context_1), NULL, NULL, NULL, &scope_23, 1, 1},
  /* 6 */ { MAP_LOCAL, "_L137", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L137), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 11},
  /* 7 */ { MAP_LOCAL, "_L156", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L156), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 8 */ { MAP_LOCAL, "_L157", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L157), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 13},
  /* 9 */ { MAP_LOCAL, "_L225", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L225), &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 14},
  /* 10 */ { MAP_LOCAL, "_L298", NULL, sizeof(kcg_int), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L298), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 16},
  /* 11 */ { MAP_LOCAL, "_L299", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L299), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 24},
  /* 12 */ { MAP_LOCAL, "_L301", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L301), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L324", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L324), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 17},
  /* 14 */ { MAP_LOCAL, "_L346", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L346), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 18},
  /* 15 */ { MAP_LOCAL, "_L347", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L347), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 19},
  /* 16 */ { MAP_LOCAL, "_L349", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L349), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 20},
  /* 17 */ { MAP_LOCAL, "_L351", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L351), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 21},
  /* 18 */ { MAP_LOCAL, "_L352", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L352), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 22},
  /* 19 */ { MAP_LOCAL, "_L353", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L353), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 23},
  /* 20 */ { MAP_LOCAL, "_L354", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L354), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 25},
  /* 21 */ { MAP_LOCAL, "_L355", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L355), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 26},
  /* 22 */ { MAP_LOCAL, "_L356", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L356), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 27},
  /* 23 */ { MAP_LOCAL, "_L357", NULL, sizeof(Q_LINK), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L357), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 30},
  /* 24 */ { MAP_LOCAL, "_L358", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L358), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 29},
  /* 25 */ { MAP_LOCAL, "_L359", NULL, sizeof(Q_LINK), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L359), &_Type_Q_LINK_Utils, NULL, NULL, NULL, 1, 28},
  /* 26 */ { MAP_LOCAL, "_L360", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L360), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 31},
  /* 27 */ { MAP_LOCAL, "_L361", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L361), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 32},
  /* 28 */ { MAP_LOCAL, "_L362", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L362), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 33},
  /* 29 */ { MAP_LOCAL, "_L87", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L87), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 7},
  /* 30 */ { MAP_LOCAL, "_L88", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L88), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 8},
  /* 31 */ { MAP_LOCAL, "_L89", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L89), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 9},
  /* 32 */ { MAP_LOCAL, "_L90", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L90), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 10},
  /* 33 */ { MAP_LOCAL, "_L92", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, _L92), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 6},
  /* 34 */ { MAP_OUTPUT, "errors", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, errors), &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 36},
  /* 35 */ { MAP_LOCAL, "outOfMemSpace", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, outOfMemSpace), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 36 */ { MAP_LOCAL, "passedBG_notFoundWhereExpected", NULL, sizeof(kcg_bool), offsetof(outC_calculateBGLocations_CalculateTrainPosition_Pkg, passedBG_notFoundWhereExpected), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5}
};
static const MappingScope scope_5 = {
  "CalculateTrainPosition_Pkg::calculateBGLocations/ calculateBGLocations_CalculateTrainPosition_Pkg",
  scope_5_entries, 37,
};

/* ctp_t_pck::t_engine::observeBG/ observeBG_ctp_t_pck_t_engine */
static const MappingEntry scope_4_entries[25] = {
  /* 0 */ { MAP_INSTANCE, "BasicLocationFunctions_Pkg::sub_2_distances 1", NULL, sizeof(outC_sub_2_distances_BasicLocationFunctions_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _1_Context_1), NULL, NULL, NULL, &scope_21, 1, 1},
  /* 1 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id 1", NULL, sizeof(outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, Context_1), NULL, NULL, NULL, &scope_20, 1, 0},
  /* 2 */ { MAP_LOCAL, "_L1", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L1), &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 2},
  /* 3 */ { MAP_LOCAL, "_L10", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L10), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 7},
  /* 4 */ { MAP_LOCAL, "_L11", NULL, sizeof(kcg_bool), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L11), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 8},
  /* 5 */ { MAP_LOCAL, "_L13", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L13), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 9},
  /* 6 */ { MAP_LOCAL, "_L14", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L14), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 10},
  /* 7 */ { MAP_LOCAL, "_L16", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L16), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 11},
  /* 8 */ { MAP_LOCAL, "_L2", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L2), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 3},
  /* 9 */ { MAP_LOCAL, "_L20", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L20), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 14},
  /* 10 */ { MAP_LOCAL, "_L21", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L21), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 13},
  /* 11 */ { MAP_LOCAL, "_L22", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L22), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 12},
  /* 12 */ { MAP_LOCAL, "_L23", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L23), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 15},
  /* 13 */ { MAP_LOCAL, "_L24", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L24), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 16},
  /* 14 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L25), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 17},
  /* 15 */ { MAP_LOCAL, "_L26", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L26), &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 18},
  /* 16 */ { MAP_LOCAL, "_L27", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L27), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 19},
  /* 17 */ { MAP_LOCAL, "_L28", NULL, sizeof(kcg_int), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L28), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 20},
  /* 18 */ { MAP_LOCAL, "_L29", NULL, sizeof(kcg_int), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L29), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 21},
  /* 19 */ { MAP_LOCAL, "_L7", NULL, sizeof(kcg_int), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L7), &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 6},
  /* 20 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L8), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 5},
  /* 21 */ { MAP_LOCAL, "_L9", NULL, sizeof(kcg_bool), offsetof(outC_observeBG_ctp_t_pck_t_engine, _L9), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 4},
  /* 22 */ { MAP_OUTPUT, "loc_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, loc_max), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 24},
  /* 23 */ { MAP_OUTPUT, "loc_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, loc_min), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 22},
  /* 24 */ { MAP_OUTPUT, "loc_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_observeBG_ctp_t_pck_t_engine, loc_nom), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 23}
};
static const MappingScope scope_4 = {
  "ctp_t_pck::t_engine::observeBG/ observeBG_ctp_t_pck_t_engine",
  scope_4_entries, 25,
};

/* ctp_t_pck::t_engine::stimulator/ stimulator_ctp_t_pck_t_engine */
static const MappingEntry scope_3_entries[18] = {
  /* 0 */ { MAP_LOCAL, "_L1", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L1), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 5},
  /* 1 */ { MAP_LOCAL, "_L10", NULL, sizeof(odometryFactors_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L10), &_Type_odometryFactors_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_158, 1, 13},
  /* 2 */ { MAP_LOCAL, "_L11", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L11), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 14},
  /* 3 */ { MAP_LOCAL, "_L2", NULL, sizeof(T_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L2), &_Type_T_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 4},
  /* 4 */ { MAP_LOCAL, "_L3", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L3), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 6},
  /* 5 */ { MAP_LOCAL, "_L4", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L4), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 7},
  /* 6 */ { MAP_LOCAL, "_L5", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L5), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 8},
  /* 7 */ { MAP_LOCAL, "_L6", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L6), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 9},
  /* 8 */ { MAP_LOCAL, "_L7", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L7), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 10},
  /* 9 */ { MAP_LOCAL, "_L8", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L8), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 11},
  /* 10 */ { MAP_LOCAL, "_L9", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _L9), &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 12},
  /* 11 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::genLocation 1", NULL, sizeof(outC_genLocation_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, Context_1), NULL, NULL, NULL, &scope_12, 1, 0},
  /* 12 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::genOdometry 1", NULL, sizeof(outC_genOdometry_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _1_Context_1), NULL, NULL, NULL, &scope_17, 1, 1},
  /* 13 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::genPassedBG 1", NULL, sizeof(outC_genPassedBG_ctp_t_pck_t_engine), offsetof(outC_stimulator_ctp_t_pck_t_engine, _2_Context_1), NULL, NULL, NULL, &scope_19, 1, 2},
  /* 14 */ { MAP_OUTPUT, "odometry", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, odometry), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 16},
  /* 15 */ { MAP_OUTPUT, "passedBG", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, passedBG), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 17},
  /* 16 */ { MAP_OUTPUT, "pos_true", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, pos_true), &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 15},
  /* 17 */ { MAP_PROBE, "truePosition", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), offsetof(outC_stimulator_ctp_t_pck_t_engine, truePosition), &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 3}
};
static const MappingScope scope_3 = {
  "ctp_t_pck::t_engine::stimulator/ stimulator_ctp_t_pck_t_engine",
  scope_3_entries, 18,
};

/* CalculateTrainPosition_Pkg::calculateTrainPosition/ calculateTrainPosition_CalculateTrainPosition_Pkg */
static const MappingEntry scope_2_entries[33] = {
  /* 0 */ { MAP_LOCAL, "@kcg1", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, init), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 4},
  /* 1 */ { MAP_LOCAL, "@kcg2", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, tmp4), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 27},
  /* 2 */ { MAP_LOCAL, "@kcg3", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, tmp), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 28},
  /* 3 */ { MAP_OUTPUT, "BGs", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, BGs), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 31},
  /* 4 */ { MAP_LOCAL, "BGs_loc@mem", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, BGs_loc), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 0, 0},
  /* 5 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::calculateBGLocations 1", NULL, sizeof(outC_calculateBGLocations_CalculateTrainPosition_Pkg), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, Context_1), NULL, &scope_2_entries[1], isActive_kcg_bool_kcg_true, &scope_5, 1, 5},
  /* 6 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::calculateTrainPositionInfo 1", NULL, sizeof(outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _2_Context_1), NULL, NULL, NULL, &scope_7, 1, 7},
  /* 7 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::calculateTrainpositionAttributes 1", NULL, sizeof(outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _3_Context_1), NULL, NULL, NULL, &scope_6, 1, 6},
  /* 8 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::delDispensableBGs 1", NULL, sizeof(outC_delDispensableBGs_CalculateTrainPosition_Pkg), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _1_Context_1), NULL, &scope_2_entries[2], isActive_kcg_bool_kcg_true, &scope_8, 1, 8},
  /* 9 */ { MAP_LOCAL, "_L198@mem", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L198), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 0, 2},
  /* 10 */ { MAP_LOCAL, "_L199@mem", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L199), &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 0, 1},
  /* 11 */ { MAP_LOCAL, "_L200", NULL, sizeof(trainPosition_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L200), &_Type_trainPosition_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_144, 1, 9},
  /* 12 */ { MAP_LOCAL, "_L201", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L201), &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 10},
  /* 13 */ { MAP_LOCAL, "_L202", NULL, sizeof(passedBG_T_BG_Types_Pkg), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L202), &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 11},
  /* 14 */ { MAP_LOCAL, "_L203", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L203), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 12},
  /* 15 */ { MAP_LOCAL, "_L204", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L204), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 13},
  /* 16 */ { MAP_LOCAL, "_L205", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L205), &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 14},
  /* 17 */ { MAP_LOCAL, "_L207", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L207), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 15},
  /* 18 */ { MAP_LOCAL, "_L210", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L210), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 16},
  /* 19 */ { MAP_LOCAL, "_L215", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L215), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 18},
  /* 20 */ { MAP_LOCAL, "_L216", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L216), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 17},
  /* 21 */ { MAP_LOCAL, "_L217", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L217), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 19},
  /* 22 */ { MAP_LOCAL, "_L227", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L227), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 21},
  /* 23 */ { MAP_LOCAL, "_L228", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L228), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 20},
  /* 24 */ { MAP_LOCAL, "_L229", NULL, sizeof(kcg_bool), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L229), &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 22},
  /* 25 */ { MAP_LOCAL, "_L230", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L230), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 23},
  /* 26 */ { MAP_LOCAL, "_L231", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L231), &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 24},
  /* 27 */ { MAP_LOCAL, "_L232", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L232), &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 25},
  /* 28 */ { MAP_LOCAL, "_L233@mem", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L233), &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 0, 3},
  /* 29 */ { MAP_LOCAL, "_L234", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, _L234), &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 26},
  /* 30 */ { MAP_OUTPUT, "errors", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, errors), &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 32},
  /* 31 */ { MAP_OUTPUT, "trainPosition", NULL, sizeof(trainPosition_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, trainPosition), &_Type_trainPosition_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_144, 1, 29},
  /* 32 */ { MAP_OUTPUT, "trainPositionInfo", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), offsetof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg, trainPositionInfo), &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 30}
};
static const MappingScope scope_2 = {
  "CalculateTrainPosition_Pkg::calculateTrainPosition/ calculateTrainPosition_CalculateTrainPosition_Pkg",
  scope_2_entries, 33,
};

/* ctp_t_pck::vincent_scenario_07/ vincent_scenario_07_ctp_t_pck */
static const MappingEntry scope_1_entries[76] = {
  /* 0 */ { MAP_LOCAL, "@kcg0", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx.init, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 0, 1},
  /* 1 */ { MAP_OUTPUT, "BGs", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx.BGs, &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 55},
  /* 2 */ { MAP_INSTANCE, "CalculateTrainPosition_Pkg::calculateTrainPosition 1", NULL, sizeof(outC_calculateTrainPosition_CalculateTrainPosition_Pkg), (size_t)&outputs_ctx._1_Context_1, NULL, NULL, NULL, &scope_2, 1, 2},
  /* 3 */ { MAP_LOCAL, "LRBG@mem", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx.LRBG, &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 0, 0},
  /* 4 */ { MAP_LOCAL, "_L1", NULL, sizeof(odometry_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L1, &_Type_odometry_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_148, 1, 25},
  /* 5 */ { MAP_LOCAL, "_L10", NULL, sizeof(passedBG_T_BG_Types_Pkg), (size_t)&outputs_ctx._L10, &_Type_passedBG_T_BG_Types_Pkg_Utils, NULL, NULL, &scope_141, 1, 24},
  /* 6 */ { MAP_LOCAL, "_L11", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L11, &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 17},
  /* 7 */ { MAP_LOCAL, "_L13", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L13, &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 18},
  /* 8 */ { MAP_LOCAL, "_L14", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L14, &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 19},
  /* 9 */ { MAP_LOCAL, "_L18", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L18, &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 22},
  /* 10 */ { MAP_LOCAL, "_L19", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L19, &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 21},
  /* 11 */ { MAP_LOCAL, "_L2", NULL, sizeof(trainPosition_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L2, &_Type_trainPosition_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_144, 1, 13},
  /* 12 */ { MAP_LOCAL, "_L20", NULL, sizeof(L_internal_Type_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L20, &_Type_L_internal_Type_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 20},
  /* 13 */ { MAP_LOCAL, "_L21", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L21, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 23},
  /* 14 */ { MAP_LOCAL, "_L22", NULL, sizeof(kcg_int), (size_t)&outputs_ctx._L22, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 26},
  /* 15 */ { MAP_LOCAL, "_L23", NULL, sizeof(kcg_int), (size_t)&outputs_ctx._L23, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 27},
  /* 16 */ { MAP_LOCAL, "_L24", NULL, sizeof(kcg_int), (size_t)&outputs_ctx._L24, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 28},
  /* 17 */ { MAP_LOCAL, "_L25", NULL, sizeof(kcg_int), (size_t)&outputs_ctx._L25, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 29},
  /* 18 */ { MAP_LOCAL, "_L26", NULL, sizeof(kcg_int), (size_t)&outputs_ctx._L26, &_Type_kcg_int_Utils, NULL, NULL, NULL, 1, 30},
  /* 19 */ { MAP_LOCAL, "_L29", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L29, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 33},
  /* 20 */ { MAP_LOCAL, "_L3", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L3, &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 12},
  /* 21 */ { MAP_LOCAL, "_L30", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L30, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 32},
  /* 22 */ { MAP_LOCAL, "_L31", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L31, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 31},
  /* 23 */ { MAP_LOCAL, "_L4", NULL, sizeof(positionedBGs_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L4, &_Type_positionedBGs_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_146, 1, 11},
  /* 24 */ { MAP_LOCAL, "_L5", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L5, &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 10},
  /* 25 */ { MAP_LOCAL, "_L52", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L52, &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 34},
  /* 26 */ { MAP_LOCAL, "_L53", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L53, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 35},
  /* 27 */ { MAP_LOCAL, "_L54", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L54, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 36},
  /* 28 */ { MAP_LOCAL, "_L55", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L55, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 37},
  /* 29 */ { MAP_LOCAL, "_L59", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L59, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 38},
  /* 30 */ { MAP_LOCAL, "_L60", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L60, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 39},
  /* 31 */ { MAP_LOCAL, "_L61", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L61, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 40},
  /* 32 */ { MAP_LOCAL, "_L62", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L62, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 41},
  /* 33 */ { MAP_LOCAL, "_L63", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L63, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 42},
  /* 34 */ { MAP_LOCAL, "_L64", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L64, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 43},
  /* 35 */ { MAP_LOCAL, "_L65", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L65, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 44},
  /* 36 */ { MAP_LOCAL, "_L66", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L66, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 45},
  /* 37 */ { MAP_LOCAL, "_L67", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx._L67, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 46},
  /* 38 */ { MAP_LOCAL, "_L68", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L68, &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 47},
  /* 39 */ { MAP_LOCAL, "_L69", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L69, &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 48},
  /* 40 */ { MAP_LOCAL, "_L7", NULL, sizeof(positionedBG_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L7, &_Type_positionedBG_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_142, 1, 14},
  /* 41 */ { MAP_LOCAL, "_L70", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L70, &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 49},
  /* 42 */ { MAP_LOCAL, "_L71", NULL, sizeof(genPassedBG_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L71, &_Type_genPassedBG_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_156, 1, 50},
  /* 43 */ { MAP_LOCAL, "_L73", NULL, sizeof(genPassedBGs_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L73, &_Type_genPassedBGs_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_157, 1, 51},
  /* 44 */ { MAP_LOCAL, "_L74", NULL, sizeof(odometryFactors_T_ctp_t_pck_t_engine), (size_t)&outputs_ctx._L74, &_Type_odometryFactors_T_ctp_t_pck_t_engine_Utils, NULL, NULL, &scope_158, 1, 52},
  /* 45 */ { MAP_LOCAL, "_L8", NULL, sizeof(kcg_bool), (size_t)&outputs_ctx._L8, &_Type_kcg_bool_Utils, NULL, NULL, NULL, 1, 15},
  /* 46 */ { MAP_LOCAL, "_L9", NULL, sizeof(trainProperties_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx._L9, &_Type_trainProperties_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_147, 1, 16},
  /* 47 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::observeBG 1", NULL, sizeof(outC_observeBG_ctp_t_pck_t_engine), (size_t)&outputs_ctx._2_Context_1, NULL, NULL, NULL, &scope_4, 1, 4},
  /* 48 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::observeBG 2", NULL, sizeof(outC_observeBG_ctp_t_pck_t_engine), (size_t)&outputs_ctx.Context_2, NULL, NULL, NULL, &scope_4, 1, 5},
  /* 49 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::observeBG 3", NULL, sizeof(outC_observeBG_ctp_t_pck_t_engine), (size_t)&outputs_ctx.Context_3, NULL, NULL, NULL, &scope_4, 1, 6},
  /* 50 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::observeBG 4", NULL, sizeof(outC_observeBG_ctp_t_pck_t_engine), (size_t)&outputs_ctx.Context_4, NULL, NULL, NULL, &scope_4, 1, 7},
  /* 51 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::observeBG 5", NULL, sizeof(outC_observeBG_ctp_t_pck_t_engine), (size_t)&outputs_ctx.Context_5, NULL, NULL, NULL, &scope_4, 1, 8},
  /* 52 */ { MAP_INSTANCE, "ctp_t_pck::t_engine::stimulator 1", NULL, sizeof(outC_stimulator_ctp_t_pck_t_engine), (size_t)&outputs_ctx.Context_1, NULL, NULL, NULL, &scope_3, 1, 3},
  /* 53 */ { MAP_OUTPUT, "errors", NULL, sizeof(positionErrors_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx.errors, &_Type_positionErrors_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_145, 1, 56},
  /* 54 */ { MAP_OUTPUT, "locBG_001_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_001_max, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 63},
  /* 55 */ { MAP_OUTPUT, "locBG_001_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_001_min, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 61},
  /* 56 */ { MAP_OUTPUT, "locBG_001_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_001_nom, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 62},
  /* 57 */ { MAP_OUTPUT, "locBG_002_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_002_max, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 66},
  /* 58 */ { MAP_OUTPUT, "locBG_002_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_002_min, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 64},
  /* 59 */ { MAP_OUTPUT, "locBG_002_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_002_nom, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 65},
  /* 60 */ { MAP_OUTPUT, "locBG_003_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_003_max, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 69},
  /* 61 */ { MAP_OUTPUT, "locBG_003_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_003_min, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 67},
  /* 62 */ { MAP_OUTPUT, "locBG_003_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_003_nom, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 68},
  /* 63 */ { MAP_OUTPUT, "locBG_004_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_004_max, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 72},
  /* 64 */ { MAP_OUTPUT, "locBG_004_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_004_min, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 70},
  /* 65 */ { MAP_OUTPUT, "locBG_004_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_004_nom, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 71},
  /* 66 */ { MAP_OUTPUT, "locBG_005_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_005_max, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 75},
  /* 67 */ { MAP_OUTPUT, "locBG_005_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_005_min, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 73},
  /* 68 */ { MAP_OUTPUT, "locBG_005_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.locBG_005_nom, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 74},
  /* 69 */ { MAP_OUTPUT, "pos_max", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.pos_max, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 60},
  /* 70 */ { MAP_OUTPUT, "pos_min", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.pos_min, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 58},
  /* 71 */ { MAP_OUTPUT, "pos_nom", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.pos_nom, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 59},
  /* 72 */ { MAP_OUTPUT, "pos_true", NULL, sizeof(Location_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.pos_true, &_Type_Location_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, NULL, 1, 57},
  /* 73 */ { MAP_PROBE, "trainPos", NULL, sizeof(LocWithInAcc_T_Obu_BasicTypes_Pkg), (size_t)&outputs_ctx.trainPos, &_Type_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, NULL, NULL, &scope_135, 1, 9},
  /* 74 */ { MAP_OUTPUT, "trainPosition", NULL, sizeof(trainPosition_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx.trainPosition, &_Type_trainPosition_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_144, 1, 53},
  /* 75 */ { MAP_OUTPUT, "trainPositionInfo", NULL, sizeof(trainPositionInfo_T_TrainPosition_Types_Pck), (size_t)&outputs_ctx.trainPositionInfo, &_Type_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, NULL, NULL, &scope_143, 1, 54}
};
static const MappingScope scope_1 = {
  "ctp_t_pck::vincent_scenario_07/ vincent_scenario_07_ctp_t_pck",
  scope_1_entries, 76,
};

/*  */
static const MappingEntry scope_0_entries[1] = {
  /* 0 */ { MAP_ROOT, "ctp_t_pck::vincent_scenario_07", NULL, 0, 0, NULL, NULL, NULL, &scope_1, 1, 0}
};
static const MappingScope scope_0 = {
  "",
  scope_0_entries, 1,
};

const MappingScope* pTop = &scope_0;

