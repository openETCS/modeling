/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _KCG_CONSTS_H_
#define _KCG_CONSTS_H_

#include "kcg_types.h"

/* CalculateTrainPosition_Pkg::cTrainPosition_0 */
extern const trainPosition_T_TrainPosition_Types_Pck cTrainPosition_0_CalculateTrainPosition_Pkg;

/* BG_Types_Pkg::cMaxListBGs */
#define cMaxListBGs_BG_Types_Pkg 20

/* BG_Types_Pkg::cMaxDistanceBalisesInGroup */
extern const OdometryLocations_T_Obu_BasicTypes_Pkg cMaxDistanceBalisesInGroup_BG_Types_Pkg;

/* BG_Types_Pkg::cInvalidIndex */
#define cInvalidIndex_BG_Types_Pkg (- 1)

/* BG_Types_Pkg::cInitOrientation */
#define cInitOrientation_BG_Types_Pkg Q_DIRTRAIN_Unknown

/* BG_Types_Pkg::cemptyPosition */
extern const centerOfBalisePosition_T_BG_Types_Pkg cemptyPosition_BG_Types_Pkg;

/* BG_Types_Pkg::cemptyHeaderArray */
extern const TelegramArray_T_BG_Types_Pkg cemptyHeaderArray_BG_Types_Pkg;

/* BG_Types_Pkg::cEmptyHeader */
extern const TelegramHeader_T_BG_Types_Pkg cEmptyHeader_BG_Types_Pkg;

/* BG_Types_Pkg::cEmptyBGMessage */
extern const BG_Message_T_BG_Types_Pkg cEmptyBGMessage_BG_Types_Pkg;

/* BG_Types_Pkg::cEmpty_BaliseTlg */
extern const Telegram_T_BG_Types_Pkg cEmpty_BaliseTlg_BG_Types_Pkg;

/* BG_Types_Pkg::cAddInfo */
extern const AdditionalInformation_T_BG_Types_Pkg cAddInfo_BG_Types_Pkg;

/* BG_Types_Pkg::cEmptyPassedBG */
extern const passedBG_T_BG_Types_Pkg cEmptyPassedBG_BG_Types_Pkg;

/* BG_Types_Pkg::cMaxNoBalises */
#define cMaxNoBalises_BG_Types_Pkg 8

/* BG_Types_Pkg::cMaxNoOfLevelTransitionOrders */
#define cMaxNoOfLevelTransitionOrders_BG_Types_Pkg 4

/* ctp_t_pck::t_engine::cTrainProperties */
extern const trainProperties_T_TrainPosition_Types_Pck cTrainProperties_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cTrack_2_unlinkedBGs */
extern const genPassedBGs_T_ctp_t_pck_t_engine cTrack_2_unlinkedBGs_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cTrack_2_linkedBGs_withoutLinkingInfo */
extern const genPassedBGs_T_ctp_t_pck_t_engine cTrack_2_linkedBGs_withoutLinkingInfo_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cTrack_3_linkedBGs_withLinkingInfo */
extern const genPassedBGs_T_ctp_t_pck_t_engine cTrack_3_linkedBGs_withLinkingInfo_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cTrack_3_linkedBGs_2_unlinkedBGs */
extern const genPassedBGs_T_ctp_t_pck_t_engine cTrack_3_linkedBGs_2_unlinkedBGs_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cTrack_3_linkedBGs_2_unlinkedBGs_far */
extern const genPassedBGs_T_ctp_t_pck_t_engine cTrack_3_linkedBGs_2_unlinkedBGs_far_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cOdometryFactors */
extern const odometryFactors_T_ctp_t_pck_t_engine cOdometryFactors_ctp_t_pck_t_engine;

/* ctp_t_pck::t_engine::cNoOfGenPassedBGs */
#define cNoOfGenPassedBGs_ctp_t_pck_t_engine 10

/* CalculateTrainPosition_Pkg::cNoPositionErrors */
extern const positionErrors_T_TrainPosition_Types_Pck cNoPositionErrors_CalculateTrainPosition_Pkg;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::cNoRefPrevBGs */
extern const refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg cNoRefPrevBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

/* CalculateTrainPosition_Pkg::BG_relocation_Pkg::cNoLinkedBG_index */
extern const linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg cNoLinkedBG_index_CalculateTrainPosition_Pkg_BG_relocation_Pkg;

/* CalculateTrainPosition_Pkg::gp_functions_Pkg::noValidIndex */
#define noValidIndex_CalculateTrainPosition_Pkg_gp_functions_Pkg (- 1)

/* CalculateTrainPosition_Pkg::cNoPositionedBGs */
extern const positionedBGs_T_TrainPosition_Types_Pck cNoPositionedBGs_CalculateTrainPosition_Pkg;

/* CalculateTrainPosition_Pkg::cNoPassedBG */
extern const passedBG_T_BG_Types_Pkg cNoPassedBG_CalculateTrainPosition_Pkg;

/* TrainPosition_Types_Pck::cQLOCACC_resolution */
#define cQLOCACC_resolution_TrainPosition_Types_Pck 100

/* TrainPosition_Types_Pck::cQ_SCALE_10_cm_resolution */
#define cQ_SCALE_10_cm_resolution_TrainPosition_Types_Pck 10

/* TrainPosition_Types_Pck::cQ_SCALE_1_m_resolution */
#define cQ_SCALE_1_m_resolution_TrainPosition_Types_Pck 100

/* TrainPosition_Types_Pck::cQ_SCALE_10_m_resolution */
#define cQ_SCALE_10_m_resolution_TrainPosition_Types_Pck 1000

/* Obu_BasicTypes_Pkg::cLocWithInAcc_0 */
extern const LocWithInAcc_T_Obu_BasicTypes_Pkg cLocWithInAcc_0_Obu_BasicTypes_Pkg;

/* CalculateTrainPosition_Pkg::cNoInfoFromLinking */
extern const infoFromLinking_T_TrainPosition_Types_Pck cNoInfoFromLinking_CalculateTrainPosition_Pkg;

/* BG_Types_Pkg::cNID_LRBG_14Bits_Multiplicator */
#define cNID_LRBG_14Bits_Multiplicator_BG_Types_Pkg 16384

/* BG_Types_Pkg::cNID_BG_unknown */
#define cNID_BG_unknown_BG_Types_Pkg 16383

/* CalculateTrainPosition_Pkg::Pos_Pkg::cSpeed_0 */
#define cSpeed_0_CalculateTrainPosition_Pkg_Pos_Pkg 0

/* CalculateTrainPosition_Pkg::Pos_Pkg::cOdometryStartVal */
extern const odometry_T_Obu_BasicTypes_Pkg cOdometryStartVal_CalculateTrainPosition_Pkg_Pos_Pkg;

/* BG_Types_Pkg::cNID_LRBG_unknown */
#define cNID_LRBG_unknown_BG_Types_Pkg 16777215

/* Obu_BasicTypes_Pkg::cOdometryInitialValue */
extern const OdometryLocations_T_Obu_BasicTypes_Pkg cOdometryInitialValue_Obu_BasicTypes_Pkg;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::cEmptyPositionedBG */
extern const positionedBG_T_TrainPosition_Types_Pck cEmptyPositionedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

/* CalculateTrainPosition_Pkg::cNoPositionedBG */
extern const positionedBG_T_TrainPosition_Types_Pck cNoPositionedBG_CalculateTrainPosition_Pkg;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::cBGCounters_0 */
extern const BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg cBGCounters_0_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

/* CalculateTrainPosition_Pkg::BG_utilities_Pkg::cBG_find_0 */
extern const BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg cBG_find_0_CalculateTrainPosition_Pkg_BG_utilities_Pkg;

/* CalculateTrainPosition_Pkg::cNoValidIndex */
#define cNoValidIndex_CalculateTrainPosition_Pkg (- 1)

/* CalculateTrainPosition_Pkg::cNoOfAtLeast_8_LRBGs */
#define cNoOfAtLeast_8_LRBGs_CalculateTrainPosition_Pkg 3

/* CalculateTrainPosition_Pkg::cNoOfAtLeast_x_unlinkedBGs */
#define cNoOfAtLeast_x_unlinkedBGs_CalculateTrainPosition_Pkg 2

/* TrainPosition_Types_Pck::cMaxNoOfStoredBGs */
#define cMaxNoOfStoredBGs_TrainPosition_Types_Pck (2 * cMaxNoOfLinkedBGs_BG_Types_Pkg)

/* BG_Types_Pkg::cMaxNoOfLinkedBGs */
#define cMaxNoOfLinkedBGs_BG_Types_Pkg 4

#endif /* _KCG_CONSTS_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** kcg_consts.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

