/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:49
*************************************************************$ */

#include "kcg_types.h"

kcg_bool kcg_comp_array__13393(array__13393 *kcg_c1, array__13393 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 4; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13377(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13469(array__13469 *kcg_c1, array__13469 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 8; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13447(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13522(array__13522 *kcg_c1, array__13522 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 4; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13447(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13536(array__13536 *kcg_c1, array__13536 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 8; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13530(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13563(array__13563 *kcg_c1, array__13563 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 4; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13547(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13603(array__13603 *kcg_c1, array__13603 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 8; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13596(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13932(array__13932 *kcg_c1, array__13932 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13928(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13945(array__13945 *kcg_c1, array__13945 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13940(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__13990(array__13990 *kcg_c1, array__13990 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13986(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14175(array__14175 *kcg_c1, array__14175 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14166(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14206(array__14206 *kcg_c1, array__14206 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14197(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14296(array__14296 *kcg_c1, array__14296 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14287(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14327(array__14327 *kcg_c1, array__14327 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14320(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14355(array__14355 *kcg_c1, array__14355 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14349(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14381(array__14381 *kcg_c1, array__14381 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14376(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14424(array__14424 *kcg_c1, array__14424 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14418(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14444(array__14444 *kcg_c1, array__14444 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14439(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14481(array__14481 *kcg_c1, array__14481 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14472(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14510(array__14510 *kcg_c1, array__14510 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14505(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14525(array__14525 *kcg_c1, array__14525 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14518(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14559(array__14559 *kcg_c1, array__14559 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14554(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14609(array__14609 *kcg_c1, array__14609 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14603(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14655(array__14655 *kcg_c1, array__14655 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14648(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14670(array__14670 *kcg_c1, array__14670 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14663(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14696(array__14696 *kcg_c1, array__14696 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14690(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14730(array__14730 *kcg_c1, array__14730 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14723(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14770(array__14770 *kcg_c1, array__14770 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14763(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14835(array__14835 *kcg_c1, array__14835 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14825(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14863(array__14863 *kcg_c1, array__14863 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14858(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14876(array__14876 *kcg_c1, array__14876 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14871(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14893(array__14893 *kcg_c1, array__14893 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14884(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14905(array__14905 *kcg_c1, array__14905 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 33; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__14901(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__14975(array__14975 *kcg_c1, array__14975 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 1; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13447(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_array__15613(array__15613 *kcg_c1, array__15613 *kcg_c2)
{
  static kcg_bool kcg_equ;
  static kcg_int kcg_ci;
  
  kcg_equ = kcg_true;
  for (kcg_ci = 0; kcg_ci < 7; kcg_ci++) {
    kcg_equ = kcg_equ & kcg_comp_struct__13447(
        &(*kcg_c1)[kcg_ci],
        &(*kcg_c2)[kcg_ci]);
  }
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13377(struct__13377 *kcg_c1, struct__13377 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->q_locacc == kcg_c2->q_locacc);
  kcg_equ = kcg_equ & (kcg_c1->q_linkreaction == kcg_c2->q_linkreaction);
  kcg_equ = kcg_equ & (kcg_c1->q_linkorientation == kcg_c2->q_linkorientation);
  kcg_equ = kcg_equ & (kcg_c1->nid_bg == kcg_c2->nid_bg);
  kcg_equ = kcg_equ & (kcg_c1->nid_c == kcg_c2->nid_c);
  kcg_equ = kcg_equ & (kcg_c1->q_newcountry == kcg_c2->q_newcountry);
  kcg_equ = kcg_equ & (kcg_c1->d_link == kcg_c2->d_link);
  kcg_equ = kcg_equ & (kcg_c1->q_scale == kcg_c2->q_scale);
  kcg_equ = kcg_equ & (kcg_c1->l_packet == kcg_c2->l_packet);
  kcg_equ = kcg_equ & (kcg_c1->q_dir == kcg_c2->q_dir);
  kcg_equ = kcg_equ & (kcg_c1->nid_packet == kcg_c2->nid_packet);
  kcg_equ = kcg_equ & (kcg_c1->nid_LRBG == kcg_c2->nid_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13396(struct__13396 *kcg_c1, struct__13396 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->q_link == kcg_c2->q_link);
  kcg_equ = kcg_equ & (kcg_c1->nid_bg == kcg_c2->nid_bg);
  kcg_equ = kcg_equ & (kcg_c1->nid_c == kcg_c2->nid_c);
  kcg_equ = kcg_equ & (kcg_c1->m_mcount == kcg_c2->m_mcount);
  kcg_equ = kcg_equ & (kcg_c1->n_total == kcg_c2->n_total);
  kcg_equ = kcg_equ & (kcg_c1->q_media == kcg_c2->q_media);
  kcg_equ = kcg_equ & (kcg_c1->m_version == kcg_c2->m_version);
  kcg_equ = kcg_equ & (kcg_c1->q_updown == kcg_c2->q_updown);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13407(struct__13407 *kcg_c1, struct__13407 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->o_max == kcg_c2->o_max);
  kcg_equ = kcg_equ & (kcg_c1->o_min == kcg_c2->o_min);
  kcg_equ = kcg_equ & (kcg_c1->o_nominal == kcg_c2->o_nominal);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13413(struct__13413 *kcg_c1, struct__13413 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->d_max == kcg_c2->d_max);
  kcg_equ = kcg_equ & (kcg_c1->d_min == kcg_c2->d_min);
  kcg_equ = kcg_equ & (kcg_c1->nominal == kcg_c2->nominal);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13419(struct__13419 *kcg_c1, struct__13419 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->passingSpeed == kcg_c2->passingSpeed);
  kcg_equ = kcg_equ & (kcg_c1->trainRunningDirectionToBG ==
      kcg_c2->trainRunningDirectionToBG);
  kcg_equ = kcg_equ & (kcg_c1->trainOrientationToBG ==
      kcg_c2->trainOrientationToBG);
  kcg_equ = kcg_equ & (kcg_c1->noCoordinateSystemHasBeenAssigned ==
      kcg_c2->noCoordinateSystemHasBeenAssigned);
  kcg_equ = kcg_equ & kcg_comp_array__13393(
      &kcg_c1->linkedBGs,
      &kcg_c2->linkedBGs);
  kcg_equ = kcg_equ & kcg_comp_struct__13396(
      &kcg_c1->BG_Header,
      &kcg_c2->BG_Header);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->BG_centerDetectionInaccuraccuracies,
      &kcg_c2->BG_centerDetectionInaccuraccuracies);
  kcg_equ = kcg_equ & kcg_comp_struct__13407(
      &kcg_c1->odometrystamp,
      &kcg_c2->odometrystamp);
  kcg_equ = kcg_equ & (kcg_c1->timestamp == kcg_c2->timestamp);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13432(struct__13432 *kcg_c1, struct__13432 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->positionCalculation_inconsistent ==
      kcg_c2->positionCalculation_inconsistent);
  kcg_equ = kcg_equ & (kcg_c1->passedBG_notFoundWhereExpected ==
      kcg_c2->passedBG_notFoundWhereExpected);
  kcg_equ = kcg_equ & (kcg_c1->outOfMemSpace == kcg_c2->outOfMemSpace);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13438(struct__13438 *kcg_c1, struct__13438 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13377(
      &kcg_c1->linkingInfo,
      &kcg_c2->linkingInfo);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(&kcg_c1->d_link, &kcg_c2->d_link);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->expectedLocation,
      &kcg_c2->expectedLocation);
  kcg_equ = kcg_equ & (kcg_c1->nid_c_fromLinkingBG ==
      kcg_c2->nid_c_fromLinkingBG);
  kcg_equ = kcg_equ & (kcg_c1->nid_bg_fromLinkingBG ==
      kcg_c2->nid_bg_fromLinkingBG);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13447(struct__13447 *kcg_c1, struct__13447 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13419(
      &kcg_c1->infoFromPassing,
      &kcg_c2->infoFromPassing);
  kcg_equ = kcg_equ & kcg_comp_struct__13438(
      &kcg_c1->infoFromLinking,
      &kcg_c2->infoFromLinking);
  kcg_equ = kcg_equ & (kcg_c1->seqNoOnTrack == kcg_c2->seqNoOnTrack);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->location,
      &kcg_c2->location);
  kcg_equ = kcg_equ & (kcg_c1->q_link == kcg_c2->q_link);
  kcg_equ = kcg_equ & (kcg_c1->nid_bg == kcg_c2->nid_bg);
  kcg_equ = kcg_equ & (kcg_c1->nid_c == kcg_c2->nid_c);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13458(struct__13458 *kcg_c1, struct__13458 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->speed == kcg_c2->speed);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(
      &kcg_c1->lastPassedUnlinkedBG,
      &kcg_c2->lastPassedUnlinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(
      &kcg_c1->lastPassedLinkedBG,
      &kcg_c2->lastPassedLinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->trainPositionDerivedFromLastUnlinkedBG,
      &kcg_c2->trainPositionDerivedFromLastUnlinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->trainPositionDerivedFromLastLinkedBG,
      &kcg_c2->trainPositionDerivedFromLastLinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->trainPosition,
      &kcg_c2->trainPosition);
  kcg_equ = kcg_equ & (kcg_c1->timestamp == kcg_c2->timestamp);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13472(struct__13472 *kcg_c1, struct__13472 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->speed == kcg_c2->speed);
  kcg_equ = kcg_equ & (kcg_c1->trainRunningDirectionToLRBG ==
      kcg_c2->trainRunningDirectionToLRBG);
  kcg_equ = kcg_equ & (kcg_c1->trainOrientationToLRBG ==
      kcg_c2->trainOrientationToLRBG);
  kcg_equ = kcg_equ & (kcg_c1->nominalOrReverseToLRBG ==
      kcg_c2->nominalOrReverseToLRBG);
  kcg_equ = kcg_equ & (kcg_c1->nid_PrvLRB == kcg_c2->nid_PrvLRB);
  kcg_equ = kcg_equ & (kcg_c1->nid_LRBG == kcg_c2->nid_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->maxSafeFrontEndPostion ==
      kcg_c2->maxSafeFrontEndPostion);
  kcg_equ = kcg_equ & (kcg_c1->minSafeFrontEndPosition ==
      kcg_c2->minSafeFrontEndPosition);
  kcg_equ = kcg_equ & (kcg_c1->estimatedFrontEndPosition ==
      kcg_c2->estimatedFrontEndPosition);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->trainPosition,
      &kcg_c2->trainPosition);
  kcg_equ = kcg_equ & (kcg_c1->noCoordinateSystemHasBeenAssigned ==
      kcg_c2->noCoordinateSystemHasBeenAssigned);
  kcg_equ = kcg_equ & (kcg_c1->trainPositionIsUnknown ==
      kcg_c2->trainPositionIsUnknown);
  kcg_equ = kcg_equ & (kcg_c1->timestamp == kcg_c2->timestamp);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13489(struct__13489 *kcg_c1, struct__13489 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->centerDetectionAcc_DefaultValue,
      &kcg_c2->centerDetectionAcc_DefaultValue);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->locationAccuracy_DefaultValue,
      &kcg_c2->locationAccuracy_DefaultValue);
  kcg_equ = kcg_equ & (kcg_c1->locationAccuracy_NationalValue ==
      kcg_c2->locationAccuracy_NationalValue);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->d_frontend_2_rearend,
      &kcg_c2->d_frontend_2_rearend);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->d_baliseAntenna_2_frontend,
      &kcg_c2->d_baliseAntenna_2_frontend);
  kcg_equ = kcg_equ & (kcg_c1->l_train == kcg_c2->l_train);
  kcg_equ = kcg_equ & (kcg_c1->nid_operational == kcg_c2->nid_operational);
  kcg_equ = kcg_equ & (kcg_c1->nid_engine == kcg_c2->nid_engine);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13500(struct__13500 *kcg_c1, struct__13500 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->speed == kcg_c2->speed);
  kcg_equ = kcg_equ & kcg_comp_struct__13407(&kcg_c1->odo, &kcg_c2->odo);
  kcg_equ = kcg_equ & (kcg_c1->timestamp == kcg_c2->timestamp);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13507(struct__13507 *kcg_c1, struct__13507 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->BGFound == kcg_c2->BGFound);
  kcg_equ = kcg_equ & (kcg_c1->noOfFoundBGs == kcg_c2->noOfFoundBGs);
  kcg_equ = kcg_equ & (kcg_c1->index == kcg_c2->index);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13513(struct__13513 *kcg_c1, struct__13513 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->passedTotalBGsCount ==
      kcg_c2->passedTotalBGsCount);
  kcg_equ = kcg_equ & (kcg_c1->passedLinkedBGsCount ==
      kcg_c2->passedLinkedBGsCount);
  kcg_equ = kcg_equ & (kcg_c1->passedUnlinkedBGsCount ==
      kcg_c2->passedUnlinkedBGsCount);
  kcg_equ = kcg_equ & (kcg_c1->totalBGsCount == kcg_c2->totalBGsCount);
  kcg_equ = kcg_equ & (kcg_c1->linkedBGsCount == kcg_c2->linkedBGsCount);
  kcg_equ = kcg_equ & (kcg_c1->unlinkedBGsCount == kcg_c2->unlinkedBGsCount);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13525(struct__13525 *kcg_c1, struct__13525 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->overrun == kcg_c2->overrun);
  kcg_equ = kcg_equ & kcg_comp_array__13469(&kcg_c1->BGs, &kcg_c2->BGs);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13530(struct__13530 *kcg_c1, struct__13530 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->subsequentLinkedBG_idx ==
      kcg_c2->subsequentLinkedBG_idx);
  kcg_equ = kcg_equ & (kcg_c1->currentIndex == kcg_c2->currentIndex);
  kcg_equ = kcg_equ & (kcg_c1->previousLinkedBG_idx ==
      kcg_c2->previousLinkedBG_idx);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13539(struct__13539 *kcg_c1, struct__13539 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->sumOfBestDistances,
      &kcg_c2->sumOfBestDistances);
  kcg_equ = kcg_equ & (kcg_c1->recalculate == kcg_c2->recalculate);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(
      &kcg_c1->prevUnlinkedBG,
      &kcg_c2->prevUnlinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(
      &kcg_c1->prevLinkedBG,
      &kcg_c2->prevLinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(&kcg_c1->refBG, &kcg_c2->refBG);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13547(struct__13547 *kcg_c1, struct__13547 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->l_ackleveltr == kcg_c2->l_ackleveltr);
  kcg_equ = kcg_equ & (kcg_c1->nid_ntc == kcg_c2->nid_ntc);
  kcg_equ = kcg_equ & (kcg_c1->m_leveltr == kcg_c2->m_leveltr);
  kcg_equ = kcg_equ & (kcg_c1->d_leveltr == kcg_c2->d_leveltr);
  kcg_equ = kcg_equ & (kcg_c1->q_scale == kcg_c2->q_scale);
  kcg_equ = kcg_equ & (kcg_c1->q_dir == kcg_c2->q_dir);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13557(struct__13557 *kcg_c1, struct__13557 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13547(
      &kcg_c1->nextLTO,
      &kcg_c2->nextLTO);
  kcg_equ = kcg_equ & (kcg_c1->distanceSinceLTORef ==
      kcg_c2->distanceSinceLTORef);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13566(struct__13566 *kcg_c1, struct__13566 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__13563(&kcg_c1->orders, &kcg_c2->orders);
  kcg_equ = kcg_equ & kcg_comp_struct__13396(
      &kcg_c1->BG_Header,
      &kcg_c2->BG_Header);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13572(struct__13572 *kcg_c1, struct__13572 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->timestamp == kcg_c2->timestamp);
  kcg_equ = kcg_equ & kcg_comp_struct__13413(
      &kcg_c1->BG_centerDetectionInaccuraccuracies,
      &kcg_c2->BG_centerDetectionInaccuraccuracies);
  kcg_equ = kcg_equ & kcg_comp_struct__13407(
      &kcg_c1->centerOfBalisePosition,
      &kcg_c2->centerOfBalisePosition);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13579(struct__13579 *kcg_c1, struct__13579 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->q_link == kcg_c2->q_link);
  kcg_equ = kcg_equ & (kcg_c1->nid_bg == kcg_c2->nid_bg);
  kcg_equ = kcg_equ & (kcg_c1->nid_c == kcg_c2->nid_c);
  kcg_equ = kcg_equ & (kcg_c1->m_mcount == kcg_c2->m_mcount);
  kcg_equ = kcg_equ & (kcg_c1->m_dup == kcg_c2->m_dup);
  kcg_equ = kcg_equ & (kcg_c1->n_total == kcg_c2->n_total);
  kcg_equ = kcg_equ & (kcg_c1->n_pig == kcg_c2->n_pig);
  kcg_equ = kcg_equ & (kcg_c1->q_media == kcg_c2->q_media);
  kcg_equ = kcg_equ & (kcg_c1->m_version == kcg_c2->m_version);
  kcg_equ = kcg_equ & (kcg_c1->q_updown == kcg_c2->q_updown);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13592(struct__13592 *kcg_c1, struct__13592 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__13393(
      &kcg_c1->linkingPackets,
      &kcg_c2->linkingPackets);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13596(struct__13596 *kcg_c1, struct__13596 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13592(
      &kcg_c1->packets,
      &kcg_c2->packets);
  kcg_equ = kcg_equ & kcg_comp_struct__13579(
      &kcg_c1->telegramheader,
      &kcg_c2->telegramheader);
  kcg_equ = kcg_equ & (kcg_c1->checkResult == kcg_c2->checkResult);
  kcg_equ = kcg_equ & (kcg_c1->valid == kcg_c2->valid);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13606(struct__13606 *kcg_c1, struct__13606 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->BGOrientation == kcg_c2->BGOrientation);
  kcg_equ = kcg_equ & kcg_comp_struct__13572(
      &kcg_c1->centerOfBalisePosition,
      &kcg_c2->centerOfBalisePosition);
  kcg_equ = kcg_equ & (kcg_c1->numberBalises == kcg_c2->numberBalises);
  kcg_equ = kcg_equ & kcg_comp_array__13603(
      &kcg_c1->Telegrams,
      &kcg_c2->Telegrams);
  kcg_equ = kcg_equ & (kcg_c1->present == kcg_c2->present);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13614(struct__13614 *kcg_c1, struct__13614 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_ORIENTATION == kcg_c2->Q_ORIENTATION);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13623(struct__13623 *kcg_c1, struct__13623 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13614(
      &kcg_c1->assignment_of_coordinate_system,
      &kcg_c2->assignment_of_coordinate_system);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13627(struct__13627 *kcg_c1, struct__13627 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Train_Position_Report_OptionalPackets ==
      kcg_c2->Train_Position_Report_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING3 == kcg_c2->PADDING3);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13636(struct__13636 *kcg_c1, struct__13636 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13627(
      &kcg_c1->train_position_report,
      &kcg_c2->train_position_report);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13640(struct__13640 *kcg_c1, struct__13640 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->q_length == kcg_c2->q_length);
  kcg_equ = kcg_equ & (kcg_c1->nid_ntc == kcg_c2->nid_ntc);
  kcg_equ = kcg_equ & (kcg_c1->m_leveltr == kcg_c2->m_leveltr);
  kcg_equ = kcg_equ & (kcg_c1->m_level == kcg_c2->m_level);
  kcg_equ = kcg_equ & (kcg_c1->m_mode == kcg_c2->m_mode);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13648(struct__13648 *kcg_c1, struct__13648 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->f == kcg_c2->f);
  kcg_equ = kcg_equ & (kcg_c1->k == kcg_c2->k);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13653(struct__13653 *kcg_c1, struct__13653 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->indexOfUnlinkedBG == kcg_c2->indexOfUnlinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(
      &kcg_c1->unlinkedBG,
      &kcg_c2->unlinkedBG);
  kcg_equ = kcg_equ & kcg_comp_struct__13447(
      &kcg_c1->prevLinkedBG,
      &kcg_c2->prevLinkedBG);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13659(struct__13659 *kcg_c1, struct__13659 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13667(struct__13667 *kcg_c1, struct__13667 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Infill_MA_OptionalPackets ==
      kcg_c2->Infill_MA_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING18 == kcg_c2->PADDING18);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13677(struct__13677 *kcg_c1, struct__13677 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_TAFDISPLAY == kcg_c2->L_TAFDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->D_TAFDISPLAY == kcg_c2->D_TAFDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->D_REF == kcg_c2->D_REF);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13690(struct__13690 *kcg_c1, struct__13690 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ &
    (kcg_c1->MA_with_Shifted_Location_Reference_OptionalPackets ==
      kcg_c2->MA_with_Shifted_Location_Reference_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING17 == kcg_c2->PADDING17);
  kcg_equ = kcg_equ & (kcg_c1->D_REF == kcg_c2->D_REF);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13702(struct__13702 *kcg_c1, struct__13702 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_VERSION == kcg_c2->M_VERSION);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13711(struct__13711 *kcg_c1, struct__13711 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->SH_Authorised_OptionalPackets ==
      kcg_c2->SH_Authorised_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING16 == kcg_c2->PADDING16);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN1 == kcg_c2->T_TRAIN1);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN0 == kcg_c2->T_TRAIN0);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13722(struct__13722 *kcg_c1, struct__13722 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN1 == kcg_c2->T_TRAIN1);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN0 == kcg_c2->T_TRAIN0);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13731(struct__13731 *kcg_c1, struct__13731 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->General_message_OptionalPackets ==
      kcg_c2->General_message_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING15 == kcg_c2->PADDING15);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13741(struct__13741 *kcg_c1, struct__13741 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_EM == kcg_c2->NID_EM);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13750(struct__13750 *kcg_c1, struct__13750 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->D_EMERGENCYSTOP == kcg_c2->D_EMERGENCYSTOP);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->D_REF == kcg_c2->D_REF);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->NID_EM == kcg_c2->NID_EM);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13763(struct__13763 *kcg_c1, struct__13763 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Request_to_Shorten_MA_OptionalPackets ==
      kcg_c2->Request_to_Shorten_MA_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING14 == kcg_c2->PADDING14);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13773(struct__13773 *kcg_c1, struct__13773 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Movement_Authority_OptionalPackets ==
      kcg_c2->Movement_Authority_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING13 == kcg_c2->PADDING13);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13783(struct__13783 *kcg_c1, struct__13783 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->SR_Authorisation_OptionalPackets ==
      kcg_c2->SR_Authorisation_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING12 == kcg_c2->PADDING12);
  kcg_equ = kcg_equ & (kcg_c1->D_SR == kcg_c2->D_SR);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->M_ACK == kcg_c2->M_ACK);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13795(struct__13795 *kcg_c1, struct__13795 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Session_Established_OptionalPackets ==
      kcg_c2->Session_Established_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING11 == kcg_c2->PADDING11);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13804(struct__13804 *kcg_c1, struct__13804 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ &
    (kcg_c1->Text_message_acknowledged_by_driver_OptionalPackets ==
      kcg_c2->Text_message_acknowledged_by_driver_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING10 == kcg_c2->PADDING10);
  kcg_equ = kcg_equ & (kcg_c1->NID_TEXTMESSAGE == kcg_c2->NID_TEXTMESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13814(struct__13814 *kcg_c1, struct__13814 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->SoM_Position_Report_OptionalPackets ==
      kcg_c2->SoM_Position_Report_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING9 == kcg_c2->PADDING9);
  kcg_equ = kcg_equ & (kcg_c1->Q_STATUS == kcg_c2->Q_STATUS);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13824(struct__13824 *kcg_c1, struct__13824 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13831(struct__13831 *kcg_c1, struct__13831 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Radio_infill_request_OptionalPackets ==
      kcg_c2->Radio_infill_request_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING8 == kcg_c2->PADDING8);
  kcg_equ = kcg_equ & (kcg_c1->Q_INFILL == kcg_c2->Q_INFILL);
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13843(struct__13843 *kcg_c1, struct__13843 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->End_of_Mission_OptionalPackets ==
      kcg_c2->End_of_Mission_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING7 == kcg_c2->PADDING7);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13852(struct__13852 *kcg_c1, struct__13852 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Track_Ahead_Free_Granted_OptionalPackets ==
      kcg_c2->Track_Ahead_Free_Granted_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING6 == kcg_c2->PADDING6);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13861(struct__13861 *kcg_c1, struct__13861 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ &
    (kcg_c1->Acknowledgement_of_Emergency_Stop_OptionalPackets ==
      kcg_c2->Acknowledgement_of_Emergency_Stop_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->Q_EMERGENCYSTOP == kcg_c2->Q_EMERGENCYSTOP);
  kcg_equ = kcg_equ & (kcg_c1->NID_EM == kcg_c2->NID_EM);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13871(struct__13871 *kcg_c1, struct__13871 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ &
    (kcg_c1->Request_to_shorten_MA_is_rejected_OptionalPackets ==
      kcg_c2->Request_to_shorten_MA_is_rejected_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING5 == kcg_c2->PADDING5);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13880(struct__13880 *kcg_c1, struct__13880 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ &
    (kcg_c1->Request_to_shorten_MA_is_granted_OptionalPackets ==
      kcg_c2->Request_to_shorten_MA_is_granted_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING4 == kcg_c2->PADDING4);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13889(struct__13889 *kcg_c1, struct__13889 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->MA_Request_OptionalPackets ==
      kcg_c2->MA_Request_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING2 == kcg_c2->PADDING2);
  kcg_equ = kcg_equ & (kcg_c1->Q_MARQSTREASON == kcg_c2->Q_MARQSTREASON);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13899(struct__13899 *kcg_c1, struct__13899 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Request_for_Shunting_OptionalPackets ==
      kcg_c2->Request_for_Shunting_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING1 == kcg_c2->PADDING1);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13908(struct__13908 *kcg_c1, struct__13908 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Validated_Train_Data_OptionalPackets ==
      kcg_c2->Validated_Train_Data_OptionalPackets);
  kcg_equ = kcg_equ & (kcg_c1->PADDING0 == kcg_c2->PADDING0);
  kcg_equ = kcg_equ & (kcg_c1->NID_ENGINE == kcg_c2->NID_ENGINE);
  kcg_equ = kcg_equ & (kcg_c1->T_TRAIN == kcg_c2->T_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_MESSAGE == kcg_c2->L_MESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->NID_MESSAGE == kcg_c2->NID_MESSAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13917(struct__13917 *kcg_c1, struct__13917 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13921(struct__13921 *kcg_c1, struct__13921 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Other_data_depending_on__NID_XUSER ==
      kcg_c2->Other_data_depending_on__NID_XUSER);
  kcg_equ = kcg_equ & (kcg_c1->NID_XUSER == kcg_c2->NID_XUSER);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13928(struct__13928 *kcg_c1, struct__13928 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13935(struct__13935 *kcg_c1, struct__13935 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__13932(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13940(struct__13940 *kcg_c1, struct__13940 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_CTRACTION == kcg_c2->NID_CTRACTION);
  kcg_equ = kcg_equ & (kcg_c1->M_VOLTAGE == kcg_c2->M_VOLTAGE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13948(struct__13948 *kcg_c1, struct__13948 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__13945(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13953(struct__13953 *kcg_c1, struct__13953 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13935(
      &kcg_c1->Struct48,
      &kcg_c2->Struct48);
  kcg_equ = kcg_equ & kcg_comp_struct__13948(
      &kcg_c1->Struct47,
      &kcg_c2->Struct47);
  kcg_equ = kcg_equ & (kcg_c1->N_AXLE == kcg_c2->N_AXLE);
  kcg_equ = kcg_equ & (kcg_c1->M_AIRTIGHT == kcg_c2->M_AIRTIGHT);
  kcg_equ = kcg_equ & (kcg_c1->M_AXLELOADCAT == kcg_c2->M_AXLELOADCAT);
  kcg_equ = kcg_equ & (kcg_c1->M_LOADINGGAUGE == kcg_c2->M_LOADINGGAUGE);
  kcg_equ = kcg_equ & (kcg_c1->V_MAXTRAIN == kcg_c2->V_MAXTRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_TRAIN == kcg_c2->L_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->NC_TRAIN == kcg_c2->NC_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->NC_CDTRAIN == kcg_c2->NC_CDTRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13968(struct__13968 *kcg_c1, struct__13968 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_LTRBG == kcg_c2->NID_LTRBG);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13974(struct__13974 *kcg_c1, struct__13974 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_OPERATIONAL == kcg_c2->NID_OPERATIONAL);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13980(struct__13980 *kcg_c1, struct__13980 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->error == kcg_c2->error);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13986(struct__13986 *kcg_c1, struct__13986 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_RADIO == kcg_c2->NID_RADIO);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13993(struct__13993 *kcg_c1, struct__13993 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__13990(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__13998(struct__13998 *kcg_c1, struct__13998 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__13993(
      &kcg_c1->Struct46,
      &kcg_c2->Struct46);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14004(struct__14004 *kcg_c1, struct__14004 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->level == kcg_c2->level);
  kcg_equ = kcg_equ & (kcg_c1->mode == kcg_c2->mode);
  kcg_equ = kcg_equ & (kcg_c1->dirtrain == kcg_c2->dirtrain);
  kcg_equ = kcg_equ & (kcg_c1->V_TRAIN == kcg_c2->V_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_TRAININT == kcg_c2->L_TRAININT);
  kcg_equ = kcg_equ & (kcg_c1->length == kcg_c2->length);
  kcg_equ = kcg_equ & (kcg_c1->L_DOUBTUNDER == kcg_c2->L_DOUBTUNDER);
  kcg_equ = kcg_equ & (kcg_c1->L_DOUBTOVER == kcg_c2->L_DOUBTOVER);
  kcg_equ = kcg_equ & (kcg_c1->dlrbg == kcg_c2->dlrbg);
  kcg_equ = kcg_equ & (kcg_c1->dirlrbg == kcg_c2->dirlrbg);
  kcg_equ = kcg_equ & (kcg_c1->D_LRBG == kcg_c2->D_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->NID_PRVLRBG == kcg_c2->NID_PRVLRBG);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->qscale == kcg_c2->qscale);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14024(struct__14024 *kcg_c1, struct__14024 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->level == kcg_c2->level);
  kcg_equ = kcg_equ & (kcg_c1->mode == kcg_c2->mode);
  kcg_equ = kcg_equ & (kcg_c1->dirtrain == kcg_c2->dirtrain);
  kcg_equ = kcg_equ & (kcg_c1->V_TRAIN == kcg_c2->V_TRAIN);
  kcg_equ = kcg_equ & (kcg_c1->L_TRAININT == kcg_c2->L_TRAININT);
  kcg_equ = kcg_equ & (kcg_c1->length == kcg_c2->length);
  kcg_equ = kcg_equ & (kcg_c1->L_DOUBTUNDER == kcg_c2->L_DOUBTUNDER);
  kcg_equ = kcg_equ & (kcg_c1->L_DOUBTOVER == kcg_c2->L_DOUBTOVER);
  kcg_equ = kcg_equ & (kcg_c1->dlrbg == kcg_c2->dlrbg);
  kcg_equ = kcg_equ & (kcg_c1->dirlrbg == kcg_c2->dirlrbg);
  kcg_equ = kcg_equ & (kcg_c1->D_LRBG == kcg_c2->D_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->NID_LRBG == kcg_c2->NID_LRBG);
  kcg_equ = kcg_equ & (kcg_c1->qscale == kcg_c2->qscale);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14043(struct__14043 *kcg_c1, struct__14043 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14049(struct__14049 *kcg_c1, struct__14049 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_RADIO == kcg_c2->NID_RADIO);
  kcg_equ = kcg_equ & (kcg_c1->NID_RIU == kcg_c2->NID_RIU);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_RIU == kcg_c2->Q_RIU);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14059(struct__14059 *kcg_c1, struct__14059 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->G_TSR == kcg_c2->G_TSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_GDIR == kcg_c2->Q_GDIR);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14067(struct__14067 *kcg_c1, struct__14067 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_OPERATIONAL == kcg_c2->NID_OPERATIONAL);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14074(struct__14074 *kcg_c1, struct__14074 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->V_REVERSE == kcg_c2->V_REVERSE);
  kcg_equ = kcg_equ & (kcg_c1->D_REVERSE == kcg_c2->D_REVERSE);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14083(struct__14083 *kcg_c1, struct__14083 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_REVERSEAREA == kcg_c2->L_REVERSEAREA);
  kcg_equ = kcg_equ & (kcg_c1->D_STARTREVERSE == kcg_c2->D_STARTREVERSE);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14092(struct__14092 *kcg_c1, struct__14092 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_SRSTOP == kcg_c2->Q_SRSTOP);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14099(struct__14099 *kcg_c1, struct__14099 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14108(struct__14108 *kcg_c1, struct__14108 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_SSCODE == kcg_c2->Q_SSCODE);
  kcg_equ = kcg_equ & (kcg_c1->Q_LOOPDIR == kcg_c2->Q_LOOPDIR);
  kcg_equ = kcg_equ & (kcg_c1->L_LOOP == kcg_c2->L_LOOP);
  kcg_equ = kcg_equ & (kcg_c1->D_LOOP == kcg_c2->D_LOOP);
  kcg_equ = kcg_equ & (kcg_c1->NID_LOOP == kcg_c2->NID_LOOP);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14120(struct__14120 *kcg_c1, struct__14120 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->D_INFILL == kcg_c2->D_INFILL);
  kcg_equ = kcg_equ & (kcg_c1->NID_RADIO == kcg_c2->NID_RADIO);
  kcg_equ = kcg_equ & (kcg_c1->NID_RIU == kcg_c2->NID_RIU);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_RIU == kcg_c2->Q_RIU);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14133(struct__14133 *kcg_c1, struct__14133 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_ASPECT == kcg_c2->Q_ASPECT);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14140(struct__14140 *kcg_c1, struct__14140 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_SLEEPSESSION == kcg_c2->Q_SLEEPSESSION);
  kcg_equ = kcg_equ & (kcg_c1->NID_RADIO == kcg_c2->NID_RADIO);
  kcg_equ = kcg_equ & (kcg_c1->NID_RBC == kcg_c2->NID_RBC);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->D_RBCTR == kcg_c2->D_RBCTR);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14152(struct__14152 *kcg_c1, struct__14152 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_STOPLX == kcg_c2->L_STOPLX);
  kcg_equ = kcg_equ & (kcg_c1->Q_STOPLX == kcg_c2->Q_STOPLX);
  kcg_equ = kcg_equ & (kcg_c1->V_LX == kcg_c2->V_LX);
  kcg_equ = kcg_equ & (kcg_c1->Q_LXSTATUS == kcg_c2->Q_LXSTATUS);
  kcg_equ = kcg_equ & (kcg_c1->L_LX == kcg_c2->L_LX);
  kcg_equ = kcg_equ & (kcg_c1->D_LX == kcg_c2->D_LX);
  kcg_equ = kcg_equ & (kcg_c1->NID_LX == kcg_c2->NID_LX);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14166(struct__14166 *kcg_c1, struct__14166 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_MAMODE == kcg_c2->Q_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->L_ACKMAMODE == kcg_c2->L_ACKMAMODE);
  kcg_equ = kcg_equ & (kcg_c1->L_MAMODE == kcg_c2->L_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->V_MAMODE == kcg_c2->V_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->M_MAMODE == kcg_c2->M_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->D_MAMODE == kcg_c2->D_MAMODE);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14178(struct__14178 *kcg_c1, struct__14178 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14175(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14183(struct__14183 *kcg_c1, struct__14183 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14178(
      &kcg_c1->Struct45,
      &kcg_c2->Struct45);
  kcg_equ = kcg_equ & (kcg_c1->Q_MAMODE == kcg_c2->Q_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->L_ACKMAMODE == kcg_c2->L_ACKMAMODE);
  kcg_equ = kcg_equ & (kcg_c1->L_MAMODE == kcg_c2->L_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->V_MAMODE == kcg_c2->V_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->M_MAMODE == kcg_c2->M_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->D_MAMODE == kcg_c2->D_MAMODE);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14197(struct__14197 *kcg_c1, struct__14197 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_POSITION == kcg_c2->M_POSITION);
  kcg_equ = kcg_equ & (kcg_c1->Q_MPOSITION == kcg_c2->Q_MPOSITION);
  kcg_equ = kcg_equ & (kcg_c1->D_POSOFF == kcg_c2->D_POSOFF);
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14209(struct__14209 *kcg_c1, struct__14209 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14206(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14214(struct__14214 *kcg_c1, struct__14214 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14209(
      &kcg_c1->Struct44,
      &kcg_c2->Struct44);
  kcg_equ = kcg_equ & (kcg_c1->M_POSITION == kcg_c2->M_POSITION);
  kcg_equ = kcg_equ & (kcg_c1->Q_MPOSITION == kcg_c2->Q_MPOSITION);
  kcg_equ = kcg_equ & (kcg_c1->D_POSOFF == kcg_c2->D_POSOFF);
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14228(struct__14228 *kcg_c1, struct__14228 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->M_LEVELTEXTDISPLAY ==
      kcg_c2->M_LEVELTEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->M_MODETEXTDISPLAY == kcg_c2->M_MODETEXTDISPLAY);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14234(struct__14234 *kcg_c1, struct__14234 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXT == kcg_c2->Q_TEXT);
  kcg_equ = kcg_equ & (kcg_c1->NID_RBC == kcg_c2->NID_RBC);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->NID_TEXTMESSAGE == kcg_c2->NID_TEXTMESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTREPORT == kcg_c2->Q_TEXTREPORT);
  kcg_equ = kcg_equ & (kcg_c1->Q_CONFTEXTDISPLAY == kcg_c2->Q_CONFTEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTCONFIRM == kcg_c2->Q_TEXTCONFIRM);
  kcg_equ = kcg_equ & kcg_comp_struct__14228(
      &kcg_c1->Struct43,
      &kcg_c2->Struct43);
  kcg_equ = kcg_equ & (kcg_c1->T_TEXTDISPLAY == kcg_c2->T_TEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->L_TEXTDISPLAY == kcg_c2->L_TEXTDISPLAY);
  kcg_equ = kcg_equ & kcg_comp_struct__14228(
      &kcg_c1->Struct40,
      &kcg_c2->Struct40);
  kcg_equ = kcg_equ & (kcg_c1->D_TEXTDISPLAY == kcg_c2->D_TEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTDISPLAY == kcg_c2->Q_TEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTCLASS == kcg_c2->Q_TEXTCLASS);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14255(struct__14255 *kcg_c1, struct__14255 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->X_TEXT == kcg_c2->X_TEXT);
  kcg_equ = kcg_equ & (kcg_c1->L_TEXT == kcg_c2->L_TEXT);
  kcg_equ = kcg_equ & (kcg_c1->NID_RBC == kcg_c2->NID_RBC);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->NID_TEXTMESSAGE == kcg_c2->NID_TEXTMESSAGE);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTREPORT == kcg_c2->Q_TEXTREPORT);
  kcg_equ = kcg_equ & (kcg_c1->Q_CONFTEXTDISPLAY == kcg_c2->Q_CONFTEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTCONFIRM == kcg_c2->Q_TEXTCONFIRM);
  kcg_equ = kcg_equ & kcg_comp_struct__14228(
      &kcg_c1->Struct37,
      &kcg_c2->Struct37);
  kcg_equ = kcg_equ & (kcg_c1->T_TEXTDISPLAY == kcg_c2->T_TEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->L_TEXTDISPLAY == kcg_c2->L_TEXTDISPLAY);
  kcg_equ = kcg_equ & kcg_comp_struct__14228(
      &kcg_c1->Struct34,
      &kcg_c2->Struct34);
  kcg_equ = kcg_equ & (kcg_c1->D_TEXTDISPLAY == kcg_c2->D_TEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTDISPLAY == kcg_c2->Q_TEXTDISPLAY);
  kcg_equ = kcg_equ & (kcg_c1->Q_TEXTCLASS == kcg_c2->Q_TEXTCLASS);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14277(struct__14277 *kcg_c1, struct__14277 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_ADHESION == kcg_c2->M_ADHESION);
  kcg_equ = kcg_equ & (kcg_c1->L_ADHESION == kcg_c2->L_ADHESION);
  kcg_equ = kcg_equ & (kcg_c1->D_ADHESION == kcg_c2->D_ADHESION);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14287(struct__14287 *kcg_c1, struct__14287 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_CTRACTION == kcg_c2->NID_CTRACTION);
  kcg_equ = kcg_equ & (kcg_c1->M_VOLTAGE == kcg_c2->M_VOLTAGE);
  kcg_equ = kcg_equ & (kcg_c1->M_AXLELOADCAT == kcg_c2->M_AXLELOADCAT);
  kcg_equ = kcg_equ & (kcg_c1->M_LINEGAUGE == kcg_c2->M_LINEGAUGE);
  kcg_equ = kcg_equ & (kcg_c1->Q_SUITABILITY == kcg_c2->Q_SUITABILITY);
  kcg_equ = kcg_equ & (kcg_c1->D_SUITABILITY == kcg_c2->D_SUITABILITY);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14299(struct__14299 *kcg_c1, struct__14299 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14296(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14304(struct__14304 *kcg_c1, struct__14304 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14299(
      &kcg_c1->Struct31,
      &kcg_c2->Struct31);
  kcg_equ = kcg_equ & (kcg_c1->NID_CTRACTION == kcg_c2->NID_CTRACTION);
  kcg_equ = kcg_equ & (kcg_c1->M_VOLTAGE == kcg_c2->M_VOLTAGE);
  kcg_equ = kcg_equ & (kcg_c1->M_AXLELOADCAT == kcg_c2->M_AXLELOADCAT);
  kcg_equ = kcg_equ & (kcg_c1->M_LINEGAUGE == kcg_c2->M_LINEGAUGE);
  kcg_equ = kcg_equ & (kcg_c1->Q_SUITABILITY == kcg_c2->Q_SUITABILITY);
  kcg_equ = kcg_equ & (kcg_c1->D_SUITABILITY == kcg_c2->D_SUITABILITY);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKINIT == kcg_c2->D_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_TRACKINIT == kcg_c2->Q_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14320(struct__14320 *kcg_c1, struct__14320 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_PLATFORM == kcg_c2->Q_PLATFORM);
  kcg_equ = kcg_equ & (kcg_c1->M_PLATFORM == kcg_c2->M_PLATFORM);
  kcg_equ = kcg_equ & (kcg_c1->L_TRACKCOND == kcg_c2->L_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKCOND == kcg_c2->D_TRACKCOND);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14330(struct__14330 *kcg_c1, struct__14330 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14327(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14335(struct__14335 *kcg_c1, struct__14335 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14330(
      &kcg_c1->Struct30,
      &kcg_c2->Struct30);
  kcg_equ = kcg_equ & (kcg_c1->Q_PLATFORM == kcg_c2->Q_PLATFORM);
  kcg_equ = kcg_equ & (kcg_c1->M_PLATFORM == kcg_c2->M_PLATFORM);
  kcg_equ = kcg_equ & (kcg_c1->L_TRACKCOND == kcg_c2->L_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKCOND == kcg_c2->D_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKINIT == kcg_c2->D_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_TRACKINIT == kcg_c2->Q_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14349(struct__14349 *kcg_c1, struct__14349 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_TRACKCOND == kcg_c2->M_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->L_TRACKCOND == kcg_c2->L_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKCOND == kcg_c2->D_TRACKCOND);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14358(struct__14358 *kcg_c1, struct__14358 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14355(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14363(struct__14363 *kcg_c1, struct__14363 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14358(
      &kcg_c1->Struct29,
      &kcg_c2->Struct29);
  kcg_equ = kcg_equ & (kcg_c1->M_TRACKCOND == kcg_c2->M_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->L_TRACKCOND == kcg_c2->L_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKCOND == kcg_c2->D_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKINIT == kcg_c2->D_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_TRACKINIT == kcg_c2->Q_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14376(struct__14376 *kcg_c1, struct__14376 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_TRACKCOND == kcg_c2->L_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKCOND == kcg_c2->D_TRACKCOND);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14384(struct__14384 *kcg_c1, struct__14384 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14381(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14389(struct__14389 *kcg_c1, struct__14389 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14384(
      &kcg_c1->Struct28,
      &kcg_c2->Struct28);
  kcg_equ = kcg_equ & (kcg_c1->L_TRACKCOND == kcg_c2->L_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKCOND == kcg_c2->D_TRACKCOND);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14399(struct__14399 *kcg_c1, struct__14399 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_TSR == kcg_c2->NID_TSR);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14406(struct__14406 *kcg_c1, struct__14406 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->V_TSR == kcg_c2->V_TSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_FRONT == kcg_c2->Q_FRONT);
  kcg_equ = kcg_equ & (kcg_c1->L_TSR == kcg_c2->L_TSR);
  kcg_equ = kcg_equ & (kcg_c1->D_TSR == kcg_c2->D_TSR);
  kcg_equ = kcg_equ & (kcg_c1->NID_TSR == kcg_c2->NID_TSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14418(struct__14418 *kcg_c1, struct__14418 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14427(struct__14427 *kcg_c1, struct__14427 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14424(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14432(struct__14432 *kcg_c1, struct__14432 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14427(
      &kcg_c1->Struct27,
      &kcg_c2->Struct27);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14439(struct__14439 *kcg_c1, struct__14439 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->q_lgtloc == kcg_c2->q_lgtloc);
  kcg_equ = kcg_equ & (kcg_c1->D_LOC == kcg_c2->D_LOC);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14447(struct__14447 *kcg_c1, struct__14447 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14444(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14452(struct__14452 *kcg_c1, struct__14452 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14447(
      &kcg_c1->Struct26,
      &kcg_c2->Struct26);
  kcg_equ = kcg_equ & (kcg_c1->m_loc == kcg_c2->m_loc);
  kcg_equ = kcg_equ & (kcg_c1->D_CYCLOC == kcg_c2->D_CYCLOC);
  kcg_equ = kcg_equ & (kcg_c1->T_CYCLOC == kcg_c2->T_CYCLOC);
  kcg_equ = kcg_equ & (kcg_c1->q_scale == kcg_c2->q_scale);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->q_dir == kcg_c2->q_dir);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14463(struct__14463 *kcg_c1, struct__14463 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->T_CYCRQST == kcg_c2->T_CYCRQST);
  kcg_equ = kcg_equ & (kcg_c1->T_TIMEOUTRQST == kcg_c2->T_TIMEOUTRQST);
  kcg_equ = kcg_equ & (kcg_c1->T_MAR == kcg_c2->T_MAR);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14472(struct__14472 *kcg_c1, struct__14472 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_PBDSR == kcg_c2->L_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->D_PBDSR == kcg_c2->D_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_PBDSR == kcg_c2->Q_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->G_PBDSR == kcg_c2->G_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_GDIR == kcg_c2->Q_GDIR);
  kcg_equ = kcg_equ & (kcg_c1->D_PBD == kcg_c2->D_PBD);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14484(struct__14484 *kcg_c1, struct__14484 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14481(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14489(struct__14489 *kcg_c1, struct__14489 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14484(
      &kcg_c1->Struct25,
      &kcg_c2->Struct25);
  kcg_equ = kcg_equ & (kcg_c1->L_PBDSR == kcg_c2->L_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->D_PBDSR == kcg_c2->D_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_PBDSR == kcg_c2->Q_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->G_PBDSR == kcg_c2->G_PBDSR);
  kcg_equ = kcg_equ & (kcg_c1->Q_GDIR == kcg_c2->Q_GDIR);
  kcg_equ = kcg_equ & (kcg_c1->D_PBD == kcg_c2->D_PBD);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKINIT == kcg_c2->D_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_TRACKINIT == kcg_c2->Q_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14505(struct__14505 *kcg_c1, struct__14505 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->V_AXLELOAD == kcg_c2->V_AXLELOAD);
  kcg_equ = kcg_equ & (kcg_c1->M_AXLELOADCAT == kcg_c2->M_AXLELOADCAT);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14513(struct__14513 *kcg_c1, struct__14513 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14510(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14518(struct__14518 *kcg_c1, struct__14518 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14513(
      &kcg_c1->Struct68,
      &kcg_c2->Struct68);
  kcg_equ = kcg_equ & (kcg_c1->Q_FRONT == kcg_c2->Q_FRONT);
  kcg_equ = kcg_equ & (kcg_c1->L_AXLELOAD == kcg_c2->L_AXLELOAD);
  kcg_equ = kcg_equ & (kcg_c1->D_AXLELOAD == kcg_c2->D_AXLELOAD);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14528(struct__14528 *kcg_c1, struct__14528 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14525(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14533(struct__14533 *kcg_c1, struct__14533 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14528(
      &kcg_c1->Struct23,
      &kcg_c2->Struct23);
  kcg_equ = kcg_equ & kcg_comp_struct__14513(
      &kcg_c1->Struct22,
      &kcg_c2->Struct22);
  kcg_equ = kcg_equ & (kcg_c1->Q_FRONT == kcg_c2->Q_FRONT);
  kcg_equ = kcg_equ & (kcg_c1->L_AXLELOAD == kcg_c2->L_AXLELOAD);
  kcg_equ = kcg_equ & (kcg_c1->D_AXLELOAD == kcg_c2->D_AXLELOAD);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACKINIT == kcg_c2->D_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_TRACKINIT == kcg_c2->Q_TRACKINIT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14547(struct__14547 *kcg_c1, struct__14547 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14427(
      &kcg_c1->Struct21,
      &kcg_c2->Struct21);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14554(struct__14554 *kcg_c1, struct__14554 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->M_LEVELTR == kcg_c2->M_LEVELTR);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14562(struct__14562 *kcg_c1, struct__14562 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14559(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14567(struct__14567 *kcg_c1, struct__14567 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14562(
      &kcg_c1->Struct20,
      &kcg_c2->Struct20);
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->M_LEVELTR == kcg_c2->M_LEVELTR);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14576(struct__14576 *kcg_c1, struct__14576 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_MN == kcg_c2->NID_MN);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14583(struct__14583 *kcg_c1, struct__14583 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Other_data_depending_on__NID_XUSER ==
      kcg_c2->Other_data_depending_on__NID_XUSER);
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->NID_XUSER == kcg_c2->NID_XUSER);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14592(struct__14592 *kcg_c1, struct__14592 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_SLEEPSESSION == kcg_c2->Q_SLEEPSESSION);
  kcg_equ = kcg_equ & (kcg_c1->NID_RADIO == kcg_c2->NID_RADIO);
  kcg_equ = kcg_equ & (kcg_c1->NID_RBC == kcg_c2->NID_RBC);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_RBC == kcg_c2->Q_RBC);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14603(struct__14603 *kcg_c1, struct__14603 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_ACKLEVELTR == kcg_c2->L_ACKLEVELTR);
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->M_LEVELTR == kcg_c2->M_LEVELTR);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14612(struct__14612 *kcg_c1, struct__14612 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14609(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14617(struct__14617 *kcg_c1, struct__14617 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14612(
      &kcg_c1->Struct19,
      &kcg_c2->Struct19);
  kcg_equ = kcg_equ & (kcg_c1->L_ACKLEVELTR == kcg_c2->L_ACKLEVELTR);
  kcg_equ = kcg_equ & (kcg_c1->NID_NTC == kcg_c2->NID_NTC);
  kcg_equ = kcg_equ & (kcg_c1->M_LEVELTR == kcg_c2->M_LEVELTR);
  kcg_equ = kcg_equ & (kcg_c1->D_LEVELTR == kcg_c2->D_LEVELTR);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14629(struct__14629 *kcg_c1, struct__14629 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_CURRENT == kcg_c2->M_CURRENT);
  kcg_equ = kcg_equ & (kcg_c1->D_CURRENT == kcg_c2->D_CURRENT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14638(struct__14638 *kcg_c1, struct__14638 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_CTRACTION == kcg_c2->NID_CTRACTION);
  kcg_equ = kcg_equ & (kcg_c1->M_VOLTAGE == kcg_c2->M_VOLTAGE);
  kcg_equ = kcg_equ & (kcg_c1->D_TRACTION == kcg_c2->D_TRACTION);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14648(struct__14648 *kcg_c1, struct__14648 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->V_DIFF == kcg_c2->V_DIFF);
  kcg_equ = kcg_equ & (kcg_c1->NC_DIFF == kcg_c2->NC_DIFF);
  kcg_equ = kcg_equ & (kcg_c1->NC_CDDIFF == kcg_c2->NC_CDDIFF);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIFF == kcg_c2->Q_DIFF);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14658(struct__14658 *kcg_c1, struct__14658 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14655(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14663(struct__14663 *kcg_c1, struct__14663 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14658(
      &kcg_c1->Struct62,
      &kcg_c2->Struct62);
  kcg_equ = kcg_equ & (kcg_c1->Q_FRONT == kcg_c2->Q_FRONT);
  kcg_equ = kcg_equ & (kcg_c1->V_STATIC == kcg_c2->V_STATIC);
  kcg_equ = kcg_equ & (kcg_c1->D_STATIC == kcg_c2->D_STATIC);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14673(struct__14673 *kcg_c1, struct__14673 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14670(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14678(struct__14678 *kcg_c1, struct__14678 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14673(
      &kcg_c1->Struct17,
      &kcg_c2->Struct17);
  kcg_equ = kcg_equ & kcg_comp_struct__14658(
      &kcg_c1->Struct16,
      &kcg_c2->Struct16);
  kcg_equ = kcg_equ & (kcg_c1->Q_FRONT == kcg_c2->Q_FRONT);
  kcg_equ = kcg_equ & (kcg_c1->V_STATIC == kcg_c2->V_STATIC);
  kcg_equ = kcg_equ & (kcg_c1->D_STATIC == kcg_c2->D_STATIC);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14690(struct__14690 *kcg_c1, struct__14690 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->G_A == kcg_c2->G_A);
  kcg_equ = kcg_equ & (kcg_c1->Q_GDIR == kcg_c2->Q_GDIR);
  kcg_equ = kcg_equ & (kcg_c1->D_GRADIENT == kcg_c2->D_GRADIENT);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14699(struct__14699 *kcg_c1, struct__14699 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14696(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14704(struct__14704 *kcg_c1, struct__14704 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14699(
      &kcg_c1->Struct15,
      &kcg_c2->Struct15);
  kcg_equ = kcg_equ & (kcg_c1->G_A == kcg_c2->G_A);
  kcg_equ = kcg_equ & (kcg_c1->Q_GDIR == kcg_c2->Q_GDIR);
  kcg_equ = kcg_equ & (kcg_c1->D_GRADIENT == kcg_c2->D_GRADIENT);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14715(struct__14715 *kcg_c1, struct__14715 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->L_SECTION == kcg_c2->L_SECTION);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14723(struct__14723 *kcg_c1, struct__14723 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->D_SECTIONTIMERSTOPLOC ==
      kcg_c2->D_SECTIONTIMERSTOPLOC);
  kcg_equ = kcg_equ & (kcg_c1->T_SECTIONTIMER == kcg_c2->T_SECTIONTIMER);
  kcg_equ = kcg_equ & (kcg_c1->Q_SECTIONTIMER == kcg_c2->Q_SECTIONTIMER);
  kcg_equ = kcg_equ & (kcg_c1->L_SECTION == kcg_c2->L_SECTION);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14733(struct__14733 *kcg_c1, struct__14733 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14730(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14738(struct__14738 *kcg_c1, struct__14738 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->V_RELEASEOL == kcg_c2->V_RELEASEOL);
  kcg_equ = kcg_equ & (kcg_c1->D_OL == kcg_c2->D_OL);
  kcg_equ = kcg_equ & (kcg_c1->T_OL == kcg_c2->T_OL);
  kcg_equ = kcg_equ & (kcg_c1->D_STARTOL == kcg_c2->D_STARTOL);
  kcg_equ = kcg_equ & (kcg_c1->Q_OVERLAP == kcg_c2->Q_OVERLAP);
  kcg_equ = kcg_equ & (kcg_c1->V_RELEASEDP == kcg_c2->V_RELEASEDP);
  kcg_equ = kcg_equ & (kcg_c1->D_DP == kcg_c2->D_DP);
  kcg_equ = kcg_equ & (kcg_c1->Q_DANGERPOINT == kcg_c2->Q_DANGERPOINT);
  kcg_equ = kcg_equ & (kcg_c1->D_ENDTIMERSTARTLOC ==
      kcg_c2->D_ENDTIMERSTARTLOC);
  kcg_equ = kcg_equ & (kcg_c1->T_ENDTIMER == kcg_c2->T_ENDTIMER);
  kcg_equ = kcg_equ & (kcg_c1->Q_ENDTIMER == kcg_c2->Q_ENDTIMER);
  kcg_equ = kcg_equ & (kcg_c1->D_SECTIONTIMERSTOPLOC ==
      kcg_c2->D_SECTIONTIMERSTOPLOC);
  kcg_equ = kcg_equ & (kcg_c1->T_SECTIONTIMER == kcg_c2->T_SECTIONTIMER);
  kcg_equ = kcg_equ & (kcg_c1->Q_SECTIONTIMER == kcg_c2->Q_SECTIONTIMER);
  kcg_equ = kcg_equ & (kcg_c1->L_ENDSECTION == kcg_c2->L_ENDSECTION);
  kcg_equ = kcg_equ & kcg_comp_struct__14733(
      &kcg_c1->Struct14,
      &kcg_c2->Struct14);
  kcg_equ = kcg_equ & (kcg_c1->T_LOA == kcg_c2->T_LOA);
  kcg_equ = kcg_equ & (kcg_c1->V_LOA == kcg_c2->V_LOA);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14763(struct__14763 *kcg_c1, struct__14763 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->D_SR == kcg_c2->D_SR);
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14773(struct__14773 *kcg_c1, struct__14773 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14770(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14778(struct__14778 *kcg_c1, struct__14778 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14773(
      &kcg_c1->Struct13,
      &kcg_c2->Struct13);
  kcg_equ = kcg_equ & (kcg_c1->D_SR == kcg_c2->D_SR);
  kcg_equ = kcg_equ & kcg_comp_struct__14418(
      &kcg_c1->Struct12,
      &kcg_c2->Struct12);
  kcg_equ = kcg_equ & kcg_comp_struct__14418(
      &kcg_c1->Struct9,
      &kcg_c2->Struct9);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14789(struct__14789 *kcg_c1, struct__14789 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->V_RELEASEOL == kcg_c2->V_RELEASEOL);
  kcg_equ = kcg_equ & (kcg_c1->D_OL == kcg_c2->D_OL);
  kcg_equ = kcg_equ & (kcg_c1->T_OL == kcg_c2->T_OL);
  kcg_equ = kcg_equ & (kcg_c1->D_STARTOL == kcg_c2->D_STARTOL);
  kcg_equ = kcg_equ & (kcg_c1->Q_OVERLAP == kcg_c2->Q_OVERLAP);
  kcg_equ = kcg_equ & (kcg_c1->V_RELEASEDP == kcg_c2->V_RELEASEDP);
  kcg_equ = kcg_equ & (kcg_c1->D_DP == kcg_c2->D_DP);
  kcg_equ = kcg_equ & (kcg_c1->Q_DANGERPOINT == kcg_c2->Q_DANGERPOINT);
  kcg_equ = kcg_equ & (kcg_c1->D_ENDTIMERSTARTLOC ==
      kcg_c2->D_ENDTIMERSTARTLOC);
  kcg_equ = kcg_equ & (kcg_c1->T_ENDTIMER == kcg_c2->T_ENDTIMER);
  kcg_equ = kcg_equ & (kcg_c1->Q_ENDTIMER == kcg_c2->Q_ENDTIMER);
  kcg_equ = kcg_equ & (kcg_c1->D_SECTIONTIMERSTOPLOC ==
      kcg_c2->D_SECTIONTIMERSTOPLOC);
  kcg_equ = kcg_equ & (kcg_c1->T_SECTIONTIMER == kcg_c2->T_SECTIONTIMER);
  kcg_equ = kcg_equ & (kcg_c1->Q_SECTIONTIMER == kcg_c2->Q_SECTIONTIMER);
  kcg_equ = kcg_equ & (kcg_c1->L_ENDSECTION == kcg_c2->L_ENDSECTION);
  kcg_equ = kcg_equ & kcg_comp_struct__14733(
      &kcg_c1->Struct6,
      &kcg_c2->Struct6);
  kcg_equ = kcg_equ & (kcg_c1->T_LOA == kcg_c2->T_LOA);
  kcg_equ = kcg_equ & (kcg_c1->V_LOA == kcg_c2->V_LOA);
  kcg_equ = kcg_equ & (kcg_c1->V_MAIN == kcg_c2->V_MAIN);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14815(struct__14815 *kcg_c1, struct__14815 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->T_VBC == kcg_c2->T_VBC);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->NID_VBCMK == kcg_c2->NID_VBCMK);
  kcg_equ = kcg_equ & (kcg_c1->Q_VBCO == kcg_c2->Q_VBCO);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14825(struct__14825 *kcg_c1, struct__14825 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->Q_LOCACC == kcg_c2->Q_LOCACC);
  kcg_equ = kcg_equ & (kcg_c1->Q_LINKREACTION == kcg_c2->Q_LINKREACTION);
  kcg_equ = kcg_equ & (kcg_c1->Q_LINKORIENTATION == kcg_c2->Q_LINKORIENTATION);
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  kcg_equ = kcg_equ & (kcg_c1->D_LINK == kcg_c2->D_LINK);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14838(struct__14838 *kcg_c1, struct__14838 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14835(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14843(struct__14843 *kcg_c1, struct__14843 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14838(
      &kcg_c1->Struct5,
      &kcg_c2->Struct5);
  kcg_equ = kcg_equ & (kcg_c1->Q_LOCACC == kcg_c2->Q_LOCACC);
  kcg_equ = kcg_equ & (kcg_c1->Q_LINKREACTION == kcg_c2->Q_LINKREACTION);
  kcg_equ = kcg_equ & (kcg_c1->Q_LINKORIENTATION == kcg_c2->Q_LINKORIENTATION);
  kcg_equ = kcg_equ & (kcg_c1->NID_BG == kcg_c2->NID_BG);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->Q_NEWCOUNTRY == kcg_c2->Q_NEWCOUNTRY);
  kcg_equ = kcg_equ & (kcg_c1->D_LINK == kcg_c2->D_LINK);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14858(struct__14858 *kcg_c1, struct__14858 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_NVKRINT == kcg_c2->M_NVKRINT);
  kcg_equ = kcg_equ & (kcg_c1->L_NVKRINT == kcg_c2->L_NVKRINT);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14866(struct__14866 *kcg_c1, struct__14866 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14863(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14871(struct__14871 *kcg_c1, struct__14871 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_NVKVINT == kcg_c2->M_NVKVINT);
  kcg_equ = kcg_equ & (kcg_c1->V_NVKVINT == kcg_c2->V_NVKVINT);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14879(struct__14879 *kcg_c1, struct__14879 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14876(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14884(struct__14884 *kcg_c1, struct__14884 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_struct__14879(
      &kcg_c1->Struct51,
      &kcg_c2->Struct51);
  kcg_equ = kcg_equ & (kcg_c1->M_NVKVINT == kcg_c2->M_NVKVINT);
  kcg_equ = kcg_equ & (kcg_c1->V_NVKVINT == kcg_c2->V_NVKVINT);
  kcg_equ = kcg_equ & (kcg_c1->A_NVP23 == kcg_c2->A_NVP23);
  kcg_equ = kcg_equ & (kcg_c1->A_NVP12 == kcg_c2->A_NVP12);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVKVINTSET == kcg_c2->Q_NVKVINTSET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14896(struct__14896 *kcg_c1, struct__14896 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14893(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14901(struct__14901 *kcg_c1, struct__14901 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14908(struct__14908 *kcg_c1, struct__14908 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & kcg_comp_array__14905(&kcg_c1->Array, &kcg_c2->Array);
  kcg_equ = kcg_equ & (kcg_c1->N_ITER == kcg_c2->N_ITER);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14913(struct__14913 *kcg_c1, struct__14913 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_NVKTINT == kcg_c2->M_NVKTINT);
  kcg_equ = kcg_equ & kcg_comp_struct__14866(
      &kcg_c1->Struct4,
      &kcg_c2->Struct4);
  kcg_equ = kcg_equ & (kcg_c1->M_NVKRINT == kcg_c2->M_NVKRINT);
  kcg_equ = kcg_equ & (kcg_c1->L_NVKRINT == kcg_c2->L_NVKRINT);
  kcg_equ = kcg_equ & kcg_comp_struct__14896(
      &kcg_c1->Struct2,
      &kcg_c2->Struct2);
  kcg_equ = kcg_equ & kcg_comp_struct__14879(
      &kcg_c1->Struct1,
      &kcg_c2->Struct1);
  kcg_equ = kcg_equ & (kcg_c1->M_NVKVINT == kcg_c2->M_NVKVINT);
  kcg_equ = kcg_equ & (kcg_c1->V_NVKVINT == kcg_c2->V_NVKVINT);
  kcg_equ = kcg_equ & (kcg_c1->A_NVP23 == kcg_c2->A_NVP23);
  kcg_equ = kcg_equ & (kcg_c1->A_NVP12 == kcg_c2->A_NVP12);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVKVINTSET == kcg_c2->Q_NVKVINTSET);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVKINT == kcg_c2->Q_NVKINT);
  kcg_equ = kcg_equ & (kcg_c1->M_NVEBCL == kcg_c2->M_NVEBCL);
  kcg_equ = kcg_equ & (kcg_c1->M_NVAVADH == kcg_c2->M_NVAVADH);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVLOCACC == kcg_c2->Q_NVLOCACC);
  kcg_equ = kcg_equ & (kcg_c1->A_NVMAXREDADH3 == kcg_c2->A_NVMAXREDADH3);
  kcg_equ = kcg_equ & (kcg_c1->A_NVMAXREDADH2 == kcg_c2->A_NVMAXREDADH2);
  kcg_equ = kcg_equ & (kcg_c1->A_NVMAXREDADH1 == kcg_c2->A_NVMAXREDADH1);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVDRIVER_ADHES == kcg_c2->Q_NVDRIVER_ADHES);
  kcg_equ = kcg_equ & (kcg_c1->D_NVSTFF == kcg_c2->D_NVSTFF);
  kcg_equ = kcg_equ & (kcg_c1->M_NVDERUN == kcg_c2->M_NVDERUN);
  kcg_equ = kcg_equ & (kcg_c1->T_NVCONTACT == kcg_c2->T_NVCONTACT);
  kcg_equ = kcg_equ & (kcg_c1->M_NVCONTACT == kcg_c2->M_NVCONTACT);
  kcg_equ = kcg_equ & (kcg_c1->D_NVPOTRP == kcg_c2->D_NVPOTRP);
  kcg_equ = kcg_equ & (kcg_c1->T_NVOVTRP == kcg_c2->T_NVOVTRP);
  kcg_equ = kcg_equ & (kcg_c1->D_NVOVTRP == kcg_c2->D_NVOVTRP);
  kcg_equ = kcg_equ & (kcg_c1->V_NVSUPOVTRP == kcg_c2->V_NVSUPOVTRP);
  kcg_equ = kcg_equ & (kcg_c1->V_NVALLOWOVTRP == kcg_c2->V_NVALLOWOVTRP);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVINHSMICPERM == kcg_c2->Q_NVINHSMICPERM);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVSBFBPERM == kcg_c2->Q_NVSBFBPERM);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVGUIPERM == kcg_c2->Q_NVGUIPERM);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVEMRRLS == kcg_c2->Q_NVEMRRLS);
  kcg_equ = kcg_equ & (kcg_c1->Q_NVSBTSMPERM == kcg_c2->Q_NVSBTSMPERM);
  kcg_equ = kcg_equ & (kcg_c1->D_NVROLL == kcg_c2->D_NVROLL);
  kcg_equ = kcg_equ & (kcg_c1->V_NVREL == kcg_c2->V_NVREL);
  kcg_equ = kcg_equ & (kcg_c1->V_NVUNFIT == kcg_c2->V_NVUNFIT);
  kcg_equ = kcg_equ & (kcg_c1->V_NVLIMSUPERV == kcg_c2->V_NVLIMSUPERV);
  kcg_equ = kcg_equ & (kcg_c1->V_NVONSIGHT == kcg_c2->V_NVONSIGHT);
  kcg_equ = kcg_equ & (kcg_c1->V_NVSTFF == kcg_c2->V_NVSTFF);
  kcg_equ = kcg_equ & (kcg_c1->V_NVSHUNT == kcg_c2->V_NVSHUNT);
  kcg_equ = kcg_equ & kcg_comp_struct__14908(
      &kcg_c1->Struct0,
      &kcg_c2->Struct0);
  kcg_equ = kcg_equ & (kcg_c1->NID_C == kcg_c2->NID_C);
  kcg_equ = kcg_equ & (kcg_c1->D_VALIDNV == kcg_c2->D_VALIDNV);
  kcg_equ = kcg_equ & (kcg_c1->Q_SCALE == kcg_c2->Q_SCALE);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14963(struct__14963 *kcg_c1, struct__14963 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->M_VERSION == kcg_c2->M_VERSION);
  kcg_equ = kcg_equ & (kcg_c1->L_PACKET == kcg_c2->L_PACKET);
  kcg_equ = kcg_equ & (kcg_c1->Q_DIR == kcg_c2->Q_DIR);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

kcg_bool kcg_comp_struct__14970(struct__14970 *kcg_c1, struct__14970 *kcg_c2)
{
  static kcg_bool kcg_equ;
  
  kcg_equ = kcg_true;
  kcg_equ = kcg_equ & (kcg_c1->NID_VBCMK == kcg_c2->NID_VBCMK);
  kcg_equ = kcg_equ & (kcg_c1->NID_PACKET == kcg_c2->NID_PACKET);
  return kcg_equ;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** kcg_types.c
** Generation date: 2014-12-02T12:57:49
*************************************************************$ */

