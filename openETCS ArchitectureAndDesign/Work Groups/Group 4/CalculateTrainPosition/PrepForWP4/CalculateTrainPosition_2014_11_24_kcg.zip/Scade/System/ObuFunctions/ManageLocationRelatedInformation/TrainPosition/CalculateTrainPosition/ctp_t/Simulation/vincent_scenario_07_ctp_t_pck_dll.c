const char*  pszDllPathname = "ctp_t_pck__vincent_scenario_07.dll";

const char*  pszLauncherPathname = "D:/programme/Esterel Technologies/SCADE R15.2/SCADE/bin/SCSSMLNC.exe";

