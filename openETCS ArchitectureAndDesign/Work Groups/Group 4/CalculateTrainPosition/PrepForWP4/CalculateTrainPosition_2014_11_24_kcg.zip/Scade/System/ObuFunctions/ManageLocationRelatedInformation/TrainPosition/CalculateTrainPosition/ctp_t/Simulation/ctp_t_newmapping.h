/* ctp_t_newmapping.h */

#include "vincent_scenario_07_ctp_t_pck.h"

/*******************************
* Simulation context
*******************************/
extern outC_vincent_scenario_07_ctp_t_pck outputs_ctx;

