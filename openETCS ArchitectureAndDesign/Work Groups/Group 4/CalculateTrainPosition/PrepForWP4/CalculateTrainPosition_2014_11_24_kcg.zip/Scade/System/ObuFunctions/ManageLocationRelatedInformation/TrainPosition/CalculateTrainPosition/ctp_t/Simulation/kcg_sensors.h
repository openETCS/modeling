/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:01
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** kcg_sensors.h
** Generation date: 2014-10-27T12:56:01
*************************************************************$ */

