/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _genOdometry_ctp_t_pck_t_engine_H_
#define _genOdometry_ctp_t_pck_t_engine_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::odometry */ odometry;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  kcg_int /* ctp_t_pck::t_engine::genOdometry::_L17 */ rem__L17;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genOdometry::time */ rem_time;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
} outC_genOdometry_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::genOdometry */
extern void genOdometry_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genOdometry::location */L_internal_Type_Obu_BasicTypes_Pkg location,
  /* ctp_t_pck::t_engine::genOdometry::time */T_internal_Type_Obu_BasicTypes_Pkg time,
  outC_genOdometry_ctp_t_pck_t_engine *outC);

extern void genOdometry_reset_ctp_t_pck_t_engine(
  outC_genOdometry_ctp_t_pck_t_engine *outC);

#endif /* _genOdometry_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genOdometry_ctp_t_pck_t_engine.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

