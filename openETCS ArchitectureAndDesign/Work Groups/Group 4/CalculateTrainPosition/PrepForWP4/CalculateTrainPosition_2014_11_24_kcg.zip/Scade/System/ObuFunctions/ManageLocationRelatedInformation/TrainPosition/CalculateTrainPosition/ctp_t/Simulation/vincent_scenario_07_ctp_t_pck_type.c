
#include <stdlib.h>
#include "SmuTypes.h"
#include "kcg_types.h"
#include "vincent_scenario_07_ctp_t_pck_type.h"
#include "vincent_scenario_07_ctp_t_pck_mapping.h"

extern ScSimulator * pSimulator;

/****************************************************************
 ** Boolean entity activation
 ****************************************************************/
int _SCSIM_BoolEntity_is_active(void* pValue) {
	return *((kcg_bool*)pValue) == kcg_true ? 1 : 0;
}

/****************************************************************
 ** Type utils declarations
 ****************************************************************/
TypeUtils _SCSIM_kcg_real_Utils = {kcg_real_to_string,
	check_kcg_real_string,
	string_to_kcg_real,
	is_kcg_real_allow_double_convertion,
	kcg_real_to_double,
	compare_kcg_real_type,
	get_kcg_real_signature,
	get_kcg_real_filter_utils,
	kcg_real_filter_size,
	kcg_real_filter_values};
TypeUtils _SCSIM_kcg_bool_Utils = {kcg_bool_to_string,
	check_kcg_bool_string,
	string_to_kcg_bool,
	is_kcg_bool_allow_double_convertion,
	kcg_bool_to_double,
	compare_kcg_bool_type,
	get_kcg_bool_signature,
	get_kcg_bool_filter_utils,
	kcg_bool_filter_size,
	kcg_bool_filter_values};
TypeUtils _SCSIM_kcg_char_Utils = {kcg_char_to_string,
	check_kcg_char_string,
	string_to_kcg_char,
	is_kcg_char_allow_double_convertion,
	kcg_char_to_double,
	compare_kcg_char_type,
	get_kcg_char_signature,
	get_kcg_char_filter_utils,
	kcg_char_filter_size,
	kcg_char_filter_values};
TypeUtils _SCSIM_kcg_int_Utils = {kcg_int_to_string,
	check_kcg_int_string,
	string_to_kcg_int,
	is_kcg_int_allow_double_convertion,
	kcg_int_to_double,
	compare_kcg_int_type,
	get_kcg_int_signature,
	get_kcg_int_filter_utils,
	kcg_int_filter_size,
	kcg_int_filter_values};
TypeUtils _SCSIM_struct__5578_Utils = {struct__5578_to_string,
	check_struct__5578_string,
	string_to_struct__5578,
	is_struct__5578_allow_double_convertion,
	0,
	compare_struct__5578_type,
	get_struct__5578_signature,
	get_struct__5578_filter_utils,
	struct__5578_filter_size,
	struct__5578_filter_values};
TypeUtils _SCSIM_struct__5584_Utils = {struct__5584_to_string,
	check_struct__5584_string,
	string_to_struct__5584,
	is_struct__5584_allow_double_convertion,
	0,
	compare_struct__5584_type,
	get_struct__5584_signature,
	get_struct__5584_filter_utils,
	struct__5584_filter_size,
	struct__5584_filter_values};
TypeUtils _SCSIM_struct__5600_Utils = {struct__5600_to_string,
	check_struct__5600_string,
	string_to_struct__5600,
	is_struct__5600_allow_double_convertion,
	0,
	compare_struct__5600_type,
	get_struct__5600_signature,
	get_struct__5600_filter_utils,
	struct__5600_filter_size,
	struct__5600_filter_values};
TypeUtils _SCSIM_struct__5609_Utils = {struct__5609_to_string,
	check_struct__5609_string,
	string_to_struct__5609,
	is_struct__5609_allow_double_convertion,
	0,
	compare_struct__5609_type,
	get_struct__5609_signature,
	get_struct__5609_filter_utils,
	struct__5609_filter_size,
	struct__5609_filter_values};
TypeUtils _SCSIM_array__5615_Utils = {array__5615_to_string,
	check_array__5615_string,
	string_to_array__5615,
	is_array__5615_allow_double_convertion,
	0,
	compare_array__5615_type,
	get_array__5615_signature,
	get_array__5615_filter_utils,
	array__5615_filter_size,
	array__5615_filter_values};
TypeUtils _SCSIM_struct__5618_Utils = {struct__5618_to_string,
	check_struct__5618_string,
	string_to_struct__5618,
	is_struct__5618_allow_double_convertion,
	0,
	compare_struct__5618_type,
	get_struct__5618_signature,
	get_struct__5618_filter_utils,
	struct__5618_filter_size,
	struct__5618_filter_values};
TypeUtils _SCSIM_struct__5629_Utils = {struct__5629_to_string,
	check_struct__5629_string,
	string_to_struct__5629,
	is_struct__5629_allow_double_convertion,
	0,
	compare_struct__5629_type,
	get_struct__5629_signature,
	get_struct__5629_filter_utils,
	struct__5629_filter_size,
	struct__5629_filter_values};
TypeUtils _SCSIM_struct__5642_Utils = {struct__5642_to_string,
	check_struct__5642_string,
	string_to_struct__5642,
	is_struct__5642_allow_double_convertion,
	0,
	compare_struct__5642_type,
	get_struct__5642_signature,
	get_struct__5642_filter_utils,
	struct__5642_filter_size,
	struct__5642_filter_values};
TypeUtils _SCSIM_struct__5653_Utils = {struct__5653_to_string,
	check_struct__5653_string,
	string_to_struct__5653,
	is_struct__5653_allow_double_convertion,
	0,
	compare_struct__5653_type,
	get_struct__5653_signature,
	get_struct__5653_filter_utils,
	struct__5653_filter_size,
	struct__5653_filter_values};
TypeUtils _SCSIM_struct__5664_Utils = {struct__5664_to_string,
	check_struct__5664_string,
	string_to_struct__5664,
	is_struct__5664_allow_double_convertion,
	0,
	compare_struct__5664_type,
	get_struct__5664_signature,
	get_struct__5664_filter_utils,
	struct__5664_filter_size,
	struct__5664_filter_values};
TypeUtils _SCSIM_struct__5681_Utils = {struct__5681_to_string,
	check_struct__5681_string,
	string_to_struct__5681,
	is_struct__5681_allow_double_convertion,
	0,
	compare_struct__5681_type,
	get_struct__5681_signature,
	get_struct__5681_filter_utils,
	struct__5681_filter_size,
	struct__5681_filter_values};
TypeUtils _SCSIM_array__5687_Utils = {array__5687_to_string,
	check_array__5687_string,
	string_to_array__5687,
	is_array__5687_allow_double_convertion,
	0,
	compare_array__5687_type,
	get_array__5687_signature,
	get_array__5687_filter_utils,
	array__5687_filter_size,
	array__5687_filter_values};
TypeUtils _SCSIM_struct__5690_Utils = {struct__5690_to_string,
	check_struct__5690_string,
	string_to_struct__5690,
	is_struct__5690_allow_double_convertion,
	0,
	compare_struct__5690_type,
	get_struct__5690_signature,
	get_struct__5690_filter_utils,
	struct__5690_filter_size,
	struct__5690_filter_values};
TypeUtils _SCSIM_struct__5701_Utils = {struct__5701_to_string,
	check_struct__5701_string,
	string_to_struct__5701,
	is_struct__5701_allow_double_convertion,
	0,
	compare_struct__5701_type,
	get_struct__5701_signature,
	get_struct__5701_filter_utils,
	struct__5701_filter_size,
	struct__5701_filter_values};
TypeUtils _SCSIM_struct__5708_Utils = {struct__5708_to_string,
	check_struct__5708_string,
	string_to_struct__5708,
	is_struct__5708_allow_double_convertion,
	0,
	compare_struct__5708_type,
	get_struct__5708_signature,
	get_struct__5708_filter_utils,
	struct__5708_filter_size,
	struct__5708_filter_values};
TypeUtils _SCSIM_struct__5714_Utils = {struct__5714_to_string,
	check_struct__5714_string,
	string_to_struct__5714,
	is_struct__5714_allow_double_convertion,
	0,
	compare_struct__5714_type,
	get_struct__5714_signature,
	get_struct__5714_filter_utils,
	struct__5714_filter_size,
	struct__5714_filter_values};
TypeUtils _SCSIM_struct__5723_Utils = {struct__5723_to_string,
	check_struct__5723_string,
	string_to_struct__5723,
	is_struct__5723_allow_double_convertion,
	0,
	compare_struct__5723_type,
	get_struct__5723_signature,
	get_struct__5723_filter_utils,
	struct__5723_filter_size,
	struct__5723_filter_values};
TypeUtils _SCSIM_array__5729_Utils = {array__5729_to_string,
	check_array__5729_string,
	string_to_array__5729,
	is_array__5729_allow_double_convertion,
	0,
	compare_array__5729_type,
	get_array__5729_signature,
	get_array__5729_filter_utils,
	array__5729_filter_size,
	array__5729_filter_values};
TypeUtils _SCSIM_struct__5732_Utils = {struct__5732_to_string,
	check_struct__5732_string,
	string_to_struct__5732,
	is_struct__5732_allow_double_convertion,
	0,
	compare_struct__5732_type,
	get_struct__5732_signature,
	get_struct__5732_filter_utils,
	struct__5732_filter_size,
	struct__5732_filter_values};
TypeUtils _SCSIM_array__5740_Utils = {array__5740_to_string,
	check_array__5740_string,
	string_to_array__5740,
	is_array__5740_allow_double_convertion,
	0,
	compare_array__5740_type,
	get_array__5740_signature,
	get_array__5740_filter_utils,
	array__5740_filter_size,
	array__5740_filter_values};
TypeUtils _SCSIM_struct__5743_Utils = {struct__5743_to_string,
	check_struct__5743_string,
	string_to_struct__5743,
	is_struct__5743_allow_double_convertion,
	0,
	compare_struct__5743_type,
	get_struct__5743_signature,
	get_struct__5743_filter_utils,
	struct__5743_filter_size,
	struct__5743_filter_values};
TypeUtils _SCSIM_struct__5748_Utils = {struct__5748_to_string,
	check_struct__5748_string,
	string_to_struct__5748,
	is_struct__5748_allow_double_convertion,
	0,
	compare_struct__5748_type,
	get_struct__5748_signature,
	get_struct__5748_filter_utils,
	struct__5748_filter_size,
	struct__5748_filter_values};
TypeUtils _SCSIM_array__5753_Utils = {array__5753_to_string,
	check_array__5753_string,
	string_to_array__5753,
	is_array__5753_allow_double_convertion,
	0,
	compare_array__5753_type,
	get_array__5753_signature,
	get_array__5753_filter_utils,
	array__5753_filter_size,
	array__5753_filter_values};
TypeUtils _SCSIM_struct__5756_Utils = {struct__5756_to_string,
	check_struct__5756_string,
	string_to_struct__5756,
	is_struct__5756_allow_double_convertion,
	0,
	compare_struct__5756_type,
	get_struct__5756_signature,
	get_struct__5756_filter_utils,
	struct__5756_filter_size,
	struct__5756_filter_values};
TypeUtils _SCSIM_array__5762_Utils = {array__5762_to_string,
	check_array__5762_string,
	string_to_array__5762,
	is_array__5762_allow_double_convertion,
	0,
	compare_array__5762_type,
	get_array__5762_signature,
	get_array__5762_filter_utils,
	array__5762_filter_size,
	array__5762_filter_values};
TypeUtils _SCSIM_array_int_8_Utils = {array_int_8_to_string,
	check_array_int_8_string,
	string_to_array_int_8,
	is_array_int_8_allow_double_convertion,
	0,
	compare_array_int_8_type,
	get_array_int_8_signature,
	get_array_int_8_filter_utils,
	array_int_8_filter_size,
	array_int_8_filter_values};
TypeUtils _SCSIM_array__5768_Utils = {array__5768_to_string,
	check_array__5768_string,
	string_to_array__5768,
	is_array__5768_allow_double_convertion,
	0,
	compare_array__5768_type,
	get_array__5768_signature,
	get_array__5768_filter_utils,
	array__5768_filter_size,
	array__5768_filter_values};
TypeUtils _SCSIM_array__5771_Utils = {array__5771_to_string,
	check_array__5771_string,
	string_to_array__5771,
	is_array__5771_allow_double_convertion,
	0,
	compare_array__5771_type,
	get_array__5771_signature,
	get_array__5771_filter_utils,
	array__5771_filter_size,
	array__5771_filter_values};
TypeUtils _SCSIM_array_bool_8_Utils = {array_bool_8_to_string,
	check_array_bool_8_string,
	string_to_array_bool_8,
	is_array_bool_8_allow_double_convertion,
	0,
	compare_array_bool_8_type,
	get_array_bool_8_signature,
	get_array_bool_8_filter_utils,
	array_bool_8_filter_size,
	array_bool_8_filter_values};
TypeUtils _SCSIM_array__5777_Utils = {array__5777_to_string,
	check_array__5777_string,
	string_to_array__5777,
	is_array__5777_allow_double_convertion,
	0,
	compare_array__5777_type,
	get_array__5777_signature,
	get_array__5777_filter_utils,
	array__5777_filter_size,
	array__5777_filter_values};
TypeUtils _SCSIM_array__5780_Utils = {array__5780_to_string,
	check_array__5780_string,
	string_to_array__5780,
	is_array__5780_allow_double_convertion,
	0,
	compare_array__5780_type,
	get_array__5780_signature,
	get_array__5780_filter_utils,
	array__5780_filter_size,
	array__5780_filter_values};
TypeUtils _SCSIM_array_int_10_Utils = {array_int_10_to_string,
	check_array_int_10_string,
	string_to_array_int_10,
	is_array_int_10_allow_double_convertion,
	0,
	compare_array_int_10_type,
	get_array_int_10_signature,
	get_array_int_10_filter_utils,
	array_int_10_filter_size,
	array_int_10_filter_values};
TypeUtils _SCSIM_Q_UPDOWN_Utils = {Q_UPDOWN_to_string,
	check_Q_UPDOWN_string,
	string_to_Q_UPDOWN,
	is_Q_UPDOWN_allow_double_convertion,
	Q_UPDOWN_to_double,
	compare_Q_UPDOWN_type,
	get_Q_UPDOWN_signature,
	get_Q_UPDOWN_filter_utils,
	Q_UPDOWN_filter_size,
	Q_UPDOWN_filter_values};
TypeUtils _SCSIM_M_VERSION_Utils = {M_VERSION_to_string,
	check_M_VERSION_string,
	string_to_M_VERSION,
	is_M_VERSION_allow_double_convertion,
	M_VERSION_to_double,
	compare_M_VERSION_type,
	get_M_VERSION_signature,
	get_M_VERSION_filter_utils,
	M_VERSION_filter_size,
	M_VERSION_filter_values};
TypeUtils _SCSIM_Q_MEDIA_Utils = {Q_MEDIA_to_string,
	check_Q_MEDIA_string,
	string_to_Q_MEDIA,
	is_Q_MEDIA_allow_double_convertion,
	Q_MEDIA_to_double,
	compare_Q_MEDIA_type,
	get_Q_MEDIA_signature,
	get_Q_MEDIA_filter_utils,
	Q_MEDIA_filter_size,
	Q_MEDIA_filter_values};
TypeUtils _SCSIM_N_TOTAL_Utils = {N_TOTAL_to_string,
	check_N_TOTAL_string,
	string_to_N_TOTAL,
	is_N_TOTAL_allow_double_convertion,
	N_TOTAL_to_double,
	compare_N_TOTAL_type,
	get_N_TOTAL_signature,
	get_N_TOTAL_filter_utils,
	N_TOTAL_filter_size,
	N_TOTAL_filter_values};
TypeUtils _SCSIM_M_MCOUNT_Utils = {M_MCOUNT_to_string,
	check_M_MCOUNT_string,
	string_to_M_MCOUNT,
	is_M_MCOUNT_allow_double_convertion,
	M_MCOUNT_to_double,
	compare_M_MCOUNT_type,
	get_M_MCOUNT_signature,
	get_M_MCOUNT_filter_utils,
	M_MCOUNT_filter_size,
	M_MCOUNT_filter_values};
TypeUtils _SCSIM_NID_C_Utils = {NID_C_to_string,
	check_NID_C_string,
	string_to_NID_C,
	is_NID_C_allow_double_convertion,
	NID_C_to_double,
	compare_NID_C_type,
	get_NID_C_signature,
	get_NID_C_filter_utils,
	NID_C_filter_size,
	NID_C_filter_values};
TypeUtils _SCSIM_NID_BG_Utils = {NID_BG_to_string,
	check_NID_BG_string,
	string_to_NID_BG,
	is_NID_BG_allow_double_convertion,
	NID_BG_to_double,
	compare_NID_BG_type,
	get_NID_BG_signature,
	get_NID_BG_filter_utils,
	NID_BG_filter_size,
	NID_BG_filter_values};
TypeUtils _SCSIM_Q_LINK_Utils = {Q_LINK_to_string,
	check_Q_LINK_string,
	string_to_Q_LINK,
	is_Q_LINK_allow_double_convertion,
	Q_LINK_to_double,
	compare_Q_LINK_type,
	get_Q_LINK_signature,
	get_Q_LINK_filter_utils,
	Q_LINK_filter_size,
	Q_LINK_filter_values};
TypeUtils _SCSIM_NID_LRBG_Utils = {NID_LRBG_to_string,
	check_NID_LRBG_string,
	string_to_NID_LRBG,
	is_NID_LRBG_allow_double_convertion,
	NID_LRBG_to_double,
	compare_NID_LRBG_type,
	get_NID_LRBG_signature,
	get_NID_LRBG_filter_utils,
	NID_LRBG_filter_size,
	NID_LRBG_filter_values};
TypeUtils _SCSIM_NID_PACKET_Utils = {NID_PACKET_to_string,
	check_NID_PACKET_string,
	string_to_NID_PACKET,
	is_NID_PACKET_allow_double_convertion,
	NID_PACKET_to_double,
	compare_NID_PACKET_type,
	get_NID_PACKET_signature,
	get_NID_PACKET_filter_utils,
	NID_PACKET_filter_size,
	NID_PACKET_filter_values};
TypeUtils _SCSIM_Q_DIR_Utils = {Q_DIR_to_string,
	check_Q_DIR_string,
	string_to_Q_DIR,
	is_Q_DIR_allow_double_convertion,
	Q_DIR_to_double,
	compare_Q_DIR_type,
	get_Q_DIR_signature,
	get_Q_DIR_filter_utils,
	Q_DIR_filter_size,
	Q_DIR_filter_values};
TypeUtils _SCSIM_L_PACKET_Utils = {L_PACKET_to_string,
	check_L_PACKET_string,
	string_to_L_PACKET,
	is_L_PACKET_allow_double_convertion,
	L_PACKET_to_double,
	compare_L_PACKET_type,
	get_L_PACKET_signature,
	get_L_PACKET_filter_utils,
	L_PACKET_filter_size,
	L_PACKET_filter_values};
TypeUtils _SCSIM_Q_SCALE_Utils = {Q_SCALE_to_string,
	check_Q_SCALE_string,
	string_to_Q_SCALE,
	is_Q_SCALE_allow_double_convertion,
	Q_SCALE_to_double,
	compare_Q_SCALE_type,
	get_Q_SCALE_signature,
	get_Q_SCALE_filter_utils,
	Q_SCALE_filter_size,
	Q_SCALE_filter_values};
TypeUtils _SCSIM_D_LINK_Utils = {D_LINK_to_string,
	check_D_LINK_string,
	string_to_D_LINK,
	is_D_LINK_allow_double_convertion,
	D_LINK_to_double,
	compare_D_LINK_type,
	get_D_LINK_signature,
	get_D_LINK_filter_utils,
	D_LINK_filter_size,
	D_LINK_filter_values};
TypeUtils _SCSIM_Q_NEWCOUNTRY_Utils = {Q_NEWCOUNTRY_to_string,
	check_Q_NEWCOUNTRY_string,
	string_to_Q_NEWCOUNTRY,
	is_Q_NEWCOUNTRY_allow_double_convertion,
	Q_NEWCOUNTRY_to_double,
	compare_Q_NEWCOUNTRY_type,
	get_Q_NEWCOUNTRY_signature,
	get_Q_NEWCOUNTRY_filter_utils,
	Q_NEWCOUNTRY_filter_size,
	Q_NEWCOUNTRY_filter_values};
TypeUtils _SCSIM_Q_LINKORIENTATION_Utils = {Q_LINKORIENTATION_to_string,
	check_Q_LINKORIENTATION_string,
	string_to_Q_LINKORIENTATION,
	is_Q_LINKORIENTATION_allow_double_convertion,
	Q_LINKORIENTATION_to_double,
	compare_Q_LINKORIENTATION_type,
	get_Q_LINKORIENTATION_signature,
	get_Q_LINKORIENTATION_filter_utils,
	Q_LINKORIENTATION_filter_size,
	Q_LINKORIENTATION_filter_values};
TypeUtils _SCSIM_Q_LINKREACTION_Utils = {Q_LINKREACTION_to_string,
	check_Q_LINKREACTION_string,
	string_to_Q_LINKREACTION,
	is_Q_LINKREACTION_allow_double_convertion,
	Q_LINKREACTION_to_double,
	compare_Q_LINKREACTION_type,
	get_Q_LINKREACTION_signature,
	get_Q_LINKREACTION_filter_utils,
	Q_LINKREACTION_filter_size,
	Q_LINKREACTION_filter_values};
TypeUtils _SCSIM_Q_LOCACC_Utils = {Q_LOCACC_to_string,
	check_Q_LOCACC_string,
	string_to_Q_LOCACC,
	is_Q_LOCACC_allow_double_convertion,
	Q_LOCACC_to_double,
	compare_Q_LOCACC_type,
	get_Q_LOCACC_signature,
	get_Q_LOCACC_filter_utils,
	Q_LOCACC_filter_size,
	Q_LOCACC_filter_values};
TypeUtils _SCSIM_Q_DIRLRBG_Utils = {Q_DIRLRBG_to_string,
	check_Q_DIRLRBG_string,
	string_to_Q_DIRLRBG,
	is_Q_DIRLRBG_allow_double_convertion,
	Q_DIRLRBG_to_double,
	compare_Q_DIRLRBG_type,
	get_Q_DIRLRBG_signature,
	get_Q_DIRLRBG_filter_utils,
	Q_DIRLRBG_filter_size,
	Q_DIRLRBG_filter_values};
TypeUtils _SCSIM_Q_DIRTRAIN_Utils = {Q_DIRTRAIN_to_string,
	check_Q_DIRTRAIN_string,
	string_to_Q_DIRTRAIN,
	is_Q_DIRTRAIN_allow_double_convertion,
	Q_DIRTRAIN_to_double,
	compare_Q_DIRTRAIN_type,
	get_Q_DIRTRAIN_signature,
	get_Q_DIRTRAIN_filter_utils,
	Q_DIRTRAIN_filter_size,
	Q_DIRTRAIN_filter_values};
TypeUtils _SCSIM_NID_ENGINE_Utils = {NID_ENGINE_to_string,
	check_NID_ENGINE_string,
	string_to_NID_ENGINE,
	is_NID_ENGINE_allow_double_convertion,
	NID_ENGINE_to_double,
	compare_NID_ENGINE_type,
	get_NID_ENGINE_signature,
	get_NID_ENGINE_filter_utils,
	NID_ENGINE_filter_size,
	NID_ENGINE_filter_values};
TypeUtils _SCSIM_NID_OPERATIONAL_Utils = {NID_OPERATIONAL_to_string,
	check_NID_OPERATIONAL_string,
	string_to_NID_OPERATIONAL,
	is_NID_OPERATIONAL_allow_double_convertion,
	NID_OPERATIONAL_to_double,
	compare_NID_OPERATIONAL_type,
	get_NID_OPERATIONAL_signature,
	get_NID_OPERATIONAL_filter_utils,
	NID_OPERATIONAL_filter_size,
	NID_OPERATIONAL_filter_values};
TypeUtils _SCSIM_L_TRAIN_Utils = {L_TRAIN_to_string,
	check_L_TRAIN_string,
	string_to_L_TRAIN,
	is_L_TRAIN_allow_double_convertion,
	L_TRAIN_to_double,
	compare_L_TRAIN_type,
	get_L_TRAIN_signature,
	get_L_TRAIN_filter_utils,
	L_TRAIN_filter_size,
	L_TRAIN_filter_values};
TypeUtils _SCSIM_Q_NVLOCACC_Utils = {Q_NVLOCACC_to_string,
	check_Q_NVLOCACC_string,
	string_to_Q_NVLOCACC,
	is_Q_NVLOCACC_allow_double_convertion,
	Q_NVLOCACC_to_double,
	compare_Q_NVLOCACC_type,
	get_Q_NVLOCACC_signature,
	get_Q_NVLOCACC_filter_utils,
	Q_NVLOCACC_filter_size,
	Q_NVLOCACC_filter_values};
TypeUtils _SCSIM_NID_PRVLRBG_Utils = {NID_PRVLRBG_to_string,
	check_NID_PRVLRBG_string,
	string_to_NID_PRVLRBG,
	is_NID_PRVLRBG_allow_double_convertion,
	NID_PRVLRBG_to_double,
	compare_NID_PRVLRBG_type,
	get_NID_PRVLRBG_signature,
	get_NID_PRVLRBG_filter_utils,
	NID_PRVLRBG_filter_size,
	NID_PRVLRBG_filter_values};
TypeUtils _SCSIM_Q_DLRBG_Utils = {Q_DLRBG_to_string,
	check_Q_DLRBG_string,
	string_to_Q_DLRBG,
	is_Q_DLRBG_allow_double_convertion,
	Q_DLRBG_to_double,
	compare_Q_DLRBG_type,
	get_Q_DLRBG_signature,
	get_Q_DLRBG_filter_utils,
	Q_DLRBG_filter_size,
	Q_DLRBG_filter_values};
TypeUtils _SCSIM_odometryFactors_T_ctp_t_pck_t_engine_Utils = {odometryFactors_T_ctp_t_pck_t_engine_to_string,
	check_odometryFactors_T_ctp_t_pck_t_engine_string,
	string_to_odometryFactors_T_ctp_t_pck_t_engine,
	is_odometryFactors_T_ctp_t_pck_t_engine_allow_double_convertion,
	odometryFactors_T_ctp_t_pck_t_engine_to_double,
	compare_odometryFactors_T_ctp_t_pck_t_engine_type,
	get_odometryFactors_T_ctp_t_pck_t_engine_signature,
	get_odometryFactors_T_ctp_t_pck_t_engine_filter_utils,
	odometryFactors_T_ctp_t_pck_t_engine_filter_size,
	odometryFactors_T_ctp_t_pck_t_engine_filter_values};
TypeUtils _SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils = {genPassedBG_T_ctp_t_pck_t_engine_to_string,
	check_genPassedBG_T_ctp_t_pck_t_engine_string,
	string_to_genPassedBG_T_ctp_t_pck_t_engine,
	is_genPassedBG_T_ctp_t_pck_t_engine_allow_double_convertion,
	genPassedBG_T_ctp_t_pck_t_engine_to_double,
	compare_genPassedBG_T_ctp_t_pck_t_engine_type,
	get_genPassedBG_T_ctp_t_pck_t_engine_signature,
	get_genPassedBG_T_ctp_t_pck_t_engine_filter_utils,
	genPassedBG_T_ctp_t_pck_t_engine_filter_size,
	genPassedBG_T_ctp_t_pck_t_engine_filter_values};
TypeUtils _SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils = {genPassedBGs_T_ctp_t_pck_t_engine_to_string,
	check_genPassedBGs_T_ctp_t_pck_t_engine_string,
	string_to_genPassedBGs_T_ctp_t_pck_t_engine,
	is_genPassedBGs_T_ctp_t_pck_t_engine_allow_double_convertion,
	genPassedBGs_T_ctp_t_pck_t_engine_to_double,
	compare_genPassedBGs_T_ctp_t_pck_t_engine_type,
	get_genPassedBGs_T_ctp_t_pck_t_engine_signature,
	get_genPassedBGs_T_ctp_t_pck_t_engine_filter_utils,
	genPassedBGs_T_ctp_t_pck_t_engine_filter_size,
	genPassedBGs_T_ctp_t_pck_t_engine_filter_values};
TypeUtils _SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils = {positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_string,
	check_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_string,
	string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg,
	is_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_allow_double_convertion,
	positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_double,
	compare_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_type,
	get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_signature,
	get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_filter_utils,
	positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_filter_size,
	positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_filter_values};
TypeUtils _SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils = {BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string,
	check_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string,
	string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg,
	is_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion,
	BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double,
	compare_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_type,
	get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature,
	get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_utils,
	BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_size,
	BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_values};
TypeUtils _SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils = {BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string,
	check_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string,
	string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg,
	is_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion,
	BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double,
	compare_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_type,
	get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature,
	get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_utils,
	BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_size,
	BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_values};
TypeUtils _SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils = {refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string,
	check_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string,
	string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
	is_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion,
	refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double,
	compare_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_type,
	get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature,
	get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_utils,
	refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_size,
	refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_values};
TypeUtils _SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils = {linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string,
	check_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string,
	string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
	is_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion,
	linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double,
	compare_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_type,
	get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature,
	get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_utils,
	linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_size,
	linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_values};
TypeUtils _SCSIM_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils = {linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string,
	check_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string,
	string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg,
	is_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion,
	linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double,
	compare_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_type,
	get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature,
	get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_utils,
	linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_size,
	linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_values};
TypeUtils _SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils = {trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_string,
	check_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_string,
	string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg,
	is_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_allow_double_convertion,
	trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_double,
	compare_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_type,
	get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_signature,
	get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_filter_utils,
	trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_filter_size,
	trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_filter_values};
TypeUtils _SCSIM_passedBG_T_BG_Types_Pkg_Utils = {passedBG_T_BG_Types_Pkg_to_string,
	check_passedBG_T_BG_Types_Pkg_string,
	string_to_passedBG_T_BG_Types_Pkg,
	is_passedBG_T_BG_Types_Pkg_allow_double_convertion,
	passedBG_T_BG_Types_Pkg_to_double,
	compare_passedBG_T_BG_Types_Pkg_type,
	get_passedBG_T_BG_Types_Pkg_signature,
	get_passedBG_T_BG_Types_Pkg_filter_utils,
	passedBG_T_BG_Types_Pkg_filter_size,
	passedBG_T_BG_Types_Pkg_filter_values};
TypeUtils _SCSIM_BG_Header_T_BG_Types_Pkg_Utils = {BG_Header_T_BG_Types_Pkg_to_string,
	check_BG_Header_T_BG_Types_Pkg_string,
	string_to_BG_Header_T_BG_Types_Pkg,
	is_BG_Header_T_BG_Types_Pkg_allow_double_convertion,
	BG_Header_T_BG_Types_Pkg_to_double,
	compare_BG_Header_T_BG_Types_Pkg_type,
	get_BG_Header_T_BG_Types_Pkg_signature,
	get_BG_Header_T_BG_Types_Pkg_filter_utils,
	BG_Header_T_BG_Types_Pkg_filter_size,
	BG_Header_T_BG_Types_Pkg_filter_values};
TypeUtils _SCSIM_LinkedBGs_T_BG_Types_Pkg_Utils = {LinkedBGs_T_BG_Types_Pkg_to_string,
	check_LinkedBGs_T_BG_Types_Pkg_string,
	string_to_LinkedBGs_T_BG_Types_Pkg,
	is_LinkedBGs_T_BG_Types_Pkg_allow_double_convertion,
	LinkedBGs_T_BG_Types_Pkg_to_double,
	compare_LinkedBGs_T_BG_Types_Pkg_type,
	get_LinkedBGs_T_BG_Types_Pkg_signature,
	get_LinkedBGs_T_BG_Types_Pkg_filter_utils,
	LinkedBGs_T_BG_Types_Pkg_filter_size,
	LinkedBGs_T_BG_Types_Pkg_filter_values};
TypeUtils _SCSIM_LinkedBG_T_BG_Types_Pkg_Utils = {LinkedBG_T_BG_Types_Pkg_to_string,
	check_LinkedBG_T_BG_Types_Pkg_string,
	string_to_LinkedBG_T_BG_Types_Pkg,
	is_LinkedBG_T_BG_Types_Pkg_allow_double_convertion,
	LinkedBG_T_BG_Types_Pkg_to_double,
	compare_LinkedBG_T_BG_Types_Pkg_type,
	get_LinkedBG_T_BG_Types_Pkg_signature,
	get_LinkedBG_T_BG_Types_Pkg_filter_utils,
	LinkedBG_T_BG_Types_Pkg_filter_size,
	LinkedBG_T_BG_Types_Pkg_filter_values};
TypeUtils _SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils = {T_internal_Type_Obu_BasicTypes_Pkg_to_string,
	check_T_internal_Type_Obu_BasicTypes_Pkg_string,
	string_to_T_internal_Type_Obu_BasicTypes_Pkg,
	is_T_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion,
	T_internal_Type_Obu_BasicTypes_Pkg_to_double,
	compare_T_internal_Type_Obu_BasicTypes_Pkg_type,
	get_T_internal_Type_Obu_BasicTypes_Pkg_signature,
	get_T_internal_Type_Obu_BasicTypes_Pkg_filter_utils,
	T_internal_Type_Obu_BasicTypes_Pkg_filter_size,
	T_internal_Type_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils = {OdometryLocations_T_Obu_BasicTypes_Pkg_to_string,
	check_OdometryLocations_T_Obu_BasicTypes_Pkg_string,
	string_to_OdometryLocations_T_Obu_BasicTypes_Pkg,
	is_OdometryLocations_T_Obu_BasicTypes_Pkg_allow_double_convertion,
	OdometryLocations_T_Obu_BasicTypes_Pkg_to_double,
	compare_OdometryLocations_T_Obu_BasicTypes_Pkg_type,
	get_OdometryLocations_T_Obu_BasicTypes_Pkg_signature,
	get_OdometryLocations_T_Obu_BasicTypes_Pkg_filter_utils,
	OdometryLocations_T_Obu_BasicTypes_Pkg_filter_size,
	OdometryLocations_T_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils = {L_internal_Type_Obu_BasicTypes_Pkg_to_string,
	check_L_internal_Type_Obu_BasicTypes_Pkg_string,
	string_to_L_internal_Type_Obu_BasicTypes_Pkg,
	is_L_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion,
	L_internal_Type_Obu_BasicTypes_Pkg_to_double,
	compare_L_internal_Type_Obu_BasicTypes_Pkg_type,
	get_L_internal_Type_Obu_BasicTypes_Pkg_signature,
	get_L_internal_Type_Obu_BasicTypes_Pkg_filter_utils,
	L_internal_Type_Obu_BasicTypes_Pkg_filter_size,
	L_internal_Type_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils = {LocWithInAcc_T_Obu_BasicTypes_Pkg_to_string,
	check_LocWithInAcc_T_Obu_BasicTypes_Pkg_string,
	string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg,
	is_LocWithInAcc_T_Obu_BasicTypes_Pkg_allow_double_convertion,
	LocWithInAcc_T_Obu_BasicTypes_Pkg_to_double,
	compare_LocWithInAcc_T_Obu_BasicTypes_Pkg_type,
	get_LocWithInAcc_T_Obu_BasicTypes_Pkg_signature,
	get_LocWithInAcc_T_Obu_BasicTypes_Pkg_filter_utils,
	LocWithInAcc_T_Obu_BasicTypes_Pkg_filter_size,
	LocWithInAcc_T_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils = {Speed_T_Obu_BasicTypes_Pkg_to_string,
	check_Speed_T_Obu_BasicTypes_Pkg_string,
	string_to_Speed_T_Obu_BasicTypes_Pkg,
	is_Speed_T_Obu_BasicTypes_Pkg_allow_double_convertion,
	Speed_T_Obu_BasicTypes_Pkg_to_double,
	compare_Speed_T_Obu_BasicTypes_Pkg_type,
	get_Speed_T_Obu_BasicTypes_Pkg_signature,
	get_Speed_T_Obu_BasicTypes_Pkg_filter_utils,
	Speed_T_Obu_BasicTypes_Pkg_filter_size,
	Speed_T_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_V_internal_Type_Obu_BasicTypes_Pkg_Utils = {V_internal_Type_Obu_BasicTypes_Pkg_to_string,
	check_V_internal_Type_Obu_BasicTypes_Pkg_string,
	string_to_V_internal_Type_Obu_BasicTypes_Pkg,
	is_V_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion,
	V_internal_Type_Obu_BasicTypes_Pkg_to_double,
	compare_V_internal_Type_Obu_BasicTypes_Pkg_type,
	get_V_internal_Type_Obu_BasicTypes_Pkg_signature,
	get_V_internal_Type_Obu_BasicTypes_Pkg_filter_utils,
	V_internal_Type_Obu_BasicTypes_Pkg_filter_size,
	V_internal_Type_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils = {Location_T_Obu_BasicTypes_Pkg_to_string,
	check_Location_T_Obu_BasicTypes_Pkg_string,
	string_to_Location_T_Obu_BasicTypes_Pkg,
	is_Location_T_Obu_BasicTypes_Pkg_allow_double_convertion,
	Location_T_Obu_BasicTypes_Pkg_to_double,
	compare_Location_T_Obu_BasicTypes_Pkg_type,
	get_Location_T_Obu_BasicTypes_Pkg_signature,
	get_Location_T_Obu_BasicTypes_Pkg_filter_utils,
	Location_T_Obu_BasicTypes_Pkg_filter_size,
	Location_T_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils = {odometry_T_Obu_BasicTypes_Pkg_to_string,
	check_odometry_T_Obu_BasicTypes_Pkg_string,
	string_to_odometry_T_Obu_BasicTypes_Pkg,
	is_odometry_T_Obu_BasicTypes_Pkg_allow_double_convertion,
	odometry_T_Obu_BasicTypes_Pkg_to_double,
	compare_odometry_T_Obu_BasicTypes_Pkg_type,
	get_odometry_T_Obu_BasicTypes_Pkg_signature,
	get_odometry_T_Obu_BasicTypes_Pkg_filter_utils,
	odometry_T_Obu_BasicTypes_Pkg_filter_size,
	odometry_T_Obu_BasicTypes_Pkg_filter_values};
TypeUtils _SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils = {positionedBG_T_TrainPosition_Types_Pck_to_string,
	check_positionedBG_T_TrainPosition_Types_Pck_string,
	string_to_positionedBG_T_TrainPosition_Types_Pck,
	is_positionedBG_T_TrainPosition_Types_Pck_allow_double_convertion,
	positionedBG_T_TrainPosition_Types_Pck_to_double,
	compare_positionedBG_T_TrainPosition_Types_Pck_type,
	get_positionedBG_T_TrainPosition_Types_Pck_signature,
	get_positionedBG_T_TrainPosition_Types_Pck_filter_utils,
	positionedBG_T_TrainPosition_Types_Pck_filter_size,
	positionedBG_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils = {infoFromLinking_T_TrainPosition_Types_Pck_to_string,
	check_infoFromLinking_T_TrainPosition_Types_Pck_string,
	string_to_infoFromLinking_T_TrainPosition_Types_Pck,
	is_infoFromLinking_T_TrainPosition_Types_Pck_allow_double_convertion,
	infoFromLinking_T_TrainPosition_Types_Pck_to_double,
	compare_infoFromLinking_T_TrainPosition_Types_Pck_type,
	get_infoFromLinking_T_TrainPosition_Types_Pck_signature,
	get_infoFromLinking_T_TrainPosition_Types_Pck_filter_utils,
	infoFromLinking_T_TrainPosition_Types_Pck_filter_size,
	infoFromLinking_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils = {trainProperties_T_TrainPosition_Types_Pck_to_string,
	check_trainProperties_T_TrainPosition_Types_Pck_string,
	string_to_trainProperties_T_TrainPosition_Types_Pck,
	is_trainProperties_T_TrainPosition_Types_Pck_allow_double_convertion,
	trainProperties_T_TrainPosition_Types_Pck_to_double,
	compare_trainProperties_T_TrainPosition_Types_Pck_type,
	get_trainProperties_T_TrainPosition_Types_Pck_signature,
	get_trainProperties_T_TrainPosition_Types_Pck_filter_utils,
	trainProperties_T_TrainPosition_Types_Pck_filter_size,
	trainProperties_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils = {linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_string,
	check_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_string,
	string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck,
	is_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion,
	linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_double,
	compare_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_type,
	get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_signature,
	get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_filter_utils,
	linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_filter_size,
	linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils = {positionedBGs_T_TrainPosition_Types_Pck_to_string,
	check_positionedBGs_T_TrainPosition_Types_Pck_string,
	string_to_positionedBGs_T_TrainPosition_Types_Pck,
	is_positionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion,
	positionedBGs_T_TrainPosition_Types_Pck_to_double,
	compare_positionedBGs_T_TrainPosition_Types_Pck_type,
	get_positionedBGs_T_TrainPosition_Types_Pck_signature,
	get_positionedBGs_T_TrainPosition_Types_Pck_filter_utils,
	positionedBGs_T_TrainPosition_Types_Pck_filter_size,
	positionedBGs_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils = {positionErrors_T_TrainPosition_Types_Pck_to_string,
	check_positionErrors_T_TrainPosition_Types_Pck_string,
	string_to_positionErrors_T_TrainPosition_Types_Pck,
	is_positionErrors_T_TrainPosition_Types_Pck_allow_double_convertion,
	positionErrors_T_TrainPosition_Types_Pck_to_double,
	compare_positionErrors_T_TrainPosition_Types_Pck_type,
	get_positionErrors_T_TrainPosition_Types_Pck_signature,
	get_positionErrors_T_TrainPosition_Types_Pck_filter_utils,
	positionErrors_T_TrainPosition_Types_Pck_filter_size,
	positionErrors_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils = {trainPosition_T_TrainPosition_Types_Pck_to_string,
	check_trainPosition_T_TrainPosition_Types_Pck_string,
	string_to_trainPosition_T_TrainPosition_Types_Pck,
	is_trainPosition_T_TrainPosition_Types_Pck_allow_double_convertion,
	trainPosition_T_TrainPosition_Types_Pck_to_double,
	compare_trainPosition_T_TrainPosition_Types_Pck_type,
	get_trainPosition_T_TrainPosition_Types_Pck_signature,
	get_trainPosition_T_TrainPosition_Types_Pck_filter_utils,
	trainPosition_T_TrainPosition_Types_Pck_filter_size,
	trainPosition_T_TrainPosition_Types_Pck_filter_values};
TypeUtils _SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils = {trainPositionInfo_T_TrainPosition_Types_Pck_to_string,
	check_trainPositionInfo_T_TrainPosition_Types_Pck_string,
	string_to_trainPositionInfo_T_TrainPosition_Types_Pck,
	is_trainPositionInfo_T_TrainPosition_Types_Pck_allow_double_convertion,
	trainPositionInfo_T_TrainPosition_Types_Pck_to_double,
	compare_trainPositionInfo_T_TrainPosition_Types_Pck_type,
	get_trainPositionInfo_T_TrainPosition_Types_Pck_signature,
	get_trainPositionInfo_T_TrainPosition_Types_Pck_filter_utils,
	trainPositionInfo_T_TrainPosition_Types_Pck_filter_size,
	trainPositionInfo_T_TrainPosition_Types_Pck_filter_values};

/****************************************************************
 ** kcg_real
 ****************************************************************/
struct SimTypeVTable* pSimDoubleVTable;
const char * kcg_real_to_string(const void* pValue) {
	if (pSimDoubleVTable != 0 && pSimDoubleVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
		double value = (double)(*(const kcg_real*)pValue);
		return *(char**)pSimDoubleVTable->m_pfnToType(SptString, &value);
	}
	return pSimulator->m_pfnRealToString((double)(*(const kcg_real*)pValue));
}

int string_to_kcg_real(const char* strValue, void* pValue) {
	double nTemp = 0;
	static double rTemp;
	int nResult;
	if (pSimDoubleVTable != 0 && pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		nResult = pSimDoubleVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*(kcg_real*)pValue = (kcg_real)rTemp;
		return nResult;
	}
	nResult = pSimulator->m_pfnStringToReal(strValue, &nTemp);
	if (nResult == 1)
		*(kcg_real*)pValue = (kcg_real)nTemp;
	return nResult;
}

int compare_kcg_real_type(int* pResult, const char* toCompare, const void* pValue) {
	static kcg_real rTemp;
	const kcg_real* pCurrent = (const kcg_real*)pValue;
	if (string_to_kcg_real(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

int is_kcg_real_allow_double_convertion() {
	if (pSimDoubleVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return 1;
}

int kcg_real_to_double(double * nValue, const void* pValue) {
	if (pSimDoubleVTable != 0) {
		double value = (double)(*(const kcg_real*)pValue);
		if (pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimDoubleVTable->m_pfnToType(SptDouble, &value));
		else if (pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimDoubleVTable->m_pfnToType(SptFloat, &value));
		else if (pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimDoubleVTable->m_pfnToType(SptLong, &value));
		else if (pSimDoubleVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimDoubleVTable->m_pfnToType(SptShort, &value));
		else
			return 0;
		return 1;
	}
	*nValue = (double)*((const kcg_real*)pValue);
	return 1;
}

const char * get_kcg_real_signature() {
	return "R";
}

int check_kcg_real_string(const char* strValue) {
	static kcg_real rTemp;
	return string_to_kcg_real(strValue, &rTemp);
}


/****************************************************************
 ** kcg_bool
 ****************************************************************/
struct SimTypeVTable* pSimBoolVTable;
const char * kcg_bool_to_string(const void* pValue) {
	if (pSimBoolVTable != 0 && pSimBoolVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
		SimBool value = (*((const kcg_bool*)pValue) == kcg_true)? SbTrue : SbFalse;
		return *(char**)pSimBoolVTable->m_pfnToType(SptString, &value);
	}
	return pSimulator->m_pfnBoolToString((*(const kcg_bool*)pValue) == kcg_true ? 1 : 0);
}

int string_to_kcg_bool(const char* strValue, void* pValue) {
	int nTemp = 0;
	static SimBool rTemp;
	int nResult;
	if (pSimBoolVTable != 0 && pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		nResult = pSimBoolVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((kcg_bool*)pValue) = (rTemp == SbTrue)? kcg_true : kcg_false;
		return nResult;
	}
	nResult = pSimulator->m_pfnStringToBool(strValue, &nTemp);
	if (nResult == 1)
		*(kcg_bool*)pValue = nTemp == 1 ? kcg_true : kcg_false;
	return nResult;
}

int compare_kcg_bool_type(int* pResult, const char* toCompare, const void* pValue) {
	static kcg_bool rTemp;
	const kcg_bool* pCurrent = (const kcg_bool*)pValue;
	if (string_to_kcg_bool(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

int is_kcg_bool_allow_double_convertion() {
	if (pSimBoolVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return 1;
}

int kcg_bool_to_double(double * nValue, const void* pValue) {
	if (pSimBoolVTable != 0) {
		SimBool value = (*(const kcg_bool*)pValue == kcg_true)? SbTrue : SbFalse;
		if (pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimBoolVTable->m_pfnToType(SptDouble, &value));
		else if (pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimBoolVTable->m_pfnToType(SptFloat, &value));
		else if (pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimBoolVTable->m_pfnToType(SptLong, &value));
		else if (pSimBoolVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimBoolVTable->m_pfnToType(SptShort, &value));
		else
			return 0;
		return 1;
	}
	*nValue = *((const kcg_bool*)pValue) == kcg_true ? 1.0 : 0.0;
	return 1;
}

const char * get_kcg_bool_signature() {
	return "B";
}

int check_kcg_bool_string(const char* strValue) {
	static kcg_bool rTemp;
	return string_to_kcg_bool(strValue, &rTemp);
}


/****************************************************************
 ** kcg_char
 ****************************************************************/
struct SimTypeVTable* pSimCharVTable;
const char * kcg_char_to_string(const void* pValue) {
	if (pSimCharVTable != 0 && pSimCharVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
		char value = (char)(*(const kcg_char*)pValue);
		return *(char**)pSimCharVTable->m_pfnToType(SptString, &value);
	}
	return pSimulator->m_pfnCharToString((char)(*(const kcg_char*)pValue));
}

int string_to_kcg_char(const char* strValue, void* pValue) {
	char nTemp = 0;
	static char rTemp;
	int nResult;
	if (pSimCharVTable != 0 && pSimCharVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		nResult = pSimCharVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*(kcg_char*)pValue = (kcg_char)rTemp;
		return nResult;
	}
	nResult = pSimulator->m_pfnStringToChar(strValue, &nTemp);
	if (nResult == 1)
		*(kcg_char*)pValue = (kcg_char)nTemp;
	return nResult;
}

int compare_kcg_char_type(int* pResult, const char* toCompare, const void* pValue) {
	static kcg_char rTemp;
	const kcg_char* pCurrent = (const kcg_char*)pValue;
	if (string_to_kcg_char(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

int is_kcg_char_allow_double_convertion() {
	if (pSimCharVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimCharVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimCharVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimCharVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimCharVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return 1;
}

int kcg_char_to_double(double * nValue, const void* pValue) {
	if (pSimCharVTable != 0) {
		char value = (char)(*(const kcg_char*)pValue);
		if (pSimCharVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimCharVTable->m_pfnToType(SptDouble, &value));
		else if (pSimCharVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimCharVTable->m_pfnToType(SptFloat, &value));
		else if (pSimCharVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimCharVTable->m_pfnToType(SptLong, &value));
		else if (pSimCharVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimCharVTable->m_pfnToType(SptShort, &value));
		else
			return 0;
		return 1;
	}
	*nValue = (double)*((const kcg_char*)pValue);
	return 1;
}

const char * get_kcg_char_signature() {
	return "C";
}

int check_kcg_char_string(const char* strValue) {
	static kcg_char rTemp;
	return string_to_kcg_char(strValue, &rTemp);
}


/****************************************************************
 ** kcg_int
 ****************************************************************/
struct SimTypeVTable* pSimLongVTable;
const char * kcg_int_to_string(const void* pValue) {
	if (pSimLongVTable != 0 && pSimLongVTable->m_pfnGetConvInfo(SptString, SptNone) == 1) {
		long value = (long)(*(const kcg_int*)pValue);
		return *(char**)pSimLongVTable->m_pfnToType(SptString, &value);
	}
	return pSimulator->m_pfnIntToString(*(const int*)pValue);
}

int string_to_kcg_int(const char* strValue, void* pValue) {
	int nTemp = 0;
	static long rTemp;
	int nResult;
	if (pSimLongVTable != 0 && pSimLongVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		nResult = pSimLongVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*(kcg_int*)pValue = (kcg_int)rTemp;
		return nResult;
	}
	nResult = pSimulator->m_pfnStringToInt(strValue, &nTemp);
	if (nResult == 1)
		*(kcg_int*)pValue = (kcg_int)nTemp;
	return nResult;
}

int compare_kcg_int_type(int* pResult, const char* toCompare, const void* pValue) {
	static kcg_int rTemp;
	const kcg_int* pCurrent = (const kcg_int*)pValue;
	if (string_to_kcg_int(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

int is_kcg_int_allow_double_convertion() {
	if (pSimLongVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimLongVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimLongVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimLongVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimLongVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return 1;
}

int kcg_int_to_double(double * nValue, const void* pValue) {
	if (pSimLongVTable != 0) {
		long value = (long)(*(const kcg_int*)pValue);
		if (pSimLongVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimLongVTable->m_pfnToType(SptDouble, &value));
		else if (pSimLongVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimLongVTable->m_pfnToType(SptFloat, &value));
		else if (pSimLongVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimLongVTable->m_pfnToType(SptLong, &value));
		else if (pSimLongVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimLongVTable->m_pfnToType(SptShort, &value));
		else
			return 0;
		return 1;
	}
	*nValue = (double)*((const kcg_int*)pValue);
	return 1;
}

const char * get_kcg_int_signature() {
	return "I";
}

int check_kcg_int_string(const char* strValue) {
	static kcg_int rTemp;
	return string_to_kcg_int(strValue, &rTemp);
}


/****************************************************************
 ** struct__5578
 ****************************************************************/
static void Fill_struct__5578_StructSimValue(struct__5578 * pStruct, StructSimValue * pValues) {
	/*nominal label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->nominal) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "nominal";
	/*d_min label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->d_min) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "d_min";
	/*d_max label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->d_max) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "d_max";
}

const char * struct__5578_to_string(const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5578_StructSimValue(((struct__5578*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 3);
}

int string_to_struct__5578(const char* strValue, void* pValue) {
	static struct__5578 rTemp;
	int nResult = 0;
	static StructSimValue values[3];
	kcg_copy_struct__5578(&(rTemp), &(*((struct__5578*)pValue)));
	Fill_struct__5578_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 3);
	if (nResult == 1)
		kcg_copy_struct__5578(&(*((struct__5578*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5578_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5578_StructSimValue((struct__5578*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 3);
}


int is_struct__5578_allow_double_convertion() {
	return 0;
}


const char * get_struct__5578_signature() {
	static StructSimValue values[3];
	Fill_struct__5578_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 3);
}

FilterUtils get_struct__5578_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5578_StructSimValue((struct__5578*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 3, strFilter);
}

const char * struct__5578_filter_values[3] = {"nominal", "d_min", "d_max"};
int check_struct__5578_string(const char* strValue) {
	static struct__5578 rTemp;
	return string_to_struct__5578(strValue, &rTemp);
}


/****************************************************************
 ** struct__5584
 ****************************************************************/
static void Fill_struct__5584_StructSimValue(struct__5584 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*nid_LRBG label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->nid_LRBG) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "nid_LRBG";
	/*nid_packet label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->nid_packet) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "nid_packet";
	/*q_dir label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->q_dir) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_Q_DIR_Utils;
	pValues[3].m_pszName = "q_dir";
	/*l_packet label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->l_packet) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[4].m_pszName = "l_packet";
	/*q_scale label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->q_scale) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_Q_SCALE_Utils;
	pValues[5].m_pszName = "q_scale";
	/*d_link label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->d_link) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[6].m_pszName = "d_link";
	/*q_newcountry label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->q_newcountry) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_Q_NEWCOUNTRY_Utils;
	pValues[7].m_pszName = "q_newcountry";
	/*nid_c label.*/
	pValues[8].m_pPtr = pStruct != 0 ? &(pStruct->nid_c) : 0;
	pValues[8].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[8].m_pszName = "nid_c";
	/*nid_bg label.*/
	pValues[9].m_pPtr = pStruct != 0 ? &(pStruct->nid_bg) : 0;
	pValues[9].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[9].m_pszName = "nid_bg";
	/*q_linkorientation label.*/
	pValues[10].m_pPtr = pStruct != 0 ? &(pStruct->q_linkorientation) : 0;
	pValues[10].m_pTypeUtils = &_SCSIM_Q_LINKORIENTATION_Utils;
	pValues[10].m_pszName = "q_linkorientation";
	/*q_linkreaction label.*/
	pValues[11].m_pPtr = pStruct != 0 ? &(pStruct->q_linkreaction) : 0;
	pValues[11].m_pTypeUtils = &_SCSIM_Q_LINKREACTION_Utils;
	pValues[11].m_pszName = "q_linkreaction";
	/*q_locacc label.*/
	pValues[12].m_pPtr = pStruct != 0 ? &(pStruct->q_locacc) : 0;
	pValues[12].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[12].m_pszName = "q_locacc";
}

const char * struct__5584_to_string(const void* pValue) {
	static StructSimValue values[13];
	Fill_struct__5584_StructSimValue(((struct__5584*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 13);
}

int string_to_struct__5584(const char* strValue, void* pValue) {
	static struct__5584 rTemp;
	int nResult = 0;
	static StructSimValue values[13];
	kcg_copy_struct__5584(&(rTemp), &(*((struct__5584*)pValue)));
	Fill_struct__5584_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 13);
	if (nResult == 1)
		kcg_copy_struct__5584(&(*((struct__5584*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5584_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[13];
	Fill_struct__5584_StructSimValue((struct__5584*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 13);
}


int is_struct__5584_allow_double_convertion() {
	return 0;
}


const char * get_struct__5584_signature() {
	static StructSimValue values[13];
	Fill_struct__5584_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 13);
}

FilterUtils get_struct__5584_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[13];
	Fill_struct__5584_StructSimValue((struct__5584*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 13, strFilter);
}

const char * struct__5584_filter_values[13] = {"valid", "nid_LRBG", "nid_packet", "q_dir", "l_packet", "q_scale", "d_link", "q_newcountry", "nid_c", "nid_bg", "q_linkorientation", "q_linkreaction", "q_locacc"};
int check_struct__5584_string(const char* strValue) {
	static struct__5584 rTemp;
	return string_to_struct__5584(strValue, &rTemp);
}


/****************************************************************
 ** struct__5600
 ****************************************************************/
static void Fill_struct__5600_StructSimValue(struct__5600 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*nid_bg_fromLinkingBG label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->nid_bg_fromLinkingBG) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "nid_bg_fromLinkingBG";
	/*nid_c_fromLinkingBG label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->nid_c_fromLinkingBG) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "nid_c_fromLinkingBG";
	/*expectedLocation label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->expectedLocation) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[3].m_pszName = "expectedLocation";
	/*d_link label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->d_link) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[4].m_pszName = "d_link";
	/*linkingInfo label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->linkingInfo) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_struct__5584_Utils;
	pValues[5].m_pszName = "linkingInfo";
}

const char * struct__5600_to_string(const void* pValue) {
	static StructSimValue values[6];
	Fill_struct__5600_StructSimValue(((struct__5600*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 6);
}

int string_to_struct__5600(const char* strValue, void* pValue) {
	static struct__5600 rTemp;
	int nResult = 0;
	static StructSimValue values[6];
	kcg_copy_struct__5600(&(rTemp), &(*((struct__5600*)pValue)));
	Fill_struct__5600_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 6);
	if (nResult == 1)
		kcg_copy_struct__5600(&(*((struct__5600*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5600_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[6];
	Fill_struct__5600_StructSimValue((struct__5600*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 6);
}


int is_struct__5600_allow_double_convertion() {
	return 0;
}


const char * get_struct__5600_signature() {
	static StructSimValue values[6];
	Fill_struct__5600_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 6);
}

FilterUtils get_struct__5600_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[6];
	Fill_struct__5600_StructSimValue((struct__5600*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 6, strFilter);
}

const char * struct__5600_filter_values[6] = {"valid", "nid_bg_fromLinkingBG", "nid_c_fromLinkingBG", "expectedLocation", "d_link", "linkingInfo"};
int check_struct__5600_string(const char* strValue) {
	static struct__5600 rTemp;
	return string_to_struct__5600(strValue, &rTemp);
}


/****************************************************************
 ** struct__5609
 ****************************************************************/
static void Fill_struct__5609_StructSimValue(struct__5609 * pStruct, StructSimValue * pValues) {
	/*o_nominal label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->o_nominal) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "o_nominal";
	/*o_min label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->o_min) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "o_min";
	/*o_max label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->o_max) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "o_max";
}

const char * struct__5609_to_string(const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5609_StructSimValue(((struct__5609*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 3);
}

int string_to_struct__5609(const char* strValue, void* pValue) {
	static struct__5609 rTemp;
	int nResult = 0;
	static StructSimValue values[3];
	kcg_copy_struct__5609(&(rTemp), &(*((struct__5609*)pValue)));
	Fill_struct__5609_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 3);
	if (nResult == 1)
		kcg_copy_struct__5609(&(*((struct__5609*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5609_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5609_StructSimValue((struct__5609*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 3);
}


int is_struct__5609_allow_double_convertion() {
	return 0;
}


const char * get_struct__5609_signature() {
	static StructSimValue values[3];
	Fill_struct__5609_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 3);
}

FilterUtils get_struct__5609_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5609_StructSimValue((struct__5609*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 3, strFilter);
}

const char * struct__5609_filter_values[3] = {"o_nominal", "o_min", "o_max"};
int check_struct__5609_string(const char* strValue) {
	static struct__5609 rTemp;
	return string_to_struct__5609(strValue, &rTemp);
}


/****************************************************************
 ** array__5615
 ****************************************************************/
void* array__5615_projection(void** pValues, int nIndex) {
	return &((*(array__5615*)pValues)[nIndex]);
}

const char * array__5615_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5584_to_string, 4, array__5615_projection);
}

int compare_array__5615_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5584_type , 4, array__5615_projection);
}

int is_array__5615_allow_double_convertion() {
	return 0;
}

int string_to_array__5615(const char* strValue, void* pValue) {
	static array__5615 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5584, 4, array__5615_projection);
	if (nResult == 1)
		kcg_copy_array__5615(&(*((array__5615*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5615_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5584_signature, 4);
}

FilterUtils get_array__5615_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5584_Utils, strFilter, (void**)pValue, 4, array__5615_projection);
}

int check_array__5615_string(const char* strValue) {
	static array__5615 rTemp;
	return string_to_array__5615(strValue, &rTemp);
}


/****************************************************************
 ** struct__5618
 ****************************************************************/
static void Fill_struct__5618_StructSimValue(struct__5618 * pStruct, StructSimValue * pValues) {
	/*q_updown label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->q_updown) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_Q_UPDOWN_Utils;
	pValues[0].m_pszName = "q_updown";
	/*m_version label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->m_version) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_M_VERSION_Utils;
	pValues[1].m_pszName = "m_version";
	/*q_media label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->q_media) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_Q_MEDIA_Utils;
	pValues[2].m_pszName = "q_media";
	/*n_total label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->n_total) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_N_TOTAL_Utils;
	pValues[3].m_pszName = "n_total";
	/*m_mcount label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->m_mcount) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[4].m_pszName = "m_mcount";
	/*nid_c label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->nid_c) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[5].m_pszName = "nid_c";
	/*nid_bg label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->nid_bg) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[6].m_pszName = "nid_bg";
	/*q_link label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->q_link) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_Q_LINK_Utils;
	pValues[7].m_pszName = "q_link";
}

const char * struct__5618_to_string(const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5618_StructSimValue(((struct__5618*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 8);
}

int string_to_struct__5618(const char* strValue, void* pValue) {
	static struct__5618 rTemp;
	int nResult = 0;
	static StructSimValue values[8];
	kcg_copy_struct__5618(&(rTemp), &(*((struct__5618*)pValue)));
	Fill_struct__5618_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 8);
	if (nResult == 1)
		kcg_copy_struct__5618(&(*((struct__5618*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5618_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5618_StructSimValue((struct__5618*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 8);
}


int is_struct__5618_allow_double_convertion() {
	return 0;
}


const char * get_struct__5618_signature() {
	static StructSimValue values[8];
	Fill_struct__5618_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 8);
}

FilterUtils get_struct__5618_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5618_StructSimValue((struct__5618*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 8, strFilter);
}

const char * struct__5618_filter_values[8] = {"q_updown", "m_version", "q_media", "n_total", "m_mcount", "nid_c", "nid_bg", "q_link"};
int check_struct__5618_string(const char* strValue) {
	static struct__5618 rTemp;
	return string_to_struct__5618(strValue, &rTemp);
}


/****************************************************************
 ** struct__5629
 ****************************************************************/
static void Fill_struct__5629_StructSimValue(struct__5629 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*timestamp label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->timestamp) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "timestamp";
	/*odometrystamp label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->odometrystamp) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_struct__5609_Utils;
	pValues[2].m_pszName = "odometrystamp";
	/*BG_centerDetectionInaccuraccuracies label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->BG_centerDetectionInaccuraccuracies) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[3].m_pszName = "BG_centerDetectionInaccuraccuracies";
	/*BG_Header label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->BG_Header) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5618_Utils;
	pValues[4].m_pszName = "BG_Header";
	/*linkedBGs label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->linkedBGs) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_array__5615_Utils;
	pValues[5].m_pszName = "linkedBGs";
	/*noCoordinateSystemHasBeenAssigned label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->noCoordinateSystemHasBeenAssigned) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[6].m_pszName = "noCoordinateSystemHasBeenAssigned";
	/*trainOrientationToBG label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->trainOrientationToBG) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_Q_DIRLRBG_Utils;
	pValues[7].m_pszName = "trainOrientationToBG";
	/*trainRunningDirectionToBG label.*/
	pValues[8].m_pPtr = pStruct != 0 ? &(pStruct->trainRunningDirectionToBG) : 0;
	pValues[8].m_pTypeUtils = &_SCSIM_Q_DIRTRAIN_Utils;
	pValues[8].m_pszName = "trainRunningDirectionToBG";
	/*passingSpeed label.*/
	pValues[9].m_pPtr = pStruct != 0 ? &(pStruct->passingSpeed) : 0;
	pValues[9].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[9].m_pszName = "passingSpeed";
}

const char * struct__5629_to_string(const void* pValue) {
	static StructSimValue values[10];
	Fill_struct__5629_StructSimValue(((struct__5629*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 10);
}

int string_to_struct__5629(const char* strValue, void* pValue) {
	static struct__5629 rTemp;
	int nResult = 0;
	static StructSimValue values[10];
	kcg_copy_struct__5629(&(rTemp), &(*((struct__5629*)pValue)));
	Fill_struct__5629_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 10);
	if (nResult == 1)
		kcg_copy_struct__5629(&(*((struct__5629*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5629_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[10];
	Fill_struct__5629_StructSimValue((struct__5629*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 10);
}


int is_struct__5629_allow_double_convertion() {
	return 0;
}


const char * get_struct__5629_signature() {
	static StructSimValue values[10];
	Fill_struct__5629_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 10);
}

FilterUtils get_struct__5629_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[10];
	Fill_struct__5629_StructSimValue((struct__5629*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 10, strFilter);
}

const char * struct__5629_filter_values[10] = {"valid", "timestamp", "odometrystamp", "BG_centerDetectionInaccuraccuracies", "BG_Header", "linkedBGs", "noCoordinateSystemHasBeenAssigned", "trainOrientationToBG", "trainRunningDirectionToBG", "passingSpeed"};
int check_struct__5629_string(const char* strValue) {
	static struct__5629 rTemp;
	return string_to_struct__5629(strValue, &rTemp);
}


/****************************************************************
 ** struct__5642
 ****************************************************************/
static void Fill_struct__5642_StructSimValue(struct__5642 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*nid_c label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->nid_c) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "nid_c";
	/*nid_bg label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->nid_bg) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "nid_bg";
	/*q_link label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->q_link) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_Q_LINK_Utils;
	pValues[3].m_pszName = "q_link";
	/*location label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->location) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[4].m_pszName = "location";
	/*seqNoOnTrack label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->seqNoOnTrack) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[5].m_pszName = "seqNoOnTrack";
	/*infoFromLinking label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->infoFromLinking) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_struct__5600_Utils;
	pValues[6].m_pszName = "infoFromLinking";
	/*infoFromPassing label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->infoFromPassing) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_struct__5629_Utils;
	pValues[7].m_pszName = "infoFromPassing";
}

const char * struct__5642_to_string(const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5642_StructSimValue(((struct__5642*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 8);
}

int string_to_struct__5642(const char* strValue, void* pValue) {
	static struct__5642 rTemp;
	int nResult = 0;
	static StructSimValue values[8];
	kcg_copy_struct__5642(&(rTemp), &(*((struct__5642*)pValue)));
	Fill_struct__5642_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 8);
	if (nResult == 1)
		kcg_copy_struct__5642(&(*((struct__5642*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5642_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5642_StructSimValue((struct__5642*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 8);
}


int is_struct__5642_allow_double_convertion() {
	return 0;
}


const char * get_struct__5642_signature() {
	static StructSimValue values[8];
	Fill_struct__5642_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 8);
}

FilterUtils get_struct__5642_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5642_StructSimValue((struct__5642*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 8, strFilter);
}

const char * struct__5642_filter_values[8] = {"valid", "nid_c", "nid_bg", "q_link", "location", "seqNoOnTrack", "infoFromLinking", "infoFromPassing"};
int check_struct__5642_string(const char* strValue) {
	static struct__5642 rTemp;
	return string_to_struct__5642(strValue, &rTemp);
}


/****************************************************************
 ** struct__5653
 ****************************************************************/
static void Fill_struct__5653_StructSimValue(struct__5653 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*timestamp label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->timestamp) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "timestamp";
	/*trainPosition label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->trainPosition) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[2].m_pszName = "trainPosition";
	/*trainPositionDerivedFromLastLinkedBG label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->trainPositionDerivedFromLastLinkedBG) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[3].m_pszName = "trainPositionDerivedFromLastLinkedBG";
	/*trainPositionDerivedFromLastUnlinkedBG label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->trainPositionDerivedFromLastUnlinkedBG) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[4].m_pszName = "trainPositionDerivedFromLastUnlinkedBG";
	/*lastPassedLinkedBG label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->lastPassedLinkedBG) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_struct__5642_Utils;
	pValues[5].m_pszName = "lastPassedLinkedBG";
	/*lastPassedUnlinkedBG label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->lastPassedUnlinkedBG) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_struct__5642_Utils;
	pValues[6].m_pszName = "lastPassedUnlinkedBG";
	/*speed label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->speed) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[7].m_pszName = "speed";
}

const char * struct__5653_to_string(const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5653_StructSimValue(((struct__5653*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 8);
}

int string_to_struct__5653(const char* strValue, void* pValue) {
	static struct__5653 rTemp;
	int nResult = 0;
	static StructSimValue values[8];
	kcg_copy_struct__5653(&(rTemp), &(*((struct__5653*)pValue)));
	Fill_struct__5653_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 8);
	if (nResult == 1)
		kcg_copy_struct__5653(&(*((struct__5653*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5653_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5653_StructSimValue((struct__5653*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 8);
}


int is_struct__5653_allow_double_convertion() {
	return 0;
}


const char * get_struct__5653_signature() {
	static StructSimValue values[8];
	Fill_struct__5653_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 8);
}

FilterUtils get_struct__5653_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5653_StructSimValue((struct__5653*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 8, strFilter);
}

const char * struct__5653_filter_values[8] = {"valid", "timestamp", "trainPosition", "trainPositionDerivedFromLastLinkedBG", "trainPositionDerivedFromLastUnlinkedBG", "lastPassedLinkedBG", "lastPassedUnlinkedBG", "speed"};
int check_struct__5653_string(const char* strValue) {
	static struct__5653 rTemp;
	return string_to_struct__5653(strValue, &rTemp);
}


/****************************************************************
 ** struct__5664
 ****************************************************************/
static void Fill_struct__5664_StructSimValue(struct__5664 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*timestamp label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->timestamp) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "timestamp";
	/*trainPositionIsUnknown label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->trainPositionIsUnknown) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[2].m_pszName = "trainPositionIsUnknown";
	/*noCoordinateSystemHasBeenAssigned label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->noCoordinateSystemHasBeenAssigned) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[3].m_pszName = "noCoordinateSystemHasBeenAssigned";
	/*trainPosition label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->trainPosition) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[4].m_pszName = "trainPosition";
	/*estimatedFrontEndPosition label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->estimatedFrontEndPosition) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[5].m_pszName = "estimatedFrontEndPosition";
	/*minSafeFrontEndPosition label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->minSafeFrontEndPosition) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[6].m_pszName = "minSafeFrontEndPosition";
	/*maxSafeFrontEndPostion label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->maxSafeFrontEndPostion) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[7].m_pszName = "maxSafeFrontEndPostion";
	/*nid_LRBG label.*/
	pValues[8].m_pPtr = pStruct != 0 ? &(pStruct->nid_LRBG) : 0;
	pValues[8].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[8].m_pszName = "nid_LRBG";
	/*nid_PrvLRB label.*/
	pValues[9].m_pPtr = pStruct != 0 ? &(pStruct->nid_PrvLRB) : 0;
	pValues[9].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[9].m_pszName = "nid_PrvLRB";
	/*nominalOrReverseToLRBG label.*/
	pValues[10].m_pPtr = pStruct != 0 ? &(pStruct->nominalOrReverseToLRBG) : 0;
	pValues[10].m_pTypeUtils = &_SCSIM_Q_DLRBG_Utils;
	pValues[10].m_pszName = "nominalOrReverseToLRBG";
	/*trainOrientationToLRBG label.*/
	pValues[11].m_pPtr = pStruct != 0 ? &(pStruct->trainOrientationToLRBG) : 0;
	pValues[11].m_pTypeUtils = &_SCSIM_Q_DIRLRBG_Utils;
	pValues[11].m_pszName = "trainOrientationToLRBG";
	/*trainRunningDirectionToLRBG label.*/
	pValues[12].m_pPtr = pStruct != 0 ? &(pStruct->trainRunningDirectionToLRBG) : 0;
	pValues[12].m_pTypeUtils = &_SCSIM_Q_DIRTRAIN_Utils;
	pValues[12].m_pszName = "trainRunningDirectionToLRBG";
	/*speed label.*/
	pValues[13].m_pPtr = pStruct != 0 ? &(pStruct->speed) : 0;
	pValues[13].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[13].m_pszName = "speed";
}

const char * struct__5664_to_string(const void* pValue) {
	static StructSimValue values[14];
	Fill_struct__5664_StructSimValue(((struct__5664*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 14);
}

int string_to_struct__5664(const char* strValue, void* pValue) {
	static struct__5664 rTemp;
	int nResult = 0;
	static StructSimValue values[14];
	kcg_copy_struct__5664(&(rTemp), &(*((struct__5664*)pValue)));
	Fill_struct__5664_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 14);
	if (nResult == 1)
		kcg_copy_struct__5664(&(*((struct__5664*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5664_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[14];
	Fill_struct__5664_StructSimValue((struct__5664*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 14);
}


int is_struct__5664_allow_double_convertion() {
	return 0;
}


const char * get_struct__5664_signature() {
	static StructSimValue values[14];
	Fill_struct__5664_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 14);
}

FilterUtils get_struct__5664_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[14];
	Fill_struct__5664_StructSimValue((struct__5664*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 14, strFilter);
}

const char * struct__5664_filter_values[14] = {"valid", "timestamp", "trainPositionIsUnknown", "noCoordinateSystemHasBeenAssigned", "trainPosition", "estimatedFrontEndPosition", "minSafeFrontEndPosition", "maxSafeFrontEndPostion", "nid_LRBG", "nid_PrvLRB", "nominalOrReverseToLRBG", "trainOrientationToLRBG", "trainRunningDirectionToLRBG", "speed"};
int check_struct__5664_string(const char* strValue) {
	static struct__5664 rTemp;
	return string_to_struct__5664(strValue, &rTemp);
}


/****************************************************************
 ** struct__5681
 ****************************************************************/
static void Fill_struct__5681_StructSimValue(struct__5681 * pStruct, StructSimValue * pValues) {
	/*outOfMemSpace label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->outOfMemSpace) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "outOfMemSpace";
	/*passedBG_notFoundWhereExpected label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->passedBG_notFoundWhereExpected) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[1].m_pszName = "passedBG_notFoundWhereExpected";
	/*positionCalculation_inconsistent label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->positionCalculation_inconsistent) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[2].m_pszName = "positionCalculation_inconsistent";
}

const char * struct__5681_to_string(const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5681_StructSimValue(((struct__5681*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 3);
}

int string_to_struct__5681(const char* strValue, void* pValue) {
	static struct__5681 rTemp;
	int nResult = 0;
	static StructSimValue values[3];
	kcg_copy_struct__5681(&(rTemp), &(*((struct__5681*)pValue)));
	Fill_struct__5681_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 3);
	if (nResult == 1)
		kcg_copy_struct__5681(&(*((struct__5681*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5681_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5681_StructSimValue((struct__5681*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 3);
}


int is_struct__5681_allow_double_convertion() {
	return 0;
}


const char * get_struct__5681_signature() {
	static StructSimValue values[3];
	Fill_struct__5681_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 3);
}

FilterUtils get_struct__5681_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5681_StructSimValue((struct__5681*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 3, strFilter);
}

const char * struct__5681_filter_values[3] = {"outOfMemSpace", "passedBG_notFoundWhereExpected", "positionCalculation_inconsistent"};
int check_struct__5681_string(const char* strValue) {
	static struct__5681 rTemp;
	return string_to_struct__5681(strValue, &rTemp);
}


/****************************************************************
 ** array__5687
 ****************************************************************/
void* array__5687_projection(void** pValues, int nIndex) {
	return &((*(array__5687*)pValues)[nIndex]);
}

const char * array__5687_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5642_to_string, 8, array__5687_projection);
}

int compare_array__5687_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5642_type , 8, array__5687_projection);
}

int is_array__5687_allow_double_convertion() {
	return 0;
}

int string_to_array__5687(const char* strValue, void* pValue) {
	static array__5687 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5642, 8, array__5687_projection);
	if (nResult == 1)
		kcg_copy_array__5687(&(*((array__5687*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5687_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5642_signature, 8);
}

FilterUtils get_array__5687_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5642_Utils, strFilter, (void**)pValue, 8, array__5687_projection);
}

int check_array__5687_string(const char* strValue) {
	static array__5687 rTemp;
	return string_to_array__5687(strValue, &rTemp);
}


/****************************************************************
 ** struct__5690
 ****************************************************************/
static void Fill_struct__5690_StructSimValue(struct__5690 * pStruct, StructSimValue * pValues) {
	/*nid_engine label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->nid_engine) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "nid_engine";
	/*nid_operational label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->nid_operational) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "nid_operational";
	/*l_train label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->l_train) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "l_train";
	/*d_baliseAntenna_2_frontend label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->d_baliseAntenna_2_frontend) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[3].m_pszName = "d_baliseAntenna_2_frontend";
	/*d_frontend_2_rearend label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->d_frontend_2_rearend) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[4].m_pszName = "d_frontend_2_rearend";
	/*locationAccuracy_NationalValue label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->locationAccuracy_NationalValue) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[5].m_pszName = "locationAccuracy_NationalValue";
	/*locationAccuracy_DefaultValue label.*/
	pValues[6].m_pPtr = pStruct != 0 ? &(pStruct->locationAccuracy_DefaultValue) : 0;
	pValues[6].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[6].m_pszName = "locationAccuracy_DefaultValue";
	/*centerDetectionAcc_DefaultValue label.*/
	pValues[7].m_pPtr = pStruct != 0 ? &(pStruct->centerDetectionAcc_DefaultValue) : 0;
	pValues[7].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[7].m_pszName = "centerDetectionAcc_DefaultValue";
}

const char * struct__5690_to_string(const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5690_StructSimValue(((struct__5690*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 8);
}

int string_to_struct__5690(const char* strValue, void* pValue) {
	static struct__5690 rTemp;
	int nResult = 0;
	static StructSimValue values[8];
	kcg_copy_struct__5690(&(rTemp), &(*((struct__5690*)pValue)));
	Fill_struct__5690_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 8);
	if (nResult == 1)
		kcg_copy_struct__5690(&(*((struct__5690*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5690_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5690_StructSimValue((struct__5690*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 8);
}


int is_struct__5690_allow_double_convertion() {
	return 0;
}


const char * get_struct__5690_signature() {
	static StructSimValue values[8];
	Fill_struct__5690_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 8);
}

FilterUtils get_struct__5690_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[8];
	Fill_struct__5690_StructSimValue((struct__5690*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 8, strFilter);
}

const char * struct__5690_filter_values[8] = {"nid_engine", "nid_operational", "l_train", "d_baliseAntenna_2_frontend", "d_frontend_2_rearend", "locationAccuracy_NationalValue", "locationAccuracy_DefaultValue", "centerDetectionAcc_DefaultValue"};
int check_struct__5690_string(const char* strValue) {
	static struct__5690 rTemp;
	return string_to_struct__5690(strValue, &rTemp);
}


/****************************************************************
 ** struct__5701
 ****************************************************************/
static void Fill_struct__5701_StructSimValue(struct__5701 * pStruct, StructSimValue * pValues) {
	/*valid label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->valid) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[0].m_pszName = "valid";
	/*timestamp label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->timestamp) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "timestamp";
	/*odo label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->odo) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_struct__5609_Utils;
	pValues[2].m_pszName = "odo";
	/*speed label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->speed) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[3].m_pszName = "speed";
}

const char * struct__5701_to_string(const void* pValue) {
	static StructSimValue values[4];
	Fill_struct__5701_StructSimValue(((struct__5701*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 4);
}

int string_to_struct__5701(const char* strValue, void* pValue) {
	static struct__5701 rTemp;
	int nResult = 0;
	static StructSimValue values[4];
	kcg_copy_struct__5701(&(rTemp), &(*((struct__5701*)pValue)));
	Fill_struct__5701_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 4);
	if (nResult == 1)
		kcg_copy_struct__5701(&(*((struct__5701*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5701_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[4];
	Fill_struct__5701_StructSimValue((struct__5701*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 4);
}


int is_struct__5701_allow_double_convertion() {
	return 0;
}


const char * get_struct__5701_signature() {
	static StructSimValue values[4];
	Fill_struct__5701_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 4);
}

FilterUtils get_struct__5701_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[4];
	Fill_struct__5701_StructSimValue((struct__5701*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 4, strFilter);
}

const char * struct__5701_filter_values[4] = {"valid", "timestamp", "odo", "speed"};
int check_struct__5701_string(const char* strValue) {
	static struct__5701 rTemp;
	return string_to_struct__5701(strValue, &rTemp);
}


/****************************************************************
 ** struct__5708
 ****************************************************************/
static void Fill_struct__5708_StructSimValue(struct__5708 * pStruct, StructSimValue * pValues) {
	/*index label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->index) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "index";
	/*noOfFoundBGs label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->noOfFoundBGs) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "noOfFoundBGs";
	/*BGFound label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->BGFound) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[2].m_pszName = "BGFound";
}

const char * struct__5708_to_string(const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5708_StructSimValue(((struct__5708*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 3);
}

int string_to_struct__5708(const char* strValue, void* pValue) {
	static struct__5708 rTemp;
	int nResult = 0;
	static StructSimValue values[3];
	kcg_copy_struct__5708(&(rTemp), &(*((struct__5708*)pValue)));
	Fill_struct__5708_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 3);
	if (nResult == 1)
		kcg_copy_struct__5708(&(*((struct__5708*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5708_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5708_StructSimValue((struct__5708*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 3);
}


int is_struct__5708_allow_double_convertion() {
	return 0;
}


const char * get_struct__5708_signature() {
	static StructSimValue values[3];
	Fill_struct__5708_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 3);
}

FilterUtils get_struct__5708_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5708_StructSimValue((struct__5708*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 3, strFilter);
}

const char * struct__5708_filter_values[3] = {"index", "noOfFoundBGs", "BGFound"};
int check_struct__5708_string(const char* strValue) {
	static struct__5708 rTemp;
	return string_to_struct__5708(strValue, &rTemp);
}


/****************************************************************
 ** struct__5714
 ****************************************************************/
static void Fill_struct__5714_StructSimValue(struct__5714 * pStruct, StructSimValue * pValues) {
	/*unlinkedBGsCount label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->unlinkedBGsCount) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "unlinkedBGsCount";
	/*linkedBGsCount label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->linkedBGsCount) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "linkedBGsCount";
	/*totalBGsCount label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->totalBGsCount) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "totalBGsCount";
	/*passedUnlinkedBGsCount label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->passedUnlinkedBGsCount) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[3].m_pszName = "passedUnlinkedBGsCount";
	/*passedLinkedBGsCount label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->passedLinkedBGsCount) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[4].m_pszName = "passedLinkedBGsCount";
	/*passedTotalBGsCount label.*/
	pValues[5].m_pPtr = pStruct != 0 ? &(pStruct->passedTotalBGsCount) : 0;
	pValues[5].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[5].m_pszName = "passedTotalBGsCount";
}

const char * struct__5714_to_string(const void* pValue) {
	static StructSimValue values[6];
	Fill_struct__5714_StructSimValue(((struct__5714*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 6);
}

int string_to_struct__5714(const char* strValue, void* pValue) {
	static struct__5714 rTemp;
	int nResult = 0;
	static StructSimValue values[6];
	kcg_copy_struct__5714(&(rTemp), &(*((struct__5714*)pValue)));
	Fill_struct__5714_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 6);
	if (nResult == 1)
		kcg_copy_struct__5714(&(*((struct__5714*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5714_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[6];
	Fill_struct__5714_StructSimValue((struct__5714*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 6);
}


int is_struct__5714_allow_double_convertion() {
	return 0;
}


const char * get_struct__5714_signature() {
	static StructSimValue values[6];
	Fill_struct__5714_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 6);
}

FilterUtils get_struct__5714_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[6];
	Fill_struct__5714_StructSimValue((struct__5714*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 6, strFilter);
}

const char * struct__5714_filter_values[6] = {"unlinkedBGsCount", "linkedBGsCount", "totalBGsCount", "passedUnlinkedBGsCount", "passedLinkedBGsCount", "passedTotalBGsCount"};
int check_struct__5714_string(const char* strValue) {
	static struct__5714 rTemp;
	return string_to_struct__5714(strValue, &rTemp);
}


/****************************************************************
 ** struct__5723
 ****************************************************************/
static void Fill_struct__5723_StructSimValue(struct__5723 * pStruct, StructSimValue * pValues) {
	/*previousLinkedBG_idx label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->previousLinkedBG_idx) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "previousLinkedBG_idx";
	/*currentIndex label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->currentIndex) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[1].m_pszName = "currentIndex";
	/*subsequentLinkedBG_idx label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->subsequentLinkedBG_idx) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[2].m_pszName = "subsequentLinkedBG_idx";
}

const char * struct__5723_to_string(const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5723_StructSimValue(((struct__5723*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 3);
}

int string_to_struct__5723(const char* strValue, void* pValue) {
	static struct__5723 rTemp;
	int nResult = 0;
	static StructSimValue values[3];
	kcg_copy_struct__5723(&(rTemp), &(*((struct__5723*)pValue)));
	Fill_struct__5723_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 3);
	if (nResult == 1)
		kcg_copy_struct__5723(&(*((struct__5723*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5723_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5723_StructSimValue((struct__5723*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 3);
}


int is_struct__5723_allow_double_convertion() {
	return 0;
}


const char * get_struct__5723_signature() {
	static StructSimValue values[3];
	Fill_struct__5723_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 3);
}

FilterUtils get_struct__5723_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5723_StructSimValue((struct__5723*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 3, strFilter);
}

const char * struct__5723_filter_values[3] = {"previousLinkedBG_idx", "currentIndex", "subsequentLinkedBG_idx"};
int check_struct__5723_string(const char* strValue) {
	static struct__5723 rTemp;
	return string_to_struct__5723(strValue, &rTemp);
}


/****************************************************************
 ** array__5729
 ****************************************************************/
void* array__5729_projection(void** pValues, int nIndex) {
	return &((*(array__5729*)pValues)[nIndex]);
}

const char * array__5729_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5723_to_string, 8, array__5729_projection);
}

int compare_array__5729_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5723_type , 8, array__5729_projection);
}

int is_array__5729_allow_double_convertion() {
	return 0;
}

int string_to_array__5729(const char* strValue, void* pValue) {
	static array__5729 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5723, 8, array__5729_projection);
	if (nResult == 1)
		kcg_copy_array__5729(&(*((array__5729*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5729_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5723_signature, 8);
}

FilterUtils get_array__5729_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5723_Utils, strFilter, (void**)pValue, 8, array__5729_projection);
}

int check_array__5729_string(const char* strValue) {
	static array__5729 rTemp;
	return string_to_array__5729(strValue, &rTemp);
}


/****************************************************************
 ** struct__5732
 ****************************************************************/
static void Fill_struct__5732_StructSimValue(struct__5732 * pStruct, StructSimValue * pValues) {
	/*refBG label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->refBG) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_struct__5642_Utils;
	pValues[0].m_pszName = "refBG";
	/*prevLinkedBG label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->prevLinkedBG) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_struct__5642_Utils;
	pValues[1].m_pszName = "prevLinkedBG";
	/*prevUnlinkedBG label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->prevUnlinkedBG) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_struct__5642_Utils;
	pValues[2].m_pszName = "prevUnlinkedBG";
	/*recalculate label.*/
	pValues[3].m_pPtr = pStruct != 0 ? &(pStruct->recalculate) : 0;
	pValues[3].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[3].m_pszName = "recalculate";
	/*sumOfBestDistances label.*/
	pValues[4].m_pPtr = pStruct != 0 ? &(pStruct->sumOfBestDistances) : 0;
	pValues[4].m_pTypeUtils = &_SCSIM_struct__5578_Utils;
	pValues[4].m_pszName = "sumOfBestDistances";
}

const char * struct__5732_to_string(const void* pValue) {
	static StructSimValue values[5];
	Fill_struct__5732_StructSimValue(((struct__5732*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 5);
}

int string_to_struct__5732(const char* strValue, void* pValue) {
	static struct__5732 rTemp;
	int nResult = 0;
	static StructSimValue values[5];
	kcg_copy_struct__5732(&(rTemp), &(*((struct__5732*)pValue)));
	Fill_struct__5732_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 5);
	if (nResult == 1)
		kcg_copy_struct__5732(&(*((struct__5732*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5732_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[5];
	Fill_struct__5732_StructSimValue((struct__5732*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 5);
}


int is_struct__5732_allow_double_convertion() {
	return 0;
}


const char * get_struct__5732_signature() {
	static StructSimValue values[5];
	Fill_struct__5732_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 5);
}

FilterUtils get_struct__5732_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[5];
	Fill_struct__5732_StructSimValue((struct__5732*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 5, strFilter);
}

const char * struct__5732_filter_values[5] = {"refBG", "prevLinkedBG", "prevUnlinkedBG", "recalculate", "sumOfBestDistances"};
int check_struct__5732_string(const char* strValue) {
	static struct__5732 rTemp;
	return string_to_struct__5732(strValue, &rTemp);
}


/****************************************************************
 ** array__5740
 ****************************************************************/
void* array__5740_projection(void** pValues, int nIndex) {
	return &((*(array__5740*)pValues)[nIndex]);
}

const char * array__5740_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5642_to_string, 4, array__5740_projection);
}

int compare_array__5740_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5642_type , 4, array__5740_projection);
}

int is_array__5740_allow_double_convertion() {
	return 0;
}

int string_to_array__5740(const char* strValue, void* pValue) {
	static array__5740 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5642, 4, array__5740_projection);
	if (nResult == 1)
		kcg_copy_array__5740(&(*((array__5740*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5740_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5642_signature, 4);
}

FilterUtils get_array__5740_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5642_Utils, strFilter, (void**)pValue, 4, array__5740_projection);
}

int check_array__5740_string(const char* strValue) {
	static array__5740 rTemp;
	return string_to_array__5740(strValue, &rTemp);
}


/****************************************************************
 ** struct__5743
 ****************************************************************/
static void Fill_struct__5743_StructSimValue(struct__5743 * pStruct, StructSimValue * pValues) {
	/*BGs label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->BGs) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_array__5687_Utils;
	pValues[0].m_pszName = "BGs";
	/*overrun label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->overrun) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_bool_Utils;
	pValues[1].m_pszName = "overrun";
}

const char * struct__5743_to_string(const void* pValue) {
	static StructSimValue values[2];
	Fill_struct__5743_StructSimValue(((struct__5743*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 2);
}

int string_to_struct__5743(const char* strValue, void* pValue) {
	static struct__5743 rTemp;
	int nResult = 0;
	static StructSimValue values[2];
	kcg_copy_struct__5743(&(rTemp), &(*((struct__5743*)pValue)));
	Fill_struct__5743_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 2);
	if (nResult == 1)
		kcg_copy_struct__5743(&(*((struct__5743*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5743_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[2];
	Fill_struct__5743_StructSimValue((struct__5743*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 2);
}


int is_struct__5743_allow_double_convertion() {
	return 0;
}


const char * get_struct__5743_signature() {
	static StructSimValue values[2];
	Fill_struct__5743_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 2);
}

FilterUtils get_struct__5743_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[2];
	Fill_struct__5743_StructSimValue((struct__5743*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 2, strFilter);
}

const char * struct__5743_filter_values[2] = {"BGs", "overrun"};
int check_struct__5743_string(const char* strValue) {
	static struct__5743 rTemp;
	return string_to_struct__5743(strValue, &rTemp);
}


/****************************************************************
 ** struct__5748
 ****************************************************************/
static void Fill_struct__5748_StructSimValue(struct__5748 * pStruct, StructSimValue * pValues) {
	/*trueLocation label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->trueLocation) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_int_Utils;
	pValues[0].m_pszName = "trueLocation";
	/*passedBG label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->passedBG) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_struct__5629_Utils;
	pValues[1].m_pszName = "passedBG";
}

const char * struct__5748_to_string(const void* pValue) {
	static StructSimValue values[2];
	Fill_struct__5748_StructSimValue(((struct__5748*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 2);
}

int string_to_struct__5748(const char* strValue, void* pValue) {
	static struct__5748 rTemp;
	int nResult = 0;
	static StructSimValue values[2];
	kcg_copy_struct__5748(&(rTemp), &(*((struct__5748*)pValue)));
	Fill_struct__5748_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 2);
	if (nResult == 1)
		kcg_copy_struct__5748(&(*((struct__5748*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5748_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[2];
	Fill_struct__5748_StructSimValue((struct__5748*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 2);
}


int is_struct__5748_allow_double_convertion() {
	return 0;
}


const char * get_struct__5748_signature() {
	static StructSimValue values[2];
	Fill_struct__5748_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 2);
}

FilterUtils get_struct__5748_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[2];
	Fill_struct__5748_StructSimValue((struct__5748*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 2, strFilter);
}

const char * struct__5748_filter_values[2] = {"trueLocation", "passedBG"};
int check_struct__5748_string(const char* strValue) {
	static struct__5748 rTemp;
	return string_to_struct__5748(strValue, &rTemp);
}


/****************************************************************
 ** array__5753
 ****************************************************************/
void* array__5753_projection(void** pValues, int nIndex) {
	return &((*(array__5753*)pValues)[nIndex]);
}

const char * array__5753_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5748_to_string, 10, array__5753_projection);
}

int compare_array__5753_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5748_type , 10, array__5753_projection);
}

int is_array__5753_allow_double_convertion() {
	return 0;
}

int string_to_array__5753(const char* strValue, void* pValue) {
	static array__5753 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5748, 10, array__5753_projection);
	if (nResult == 1)
		kcg_copy_array__5753(&(*((array__5753*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5753_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5748_signature, 10);
}

FilterUtils get_array__5753_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5748_Utils, strFilter, (void**)pValue, 10, array__5753_projection);
}

int check_array__5753_string(const char* strValue) {
	static array__5753 rTemp;
	return string_to_array__5753(strValue, &rTemp);
}


/****************************************************************
 ** struct__5756
 ****************************************************************/
static void Fill_struct__5756_StructSimValue(struct__5756 * pStruct, StructSimValue * pValues) {
	/*o_nominal label.*/
	pValues[0].m_pPtr = pStruct != 0 ? &(pStruct->o_nominal) : 0;
	pValues[0].m_pTypeUtils = &_SCSIM_kcg_real_Utils;
	pValues[0].m_pszName = "o_nominal";
	/*o_min label.*/
	pValues[1].m_pPtr = pStruct != 0 ? &(pStruct->o_min) : 0;
	pValues[1].m_pTypeUtils = &_SCSIM_kcg_real_Utils;
	pValues[1].m_pszName = "o_min";
	/*o_max label.*/
	pValues[2].m_pPtr = pStruct != 0 ? &(pStruct->o_max) : 0;
	pValues[2].m_pTypeUtils = &_SCSIM_kcg_real_Utils;
	pValues[2].m_pszName = "o_max";
}

const char * struct__5756_to_string(const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5756_StructSimValue(((struct__5756*)pValue), values);
	return pSimulator->m_pfnStructureToString(values, 3);
}

int string_to_struct__5756(const char* strValue, void* pValue) {
	static struct__5756 rTemp;
	int nResult = 0;
	static StructSimValue values[3];
	kcg_copy_struct__5756(&(rTemp), &(*((struct__5756*)pValue)));
	Fill_struct__5756_StructSimValue(&rTemp, values);
	nResult = pSimulator->m_pfnStructureFromString(strValue, values, 3);
	if (nResult == 1)
		kcg_copy_struct__5756(&(*((struct__5756*)pValue)), &(rTemp));
	return nResult;
}

int compare_struct__5756_type(int* pResult, const char* toCompare, const void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5756_StructSimValue((struct__5756*)pValue, values);
	return pSimulator->m_pfnStructureComparison(pResult, toCompare, values, 3);
}


int is_struct__5756_allow_double_convertion() {
	return 0;
}


const char * get_struct__5756_signature() {
	static StructSimValue values[3];
	Fill_struct__5756_StructSimValue(0, values);
	return pSimulator->m_pfnStructureSignature(values, 3);
}

FilterUtils get_struct__5756_filter_utils(const char* strFilter, void* pValue) {
	static StructSimValue values[3];
	Fill_struct__5756_StructSimValue((struct__5756*)pValue, values);
	return pSimulator->m_pfnGetStructureFilterUtils(values, 3, strFilter);
}

const char * struct__5756_filter_values[3] = {"o_nominal", "o_min", "o_max"};
int check_struct__5756_string(const char* strValue) {
	static struct__5756 rTemp;
	return string_to_struct__5756(strValue, &rTemp);
}


/****************************************************************
 ** array__5762
 ****************************************************************/
void* array__5762_projection(void** pValues, int nIndex) {
	return &((*(array__5762*)pValues)[nIndex]);
}

const char * array__5762_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5690_to_string, 4, array__5762_projection);
}

int compare_array__5762_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5690_type , 4, array__5762_projection);
}

int is_array__5762_allow_double_convertion() {
	return 0;
}

int string_to_array__5762(const char* strValue, void* pValue) {
	static array__5762 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5690, 4, array__5762_projection);
	if (nResult == 1)
		kcg_copy_array__5762(&(*((array__5762*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5762_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5690_signature, 4);
}

FilterUtils get_array__5762_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5690_Utils, strFilter, (void**)pValue, 4, array__5762_projection);
}

int check_array__5762_string(const char* strValue) {
	static array__5762 rTemp;
	return string_to_array__5762(strValue, &rTemp);
}


/****************************************************************
 ** array_int_8
 ****************************************************************/
void* array_int_8_projection(void** pValues, int nIndex) {
	return &((*(array_int_8*)pValues)[nIndex]);
}

const char * array_int_8_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, kcg_int_to_string, 8, array_int_8_projection);
}

int compare_array_int_8_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_kcg_int_type , 8, array_int_8_projection);
}

int is_array_int_8_allow_double_convertion() {
	return 0;
}

int string_to_array_int_8(const char* strValue, void* pValue) {
	static array_int_8 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_kcg_int, 8, array_int_8_projection);
	if (nResult == 1)
		kcg_copy_array_int_8(&(*((array_int_8*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array_int_8_signature() {
	return pSimulator->m_pfnArraySignature(get_kcg_int_signature, 8);
}

FilterUtils get_array_int_8_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_kcg_int_Utils, strFilter, (void**)pValue, 8, array_int_8_projection);
}

int check_array_int_8_string(const char* strValue) {
	static array_int_8 rTemp;
	return string_to_array_int_8(strValue, &rTemp);
}


/****************************************************************
 ** array__5768
 ****************************************************************/
void* array__5768_projection(void** pValues, int nIndex) {
	return &((*(array__5768*)pValues)[nIndex]);
}

const char * array__5768_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5642_to_string, 7, array__5768_projection);
}

int compare_array__5768_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5642_type , 7, array__5768_projection);
}

int is_array__5768_allow_double_convertion() {
	return 0;
}

int string_to_array__5768(const char* strValue, void* pValue) {
	static array__5768 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5642, 7, array__5768_projection);
	if (nResult == 1)
		kcg_copy_array__5768(&(*((array__5768*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5768_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5642_signature, 7);
}

FilterUtils get_array__5768_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5642_Utils, strFilter, (void**)pValue, 7, array__5768_projection);
}

int check_array__5768_string(const char* strValue) {
	static array__5768 rTemp;
	return string_to_array__5768(strValue, &rTemp);
}


/****************************************************************
 ** array__5771
 ****************************************************************/
void* array__5771_projection(void** pValues, int nIndex) {
	return &((*(array__5771*)pValues)[nIndex]);
}

const char * array__5771_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5642_to_string, 1, array__5771_projection);
}

int compare_array__5771_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5642_type , 1, array__5771_projection);
}

int is_array__5771_allow_double_convertion() {
	return 0;
}

int string_to_array__5771(const char* strValue, void* pValue) {
	static array__5771 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5642, 1, array__5771_projection);
	if (nResult == 1)
		kcg_copy_array__5771(&(*((array__5771*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5771_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5642_signature, 1);
}

FilterUtils get_array__5771_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5642_Utils, strFilter, (void**)pValue, 1, array__5771_projection);
}

int check_array__5771_string(const char* strValue) {
	static array__5771 rTemp;
	return string_to_array__5771(strValue, &rTemp);
}


/****************************************************************
 ** array_bool_8
 ****************************************************************/
void* array_bool_8_projection(void** pValues, int nIndex) {
	return &((*(array_bool_8*)pValues)[nIndex]);
}

const char * array_bool_8_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, kcg_bool_to_string, 8, array_bool_8_projection);
}

int compare_array_bool_8_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_kcg_bool_type , 8, array_bool_8_projection);
}

int is_array_bool_8_allow_double_convertion() {
	return 0;
}

int string_to_array_bool_8(const char* strValue, void* pValue) {
	static array_bool_8 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_kcg_bool, 8, array_bool_8_projection);
	if (nResult == 1)
		kcg_copy_array_bool_8(&(*((array_bool_8*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array_bool_8_signature() {
	return pSimulator->m_pfnArraySignature(get_kcg_bool_signature, 8);
}

FilterUtils get_array_bool_8_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_kcg_bool_Utils, strFilter, (void**)pValue, 8, array_bool_8_projection);
}

int check_array_bool_8_string(const char* strValue) {
	static array_bool_8 rTemp;
	return string_to_array_bool_8(strValue, &rTemp);
}


/****************************************************************
 ** array__5777
 ****************************************************************/
void* array__5777_projection(void** pValues, int nIndex) {
	return &((*(array__5777*)pValues)[nIndex]);
}

const char * array__5777_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, struct__5690_to_string, 8, array__5777_projection);
}

int compare_array__5777_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_struct__5690_type , 8, array__5777_projection);
}

int is_array__5777_allow_double_convertion() {
	return 0;
}

int string_to_array__5777(const char* strValue, void* pValue) {
	static array__5777 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_struct__5690, 8, array__5777_projection);
	if (nResult == 1)
		kcg_copy_array__5777(&(*((array__5777*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5777_signature() {
	return pSimulator->m_pfnArraySignature(get_struct__5690_signature, 8);
}

FilterUtils get_array__5777_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_struct__5690_Utils, strFilter, (void**)pValue, 8, array__5777_projection);
}

int check_array__5777_string(const char* strValue) {
	static array__5777 rTemp;
	return string_to_array__5777(strValue, &rTemp);
}


/****************************************************************
 ** array__5780
 ****************************************************************/
void* array__5780_projection(void** pValues, int nIndex) {
	return &((*(array__5780*)pValues)[nIndex]);
}

const char * array__5780_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, array__5687_to_string, 8, array__5780_projection);
}

int compare_array__5780_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_array__5687_type , 8, array__5780_projection);
}

int is_array__5780_allow_double_convertion() {
	return 0;
}

int string_to_array__5780(const char* strValue, void* pValue) {
	static array__5780 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_array__5687, 8, array__5780_projection);
	if (nResult == 1)
		kcg_copy_array__5780(&(*((array__5780*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array__5780_signature() {
	return pSimulator->m_pfnArraySignature(get_array__5687_signature, 8);
}

FilterUtils get_array__5780_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_array__5687_Utils, strFilter, (void**)pValue, 8, array__5780_projection);
}

int check_array__5780_string(const char* strValue) {
	static array__5780 rTemp;
	return string_to_array__5780(strValue, &rTemp);
}


/****************************************************************
 ** array_int_10
 ****************************************************************/
void* array_int_10_projection(void** pValues, int nIndex) {
	return &((*(array_int_10*)pValues)[nIndex]);
}

const char * array_int_10_to_string(const void* pValue) {
	return (char*) pSimulator->m_pfnArrayToString((const void**)pValue, kcg_int_to_string, 10, array_int_10_projection);
}

int compare_array_int_10_type(int* pResult, const char* toCompare, const void* pValue) {
	return pSimulator->m_pfnArrayComparison(pResult, toCompare, (const void**)pValue, compare_kcg_int_type , 10, array_int_10_projection);
}

int is_array_int_10_allow_double_convertion() {
	return 0;
}

int string_to_array_int_10(const char* strValue, void* pValue) {
	static array_int_10 rTemp;
	int nResult = pSimulator->m_pfnArrayFromString(strValue, (void**)(void*)&rTemp, string_to_kcg_int, 10, array_int_10_projection);
	if (nResult == 1)
		kcg_copy_array_int_10(&(*((array_int_10*)pValue)), &(rTemp));
	return nResult;
}

const char * get_array_int_10_signature() {
	return pSimulator->m_pfnArraySignature(get_kcg_int_signature, 10);
}

FilterUtils get_array_int_10_filter_utils(const char* strFilter, void* pValue) {
	return pSimulator->m_pfnGetArrayFilterUtils(&_SCSIM_kcg_int_Utils, strFilter, (void**)pValue, 10, array_int_10_projection);
}

int check_array_int_10_string(const char* strValue) {
	static array_int_10 rTemp;
	return string_to_array_int_10(strValue, &rTemp);
}


/****************************************************************
 ** Q_UPDOWN
 ****************************************************************/
struct SimTypeVTable* pSimQ_UPDOWNVTable;
const char * Q_UPDOWN_to_string(const void* pValue) {
	if (pSimQ_UPDOWNVTable != 0 && pSimQ_UPDOWNVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_UPDOWNVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_UPDOWN*)pValue)) {
	case Q_UPDOWN_Down_link_telegram:
		return "Q_UPDOWN_Down_link_telegram";
	case Q_UPDOWN_Up_link_telegram:
		return "Q_UPDOWN_Up_link_telegram";
	default:
		return "?";
	}
}

int string_to_Q_UPDOWN(const char* strValue, void* pValue) {
	if (pSimQ_UPDOWNVTable != 0 && pSimQ_UPDOWNVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_UPDOWN rTemp;		int nResult = pSimQ_UPDOWNVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_UPDOWN*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_UPDOWN_Down_link_telegram") == 0)
		*((Q_UPDOWN*)pValue) = Q_UPDOWN_Down_link_telegram;
	else if(strcmp(strValue, "Q_UPDOWN_Up_link_telegram") == 0)
		*((Q_UPDOWN*)pValue) = Q_UPDOWN_Up_link_telegram;
	else 
		return 0;
	return 1;
}

int is_Q_UPDOWN_allow_double_convertion() {
	return 1;
}


int Q_UPDOWN_to_double(double * nValue, const void* pValue) {
	switch (*((Q_UPDOWN*)pValue)) {
	case Q_UPDOWN_Down_link_telegram:
		*nValue = 0.0;
		break;
	case Q_UPDOWN_Up_link_telegram:
		*nValue = 1.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_UPDOWN_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_UPDOWN rTemp;
	const Q_UPDOWN* pCurrent = (const Q_UPDOWN*)pValue;
	if (string_to_Q_UPDOWN(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_UPDOWN_signature() {
	return "E"
		"|Q_UPDOWN_Down_link_telegram"
		"|Q_UPDOWN_Up_link_telegram"
		;
}

int check_Q_UPDOWN_string(const char* strValue) {
	static Q_UPDOWN rTemp;
	return string_to_Q_UPDOWN(strValue, &rTemp);
}


/****************************************************************
 ** M_VERSION
 ****************************************************************/
struct SimTypeVTable* pSimM_VERSIONVTable;
const char * M_VERSION_to_string(const void* pValue) {
	if (pSimM_VERSIONVTable != 0 && pSimM_VERSIONVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimM_VERSIONVTable->m_pfnToType(SptString, pValue);
	switch (*((M_VERSION*)pValue)) {
	case M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS:
		return "M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS";
	case M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0:
		return "M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0";
	case M_VERSION_Version_1_1_introduced_in_SRS_3_3_0:
		return "M_VERSION_Version_1_1_introduced_in_SRS_3_3_0";
	case M_VERSION_Version_2_0_introduced_in_SRS_3_3_0:
		return "M_VERSION_Version_2_0_introduced_in_SRS_3_3_0";
	default:
		return "?";
	}
}

int string_to_M_VERSION(const char* strValue, void* pValue) {
	if (pSimM_VERSIONVTable != 0 && pSimM_VERSIONVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		M_VERSION rTemp;		int nResult = pSimM_VERSIONVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((M_VERSION*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS") == 0)
		*((M_VERSION*)pValue) = M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS;
	else if(strcmp(strValue, "M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0") == 0)
		*((M_VERSION*)pValue) = M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0;
	else if(strcmp(strValue, "M_VERSION_Version_1_1_introduced_in_SRS_3_3_0") == 0)
		*((M_VERSION*)pValue) = M_VERSION_Version_1_1_introduced_in_SRS_3_3_0;
	else if(strcmp(strValue, "M_VERSION_Version_2_0_introduced_in_SRS_3_3_0") == 0)
		*((M_VERSION*)pValue) = M_VERSION_Version_2_0_introduced_in_SRS_3_3_0;
	else 
		return 0;
	return 1;
}

int is_M_VERSION_allow_double_convertion() {
	return 1;
}


int M_VERSION_to_double(double * nValue, const void* pValue) {
	switch (*((M_VERSION*)pValue)) {
	case M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS:
		*nValue = 0.0;
		break;
	case M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0:
		*nValue = 1.0;
		break;
	case M_VERSION_Version_1_1_introduced_in_SRS_3_3_0:
		*nValue = 2.0;
		break;
	case M_VERSION_Version_2_0_introduced_in_SRS_3_3_0:
		*nValue = 3.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_M_VERSION_type(int* pResult, const char* toCompare, const void* pValue) {
	static M_VERSION rTemp;
	const M_VERSION* pCurrent = (const M_VERSION*)pValue;
	if (string_to_M_VERSION(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_M_VERSION_signature() {
	return "E"
		"|M_VERSION_Previous_versions_according_to_e_g_EEIG_SRS_and_UIC_A200_SRS"
		"|M_VERSION_Version_1_0_introduced_in_SRS_1_2_0_and_reused_in_SRSs_2_0_0_and_2_2_2_and_2_3_0"
		"|M_VERSION_Version_1_1_introduced_in_SRS_3_3_0"
		"|M_VERSION_Version_2_0_introduced_in_SRS_3_3_0"
		;
}

int check_M_VERSION_string(const char* strValue) {
	static M_VERSION rTemp;
	return string_to_M_VERSION(strValue, &rTemp);
}


/****************************************************************
 ** Q_MEDIA
 ****************************************************************/
struct SimTypeVTable* pSimQ_MEDIAVTable;
const char * Q_MEDIA_to_string(const void* pValue) {
	if (pSimQ_MEDIAVTable != 0 && pSimQ_MEDIAVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_MEDIAVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_MEDIA*)pValue)) {
	case Q_MEDIA_Balise:
		return "Q_MEDIA_Balise";
	case Q_MEDIA_Loop:
		return "Q_MEDIA_Loop";
	default:
		return "?";
	}
}

int string_to_Q_MEDIA(const char* strValue, void* pValue) {
	if (pSimQ_MEDIAVTable != 0 && pSimQ_MEDIAVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_MEDIA rTemp;		int nResult = pSimQ_MEDIAVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_MEDIA*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_MEDIA_Balise") == 0)
		*((Q_MEDIA*)pValue) = Q_MEDIA_Balise;
	else if(strcmp(strValue, "Q_MEDIA_Loop") == 0)
		*((Q_MEDIA*)pValue) = Q_MEDIA_Loop;
	else 
		return 0;
	return 1;
}

int is_Q_MEDIA_allow_double_convertion() {
	return 1;
}


int Q_MEDIA_to_double(double * nValue, const void* pValue) {
	switch (*((Q_MEDIA*)pValue)) {
	case Q_MEDIA_Balise:
		*nValue = 0.0;
		break;
	case Q_MEDIA_Loop:
		*nValue = 1.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_MEDIA_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_MEDIA rTemp;
	const Q_MEDIA* pCurrent = (const Q_MEDIA*)pValue;
	if (string_to_Q_MEDIA(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_MEDIA_signature() {
	return "E"
		"|Q_MEDIA_Balise"
		"|Q_MEDIA_Loop"
		;
}

int check_Q_MEDIA_string(const char* strValue) {
	static Q_MEDIA rTemp;
	return string_to_Q_MEDIA(strValue, &rTemp);
}


/****************************************************************
 ** N_TOTAL
 ****************************************************************/
struct SimTypeVTable* pSimN_TOTALVTable;
const char * N_TOTAL_to_string(const void* pValue) {
	if (pSimN_TOTALVTable != 0 && pSimN_TOTALVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimN_TOTALVTable->m_pfnToType(SptString, pValue);
	switch (*((N_TOTAL*)pValue)) {
	case N_TOTAL_1_balise_in_the_group:
		return "N_TOTAL_1_balise_in_the_group";
	case N_TOTAL_2_balises_in_the_group:
		return "N_TOTAL_2_balises_in_the_group";
	case N_TOTAL_3_balises_in_the_group:
		return "N_TOTAL_3_balises_in_the_group";
	case N_TOTAL_4_balises_in_the_group:
		return "N_TOTAL_4_balises_in_the_group";
	case N_TOTAL_5_balises_in_the_group:
		return "N_TOTAL_5_balises_in_the_group";
	case N_TOTAL_6_balises_in_the_group:
		return "N_TOTAL_6_balises_in_the_group";
	case N_TOTAL_7_balises_in_the_group:
		return "N_TOTAL_7_balises_in_the_group";
	case N_TOTAL_8_balises_in_the_group:
		return "N_TOTAL_8_balises_in_the_group";
	default:
		return "?";
	}
}

int string_to_N_TOTAL(const char* strValue, void* pValue) {
	if (pSimN_TOTALVTable != 0 && pSimN_TOTALVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		N_TOTAL rTemp;		int nResult = pSimN_TOTALVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((N_TOTAL*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "N_TOTAL_1_balise_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_1_balise_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_2_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_2_balises_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_3_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_3_balises_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_4_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_4_balises_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_5_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_5_balises_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_6_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_6_balises_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_7_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_7_balises_in_the_group;
	else if(strcmp(strValue, "N_TOTAL_8_balises_in_the_group") == 0)
		*((N_TOTAL*)pValue) = N_TOTAL_8_balises_in_the_group;
	else 
		return 0;
	return 1;
}

int is_N_TOTAL_allow_double_convertion() {
	return 1;
}


int N_TOTAL_to_double(double * nValue, const void* pValue) {
	switch (*((N_TOTAL*)pValue)) {
	case N_TOTAL_1_balise_in_the_group:
		*nValue = 0.0;
		break;
	case N_TOTAL_2_balises_in_the_group:
		*nValue = 1.0;
		break;
	case N_TOTAL_3_balises_in_the_group:
		*nValue = 2.0;
		break;
	case N_TOTAL_4_balises_in_the_group:
		*nValue = 3.0;
		break;
	case N_TOTAL_5_balises_in_the_group:
		*nValue = 4.0;
		break;
	case N_TOTAL_6_balises_in_the_group:
		*nValue = 5.0;
		break;
	case N_TOTAL_7_balises_in_the_group:
		*nValue = 6.0;
		break;
	case N_TOTAL_8_balises_in_the_group:
		*nValue = 7.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_N_TOTAL_type(int* pResult, const char* toCompare, const void* pValue) {
	static N_TOTAL rTemp;
	const N_TOTAL* pCurrent = (const N_TOTAL*)pValue;
	if (string_to_N_TOTAL(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_N_TOTAL_signature() {
	return "E"
		"|N_TOTAL_1_balise_in_the_group"
		"|N_TOTAL_2_balises_in_the_group"
		"|N_TOTAL_3_balises_in_the_group"
		"|N_TOTAL_4_balises_in_the_group"
		"|N_TOTAL_5_balises_in_the_group"
		"|N_TOTAL_6_balises_in_the_group"
		"|N_TOTAL_7_balises_in_the_group"
		"|N_TOTAL_8_balises_in_the_group"
		;
}

int check_N_TOTAL_string(const char* strValue) {
	static N_TOTAL rTemp;
	return string_to_N_TOTAL(strValue, &rTemp);
}


/****************************************************************
 ** M_MCOUNT
 ****************************************************************/
struct SimTypeVTable* pSimM_MCOUNTVTable;
const char * M_MCOUNT_to_string(const void* pValue) {
	if (pSimM_MCOUNTVTable != 0 && pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimM_MCOUNTVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_M_MCOUNT(const char* strValue, void* pValue) {
	if (pSimM_MCOUNTVTable != 0 && pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static M_MCOUNT rTemp;
		int nResult = pSimM_MCOUNTVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((M_MCOUNT*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_M_MCOUNT_allow_double_convertion() {
	if (pSimM_MCOUNTVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int M_MCOUNT_to_double(double * nValue, const void* pValue) {
	if (pSimM_MCOUNTVTable != 0) {
		if (pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimM_MCOUNTVTable->m_pfnToType(SptLong, pValue));
		else if (pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimM_MCOUNTVTable->m_pfnToType(SptShort, pValue));
		else if (pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimM_MCOUNTVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimM_MCOUNTVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimM_MCOUNTVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_M_MCOUNT_string(const char* strValue) {
	static M_MCOUNT rTemp;
	return string_to_M_MCOUNT(strValue, &rTemp);
}


/****************************************************************
 ** NID_C
 ****************************************************************/
struct SimTypeVTable* pSimNID_CVTable;
const char * NID_C_to_string(const void* pValue) {
	if (pSimNID_CVTable != 0 && pSimNID_CVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_CVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_C(const char* strValue, void* pValue) {
	if (pSimNID_CVTable != 0 && pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_C rTemp;
		int nResult = pSimNID_CVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_C*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_C_allow_double_convertion() {
	if (pSimNID_CVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_C_to_double(double * nValue, const void* pValue) {
	if (pSimNID_CVTable != 0) {
		if (pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_CVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_CVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_CVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_CVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_CVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_C_string(const char* strValue) {
	static NID_C rTemp;
	return string_to_NID_C(strValue, &rTemp);
}


/****************************************************************
 ** NID_BG
 ****************************************************************/
struct SimTypeVTable* pSimNID_BGVTable;
const char * NID_BG_to_string(const void* pValue) {
	if (pSimNID_BGVTable != 0 && pSimNID_BGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_BGVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_BG(const char* strValue, void* pValue) {
	if (pSimNID_BGVTable != 0 && pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_BG rTemp;
		int nResult = pSimNID_BGVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_BG*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_BG_allow_double_convertion() {
	if (pSimNID_BGVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_BG_to_double(double * nValue, const void* pValue) {
	if (pSimNID_BGVTable != 0) {
		if (pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_BGVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_BGVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_BGVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_BGVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_BGVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_BG_string(const char* strValue) {
	static NID_BG rTemp;
	return string_to_NID_BG(strValue, &rTemp);
}


/****************************************************************
 ** Q_LINK
 ****************************************************************/
struct SimTypeVTable* pSimQ_LINKVTable;
const char * Q_LINK_to_string(const void* pValue) {
	if (pSimQ_LINKVTable != 0 && pSimQ_LINKVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_LINKVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_LINK*)pValue)) {
	case Q_LINK_Unlinked:
		return "Q_LINK_Unlinked";
	case Q_LINK_Linked:
		return "Q_LINK_Linked";
	default:
		return "?";
	}
}

int string_to_Q_LINK(const char* strValue, void* pValue) {
	if (pSimQ_LINKVTable != 0 && pSimQ_LINKVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_LINK rTemp;		int nResult = pSimQ_LINKVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_LINK*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_LINK_Unlinked") == 0)
		*((Q_LINK*)pValue) = Q_LINK_Unlinked;
	else if(strcmp(strValue, "Q_LINK_Linked") == 0)
		*((Q_LINK*)pValue) = Q_LINK_Linked;
	else 
		return 0;
	return 1;
}

int is_Q_LINK_allow_double_convertion() {
	return 1;
}


int Q_LINK_to_double(double * nValue, const void* pValue) {
	switch (*((Q_LINK*)pValue)) {
	case Q_LINK_Unlinked:
		*nValue = 0.0;
		break;
	case Q_LINK_Linked:
		*nValue = 1.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_LINK_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_LINK rTemp;
	const Q_LINK* pCurrent = (const Q_LINK*)pValue;
	if (string_to_Q_LINK(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_LINK_signature() {
	return "E"
		"|Q_LINK_Unlinked"
		"|Q_LINK_Linked"
		;
}

int check_Q_LINK_string(const char* strValue) {
	static Q_LINK rTemp;
	return string_to_Q_LINK(strValue, &rTemp);
}


/****************************************************************
 ** NID_LRBG
 ****************************************************************/
struct SimTypeVTable* pSimNID_LRBGVTable;
const char * NID_LRBG_to_string(const void* pValue) {
	if (pSimNID_LRBGVTable != 0 && pSimNID_LRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_LRBGVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_LRBG(const char* strValue, void* pValue) {
	if (pSimNID_LRBGVTable != 0 && pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_LRBG rTemp;
		int nResult = pSimNID_LRBGVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_LRBG*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_LRBG_allow_double_convertion() {
	if (pSimNID_LRBGVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_LRBG_to_double(double * nValue, const void* pValue) {
	if (pSimNID_LRBGVTable != 0) {
		if (pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_LRBGVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_LRBGVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_LRBGVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_LRBGVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_LRBGVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_LRBG_string(const char* strValue) {
	static NID_LRBG rTemp;
	return string_to_NID_LRBG(strValue, &rTemp);
}


/****************************************************************
 ** NID_PACKET
 ****************************************************************/
struct SimTypeVTable* pSimNID_PACKETVTable;
const char * NID_PACKET_to_string(const void* pValue) {
	if (pSimNID_PACKETVTable != 0 && pSimNID_PACKETVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_PACKETVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_PACKET(const char* strValue, void* pValue) {
	if (pSimNID_PACKETVTable != 0 && pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_PACKET rTemp;
		int nResult = pSimNID_PACKETVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_PACKET*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_PACKET_allow_double_convertion() {
	if (pSimNID_PACKETVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_PACKET_to_double(double * nValue, const void* pValue) {
	if (pSimNID_PACKETVTable != 0) {
		if (pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_PACKETVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_PACKETVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_PACKETVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_PACKETVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_PACKETVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_PACKET_string(const char* strValue) {
	static NID_PACKET rTemp;
	return string_to_NID_PACKET(strValue, &rTemp);
}


/****************************************************************
 ** Q_DIR
 ****************************************************************/
struct SimTypeVTable* pSimQ_DIRVTable;
const char * Q_DIR_to_string(const void* pValue) {
	if (pSimQ_DIRVTable != 0 && pSimQ_DIRVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_DIRVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_DIR*)pValue)) {
	case Q_DIR_Reverse:
		return "Q_DIR_Reverse";
	case Q_DIR_Nominal:
		return "Q_DIR_Nominal";
	case Q_DIR_Both_directions:
		return "Q_DIR_Both_directions";
	default:
		return "?";
	}
}

int string_to_Q_DIR(const char* strValue, void* pValue) {
	if (pSimQ_DIRVTable != 0 && pSimQ_DIRVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_DIR rTemp;		int nResult = pSimQ_DIRVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_DIR*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_DIR_Reverse") == 0)
		*((Q_DIR*)pValue) = Q_DIR_Reverse;
	else if(strcmp(strValue, "Q_DIR_Nominal") == 0)
		*((Q_DIR*)pValue) = Q_DIR_Nominal;
	else if(strcmp(strValue, "Q_DIR_Both_directions") == 0)
		*((Q_DIR*)pValue) = Q_DIR_Both_directions;
	else 
		return 0;
	return 1;
}

int is_Q_DIR_allow_double_convertion() {
	return 1;
}


int Q_DIR_to_double(double * nValue, const void* pValue) {
	switch (*((Q_DIR*)pValue)) {
	case Q_DIR_Reverse:
		*nValue = 0.0;
		break;
	case Q_DIR_Nominal:
		*nValue = 1.0;
		break;
	case Q_DIR_Both_directions:
		*nValue = 2.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_DIR_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_DIR rTemp;
	const Q_DIR* pCurrent = (const Q_DIR*)pValue;
	if (string_to_Q_DIR(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_DIR_signature() {
	return "E"
		"|Q_DIR_Reverse"
		"|Q_DIR_Nominal"
		"|Q_DIR_Both_directions"
		;
}

int check_Q_DIR_string(const char* strValue) {
	static Q_DIR rTemp;
	return string_to_Q_DIR(strValue, &rTemp);
}


/****************************************************************
 ** L_PACKET
 ****************************************************************/
struct SimTypeVTable* pSimL_PACKETVTable;
const char * L_PACKET_to_string(const void* pValue) {
	if (pSimL_PACKETVTable != 0 && pSimL_PACKETVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimL_PACKETVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_L_PACKET(const char* strValue, void* pValue) {
	if (pSimL_PACKETVTable != 0 && pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static L_PACKET rTemp;
		int nResult = pSimL_PACKETVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((L_PACKET*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_L_PACKET_allow_double_convertion() {
	if (pSimL_PACKETVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int L_PACKET_to_double(double * nValue, const void* pValue) {
	if (pSimL_PACKETVTable != 0) {
		if (pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimL_PACKETVTable->m_pfnToType(SptLong, pValue));
		else if (pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimL_PACKETVTable->m_pfnToType(SptShort, pValue));
		else if (pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimL_PACKETVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimL_PACKETVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimL_PACKETVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_L_PACKET_string(const char* strValue) {
	static L_PACKET rTemp;
	return string_to_L_PACKET(strValue, &rTemp);
}


/****************************************************************
 ** Q_SCALE
 ****************************************************************/
struct SimTypeVTable* pSimQ_SCALEVTable;
const char * Q_SCALE_to_string(const void* pValue) {
	if (pSimQ_SCALEVTable != 0 && pSimQ_SCALEVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_SCALEVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_SCALE*)pValue)) {
	case Q_SCALE_10_cm_scale:
		return "Q_SCALE_10_cm_scale";
	case Q_SCALE_1_m_scale:
		return "Q_SCALE_1_m_scale";
	case Q_SCALE_10_m_scale:
		return "Q_SCALE_10_m_scale";
	default:
		return "?";
	}
}

int string_to_Q_SCALE(const char* strValue, void* pValue) {
	if (pSimQ_SCALEVTable != 0 && pSimQ_SCALEVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_SCALE rTemp;		int nResult = pSimQ_SCALEVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_SCALE*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_SCALE_10_cm_scale") == 0)
		*((Q_SCALE*)pValue) = Q_SCALE_10_cm_scale;
	else if(strcmp(strValue, "Q_SCALE_1_m_scale") == 0)
		*((Q_SCALE*)pValue) = Q_SCALE_1_m_scale;
	else if(strcmp(strValue, "Q_SCALE_10_m_scale") == 0)
		*((Q_SCALE*)pValue) = Q_SCALE_10_m_scale;
	else 
		return 0;
	return 1;
}

int is_Q_SCALE_allow_double_convertion() {
	return 1;
}


int Q_SCALE_to_double(double * nValue, const void* pValue) {
	switch (*((Q_SCALE*)pValue)) {
	case Q_SCALE_10_cm_scale:
		*nValue = 0.0;
		break;
	case Q_SCALE_1_m_scale:
		*nValue = 1.0;
		break;
	case Q_SCALE_10_m_scale:
		*nValue = 2.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_SCALE_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_SCALE rTemp;
	const Q_SCALE* pCurrent = (const Q_SCALE*)pValue;
	if (string_to_Q_SCALE(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_SCALE_signature() {
	return "E"
		"|Q_SCALE_10_cm_scale"
		"|Q_SCALE_1_m_scale"
		"|Q_SCALE_10_m_scale"
		;
}

int check_Q_SCALE_string(const char* strValue) {
	static Q_SCALE rTemp;
	return string_to_Q_SCALE(strValue, &rTemp);
}


/****************************************************************
 ** D_LINK
 ****************************************************************/
struct SimTypeVTable* pSimD_LINKVTable;
const char * D_LINK_to_string(const void* pValue) {
	if (pSimD_LINKVTable != 0 && pSimD_LINKVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimD_LINKVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_D_LINK(const char* strValue, void* pValue) {
	if (pSimD_LINKVTable != 0 && pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static D_LINK rTemp;
		int nResult = pSimD_LINKVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((D_LINK*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_D_LINK_allow_double_convertion() {
	if (pSimD_LINKVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int D_LINK_to_double(double * nValue, const void* pValue) {
	if (pSimD_LINKVTable != 0) {
		if (pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimD_LINKVTable->m_pfnToType(SptLong, pValue));
		else if (pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimD_LINKVTable->m_pfnToType(SptShort, pValue));
		else if (pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimD_LINKVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimD_LINKVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimD_LINKVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_D_LINK_string(const char* strValue) {
	static D_LINK rTemp;
	return string_to_D_LINK(strValue, &rTemp);
}


/****************************************************************
 ** Q_NEWCOUNTRY
 ****************************************************************/
struct SimTypeVTable* pSimQ_NEWCOUNTRYVTable;
const char * Q_NEWCOUNTRY_to_string(const void* pValue) {
	if (pSimQ_NEWCOUNTRYVTable != 0 && pSimQ_NEWCOUNTRYVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_NEWCOUNTRYVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_NEWCOUNTRY*)pValue)) {
	case Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows:
		return "Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows";
	case Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows:
		return "Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows";
	default:
		return "?";
	}
}

int string_to_Q_NEWCOUNTRY(const char* strValue, void* pValue) {
	if (pSimQ_NEWCOUNTRYVTable != 0 && pSimQ_NEWCOUNTRYVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_NEWCOUNTRY rTemp;		int nResult = pSimQ_NEWCOUNTRYVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_NEWCOUNTRY*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows") == 0)
		*((Q_NEWCOUNTRY*)pValue) = Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows;
	else if(strcmp(strValue, "Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows") == 0)
		*((Q_NEWCOUNTRY*)pValue) = Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows;
	else 
		return 0;
	return 1;
}

int is_Q_NEWCOUNTRY_allow_double_convertion() {
	return 1;
}


int Q_NEWCOUNTRY_to_double(double * nValue, const void* pValue) {
	switch (*((Q_NEWCOUNTRY*)pValue)) {
	case Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows:
		*nValue = 0.0;
		break;
	case Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows:
		*nValue = 1.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_NEWCOUNTRY_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_NEWCOUNTRY rTemp;
	const Q_NEWCOUNTRY* pCurrent = (const Q_NEWCOUNTRY*)pValue;
	if (string_to_Q_NEWCOUNTRY(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_NEWCOUNTRY_signature() {
	return "E"
		"|Q_NEWCOUNTRY_Same_country__or__railway_administration_no_NID_C_follows"
		"|Q_NEWCOUNTRY_Not_the_same_country__or__railway_administration_NID_C_follows"
		;
}

int check_Q_NEWCOUNTRY_string(const char* strValue) {
	static Q_NEWCOUNTRY rTemp;
	return string_to_Q_NEWCOUNTRY(strValue, &rTemp);
}


/****************************************************************
 ** Q_LINKORIENTATION
 ****************************************************************/
struct SimTypeVTable* pSimQ_LINKORIENTATIONVTable;
const char * Q_LINKORIENTATION_to_string(const void* pValue) {
	if (pSimQ_LINKORIENTATIONVTable != 0 && pSimQ_LINKORIENTATIONVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_LINKORIENTATIONVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_LINKORIENTATION*)pValue)) {
	case Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction:
		return "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction";
	case Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction:
		return "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction";
	default:
		return "?";
	}
}

int string_to_Q_LINKORIENTATION(const char* strValue, void* pValue) {
	if (pSimQ_LINKORIENTATIONVTable != 0 && pSimQ_LINKORIENTATIONVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_LINKORIENTATION rTemp;		int nResult = pSimQ_LINKORIENTATIONVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_LINKORIENTATION*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction") == 0)
		*((Q_LINKORIENTATION*)pValue) = Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction;
	else if(strcmp(strValue, "Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction") == 0)
		*((Q_LINKORIENTATION*)pValue) = Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction;
	else 
		return 0;
	return 1;
}

int is_Q_LINKORIENTATION_allow_double_convertion() {
	return 1;
}


int Q_LINKORIENTATION_to_double(double * nValue, const void* pValue) {
	switch (*((Q_LINKORIENTATION*)pValue)) {
	case Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction:
		*nValue = 0.0;
		break;
	case Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction:
		*nValue = 1.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_LINKORIENTATION_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_LINKORIENTATION rTemp;
	const Q_LINKORIENTATION* pCurrent = (const Q_LINKORIENTATION*)pValue;
	if (string_to_Q_LINKORIENTATION(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_LINKORIENTATION_signature() {
	return "E"
		"|Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_reverse_direction"
		"|Q_LINKORIENTATION_The_balise_group_is_seen_by_the_train_in_nominal_direction"
		;
}

int check_Q_LINKORIENTATION_string(const char* strValue) {
	static Q_LINKORIENTATION rTemp;
	return string_to_Q_LINKORIENTATION(strValue, &rTemp);
}


/****************************************************************
 ** Q_LINKREACTION
 ****************************************************************/
struct SimTypeVTable* pSimQ_LINKREACTIONVTable;
const char * Q_LINKREACTION_to_string(const void* pValue) {
	if (pSimQ_LINKREACTIONVTable != 0 && pSimQ_LINKREACTIONVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_LINKREACTIONVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_LINKREACTION*)pValue)) {
	case Q_LINKREACTION_Train_trip:
		return "Q_LINKREACTION_Train_trip";
	case Q_LINKREACTION_Apply_service_brake:
		return "Q_LINKREACTION_Apply_service_brake";
	case Q_LINKREACTION_No_Reaction:
		return "Q_LINKREACTION_No_Reaction";
	default:
		return "?";
	}
}

int string_to_Q_LINKREACTION(const char* strValue, void* pValue) {
	if (pSimQ_LINKREACTIONVTable != 0 && pSimQ_LINKREACTIONVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_LINKREACTION rTemp;		int nResult = pSimQ_LINKREACTIONVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_LINKREACTION*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_LINKREACTION_Train_trip") == 0)
		*((Q_LINKREACTION*)pValue) = Q_LINKREACTION_Train_trip;
	else if(strcmp(strValue, "Q_LINKREACTION_Apply_service_brake") == 0)
		*((Q_LINKREACTION*)pValue) = Q_LINKREACTION_Apply_service_brake;
	else if(strcmp(strValue, "Q_LINKREACTION_No_Reaction") == 0)
		*((Q_LINKREACTION*)pValue) = Q_LINKREACTION_No_Reaction;
	else 
		return 0;
	return 1;
}

int is_Q_LINKREACTION_allow_double_convertion() {
	return 1;
}


int Q_LINKREACTION_to_double(double * nValue, const void* pValue) {
	switch (*((Q_LINKREACTION*)pValue)) {
	case Q_LINKREACTION_Train_trip:
		*nValue = 0.0;
		break;
	case Q_LINKREACTION_Apply_service_brake:
		*nValue = 1.0;
		break;
	case Q_LINKREACTION_No_Reaction:
		*nValue = 2.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_LINKREACTION_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_LINKREACTION rTemp;
	const Q_LINKREACTION* pCurrent = (const Q_LINKREACTION*)pValue;
	if (string_to_Q_LINKREACTION(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_LINKREACTION_signature() {
	return "E"
		"|Q_LINKREACTION_Train_trip"
		"|Q_LINKREACTION_Apply_service_brake"
		"|Q_LINKREACTION_No_Reaction"
		;
}

int check_Q_LINKREACTION_string(const char* strValue) {
	static Q_LINKREACTION rTemp;
	return string_to_Q_LINKREACTION(strValue, &rTemp);
}


/****************************************************************
 ** Q_LOCACC
 ****************************************************************/
struct SimTypeVTable* pSimQ_LOCACCVTable;
const char * Q_LOCACC_to_string(const void* pValue) {
	if (pSimQ_LOCACCVTable != 0 && pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_LOCACCVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_Q_LOCACC(const char* strValue, void* pValue) {
	if (pSimQ_LOCACCVTable != 0 && pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static Q_LOCACC rTemp;
		int nResult = pSimQ_LOCACCVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_LOCACC*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_Q_LOCACC_allow_double_convertion() {
	if (pSimQ_LOCACCVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int Q_LOCACC_to_double(double * nValue, const void* pValue) {
	if (pSimQ_LOCACCVTable != 0) {
		if (pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimQ_LOCACCVTable->m_pfnToType(SptLong, pValue));
		else if (pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimQ_LOCACCVTable->m_pfnToType(SptShort, pValue));
		else if (pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimQ_LOCACCVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimQ_LOCACCVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimQ_LOCACCVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_Q_LOCACC_string(const char* strValue) {
	static Q_LOCACC rTemp;
	return string_to_Q_LOCACC(strValue, &rTemp);
}


/****************************************************************
 ** Q_DIRLRBG
 ****************************************************************/
struct SimTypeVTable* pSimQ_DIRLRBGVTable;
const char * Q_DIRLRBG_to_string(const void* pValue) {
	if (pSimQ_DIRLRBGVTable != 0 && pSimQ_DIRLRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_DIRLRBGVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_DIRLRBG*)pValue)) {
	case Q_DIRLRBG_Reverse:
		return "Q_DIRLRBG_Reverse";
	case Q_DIRLRBG_Nominal:
		return "Q_DIRLRBG_Nominal";
	case Q_DIRLRBG_Unknown:
		return "Q_DIRLRBG_Unknown";
	default:
		return "?";
	}
}

int string_to_Q_DIRLRBG(const char* strValue, void* pValue) {
	if (pSimQ_DIRLRBGVTable != 0 && pSimQ_DIRLRBGVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_DIRLRBG rTemp;		int nResult = pSimQ_DIRLRBGVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_DIRLRBG*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_DIRLRBG_Reverse") == 0)
		*((Q_DIRLRBG*)pValue) = Q_DIRLRBG_Reverse;
	else if(strcmp(strValue, "Q_DIRLRBG_Nominal") == 0)
		*((Q_DIRLRBG*)pValue) = Q_DIRLRBG_Nominal;
	else if(strcmp(strValue, "Q_DIRLRBG_Unknown") == 0)
		*((Q_DIRLRBG*)pValue) = Q_DIRLRBG_Unknown;
	else 
		return 0;
	return 1;
}

int is_Q_DIRLRBG_allow_double_convertion() {
	return 1;
}


int Q_DIRLRBG_to_double(double * nValue, const void* pValue) {
	switch (*((Q_DIRLRBG*)pValue)) {
	case Q_DIRLRBG_Reverse:
		*nValue = 0.0;
		break;
	case Q_DIRLRBG_Nominal:
		*nValue = 1.0;
		break;
	case Q_DIRLRBG_Unknown:
		*nValue = 2.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_DIRLRBG_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_DIRLRBG rTemp;
	const Q_DIRLRBG* pCurrent = (const Q_DIRLRBG*)pValue;
	if (string_to_Q_DIRLRBG(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_DIRLRBG_signature() {
	return "E"
		"|Q_DIRLRBG_Reverse"
		"|Q_DIRLRBG_Nominal"
		"|Q_DIRLRBG_Unknown"
		;
}

int check_Q_DIRLRBG_string(const char* strValue) {
	static Q_DIRLRBG rTemp;
	return string_to_Q_DIRLRBG(strValue, &rTemp);
}


/****************************************************************
 ** Q_DIRTRAIN
 ****************************************************************/
struct SimTypeVTable* pSimQ_DIRTRAINVTable;
const char * Q_DIRTRAIN_to_string(const void* pValue) {
	if (pSimQ_DIRTRAINVTable != 0 && pSimQ_DIRTRAINVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_DIRTRAINVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_DIRTRAIN*)pValue)) {
	case Q_DIRTRAIN_Reverse:
		return "Q_DIRTRAIN_Reverse";
	case Q_DIRTRAIN_Nominal:
		return "Q_DIRTRAIN_Nominal";
	case Q_DIRTRAIN_Unknown:
		return "Q_DIRTRAIN_Unknown";
	default:
		return "?";
	}
}

int string_to_Q_DIRTRAIN(const char* strValue, void* pValue) {
	if (pSimQ_DIRTRAINVTable != 0 && pSimQ_DIRTRAINVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_DIRTRAIN rTemp;		int nResult = pSimQ_DIRTRAINVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_DIRTRAIN*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_DIRTRAIN_Reverse") == 0)
		*((Q_DIRTRAIN*)pValue) = Q_DIRTRAIN_Reverse;
	else if(strcmp(strValue, "Q_DIRTRAIN_Nominal") == 0)
		*((Q_DIRTRAIN*)pValue) = Q_DIRTRAIN_Nominal;
	else if(strcmp(strValue, "Q_DIRTRAIN_Unknown") == 0)
		*((Q_DIRTRAIN*)pValue) = Q_DIRTRAIN_Unknown;
	else 
		return 0;
	return 1;
}

int is_Q_DIRTRAIN_allow_double_convertion() {
	return 1;
}


int Q_DIRTRAIN_to_double(double * nValue, const void* pValue) {
	switch (*((Q_DIRTRAIN*)pValue)) {
	case Q_DIRTRAIN_Reverse:
		*nValue = 0.0;
		break;
	case Q_DIRTRAIN_Nominal:
		*nValue = 1.0;
		break;
	case Q_DIRTRAIN_Unknown:
		*nValue = 2.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_DIRTRAIN_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_DIRTRAIN rTemp;
	const Q_DIRTRAIN* pCurrent = (const Q_DIRTRAIN*)pValue;
	if (string_to_Q_DIRTRAIN(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_DIRTRAIN_signature() {
	return "E"
		"|Q_DIRTRAIN_Reverse"
		"|Q_DIRTRAIN_Nominal"
		"|Q_DIRTRAIN_Unknown"
		;
}

int check_Q_DIRTRAIN_string(const char* strValue) {
	static Q_DIRTRAIN rTemp;
	return string_to_Q_DIRTRAIN(strValue, &rTemp);
}


/****************************************************************
 ** NID_ENGINE
 ****************************************************************/
struct SimTypeVTable* pSimNID_ENGINEVTable;
const char * NID_ENGINE_to_string(const void* pValue) {
	if (pSimNID_ENGINEVTable != 0 && pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_ENGINEVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_ENGINE(const char* strValue, void* pValue) {
	if (pSimNID_ENGINEVTable != 0 && pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_ENGINE rTemp;
		int nResult = pSimNID_ENGINEVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_ENGINE*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_ENGINE_allow_double_convertion() {
	if (pSimNID_ENGINEVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_ENGINE_to_double(double * nValue, const void* pValue) {
	if (pSimNID_ENGINEVTable != 0) {
		if (pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_ENGINEVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_ENGINEVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_ENGINEVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_ENGINEVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_ENGINEVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_ENGINE_string(const char* strValue) {
	static NID_ENGINE rTemp;
	return string_to_NID_ENGINE(strValue, &rTemp);
}


/****************************************************************
 ** NID_OPERATIONAL
 ****************************************************************/
struct SimTypeVTable* pSimNID_OPERATIONALVTable;
const char * NID_OPERATIONAL_to_string(const void* pValue) {
	if (pSimNID_OPERATIONALVTable != 0 && pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_OPERATIONALVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_OPERATIONAL(const char* strValue, void* pValue) {
	if (pSimNID_OPERATIONALVTable != 0 && pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_OPERATIONAL rTemp;
		int nResult = pSimNID_OPERATIONALVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_OPERATIONAL*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_OPERATIONAL_allow_double_convertion() {
	if (pSimNID_OPERATIONALVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_OPERATIONAL_to_double(double * nValue, const void* pValue) {
	if (pSimNID_OPERATIONALVTable != 0) {
		if (pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_OPERATIONALVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_OPERATIONALVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_OPERATIONALVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_OPERATIONALVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_OPERATIONALVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_OPERATIONAL_string(const char* strValue) {
	static NID_OPERATIONAL rTemp;
	return string_to_NID_OPERATIONAL(strValue, &rTemp);
}


/****************************************************************
 ** L_TRAIN
 ****************************************************************/
struct SimTypeVTable* pSimL_TRAINVTable;
const char * L_TRAIN_to_string(const void* pValue) {
	if (pSimL_TRAINVTable != 0 && pSimL_TRAINVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimL_TRAINVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_L_TRAIN(const char* strValue, void* pValue) {
	if (pSimL_TRAINVTable != 0 && pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static L_TRAIN rTemp;
		int nResult = pSimL_TRAINVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((L_TRAIN*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_L_TRAIN_allow_double_convertion() {
	if (pSimL_TRAINVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int L_TRAIN_to_double(double * nValue, const void* pValue) {
	if (pSimL_TRAINVTable != 0) {
		if (pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimL_TRAINVTable->m_pfnToType(SptLong, pValue));
		else if (pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimL_TRAINVTable->m_pfnToType(SptShort, pValue));
		else if (pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimL_TRAINVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimL_TRAINVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimL_TRAINVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_L_TRAIN_string(const char* strValue) {
	static L_TRAIN rTemp;
	return string_to_L_TRAIN(strValue, &rTemp);
}


/****************************************************************
 ** Q_NVLOCACC
 ****************************************************************/
struct SimTypeVTable* pSimQ_NVLOCACCVTable;
const char * Q_NVLOCACC_to_string(const void* pValue) {
	if (pSimQ_NVLOCACCVTable != 0 && pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_NVLOCACCVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_Q_NVLOCACC(const char* strValue, void* pValue) {
	if (pSimQ_NVLOCACCVTable != 0 && pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static Q_NVLOCACC rTemp;
		int nResult = pSimQ_NVLOCACCVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_NVLOCACC*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_Q_NVLOCACC_allow_double_convertion() {
	if (pSimQ_NVLOCACCVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int Q_NVLOCACC_to_double(double * nValue, const void* pValue) {
	if (pSimQ_NVLOCACCVTable != 0) {
		if (pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimQ_NVLOCACCVTable->m_pfnToType(SptLong, pValue));
		else if (pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimQ_NVLOCACCVTable->m_pfnToType(SptShort, pValue));
		else if (pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimQ_NVLOCACCVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimQ_NVLOCACCVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimQ_NVLOCACCVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_Q_NVLOCACC_string(const char* strValue) {
	static Q_NVLOCACC rTemp;
	return string_to_Q_NVLOCACC(strValue, &rTemp);
}


/****************************************************************
 ** NID_PRVLRBG
 ****************************************************************/
struct SimTypeVTable* pSimNID_PRVLRBGVTable;
const char * NID_PRVLRBG_to_string(const void* pValue) {
	if (pSimNID_PRVLRBGVTable != 0 && pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimNID_PRVLRBGVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_NID_PRVLRBG(const char* strValue, void* pValue) {
	if (pSimNID_PRVLRBGVTable != 0 && pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static NID_PRVLRBG rTemp;
		int nResult = pSimNID_PRVLRBGVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((NID_PRVLRBG*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_NID_PRVLRBG_allow_double_convertion() {
	if (pSimNID_PRVLRBGVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int NID_PRVLRBG_to_double(double * nValue, const void* pValue) {
	if (pSimNID_PRVLRBGVTable != 0) {
		if (pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimNID_PRVLRBGVTable->m_pfnToType(SptLong, pValue));
		else if (pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimNID_PRVLRBGVTable->m_pfnToType(SptShort, pValue));
		else if (pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimNID_PRVLRBGVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimNID_PRVLRBGVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimNID_PRVLRBGVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_NID_PRVLRBG_string(const char* strValue) {
	static NID_PRVLRBG rTemp;
	return string_to_NID_PRVLRBG(strValue, &rTemp);
}


/****************************************************************
 ** Q_DLRBG
 ****************************************************************/
struct SimTypeVTable* pSimQ_DLRBGVTable;
const char * Q_DLRBG_to_string(const void* pValue) {
	if (pSimQ_DLRBGVTable != 0 && pSimQ_DLRBGVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimQ_DLRBGVTable->m_pfnToType(SptString, pValue);
	switch (*((Q_DLRBG*)pValue)) {
	case Q_DLRBG_Reverse:
		return "Q_DLRBG_Reverse";
	case Q_DLRBG_Nominal:
		return "Q_DLRBG_Nominal";
	case Q_DLRBG_Unknown:
		return "Q_DLRBG_Unknown";
	default:
		return "?";
	}
}

int string_to_Q_DLRBG(const char* strValue, void* pValue) {
	if (pSimQ_DLRBGVTable != 0 && pSimQ_DLRBGVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		Q_DLRBG rTemp;		int nResult = pSimQ_DLRBGVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Q_DLRBG*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "Q_DLRBG_Reverse") == 0)
		*((Q_DLRBG*)pValue) = Q_DLRBG_Reverse;
	else if(strcmp(strValue, "Q_DLRBG_Nominal") == 0)
		*((Q_DLRBG*)pValue) = Q_DLRBG_Nominal;
	else if(strcmp(strValue, "Q_DLRBG_Unknown") == 0)
		*((Q_DLRBG*)pValue) = Q_DLRBG_Unknown;
	else 
		return 0;
	return 1;
}

int is_Q_DLRBG_allow_double_convertion() {
	return 1;
}


int Q_DLRBG_to_double(double * nValue, const void* pValue) {
	switch (*((Q_DLRBG*)pValue)) {
	case Q_DLRBG_Reverse:
		*nValue = 0.0;
		break;
	case Q_DLRBG_Nominal:
		*nValue = 1.0;
		break;
	case Q_DLRBG_Unknown:
		*nValue = 2.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_Q_DLRBG_type(int* pResult, const char* toCompare, const void* pValue) {
	static Q_DLRBG rTemp;
	const Q_DLRBG* pCurrent = (const Q_DLRBG*)pValue;
	if (string_to_Q_DLRBG(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_Q_DLRBG_signature() {
	return "E"
		"|Q_DLRBG_Reverse"
		"|Q_DLRBG_Nominal"
		"|Q_DLRBG_Unknown"
		;
}

int check_Q_DLRBG_string(const char* strValue) {
	static Q_DLRBG rTemp;
	return string_to_Q_DLRBG(strValue, &rTemp);
}


/****************************************************************
 ** odometryFactors_T_ctp_t_pck_t_engine
 ****************************************************************/
struct SimTypeVTable* pSimodometryFactors_T_ctp_t_pck_t_engineVTable;
const char * odometryFactors_T_ctp_t_pck_t_engine_to_string(const void* pValue) {
	if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != 0 && pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptString, pValue);
	return struct__5756_to_string(pValue);
}

int string_to_odometryFactors_T_ctp_t_pck_t_engine(const char* strValue, void* pValue) {
	if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != 0 && pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static odometryFactors_T_ctp_t_pck_t_engine rTemp;
		int nResult = pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5756(&(*((odometryFactors_T_ctp_t_pck_t_engine*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5756(strValue, pValue);
}

int is_odometryFactors_T_ctp_t_pck_t_engine_allow_double_convertion() {
	if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5756_allow_double_convertion();
}

int odometryFactors_T_ctp_t_pck_t_engine_to_double(double * nValue, const void* pValue) {
	if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable != 0) {
		if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptLong, pValue));
		else if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptShort, pValue));
		else if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimodometryFactors_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5756_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5756_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_odometryFactors_T_ctp_t_pck_t_engine_string(const char* strValue) {
	static odometryFactors_T_ctp_t_pck_t_engine rTemp;
	return string_to_odometryFactors_T_ctp_t_pck_t_engine(strValue, &rTemp);
}


/****************************************************************
 ** genPassedBG_T_ctp_t_pck_t_engine
 ****************************************************************/
struct SimTypeVTable* pSimgenPassedBG_T_ctp_t_pck_t_engineVTable;
const char * genPassedBG_T_ctp_t_pck_t_engine_to_string(const void* pValue) {
	if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != 0 && pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptString, pValue);
	return struct__5748_to_string(pValue);
}

int string_to_genPassedBG_T_ctp_t_pck_t_engine(const char* strValue, void* pValue) {
	if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != 0 && pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static genPassedBG_T_ctp_t_pck_t_engine rTemp;
		int nResult = pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5748(&(*((genPassedBG_T_ctp_t_pck_t_engine*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5748(strValue, pValue);
}

int is_genPassedBG_T_ctp_t_pck_t_engine_allow_double_convertion() {
	if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5748_allow_double_convertion();
}

int genPassedBG_T_ctp_t_pck_t_engine_to_double(double * nValue, const void* pValue) {
	if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable != 0) {
		if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptLong, pValue));
		else if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptShort, pValue));
		else if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimgenPassedBG_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5748_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5748_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_genPassedBG_T_ctp_t_pck_t_engine_string(const char* strValue) {
	static genPassedBG_T_ctp_t_pck_t_engine rTemp;
	return string_to_genPassedBG_T_ctp_t_pck_t_engine(strValue, &rTemp);
}


/****************************************************************
 ** genPassedBGs_T_ctp_t_pck_t_engine
 ****************************************************************/
struct SimTypeVTable* pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable;
const char * genPassedBGs_T_ctp_t_pck_t_engine_to_string(const void* pValue) {
	if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != 0 && pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptString, pValue);
	return array__5753_to_string(pValue);
}

int string_to_genPassedBGs_T_ctp_t_pck_t_engine(const char* strValue, void* pValue) {
	if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != 0 && pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static genPassedBGs_T_ctp_t_pck_t_engine rTemp;
		int nResult = pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_array__5753(&(*((genPassedBGs_T_ctp_t_pck_t_engine*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_array__5753(strValue, pValue);
}

int is_genPassedBGs_T_ctp_t_pck_t_engine_allow_double_convertion() {
	if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_array__5753_allow_double_convertion();
}

int genPassedBGs_T_ctp_t_pck_t_engine_to_double(double * nValue, const void* pValue) {
	if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable != 0) {
		if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptLong, pValue));
		else if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptShort, pValue));
		else if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimgenPassedBGs_T_ctp_t_pck_t_engineVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_array__5753_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_array__5753_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_genPassedBGs_T_ctp_t_pck_t_engine_string(const char* strValue) {
	static genPassedBGs_T_ctp_t_pck_t_engine rTemp;
	return string_to_genPassedBGs_T_ctp_t_pck_t_engine(strValue, &rTemp);
}


/****************************************************************
 ** positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable;
const char * positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_string(const void* pValue) {
	if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != 0 && pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5743_to_string(pValue);
}

int string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(const char* strValue, void* pValue) {
	if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != 0 && pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg rTemp;
		int nResult = pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5743(&(*((positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5743(strValue, pValue);
}

int is_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_allow_double_convertion() {
	if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5743_allow_double_convertion();
}

int positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable != 0) {
		if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimpositionedBGs_w_overrun_T_CalculateTrainPosition_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5743_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5743_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_string(const char* strValue) {
	static positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg rTemp;
	return string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable;
const char * BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void* pValue) {
	if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0 && pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5714_to_string(pValue);
}

int string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* strValue, void* pValue) {
	if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0 && pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg rTemp;
		int nResult = pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5714(&(*((BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5714(strValue, pValue);
}

int is_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion() {
	if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5714_allow_double_convertion();
}

int BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0) {
		if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimBG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5714_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5714_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char* strValue) {
	static BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg rTemp;
	return string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable;
const char * BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void* pValue) {
	if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0 && pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5708_to_string(pValue);
}

int string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* strValue, void* pValue) {
	if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0 && pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg rTemp;
		int nResult = pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5708(&(*((BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5708(strValue, pValue);
}

int is_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion() {
	if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5708_allow_double_convertion();
}

int BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable != 0) {
		if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimBG_find_T_CalculateTrainPosition_Pkg_BG_utilities_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5708_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5708_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char* strValue) {
	static BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg rTemp;
	return string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable;
const char * refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void* pValue) {
	if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0 && pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5732_to_string(pValue);
}

int string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* strValue, void* pValue) {
	if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0 && pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
		int nResult = pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5732(&(*((refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5732(strValue, pValue);
}

int is_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion() {
	if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5732_allow_double_convertion();
}

int refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0) {
		if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimrefBGs_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5732_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5732_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char* strValue) {
	static refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
	return string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable;
const char * linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void* pValue) {
	if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0 && pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5723_to_string(pValue);
}

int string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* strValue, void* pValue) {
	if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0 && pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
		int nResult = pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5723(&(*((linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5723(strValue, pValue);
}

int is_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion() {
	if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5723_allow_double_convertion();
}

int linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0) {
		if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimlinkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5723_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5723_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char* strValue) {
	static linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
	return string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable;
const char * linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void* pValue) {
	if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0 && pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptString, pValue);
	return array__5729_to_string(pValue);
}

int string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* strValue, void* pValue) {
	if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0 && pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
		int nResult = pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_array__5729(&(*((linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_array__5729(strValue, pValue);
}

int is_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion() {
	if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_array__5729_allow_double_convertion();
}

int linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable != 0) {
		if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimlinkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_array__5729_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_array__5729_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char* strValue) {
	static linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg rTemp;
	return string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable;
const char * trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_string(const void* pValue) {
	if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != 0 && pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnToType(SptString, pValue);
	switch (*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue)) {
	case trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg:
		return "CalculateTrainPosition_Pkg::Pos_Pkg::trm_unknown";
	case trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg:
		return "CalculateTrainPosition_Pkg::Pos_Pkg::trm_standstill";
	case trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg:
		return "CalculateTrainPosition_Pkg::Pos_Pkg::trm_increasing";
	case trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg:
		return "CalculateTrainPosition_Pkg::Pos_Pkg::trm_decreasing";
	default:
		return "?";
	}
}

int string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(const char* strValue, void* pValue) {
	if (pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable != 0 && pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg rTemp;		int nResult = pSimtrainMovementDir_T_CalculateTrainPosition_Pkg_Pos_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue) = rTemp;
		return nResult;
	}
	if(strcmp(strValue, "trm_unknown") == 0 || strcmp(strValue, "CalculateTrainPosition_Pkg::Pos_Pkg::trm_unknown") == 0)
		*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue) = trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg;
	else if(strcmp(strValue, "trm_standstill") == 0 || strcmp(strValue, "CalculateTrainPosition_Pkg::Pos_Pkg::trm_standstill") == 0)
		*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue) = trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg;
	else if(strcmp(strValue, "trm_increasing") == 0 || strcmp(strValue, "CalculateTrainPosition_Pkg::Pos_Pkg::trm_increasing") == 0)
		*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue) = trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg;
	else if(strcmp(strValue, "trm_decreasing") == 0 || strcmp(strValue, "CalculateTrainPosition_Pkg::Pos_Pkg::trm_decreasing") == 0)
		*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue) = trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg;
	else 
		return 0;
	return 1;
}

int is_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_allow_double_convertion() {
	return 1;
}


int trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_double(double * nValue, const void* pValue) {
	switch (*((trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue)) {
	case trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg:
		*nValue = 0.0;
		break;
	case trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg:
		*nValue = 1.0;
		break;
	case trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg:
		*nValue = 2.0;
		break;
	case trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg:
		*nValue = 3.0;
		break;
	default:
		return 0;
	}
	return 1;
}


int compare_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_type(int* pResult, const char* toCompare, const void* pValue) {
	static trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg rTemp;
	const trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg* pCurrent = (const trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg*)pValue;
	if (string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(toCompare, &rTemp) == 0)
		return 0;
	if (*pCurrent > rTemp)
		*pResult = 1;
	else if (*pCurrent < rTemp)
		*pResult = -1;
	else
		*pResult = 0;
	return 1;
}

const char * get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_signature() {
	return "E"
		"|CalculateTrainPosition_Pkg::Pos_Pkg::trm_unknown"
		"|CalculateTrainPosition_Pkg::Pos_Pkg::trm_standstill"
		"|CalculateTrainPosition_Pkg::Pos_Pkg::trm_increasing"
		"|CalculateTrainPosition_Pkg::Pos_Pkg::trm_decreasing"
		;
}

int check_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_string(const char* strValue) {
	static trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg rTemp;
	return string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** passedBG_T_BG_Types_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimpassedBG_T_BG_Types_PkgVTable;
const char * passedBG_T_BG_Types_Pkg_to_string(const void* pValue) {
	if (pSimpassedBG_T_BG_Types_PkgVTable != 0 && pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimpassedBG_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5629_to_string(pValue);
}

int string_to_passedBG_T_BG_Types_Pkg(const char* strValue, void* pValue) {
	if (pSimpassedBG_T_BG_Types_PkgVTable != 0 && pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static passedBG_T_BG_Types_Pkg rTemp;
		int nResult = pSimpassedBG_T_BG_Types_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5629(&(*((passedBG_T_BG_Types_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5629(strValue, pValue);
}

int is_passedBG_T_BG_Types_Pkg_allow_double_convertion() {
	if (pSimpassedBG_T_BG_Types_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5629_allow_double_convertion();
}

int passedBG_T_BG_Types_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimpassedBG_T_BG_Types_PkgVTable != 0) {
		if (pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimpassedBG_T_BG_Types_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimpassedBG_T_BG_Types_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimpassedBG_T_BG_Types_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimpassedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimpassedBG_T_BG_Types_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5629_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5629_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_passedBG_T_BG_Types_Pkg_string(const char* strValue) {
	static passedBG_T_BG_Types_Pkg rTemp;
	return string_to_passedBG_T_BG_Types_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** BG_Header_T_BG_Types_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimBG_Header_T_BG_Types_PkgVTable;
const char * BG_Header_T_BG_Types_Pkg_to_string(const void* pValue) {
	if (pSimBG_Header_T_BG_Types_PkgVTable != 0 && pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimBG_Header_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5618_to_string(pValue);
}

int string_to_BG_Header_T_BG_Types_Pkg(const char* strValue, void* pValue) {
	if (pSimBG_Header_T_BG_Types_PkgVTable != 0 && pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static BG_Header_T_BG_Types_Pkg rTemp;
		int nResult = pSimBG_Header_T_BG_Types_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5618(&(*((BG_Header_T_BG_Types_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5618(strValue, pValue);
}

int is_BG_Header_T_BG_Types_Pkg_allow_double_convertion() {
	if (pSimBG_Header_T_BG_Types_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5618_allow_double_convertion();
}

int BG_Header_T_BG_Types_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimBG_Header_T_BG_Types_PkgVTable != 0) {
		if (pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimBG_Header_T_BG_Types_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimBG_Header_T_BG_Types_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimBG_Header_T_BG_Types_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimBG_Header_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimBG_Header_T_BG_Types_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5618_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5618_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_BG_Header_T_BG_Types_Pkg_string(const char* strValue) {
	static BG_Header_T_BG_Types_Pkg rTemp;
	return string_to_BG_Header_T_BG_Types_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** LinkedBGs_T_BG_Types_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimLinkedBGs_T_BG_Types_PkgVTable;
const char * LinkedBGs_T_BG_Types_Pkg_to_string(const void* pValue) {
	if (pSimLinkedBGs_T_BG_Types_PkgVTable != 0 && pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue);
	return array__5615_to_string(pValue);
}

int string_to_LinkedBGs_T_BG_Types_Pkg(const char* strValue, void* pValue) {
	if (pSimLinkedBGs_T_BG_Types_PkgVTable != 0 && pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static LinkedBGs_T_BG_Types_Pkg rTemp;
		int nResult = pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_array__5615(&(*((LinkedBGs_T_BG_Types_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_array__5615(strValue, pValue);
}

int is_LinkedBGs_T_BG_Types_Pkg_allow_double_convertion() {
	if (pSimLinkedBGs_T_BG_Types_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_array__5615_allow_double_convertion();
}

int LinkedBGs_T_BG_Types_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimLinkedBGs_T_BG_Types_PkgVTable != 0) {
		if (pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimLinkedBGs_T_BG_Types_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_array__5615_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_array__5615_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_LinkedBGs_T_BG_Types_Pkg_string(const char* strValue) {
	static LinkedBGs_T_BG_Types_Pkg rTemp;
	return string_to_LinkedBGs_T_BG_Types_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** LinkedBG_T_BG_Types_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimLinkedBG_T_BG_Types_PkgVTable;
const char * LinkedBG_T_BG_Types_Pkg_to_string(const void* pValue) {
	if (pSimLinkedBG_T_BG_Types_PkgVTable != 0 && pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5584_to_string(pValue);
}

int string_to_LinkedBG_T_BG_Types_Pkg(const char* strValue, void* pValue) {
	if (pSimLinkedBG_T_BG_Types_PkgVTable != 0 && pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static LinkedBG_T_BG_Types_Pkg rTemp;
		int nResult = pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5584(&(*((LinkedBG_T_BG_Types_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5584(strValue, pValue);
}

int is_LinkedBG_T_BG_Types_Pkg_allow_double_convertion() {
	if (pSimLinkedBG_T_BG_Types_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5584_allow_double_convertion();
}

int LinkedBG_T_BG_Types_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimLinkedBG_T_BG_Types_PkgVTable != 0) {
		if (pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimLinkedBG_T_BG_Types_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5584_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5584_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_LinkedBG_T_BG_Types_Pkg_string(const char* strValue) {
	static LinkedBG_T_BG_Types_Pkg rTemp;
	return string_to_LinkedBG_T_BG_Types_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** T_internal_Type_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimT_internal_Type_Obu_BasicTypes_PkgVTable;
const char * T_internal_Type_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != 0 && pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_T_internal_Type_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != 0 && pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static T_internal_Type_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((T_internal_Type_Obu_BasicTypes_Pkg*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_T_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int T_internal_Type_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimT_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_T_internal_Type_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static T_internal_Type_Obu_BasicTypes_Pkg rTemp;
	return string_to_T_internal_Type_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** OdometryLocations_T_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable;
const char * OdometryLocations_T_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != 0 && pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5609_to_string(pValue);
}

int string_to_OdometryLocations_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != 0 && pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static OdometryLocations_T_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5609(&(*((OdometryLocations_T_Obu_BasicTypes_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5609(strValue, pValue);
}

int is_OdometryLocations_T_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5609_allow_double_convertion();
}

int OdometryLocations_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimOdometryLocations_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5609_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5609_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_OdometryLocations_T_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static OdometryLocations_T_Obu_BasicTypes_Pkg rTemp;
	return string_to_OdometryLocations_T_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** L_internal_Type_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimL_internal_Type_Obu_BasicTypes_PkgVTable;
const char * L_internal_Type_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != 0 && pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_L_internal_Type_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != 0 && pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static L_internal_Type_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((L_internal_Type_Obu_BasicTypes_Pkg*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_L_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int L_internal_Type_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimL_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_L_internal_Type_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static L_internal_Type_Obu_BasicTypes_Pkg rTemp;
	return string_to_L_internal_Type_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** LocWithInAcc_T_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable;
const char * LocWithInAcc_T_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != 0 && pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5578_to_string(pValue);
}

int string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != 0 && pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static LocWithInAcc_T_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5578(&(*((LocWithInAcc_T_Obu_BasicTypes_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5578(strValue, pValue);
}

int is_LocWithInAcc_T_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5578_allow_double_convertion();
}

int LocWithInAcc_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimLocWithInAcc_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5578_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5578_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_LocWithInAcc_T_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static LocWithInAcc_T_Obu_BasicTypes_Pkg rTemp;
	return string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** Speed_T_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimSpeed_T_Obu_BasicTypes_PkgVTable;
const char * Speed_T_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != 0 && pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return V_internal_Type_Obu_BasicTypes_Pkg_to_string(pValue);
}

int string_to_Speed_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != 0 && pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static Speed_T_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Speed_T_Obu_BasicTypes_Pkg*)pValue) = rTemp;
		return nResult;
	}
	return string_to_V_internal_Type_Obu_BasicTypes_Pkg(strValue, pValue);
}

int is_Speed_T_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_V_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
}

int Speed_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimSpeed_T_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimSpeed_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_V_internal_Type_Obu_BasicTypes_Pkg_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_V_internal_Type_Obu_BasicTypes_Pkg_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_Speed_T_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static Speed_T_Obu_BasicTypes_Pkg rTemp;
	return string_to_Speed_T_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** V_internal_Type_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimV_internal_Type_Obu_BasicTypes_PkgVTable;
const char * V_internal_Type_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != 0 && pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return kcg_int_to_string(pValue);
}

int string_to_V_internal_Type_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != 0 && pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static V_internal_Type_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((V_internal_Type_Obu_BasicTypes_Pkg*)pValue) = rTemp;
		return nResult;
	}
	return string_to_kcg_int(strValue, pValue);
}

int is_V_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_kcg_int_allow_double_convertion();
}

int V_internal_Type_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimV_internal_Type_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_kcg_int_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_kcg_int_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_V_internal_Type_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static V_internal_Type_Obu_BasicTypes_Pkg rTemp;
	return string_to_V_internal_Type_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** Location_T_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimLocation_T_Obu_BasicTypes_PkgVTable;
const char * Location_T_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimLocation_T_Obu_BasicTypes_PkgVTable != 0 && pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return L_internal_Type_Obu_BasicTypes_Pkg_to_string(pValue);
}

int string_to_Location_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimLocation_T_Obu_BasicTypes_PkgVTable != 0 && pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static Location_T_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			*((Location_T_Obu_BasicTypes_Pkg*)pValue) = rTemp;
		return nResult;
	}
	return string_to_L_internal_Type_Obu_BasicTypes_Pkg(strValue, pValue);
}

int is_Location_T_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimLocation_T_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_L_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
}

int Location_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimLocation_T_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimLocation_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_Location_T_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static Location_T_Obu_BasicTypes_Pkg rTemp;
	return string_to_Location_T_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** odometry_T_Obu_BasicTypes_Pkg
 ****************************************************************/
struct SimTypeVTable* pSimodometry_T_Obu_BasicTypes_PkgVTable;
const char * odometry_T_Obu_BasicTypes_Pkg_to_string(const void* pValue) {
	if (pSimodometry_T_Obu_BasicTypes_PkgVTable != 0 && pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptString, pValue);
	return struct__5701_to_string(pValue);
}

int string_to_odometry_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue) {
	if (pSimodometry_T_Obu_BasicTypes_PkgVTable != 0 && pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static odometry_T_Obu_BasicTypes_Pkg rTemp;
		int nResult = pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5701(&(*((odometry_T_Obu_BasicTypes_Pkg*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5701(strValue, pValue);
}

int is_odometry_T_Obu_BasicTypes_Pkg_allow_double_convertion() {
	if (pSimodometry_T_Obu_BasicTypes_PkgVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5701_allow_double_convertion();
}

int odometry_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void* pValue) {
	if (pSimodometry_T_Obu_BasicTypes_PkgVTable != 0) {
		if (pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptLong, pValue));
		else if (pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptShort, pValue));
		else if (pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimodometry_T_Obu_BasicTypes_PkgVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5701_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5701_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_odometry_T_Obu_BasicTypes_Pkg_string(const char* strValue) {
	static odometry_T_Obu_BasicTypes_Pkg rTemp;
	return string_to_odometry_T_Obu_BasicTypes_Pkg(strValue, &rTemp);
}


/****************************************************************
 ** positionedBG_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimpositionedBG_T_TrainPosition_Types_PckVTable;
const char * positionedBG_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != 0 && pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return struct__5642_to_string(pValue);
}

int string_to_positionedBG_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != 0 && pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static positionedBG_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5642(&(*((positionedBG_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5642(strValue, pValue);
}

int is_positionedBG_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5642_allow_double_convertion();
}

int positionedBG_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimpositionedBG_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimpositionedBG_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5642_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5642_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_positionedBG_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static positionedBG_T_TrainPosition_Types_Pck rTemp;
	return string_to_positionedBG_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** infoFromLinking_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSiminfoFromLinking_T_TrainPosition_Types_PckVTable;
const char * infoFromLinking_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != 0 && pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return struct__5600_to_string(pValue);
}

int string_to_infoFromLinking_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != 0 && pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static infoFromLinking_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5600(&(*((infoFromLinking_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5600(strValue, pValue);
}

int is_infoFromLinking_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5600_allow_double_convertion();
}

int infoFromLinking_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable != 0) {
		if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSiminfoFromLinking_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5600_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5600_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_infoFromLinking_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static infoFromLinking_T_TrainPosition_Types_Pck rTemp;
	return string_to_infoFromLinking_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** trainProperties_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimtrainProperties_T_TrainPosition_Types_PckVTable;
const char * trainProperties_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != 0 && pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return struct__5690_to_string(pValue);
}

int string_to_trainProperties_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != 0 && pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static trainProperties_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5690(&(*((trainProperties_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5690(strValue, pValue);
}

int is_trainProperties_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5690_allow_double_convertion();
}

int trainProperties_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimtrainProperties_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimtrainProperties_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5690_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5690_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_trainProperties_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static trainProperties_T_TrainPosition_Types_Pck rTemp;
	return string_to_trainProperties_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable;
const char * linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != 0 && pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return array__5740_to_string(pValue);
}

int string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != 0 && pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_array__5740(&(*((linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_array__5740(strValue, pValue);
}

int is_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_array__5740_allow_double_convertion();
}

int linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimlinkedBGs_asPositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_array__5740_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_array__5740_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck rTemp;
	return string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** positionedBGs_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimpositionedBGs_T_TrainPosition_Types_PckVTable;
const char * positionedBGs_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != 0 && pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return array__5687_to_string(pValue);
}

int string_to_positionedBGs_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != 0 && pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static positionedBGs_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_array__5687(&(*((positionedBGs_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_array__5687(strValue, pValue);
}

int is_positionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_array__5687_allow_double_convertion();
}

int positionedBGs_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimpositionedBGs_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_array__5687_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_array__5687_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_positionedBGs_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static positionedBGs_T_TrainPosition_Types_Pck rTemp;
	return string_to_positionedBGs_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** positionErrors_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimpositionErrors_T_TrainPosition_Types_PckVTable;
const char * positionErrors_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != 0 && pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return struct__5681_to_string(pValue);
}

int string_to_positionErrors_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != 0 && pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static positionErrors_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5681(&(*((positionErrors_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5681(strValue, pValue);
}

int is_positionErrors_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5681_allow_double_convertion();
}

int positionErrors_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimpositionErrors_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimpositionErrors_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5681_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5681_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_positionErrors_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static positionErrors_T_TrainPosition_Types_Pck rTemp;
	return string_to_positionErrors_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** trainPosition_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimtrainPosition_T_TrainPosition_Types_PckVTable;
const char * trainPosition_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != 0 && pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return struct__5664_to_string(pValue);
}

int string_to_trainPosition_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != 0 && pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static trainPosition_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5664(&(*((trainPosition_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5664(strValue, pValue);
}

int is_trainPosition_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5664_allow_double_convertion();
}

int trainPosition_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimtrainPosition_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimtrainPosition_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5664_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5664_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_trainPosition_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static trainPosition_T_TrainPosition_Types_Pck rTemp;
	return string_to_trainPosition_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


/****************************************************************
 ** trainPositionInfo_T_TrainPosition_Types_Pck
 ****************************************************************/
struct SimTypeVTable* pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable;
const char * trainPositionInfo_T_TrainPosition_Types_Pck_to_string(const void* pValue) {
	if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != 0 && pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptString, SptNone) == 1)
		return *(char**)pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnToType(SptString, pValue);
	return struct__5653_to_string(pValue);
}

int string_to_trainPositionInfo_T_TrainPosition_Types_Pck(const char* strValue, void* pValue) {
	if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != 0 && pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptString) == 1) {
		static trainPositionInfo_T_TrainPosition_Types_Pck rTemp;
		int nResult = pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnFromType(SptString, (const void*)&strValue, &rTemp);
		if (nResult == 1)
			kcg_copy_struct__5653(&(*((trainPositionInfo_T_TrainPosition_Types_Pck*)pValue)), &(rTemp));
		return nResult;
	}
	return string_to_struct__5653(strValue, pValue);
}

int is_trainPositionInfo_T_TrainPosition_Types_Pck_allow_double_convertion() {
	if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != 0) {
		int nConvertionAllowed = 0;
		nConvertionAllowed |= pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1;
		nConvertionAllowed |= pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1;
		nConvertionAllowed |= pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1;
		nConvertionAllowed |= pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1;
		return nConvertionAllowed;
	}
	return is_struct__5653_allow_double_convertion();
}

int trainPositionInfo_T_TrainPosition_Types_Pck_to_double(double * nValue, const void* pValue) {
	if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable != 0) {
		if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptLong) == 1)
			*nValue = (double)(*(long*)pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnToType(SptLong, pValue));
		else if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptShort) == 1)
			*nValue = (double)(*(int*)pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnToType(SptShort, pValue));
		else if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptDouble) == 1)
			*nValue = (*(double*)pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnToType(SptDouble, pValue));
		else if (pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnGetConvInfo(SptNone, SptFloat) == 1)
			*nValue = (double)(*(float*)pSimtrainPositionInfo_T_TrainPosition_Types_PckVTable->m_pfnToType(SptFloat, pValue));
		else
			return 0;
		return 1;
	}
	if (_SCSIM_struct__5653_Utils.m_pfnTypeToDouble != 0)
		return _SCSIM_struct__5653_Utils.m_pfnTypeToDouble(nValue, pValue);
	return 0;
}

int check_trainPositionInfo_T_TrainPosition_Types_Pck_string(const char* strValue) {
	static trainPositionInfo_T_TrainPosition_Types_Pck rTemp;
	return string_to_trainPositionInfo_T_TrainPosition_Types_Pck(strValue, &rTemp);
}


