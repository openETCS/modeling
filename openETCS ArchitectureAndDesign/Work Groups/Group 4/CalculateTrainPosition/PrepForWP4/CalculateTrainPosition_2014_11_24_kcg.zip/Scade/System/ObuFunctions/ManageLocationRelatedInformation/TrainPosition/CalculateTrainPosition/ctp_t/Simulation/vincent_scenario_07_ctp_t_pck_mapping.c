#include "vincent_scenario_07_ctp_t_pck_mapping.h"
#include "vincent_scenario_07_ctp_t_pck_interface.h"
#include "kcg_sensors.h"

/****************************************************************
 ** Boolean entity activation
 ****************************************************************/
static ControlUtils _SCSIM_BoolEntity_Control_Utils = {_SCSIM_BoolEntity_is_active};
/****************************************************************
 ** Mapping creation function
 ****************************************************************/
void _SCSIM_Mapping_Create() {
	_SCSIM_Mapping_vincent_scenario_07_ctp_t_pck();
	pSimulator->m_pfnFinalizeMapping(pSimulator);
}

/****************************************************************
 ** ctp_t_pck::vincent_scenario_07/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_vincent_scenario_07_ctp_t_pck() {
	pSimulator->m_pfnSetRoot(pSimulator, "ctp_t_pck::vincent_scenario_07/", &outputs_ctx, _SCSIM_Get_vincent_scenario_07_ctp_t_pck_Handle);
	pSimulator->m_pfnAddLocal(pSimulator, "LRBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1, valid, 0, 0);
	_SCSIM_Mapping_calculateTrainPosition_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::calculateTrainPosition", "1", 2, 0, 0);
	_SCSIM_Mapping_stimulator_ctp_t_pck_t_engine("ctp_t_pck::t_engine::stimulator", "1", 3, 0, 0);
	_SCSIM_Mapping_observeBG_ctp_t_pck_t_engine("ctp_t_pck::t_engine::observeBG", "1", 4, 0, 0);
	_SCSIM_Mapping_observeBG_ctp_t_pck_t_engine("ctp_t_pck::t_engine::observeBG", "2", 5, 0, 0);
	_SCSIM_Mapping_observeBG_ctp_t_pck_t_engine("ctp_t_pck::t_engine::observeBG", "3", 6, 0, 0);
	_SCSIM_Mapping_observeBG_ctp_t_pck_t_engine("ctp_t_pck::t_engine::observeBG", "4", 7, 0, 0);
	_SCSIM_Mapping_observeBG_ctp_t_pck_t_engine("ctp_t_pck::t_engine::observeBG", "5", 8, 0, 0);
	pSimulator->m_pfnAddProbe(pSimulator, "trainPos", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 9, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 10, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 11, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 12, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils, 13, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 14, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 15, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 16, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 17, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 18, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 19, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 20, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 21, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 22, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 23, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 24, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 25, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 26, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 27, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 28, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_int_Utils, 29, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_int_Utils, 30, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 31, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 32, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 33, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L52", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 34, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L53", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 35, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L54", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 36, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L55", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 37, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L59", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 38, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L60", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 39, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L61", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 40, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L62", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 41, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L63", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 42, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L64", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 43, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L65", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 44, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L66", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 45, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 46, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L68", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 47, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L69", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 48, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L70", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 49, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L71", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 50, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L73", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 51, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L74", &_SCSIM_odometryFactors_T_ctp_t_pck_t_engine_Utils, 52, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainPosition", &_SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils, 53, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainPositionInfo", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 54, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 55, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "errors", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 56, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "pos_true", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 57, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "pos_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 58, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "pos_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 59, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "pos_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 60, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_001_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 61, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_001_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 62, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_001_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 63, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_002_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 64, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_002_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 65, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_002_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 66, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_003_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 67, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_003_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 68, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_003_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 69, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_004_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 70, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_004_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 71, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_004_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 72, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_005_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 73, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_005_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 74, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "locBG_005_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 75, valid, 0, 0);
}

void* _SCSIM_Get_vincent_scenario_07_ctp_t_pck_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	switch (nHandleIdent) {
		case 1:
			return &(outputs_ctx.LRBG);
		case 2:
			return &(outputs_ctx._1_Context_1);
		case 3:
			return &(outputs_ctx.Context_1);
		case 4:
			return &(outputs_ctx._2_Context_1);
		case 5:
			return &(outputs_ctx.Context_2);
		case 6:
			return &(outputs_ctx.Context_3);
		case 7:
			return &(outputs_ctx.Context_4);
		case 8:
			return &(outputs_ctx.Context_5);
		case 9:
			return &(outputs_ctx.trainPos);
		case 10:
			return &(outputs_ctx._L5);
		case 11:
			return &(outputs_ctx._L4);
		case 12:
			return &(outputs_ctx._L3);
		case 13:
			return &(outputs_ctx._L2);
		case 14:
			return &(outputs_ctx._L7);
		case 15:
			return &(outputs_ctx._L8);
		case 16:
			return &(outputs_ctx._L9);
		case 17:
			return &(outputs_ctx._L11);
		case 18:
			return &(outputs_ctx._L13);
		case 19:
			return &(outputs_ctx._L14);
		case 20:
			return &(outputs_ctx._L20);
		case 21:
			return &(outputs_ctx._L19);
		case 22:
			return &(outputs_ctx._L18);
		case 23:
			return &(outputs_ctx._L21);
		case 24:
			return &(outputs_ctx._L10);
		case 25:
			return &(outputs_ctx._L1);
		case 26:
			return &(outputs_ctx._L22);
		case 27:
			return &(outputs_ctx._L23);
		case 28:
			return &(outputs_ctx._L24);
		case 29:
			return &(outputs_ctx._L25);
		case 30:
			return &(outputs_ctx._L26);
		case 31:
			return &(outputs_ctx._L31);
		case 32:
			return &(outputs_ctx._L30);
		case 33:
			return &(outputs_ctx._L29);
		case 34:
			return &(outputs_ctx._L52);
		case 35:
			return &(outputs_ctx._L53);
		case 36:
			return &(outputs_ctx._L54);
		case 37:
			return &(outputs_ctx._L55);
		case 38:
			return &(outputs_ctx._L59);
		case 39:
			return &(outputs_ctx._L60);
		case 40:
			return &(outputs_ctx._L61);
		case 41:
			return &(outputs_ctx._L62);
		case 42:
			return &(outputs_ctx._L63);
		case 43:
			return &(outputs_ctx._L64);
		case 44:
			return &(outputs_ctx._L65);
		case 45:
			return &(outputs_ctx._L66);
		case 46:
			return &(outputs_ctx._L67);
		case 47:
			return &(outputs_ctx._L68);
		case 48:
			return &(outputs_ctx._L69);
		case 49:
			return &(outputs_ctx._L70);
		case 50:
			return &(outputs_ctx._L71);
		case 51:
			return &(outputs_ctx._L73);
		case 52:
			return &(outputs_ctx._L74);
		case 53:
			return &(outputs_ctx.trainPosition);
		case 54:
			return &(outputs_ctx.trainPositionInfo);
		case 55:
			return &(outputs_ctx.BGs);
		case 56:
			return &(outputs_ctx.errors);
		case 57:
			return &(outputs_ctx.pos_true);
		case 58:
			return &(outputs_ctx.pos_min);
		case 59:
			return &(outputs_ctx.pos_nom);
		case 60:
			return &(outputs_ctx.pos_max);
		case 61:
			return &(outputs_ctx.locBG_001_min);
		case 62:
			return &(outputs_ctx.locBG_001_nom);
		case 63:
			return &(outputs_ctx.locBG_001_max);
		case 64:
			return &(outputs_ctx.locBG_002_min);
		case 65:
			return &(outputs_ctx.locBG_002_nom);
		case 66:
			return &(outputs_ctx.locBG_002_max);
		case 67:
			return &(outputs_ctx.locBG_003_min);
		case 68:
			return &(outputs_ctx.locBG_003_nom);
		case 69:
			return &(outputs_ctx.locBG_003_max);
		case 70:
			return &(outputs_ctx.locBG_004_min);
		case 71:
			return &(outputs_ctx.locBG_004_nom);
		case 72:
			return &(outputs_ctx.locBG_004_max);
		case 73:
			return &(outputs_ctx.locBG_005_min);
		case 74:
			return &(outputs_ctx.locBG_005_nom);
		case 75:
			return &(outputs_ctx.locBG_005_max);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::calculateTrainPosition/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_calculateTrainPosition_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_calculateTrainPosition_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "BGs_loc", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 76, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L199", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 77, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L198", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 78, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L233", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 79, valid, 0, 0);
	_SCSIM_Mapping_calculateBGLocations_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::calculateBGLocations", "1", 80, 81, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::calculateTrainpositionAttributes", "1", 82, 0, 0);
	_SCSIM_Mapping_calculateTrainPositionInfo_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::calculateTrainPositionInfo", "1", 83, 0, 0);
	_SCSIM_Mapping_delDispensableBGs_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::delDispensableBGs", "1", 84, 85, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L200", &_SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils, 86, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L201", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 87, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L202", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 88, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L203", &_SCSIM_kcg_bool_Utils, 89, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L204", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 90, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L205", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 91, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L207", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 92, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L210", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 93, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L216", &_SCSIM_kcg_bool_Utils, 94, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L215", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 95, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L217", &_SCSIM_kcg_bool_Utils, 96, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L228", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 97, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L227", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 98, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L229", &_SCSIM_kcg_bool_Utils, 99, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L230", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 100, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L231", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 101, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L232", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 102, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L234", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 103, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 81, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 85, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainPosition", &_SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils, 104, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainPositionInfo", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 105, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 106, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "errors", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 107, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_calculateTrainPosition_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_calculateTrainPosition_CalculateTrainPosition_Pkg* pContext = (outC_calculateTrainPosition_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 76:
			return &((*pContext).BGs_loc);
		case 77:
			return &((*pContext)._L199);
		case 78:
			return &((*pContext)._L198);
		case 79:
			return &((*pContext)._L233);
		case 80:
			return &((*pContext).Context_1);
		case 82:
			return &((*pContext)._3_Context_1);
		case 83:
			return &((*pContext)._2_Context_1);
		case 84:
			return &((*pContext)._1_Context_1);
		case 86:
			return &((*pContext)._L200);
		case 87:
			return &((*pContext)._L201);
		case 88:
			return &((*pContext)._L202);
		case 89:
			return &((*pContext)._L203);
		case 90:
			return &((*pContext)._L204);
		case 91:
			return &((*pContext)._L205);
		case 92:
			return &((*pContext)._L207);
		case 93:
			return &((*pContext)._L210);
		case 94:
			return &((*pContext)._L216);
		case 95:
			return &((*pContext)._L215);
		case 96:
			return &((*pContext)._L217);
		case 97:
			return &((*pContext)._L228);
		case 98:
			return &((*pContext)._L227);
		case 99:
			return &((*pContext)._L229);
		case 100:
			return &((*pContext)._L230);
		case 101:
			return &((*pContext)._L231);
		case 102:
			return &((*pContext)._L232);
		case 103:
			return &((*pContext)._L234);
		case 81:
			return &((*pContext).tmp4);
		case 85:
			return &((*pContext).tmp);
		case 104:
			return &((*pContext).trainPosition);
		case 105:
			return &((*pContext).trainPositionInfo);
		case 106:
			return &((*pContext).BGs);
		case 107:
			return &((*pContext).errors);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** ctp_t_pck::t_engine::stimulator/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_stimulator_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_stimulator_ctp_t_pck_t_engine_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_genLocation_ctp_t_pck_t_engine("ctp_t_pck::t_engine::genLocation", "1", 108, 0, 0);
	_SCSIM_Mapping_genOdometry_ctp_t_pck_t_engine("ctp_t_pck::t_engine::genOdometry", "1", 109, 0, 0);
	_SCSIM_Mapping_genPassedBG_ctp_t_pck_t_engine("ctp_t_pck::t_engine::genPassedBG", "1", 110, 0, 0);
	pSimulator->m_pfnAddProbe(pSimulator, "truePosition", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 111, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 112, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 113, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 114, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 115, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 116, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 117, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 118, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 119, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 120, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_odometryFactors_T_ctp_t_pck_t_engine_Utils, 121, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 122, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "pos_true", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 123, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "odometry", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 124, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "passedBG", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 125, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_stimulator_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_stimulator_ctp_t_pck_t_engine* pContext = (outC_stimulator_ctp_t_pck_t_engine*)pInstance;
	switch (nHandleIdent) {
		case 108:
			return &((*pContext).Context_1);
		case 109:
			return &((*pContext)._1_Context_1);
		case 110:
			return &((*pContext)._2_Context_1);
		case 111:
			return &((*pContext).truePosition);
		case 112:
			return &((*pContext)._L2);
		case 113:
			return &((*pContext)._L1);
		case 114:
			return &((*pContext)._L3);
		case 115:
			return &((*pContext)._L4);
		case 116:
			return &((*pContext)._L5);
		case 117:
			return &((*pContext)._L6);
		case 118:
			return &((*pContext)._L7);
		case 119:
			return &((*pContext)._L8);
		case 120:
			return &((*pContext)._L9);
		case 121:
			return &((*pContext)._L10);
		case 122:
			return &((*pContext)._L11);
		case 123:
			return &((*pContext).pos_true);
		case 124:
			return &((*pContext).odometry);
		case 125:
			return &((*pContext).passedBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** ctp_t_pck::t_engine::observeBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_observeBG_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_observeBG_ctp_t_pck_t_engine_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id", "1", 126, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "1", 127, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 128, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 129, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 130, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 131, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 132, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 133, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 134, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 135, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 136, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 137, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 138, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 139, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 140, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 141, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 142, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_int_Utils, 143, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 144, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 145, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_kcg_int_Utils, 146, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_kcg_int_Utils, 147, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "loc_min", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 148, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "loc_nom", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 149, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "loc_max", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 150, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_observeBG_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_observeBG_ctp_t_pck_t_engine* pContext = (outC_observeBG_ctp_t_pck_t_engine*)pInstance;
	switch (nHandleIdent) {
		case 126:
			return &((*pContext).Context_1);
		case 127:
			return &((*pContext)._1_Context_1);
		case 128:
			return &((*pContext)._L1);
		case 129:
			return &((*pContext)._L2);
		case 130:
			return &((*pContext)._L9);
		case 131:
			return &((*pContext)._L8);
		case 132:
			return &((*pContext)._L7);
		case 133:
			return &((*pContext)._L10);
		case 134:
			return &((*pContext)._L11);
		case 135:
			return &((*pContext)._L13);
		case 136:
			return &((*pContext)._L14);
		case 137:
			return &((*pContext)._L16);
		case 138:
			return &((*pContext)._L22);
		case 139:
			return &((*pContext)._L21);
		case 140:
			return &((*pContext)._L20);
		case 141:
			return &((*pContext)._L23);
		case 142:
			return &((*pContext)._L24);
		case 143:
			return &((*pContext)._L25);
		case 144:
			return &((*pContext)._L26);
		case 145:
			return &((*pContext)._L27);
		case 146:
			return &((*pContext)._L28);
		case 147:
			return &((*pContext)._L29);
		case 148:
			return &((*pContext).loc_min);
		case 149:
			return &((*pContext).loc_nom);
		case 150:
			return &((*pContext).loc_max);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::calculateBGLocations/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_calculateBGLocations_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_calculateBGLocations_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_passing_a_BG_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::passing_a_BG", "1", 151, 0, 0);
	_SCSIM_Mapping_prevPassedLinkedBG_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::prevPassedLinkedBG", "1", 152, 0, 0);
	_SCSIM_Mapping_genPassedBG_SeqNo_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::genPassedBG_SeqNo", "2", 153, 0, 0);
	_SCSIM_Mapping_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::improve_BG_locations", "1", 154, 155, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "outOfMemSpace", &_SCSIM_kcg_bool_Utils, 156, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "passedBG_notFoundWhereExpected", &_SCSIM_kcg_bool_Utils, 157, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L92", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 158, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L87", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 159, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L88", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 160, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L89", &_SCSIM_kcg_bool_Utils, 161, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L90", &_SCSIM_kcg_bool_Utils, 162, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L137", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 163, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L156", &_SCSIM_kcg_bool_Utils, 164, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L157", &_SCSIM_kcg_bool_Utils, 165, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L225", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 166, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L301", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 167, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L298", &_SCSIM_kcg_int_Utils, 168, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L324", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 169, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L346", &_SCSIM_kcg_bool_Utils, 170, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L347", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 171, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L349", &_SCSIM_kcg_bool_Utils, 172, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L351", &_SCSIM_kcg_bool_Utils, 173, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L352", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 174, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L353", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 175, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L299", &_SCSIM_kcg_bool_Utils, 176, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L354", &_SCSIM_kcg_bool_Utils, 177, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L355", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 178, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L356", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 179, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L359", &_SCSIM_Q_LINK_Utils, 180, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L358", &_SCSIM_kcg_bool_Utils, 181, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L357", &_SCSIM_Q_LINK_Utils, 182, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L360", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 183, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L361", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 184, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L362", &_SCSIM_kcg_bool_Utils, 185, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 155, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 186, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "errors", &_SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils, 187, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_calculateBGLocations_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_calculateBGLocations_CalculateTrainPosition_Pkg* pContext = (outC_calculateBGLocations_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 151:
			return &((*pContext)._1_Context_1);
		case 152:
			return &((*pContext).Context_1);
		case 153:
			return &((*pContext).Context_2);
		case 154:
			return &((*pContext)._2_Context_1);
		case 156:
			return &((*pContext).outOfMemSpace);
		case 157:
			return &((*pContext).passedBG_notFoundWhereExpected);
		case 158:
			return &((*pContext)._L92);
		case 159:
			return &((*pContext)._L87);
		case 160:
			return &((*pContext)._L88);
		case 161:
			return &((*pContext)._L89);
		case 162:
			return &((*pContext)._L90);
		case 163:
			return &((*pContext)._L137);
		case 164:
			return &((*pContext)._L156);
		case 165:
			return &((*pContext)._L157);
		case 166:
			return &((*pContext)._L225);
		case 167:
			return &((*pContext)._L301);
		case 168:
			return &((*pContext)._L298);
		case 169:
			return &((*pContext)._L324);
		case 170:
			return &((*pContext)._L346);
		case 171:
			return &((*pContext)._L347);
		case 172:
			return &((*pContext)._L349);
		case 173:
			return &((*pContext)._L351);
		case 174:
			return &((*pContext)._L352);
		case 175:
			return &((*pContext)._L353);
		case 176:
			return &((*pContext)._L299);
		case 177:
			return &((*pContext)._L354);
		case 178:
			return &((*pContext)._L355);
		case 179:
			return &((*pContext)._L356);
		case 180:
			return &((*pContext)._L359);
		case 181:
			return &((*pContext)._L358);
		case 182:
			return &((*pContext)._L357);
		case 183:
			return &((*pContext)._L360);
		case 184:
			return &((*pContext)._L361);
		case 185:
			return &((*pContext)._L362);
		case 155:
			return &((*pContext).tmp);
		case 186:
			return &((*pContext).BGs);
		case 187:
			return &((*pContext).errors);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::calculateTrainpositionAttributes/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "1", 188, 0, 0);
	_SCSIM_Mapping_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG", "", 189, 0, 0);
	_SCSIM_Mapping_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG", "1", 190, 0, 0);
	_SCSIM_Mapping_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg("CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef", "1", 191, 0, 0);
	_SCSIM_Mapping_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg("CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG", "1", 192, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L205", &_SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils, 193, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L218", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 194, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L219", &_SCSIM_kcg_bool_Utils, 195, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L220", &_SCSIM_kcg_bool_Utils, 196, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L221", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 197, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L223", &_SCSIM_kcg_bool_Utils, 198, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L224", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 199, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L225", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 200, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L227", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 201, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L229", &_SCSIM_NID_BG_Utils, 202, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L230", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 203, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L234", &_SCSIM_kcg_bool_Utils, 204, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L237", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 205, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L242", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 206, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L243", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 207, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L249", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 208, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L248", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 209, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L247", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 210, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L260", &_SCSIM_NID_LRBG_Utils, 211, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L261", &_SCSIM_kcg_bool_Utils, 212, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L262", &_SCSIM_NID_C_Utils, 213, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L263", &_SCSIM_NID_BG_Utils, 214, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L264", &_SCSIM_NID_LRBG_Utils, 215, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L265", &_SCSIM_NID_C_Utils, 216, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L266", &_SCSIM_kcg_bool_Utils, 217, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L267", &_SCSIM_kcg_bool_Utils, 218, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L268", &_SCSIM_NID_LRBG_Utils, 219, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L269", &_SCSIM_kcg_bool_Utils, 220, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L270", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 221, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L274", &_SCSIM_Q_DIRLRBG_Utils, 222, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L275", &_SCSIM_Q_DIRTRAIN_Utils, 223, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L276", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 224, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L301", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 225, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L302", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 226, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L303", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 227, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L304", &_SCSIM_Q_DIRTRAIN_Utils, 228, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L305", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 229, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L306", &_SCSIM_Q_DLRBG_Utils, 230, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L307", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 231, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L308", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 232, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L309", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 233, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L310", &_SCSIM_kcg_bool_Utils, 234, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L311", &_SCSIM_Q_DIRLRBG_Utils, 235, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L312", &_SCSIM_Q_DIRLRBG_Utils, 236, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L313", &_SCSIM_Q_DIRTRAIN_Utils, 237, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L314", &_SCSIM_Q_DIRTRAIN_Utils, 238, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L315", &_SCSIM_kcg_int_Utils, 239, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L316", &_SCSIM_kcg_int_Utils, 240, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainPosition", &_SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils, 241, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg* pContext = (outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 188:
			return &((*pContext).Context_1);
		case 189:
			return &((*pContext).Context_nidC_nidBG_2_NIDLRBG);
		case 190:
			return &((*pContext)._3_Context_1);
		case 191:
			return &((*pContext)._2_Context_1);
		case 192:
			return &((*pContext)._1_Context_1);
		case 193:
			return &((*pContext)._L205);
		case 194:
			return &((*pContext)._L218);
		case 195:
			return &((*pContext)._L219);
		case 196:
			return &((*pContext)._L220);
		case 197:
			return &((*pContext)._L221);
		case 198:
			return &((*pContext)._L223);
		case 199:
			return &((*pContext)._L224);
		case 200:
			return &((*pContext)._L225);
		case 201:
			return &((*pContext)._L227);
		case 202:
			return &((*pContext)._L229);
		case 203:
			return &((*pContext)._L230);
		case 204:
			return &((*pContext)._L234);
		case 205:
			return &((*pContext)._L237);
		case 206:
			return &((*pContext)._L242);
		case 207:
			return &((*pContext)._L243);
		case 208:
			return &((*pContext)._L249);
		case 209:
			return &((*pContext)._L248);
		case 210:
			return &((*pContext)._L247);
		case 211:
			return &((*pContext)._L260);
		case 212:
			return &((*pContext)._L261);
		case 213:
			return &((*pContext)._L262);
		case 214:
			return &((*pContext)._L263);
		case 215:
			return &((*pContext)._L264);
		case 216:
			return &((*pContext)._L265);
		case 217:
			return &((*pContext)._L266);
		case 218:
			return &((*pContext)._L267);
		case 219:
			return &((*pContext)._L268);
		case 220:
			return &((*pContext)._L269);
		case 221:
			return &((*pContext)._L270);
		case 222:
			return &((*pContext)._L274);
		case 223:
			return &((*pContext)._L275);
		case 224:
			return &((*pContext)._L276);
		case 225:
			return &((*pContext)._L301);
		case 226:
			return &((*pContext)._L302);
		case 227:
			return &((*pContext)._L303);
		case 228:
			return &((*pContext)._L304);
		case 229:
			return &((*pContext)._L305);
		case 230:
			return &((*pContext)._L306);
		case 231:
			return &((*pContext)._L307);
		case 232:
			return &((*pContext)._L308);
		case 233:
			return &((*pContext)._L309);
		case 234:
			return &((*pContext)._L310);
		case 235:
			return &((*pContext)._L311);
		case 236:
			return &((*pContext)._L312);
		case 237:
			return &((*pContext)._L313);
		case 238:
			return &((*pContext)._L314);
		case 239:
			return &((*pContext)._L315);
		case 240:
			return &((*pContext)._L316);
		case 241:
			return &((*pContext).trainPosition);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::calculateTrainPositionInfo/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_calculateTrainPositionInfo_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_calculateTrainPositionInfo_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 242, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 243, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 244, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 245, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_bool_Utils, 246, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_bool_Utils, 247, valid, 0, 0);
	_SCSIM_Mapping_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG", "1", 248, 0, 0);
	_SCSIM_Mapping_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG", "2", 249, 0, 0);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "1", 250, 0, 0);
	_SCSIM_Mapping_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG", "1", 251, 252, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG", "2", 253, 254, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 255, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 256, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 257, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 258, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 259, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 260, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 261, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 262, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 263, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 264, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 265, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 266, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_bool_Utils, 267, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_bool_Utils, 268, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 269, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 270, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 271, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_kcg_bool_Utils, 272, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_kcg_bool_Utils, 273, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L34", &_SCSIM_kcg_int_Utils, 274, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L35", &_SCSIM_kcg_bool_Utils, 275, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L37", &_SCSIM_kcg_int_Utils, 276, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L36", &_SCSIM_kcg_bool_Utils, 277, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 252, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 254, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainPositionInfo", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 278, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "positionCalculationNotConsistent", &_SCSIM_kcg_bool_Utils, 279, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_calculateTrainPositionInfo_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg* pContext = (outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 242:
			return &((*pContext)._L17);
		case 243:
			return &((*pContext)._L18);
		case 244:
			return &((*pContext)._L19);
		case 245:
			return &((*pContext)._L23);
		case 246:
			return &((*pContext)._L24);
		case 247:
			return &((*pContext)._L25);
		case 248:
			return &((*pContext)._1_Context_1);
		case 249:
			return &((*pContext)._2_Context_2);
		case 250:
			return &((*pContext)._3_Context_1);
		case 251:
			return &((*pContext).Context_1);
		case 253:
			return &((*pContext).Context_2);
		case 255:
			return &((*pContext)._L1);
		case 256:
			return &((*pContext)._L7);
		case 257:
			return &((*pContext)._L8);
		case 258:
			return &((*pContext)._L9);
		case 259:
			return &((*pContext)._L10);
		case 260:
			return &((*pContext)._L11);
		case 261:
			return &((*pContext)._L12);
		case 262:
			return &((*pContext)._L13);
		case 263:
			return &((*pContext)._L14);
		case 264:
			return &((*pContext)._L15);
		case 265:
			return &((*pContext)._L20);
		case 266:
			return &((*pContext)._L22);
		case 267:
			return &((*pContext)._L26);
		case 268:
			return &((*pContext)._L27);
		case 269:
			return &((*pContext)._L28);
		case 270:
			return &((*pContext)._L30);
		case 271:
			return &((*pContext)._L31);
		case 272:
			return &((*pContext)._L32);
		case 273:
			return &((*pContext)._L33);
		case 274:
			return &((*pContext)._L34);
		case 275:
			return &((*pContext)._L35);
		case 276:
			return &((*pContext)._L37);
		case 277:
			return &((*pContext)._L36);
		case 252:
			return &((*pContext).tmp4);
		case 254:
			return &((*pContext).tmp);
		case 278:
			return &((*pContext).trainPositionInfo);
		case 279:
			return &((*pContext).positionCalculationNotConsistent);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::delDispensableBGs/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_delDispensableBGs_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_delDispensableBGs_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs", "1", 280, 0, 0);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock1");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_281_Utils, 281);
	_SCSIM_Mapping_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG", "9", 282, 281, &_SCSIM_ClockActive_kcg_false);
	_SCSIM_Mapping_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex", "9", 283, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L60", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 284, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L59", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 285, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L58", &_SCSIM_kcg_bool_Utils, 286, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L57", &_SCSIM_kcg_bool_Utils, 287, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L56", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 288, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L54", &_SCSIM_kcg_int_Utils, 289, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L55", &_SCSIM_kcg_bool_Utils, 290, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L53", &_SCSIM_kcg_bool_Utils, 291, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L52", &_SCSIM_kcg_bool_Utils, 292, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L51", &_SCSIM_kcg_int_Utils, 293, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L49", &_SCSIM_kcg_int_Utils, 294, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L47", &_SCSIM_kcg_int_Utils, 295, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L61", &_SCSIM_kcg_int_Utils, 296, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L62", &_SCSIM_kcg_int_Utils, 297, valid, 281, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_298_Utils, 298);
	_SCSIM_Mapping_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG", "2", 299, 298, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex", "2", 300, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 301, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_int_Utils, 302, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 303, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 304, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 305, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_bool_Utils, 306, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 307, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 308, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 309, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 310, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 311, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 312, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 313, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 314, valid, 298, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "passedLinkedBGsCount", &_SCSIM_kcg_int_Utils, 315, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "passedUnlinkedBGsCount", &_SCSIM_kcg_int_Utils, 316, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 317, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 318, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_bool_Utils, 319, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 320, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 321, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 322, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 323, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 324, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_delDispensableBGs_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_delDispensableBGs_CalculateTrainPosition_Pkg* pContext = (outC_delDispensableBGs_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 280:
			return &((*pContext).Context_1);
		case 281:
			return &((*pContext).IfBlock1_clock);
		case 282:
			return &((*pContext).Context_9);
		case 283:
			return &((*pContext)._2_Context_9);
		case 284:
			return &((*pContext)._L60_IfBlock1);
		case 285:
			return &((*pContext)._L59_IfBlock1);
		case 286:
			return &((*pContext)._L58_IfBlock1);
		case 287:
			return &((*pContext)._L57_IfBlock1);
		case 288:
			return &((*pContext)._L56_IfBlock1);
		case 289:
			return &((*pContext)._L54_IfBlock1);
		case 290:
			return &((*pContext)._L55_IfBlock1);
		case 291:
			return &((*pContext)._L53_IfBlock1);
		case 292:
			return &((*pContext)._L52_IfBlock1);
		case 293:
			return &((*pContext)._L51_IfBlock1);
		case 294:
			return &((*pContext)._L49_IfBlock1);
		case 295:
			return &((*pContext)._L47_IfBlock1);
		case 296:
			return &((*pContext)._L61_IfBlock1);
		case 297:
			return &((*pContext)._L62_IfBlock1);
		case 298:
			return &((*pContext).IfBlock1_clock);
		case 299:
			return &((*pContext).Context_2);
		case 300:
			return &((*pContext)._1_Context_2);
		case 301:
			return &((*pContext)._L1_IfBlock1);
		case 302:
			return &((*pContext)._L2_IfBlock1);
		case 303:
			return &((*pContext)._L3_IfBlock1);
		case 304:
			return &((*pContext)._L4_IfBlock1);
		case 305:
			return &((*pContext)._L5_IfBlock1);
		case 306:
			return &((*pContext)._L7_IfBlock1);
		case 307:
			return &((*pContext)._L6_IfBlock1);
		case 308:
			return &((*pContext)._L8_IfBlock1);
		case 309:
			return &((*pContext)._L9_IfBlock1);
		case 310:
			return &((*pContext)._L10_IfBlock1);
		case 311:
			return &((*pContext)._L11_IfBlock1);
		case 312:
			return &((*pContext)._L12_IfBlock1);
		case 313:
			return &((*pContext)._L13_IfBlock1);
		case 314:
			return &((*pContext)._L14_IfBlock1);
		case 315:
			return &((*pContext).passedLinkedBGsCount);
		case 316:
			return &((*pContext).passedUnlinkedBGsCount);
		case 317:
			return &((*pContext)._L3);
		case 318:
			return &((*pContext)._L2);
		case 319:
			return &((*pContext)._L1);
		case 320:
			return &((*pContext)._L8);
		case 321:
			return &((*pContext)._L11);
		case 322:
			return &((*pContext)._L15);
		case 323:
			return &((*pContext)._L16);
		case 324:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

static int Is281Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_281_Utils = {Is281Active};

static int Is298Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_298_Utils = {Is298Active};

/****************************************************************
 ** ctp_t_pck::t_engine::genLocation/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_genLocation_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_genLocation_ctp_t_pck_t_engine_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "location_loc", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 325, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 326, valid, 0, 0);
	/*<< Inlined math::InRangeInIn*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::InRangeInIn", "1", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "IRII_Output", &_SCSIM_kcg_bool_Utils, 327, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "IRII_Input", &_SCSIM_kcg_int_Utils, 328, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "A", &_SCSIM_kcg_int_Utils, 329, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "B", &_SCSIM_kcg_int_Utils, 330, valid, 0, 0);
	pSimulator->m_pfnAddAssume(pSimulator, "A1", &_SCSIM_BoolEntity_Control_Utils, 331, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 333, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 334, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 335, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 336, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 337, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 338, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	/*<< Inlined math::InRangeInIn*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::InRangeInIn", "2", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "IRII_Output", &_SCSIM_kcg_bool_Utils, 339, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "IRII_Input", &_SCSIM_kcg_int_Utils, 340, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "A", &_SCSIM_kcg_int_Utils, 341, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "B", &_SCSIM_kcg_int_Utils, 342, valid, 0, 0);
	pSimulator->m_pfnAddAssume(pSimulator, "A1", &_SCSIM_BoolEntity_Control_Utils, 343, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 345, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 346, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 347, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 348, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 349, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 350, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	/*<< Inlined math::InRangeInIn*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::InRangeInIn", "3", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "IRII_Output", &_SCSIM_kcg_bool_Utils, 351, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "IRII_Input", &_SCSIM_kcg_int_Utils, 352, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "A", &_SCSIM_kcg_int_Utils, 353, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "B", &_SCSIM_kcg_int_Utils, 354, valid, 0, 0);
	pSimulator->m_pfnAddAssume(pSimulator, "A1", &_SCSIM_BoolEntity_Control_Utils, 355, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 357, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 358, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 359, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 360, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 361, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 362, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	/*<< Inlined math::InRangeInIn*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::InRangeInIn", "4", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "IRII_Output", &_SCSIM_kcg_bool_Utils, 363, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "IRII_Input", &_SCSIM_kcg_int_Utils, 364, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "A", &_SCSIM_kcg_int_Utils, 365, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "B", &_SCSIM_kcg_int_Utils, 366, valid, 0, 0);
	pSimulator->m_pfnAddAssume(pSimulator, "A1", &_SCSIM_BoolEntity_Control_Utils, 367, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 369, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 370, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 371, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 372, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 373, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 374, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	pSimulator->m_pfnAddLocal(pSimulator, "incr", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 375, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_int_Utils, 376, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 377, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_bool_Utils, 378, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 379, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_bool_Utils, 380, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 381, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 382, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 383, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_int_Utils, 384, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_int_Utils, 385, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 386, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_int_Utils, 387, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 388, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 389, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_bool_Utils, 390, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 391, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 392, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 393, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 394, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 395, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "location", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 396, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "time", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 397, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_genLocation_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_genLocation_ctp_t_pck_t_engine* pContext = (outC_genLocation_ctp_t_pck_t_engine*)pInstance;
	switch (nHandleIdent) {
		case 325:
			return &((*pContext).location_loc);
		case 326:
			return &((*pContext)._L1);
		case 327:
			return &((*pContext).IRII_Output_1);
		case 328:
			return &((*pContext).IRII_Input_1);
		case 329:
			return &((*pContext).A_1);
		case 330:
			return &((*pContext).B_1);
		case 331:
			return &((*pContext).A1_1);
		case 333:
			return &((*pContext)._L10_1);
		case 334:
			return &((*pContext)._L12_1);
		case 335:
			return &((*pContext)._L13_1);
		case 336:
			return &((*pContext)._L2_1);
		case 337:
			return &((*pContext)._L4_1);
		case 338:
			return &((*pContext)._L8_1);
		case 339:
			return &((*pContext).IRII_Output_2);
		case 340:
			return &((*pContext).IRII_Input_2);
		case 341:
			return &((*pContext).A_2);
		case 342:
			return &((*pContext).B_2);
		case 343:
			return &((*pContext).A1_2);
		case 345:
			return &((*pContext)._L10_2);
		case 346:
			return &((*pContext)._L12_2);
		case 347:
			return &((*pContext)._L13_2);
		case 348:
			return &((*pContext)._L2_2);
		case 349:
			return &((*pContext)._L4_2);
		case 350:
			return &((*pContext)._L8_2);
		case 351:
			return &((*pContext).IRII_Output_3);
		case 352:
			return &((*pContext).IRII_Input_3);
		case 353:
			return &((*pContext).A_3);
		case 354:
			return &((*pContext).B_3);
		case 355:
			return &((*pContext).A1_3);
		case 357:
			return &((*pContext)._L10_3);
		case 358:
			return &((*pContext)._L12_3);
		case 359:
			return &((*pContext)._L13_3);
		case 360:
			return &((*pContext)._L2_3);
		case 361:
			return &((*pContext)._L4_3);
		case 362:
			return &((*pContext)._L8_3);
		case 363:
			return &((*pContext).IRII_Output_4);
		case 364:
			return &((*pContext).IRII_Input_4);
		case 365:
			return &((*pContext).A_4);
		case 366:
			return &((*pContext).B_4);
		case 367:
			return &((*pContext).A1_4);
		case 369:
			return &((*pContext)._L10_4);
		case 370:
			return &((*pContext)._L12_4);
		case 371:
			return &((*pContext)._L13_4);
		case 372:
			return &((*pContext)._L2_4);
		case 373:
			return &((*pContext)._L4_4);
		case 374:
			return &((*pContext)._L8_4);
		case 375:
			return &((*pContext).incr);
		case 376:
			return &((*pContext)._L2);
		case 377:
			return &((*pContext)._L4);
		case 378:
			return &((*pContext)._L5);
		case 379:
			return &((*pContext)._L6);
		case 380:
			return &((*pContext)._L7);
		case 381:
			return &((*pContext)._L8);
		case 382:
			return &((*pContext)._L9);
		case 383:
			return &((*pContext)._L10);
		case 384:
			return &((*pContext)._L11);
		case 385:
			return &((*pContext)._L12);
		case 386:
			return &((*pContext)._L13);
		case 387:
			return &((*pContext)._L14);
		case 388:
			return &((*pContext)._L15);
		case 389:
			return &((*pContext)._L16);
		case 390:
			return &((*pContext)._L17);
		case 391:
			return &((*pContext)._L19);
		case 392:
			return &((*pContext)._L20);
		case 393:
			return &((*pContext)._L21);
		case 394:
			return &((*pContext)._L22);
		case 395:
			return &((*pContext)._L23);
		case 396:
			return &((*pContext).location);
		case 397:
			return &((*pContext).time);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** ctp_t_pck::t_engine::genOdometry/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_genOdometry_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_genOdometry_ctp_t_pck_t_engine_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 398, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 399, valid, 0, 0);
	/*<< Inlined math::Max*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::Max", "1", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "Ma_Output", &_SCSIM_kcg_int_Utils, 400, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "I1", &_SCSIM_kcg_int_Utils, 401, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "I2", &_SCSIM_kcg_int_Utils, 402, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 403, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_int_Utils, 404, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 405, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 406, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 407, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 408, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 409, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 410, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 411, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_real_Utils, 412, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_real_Utils, 413, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_real_Utils, 414, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_real_Utils, 415, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 416, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_int_Utils, 417, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_real_Utils, 418, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_real_Utils, 419, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_real_Utils, 420, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 421, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 422, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_int_Utils, 423, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_int_Utils, 424, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_kcg_int_Utils, 425, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 426, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_kcg_int_Utils, 427, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_kcg_int_Utils, 428, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_kcg_int_Utils, 429, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_odometryFactors_T_ctp_t_pck_t_engine_Utils, 430, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "odometry", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 431, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_genOdometry_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_genOdometry_ctp_t_pck_t_engine* pContext = (outC_genOdometry_ctp_t_pck_t_engine*)pInstance;
	switch (nHandleIdent) {
		case 398:
			return &((*pContext)._L17);
		case 399:
			return &((*pContext)._L27);
		case 400:
			return &((*pContext).Ma_Output_1);
		case 401:
			return &((*pContext).I1_1);
		case 402:
			return &((*pContext).I2_1);
		case 403:
			return &((*pContext)._L1_1);
		case 404:
			return &((*pContext)._L2_1);
		case 405:
			return &((*pContext)._L3_1);
		case 406:
			return &((*pContext)._L4_1);
		case 407:
			return &((*pContext)._L1);
		case 408:
			return &((*pContext)._L2);
		case 409:
			return &((*pContext)._L3);
		case 410:
			return &((*pContext)._L4);
		case 411:
			return &((*pContext)._L8);
		case 412:
			return &((*pContext)._L15);
		case 413:
			return &((*pContext)._L14);
		case 414:
			return &((*pContext)._L13);
		case 415:
			return &((*pContext)._L16);
		case 416:
			return &((*pContext)._L18);
		case 417:
			return &((*pContext)._L19);
		case 418:
			return &((*pContext)._L20);
		case 419:
			return &((*pContext)._L21);
		case 420:
			return &((*pContext)._L22);
		case 421:
			return &((*pContext)._L23);
		case 422:
			return &((*pContext)._L24);
		case 423:
			return &((*pContext)._L25);
		case 424:
			return &((*pContext)._L26);
		case 425:
			return &((*pContext)._L28);
		case 426:
			return &((*pContext)._L29);
		case 427:
			return &((*pContext)._L30);
		case 428:
			return &((*pContext)._L31);
		case 429:
			return &((*pContext)._L32);
		case 430:
			return &((*pContext)._L33);
		case 431:
			return &((*pContext).odometry);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** ctp_t_pck::t_engine::genPassedBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_genPassedBG_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_genPassedBG_ctp_t_pck_t_engine_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "foldw", 10, 10);
	_SCSIM_Mapping_genPassedBG_itr_ctp_t_pck_t_engine("ctp_t_pck::t_engine::genPassedBG_itr", "1", 432, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 433, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils, 434, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 435, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 436, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 437, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_array_int_10_Utils, 438, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 439, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 440, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 441, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 442, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 443, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 444, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "passedBG", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 445, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_genPassedBG_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_genPassedBG_ctp_t_pck_t_engine* pContext = (outC_genPassedBG_ctp_t_pck_t_engine*)pInstance;
	switch (nHandleIdent) {
		case 432:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 433:
			return &((*pContext)._L1);
		case 434:
			return &((*pContext)._L2);
		case 435:
			return &((*pContext)._L3);
		case 436:
			return &((*pContext)._L5);
		case 437:
			return &((*pContext)._L6);
		case 438:
			return &((*pContext)._L7);
		case 439:
			return &((*pContext)._L8);
		case 440:
			return &((*pContext)._L9);
		case 441:
			return &((*pContext)._L10);
		case 442:
			return &((*pContext)._L11);
		case 443:
			return &((*pContext)._L12);
		case 444:
			return &((*pContext)._L13);
		case 445:
			return &((*pContext).passedBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id", "1", 446, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 447, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 448, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 449, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 450, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 451, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 452, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_LinkedBGs_T_BG_Types_Pkg_Utils, 453, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_BG_Header_T_BG_Types_Pkg_Utils, 454, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 455, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 456, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 457, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 458, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 459, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 460, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_NID_C_Utils, 461, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_NID_BG_Utils, 462, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_Q_LINK_Utils, 463, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 464, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L69", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 465, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L68", &_SCSIM_Q_DIRTRAIN_Utils, 466, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_Q_DIRLRBG_Utils, 467, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L66", &_SCSIM_kcg_bool_Utils, 468, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L86", &_SCSIM_kcg_int_Utils, 469, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 470, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_found", &_SCSIM_kcg_bool_Utils, 471, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexValid", &_SCSIM_kcg_bool_Utils, 472, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 446:
			return &((*pContext).Context_1);
		case 447:
			return &((*pContext)._L3);
		case 448:
			return &((*pContext)._L2);
		case 449:
			return &((*pContext)._L1);
		case 450:
			return &((*pContext)._L4);
		case 451:
			return &((*pContext)._L5);
		case 452:
			return &((*pContext)._L6);
		case 453:
			return &((*pContext)._L18);
		case 454:
			return &((*pContext)._L17);
		case 455:
			return &((*pContext)._L16);
		case 456:
			return &((*pContext)._L15);
		case 457:
			return &((*pContext)._L14);
		case 458:
			return &((*pContext)._L13);
		case 459:
			return &((*pContext)._L19);
		case 460:
			return &((*pContext)._L20);
		case 461:
			return &((*pContext)._L21);
		case 462:
			return &((*pContext)._L22);
		case 463:
			return &((*pContext)._L23);
		case 464:
			return &((*pContext)._L25);
		case 465:
			return &((*pContext)._L69);
		case 466:
			return &((*pContext)._L68);
		case 467:
			return &((*pContext)._L67);
		case 468:
			return &((*pContext)._L66);
		case 469:
			return &((*pContext)._L86);
		case 470:
			return &((*pContext).indexOfBG);
		case 471:
			return &((*pContext).BG_found);
		case 472:
			return &((*pContext).indexValid);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** BasicLocationFunctions_Pkg::sub_2_distances/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_sub_2_distances_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 473, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 474, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 475, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 476, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 477, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 478, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 479, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 480, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 481, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 482, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 483, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 484, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 485, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 486, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 487, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 488, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "distance", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 489, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_sub_2_distances_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_sub_2_distances_BasicLocationFunctions_Pkg* pContext = (outC_sub_2_distances_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 473:
			return &((*pContext)._L1);
		case 474:
			return &((*pContext)._L2);
		case 475:
			return &((*pContext)._L3);
		case 476:
			return &((*pContext)._L4);
		case 477:
			return &((*pContext)._L5);
		case 478:
			return &((*pContext)._L17);
		case 479:
			return &((*pContext)._L16);
		case 480:
			return &((*pContext)._L15);
		case 481:
			return &((*pContext)._L14);
		case 482:
			return &((*pContext)._L13);
		case 483:
			return &((*pContext)._L22);
		case 484:
			return &((*pContext)._L21);
		case 485:
			return &((*pContext)._L20);
		case 486:
			return &((*pContext)._L19);
		case 487:
			return &((*pContext)._L18);
		case 488:
			return &((*pContext)._L23);
		case 489:
			return &((*pContext).distance);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::passing_a_BG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_passing_a_BG_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_passing_a_BG_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_passedBG_2_positionedBG_CalculateTrainPosition_Pkg("CalculateTrainPosition_Pkg::passedBG_2_positionedBG", "1", 490, 0, 0);
	_SCSIM_Mapping_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id", "1", 491, 0, 0);
	_SCSIM_Mapping_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack", "2", 492, 0, 0);
	_SCSIM_Mapping_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack", "1", 493, 0, 0);
	_SCSIM_Mapping_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack", "1", 494, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 495, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 496, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 497, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, 498, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 499, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 500, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 501, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 502, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 503, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_bool_Utils, 504, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 505, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_bool_Utils, 506, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_array__5687_Utils, 507, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 508, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_array__5740_Utils, 509, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 510, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_bool_Utils, 511, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_bool_Utils, 512, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 513, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 514, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_int_Utils, 515, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 516, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 517, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "passedPositionedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 518, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 519, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "overrun", &_SCSIM_kcg_bool_Utils, 520, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "notFoundWhereAnnounced", &_SCSIM_kcg_bool_Utils, 521, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_passing_a_BG_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_passing_a_BG_CalculateTrainPosition_Pkg* pContext = (outC_passing_a_BG_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 490:
			return &((*pContext)._1_Context_1);
		case 491:
			return &((*pContext).Context_1);
		case 492:
			return &((*pContext).Context_2);
		case 493:
			return &((*pContext)._2_Context_1);
		case 494:
			return &((*pContext)._3_Context_1);
		case 495:
			return &((*pContext)._L1);
		case 496:
			return &((*pContext)._L5);
		case 497:
			return &((*pContext)._L6);
		case 498:
			return &((*pContext)._L7);
		case 499:
			return &((*pContext)._L9);
		case 500:
			return &((*pContext)._L10);
		case 501:
			return &((*pContext)._L11);
		case 502:
			return &((*pContext)._L12);
		case 503:
			return &((*pContext)._L13);
		case 504:
			return &((*pContext)._L15);
		case 505:
			return &((*pContext)._L16);
		case 506:
			return &((*pContext)._L17);
		case 507:
			return &((*pContext)._L18);
		case 508:
			return &((*pContext)._L19);
		case 509:
			return &((*pContext)._L20);
		case 510:
			return &((*pContext)._L21);
		case 511:
			return &((*pContext)._L22);
		case 512:
			return &((*pContext)._L23);
		case 513:
			return &((*pContext)._L24);
		case 514:
			return &((*pContext)._L25);
		case 515:
			return &((*pContext)._L26);
		case 516:
			return &((*pContext)._L30);
		case 517:
			return &((*pContext)._L31);
		case 518:
			return &((*pContext).passedPositionedBG);
		case 519:
			return &((*pContext).BGs_out);
		case 520:
			return &((*pContext).overrun);
		case 521:
			return &((*pContext).notFoundWhereAnnounced);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::prevPassedLinkedBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_prevPassedLinkedBG_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_prevPassedLinkedBG_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal", "1", 522, 0, 0);
	_SCSIM_Mapping_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG", "1", 523, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L42", &_SCSIM_kcg_bool_Utils, 524, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L45", &_SCSIM_NID_C_Utils, 525, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L46", &_SCSIM_NID_BG_Utils, 526, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L49", &_SCSIM_NID_C_Utils, 527, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L50", &_SCSIM_NID_BG_Utils, 528, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L55", &_SCSIM_kcg_bool_Utils, 529, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L62", &_SCSIM_kcg_bool_Utils, 530, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L61", &_SCSIM_kcg_bool_Utils, 531, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L60", &_SCSIM_kcg_int_Utils, 532, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L63", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 533, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L64", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 534, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L68", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 535, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_kcg_bool_Utils, 536, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L69", &_SCSIM_kcg_bool_Utils, 537, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L70", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 538, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L71", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 539, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L72", &_SCSIM_kcg_bool_Utils, 540, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "previouslyPassedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 541, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_prevPassedLinkedBG_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg* pContext = (outC_prevPassedLinkedBG_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 522:
			return &((*pContext)._1_Context_1);
		case 523:
			return &((*pContext).Context_1);
		case 524:
			return &((*pContext)._L42);
		case 525:
			return &((*pContext)._L45);
		case 526:
			return &((*pContext)._L46);
		case 527:
			return &((*pContext)._L49);
		case 528:
			return &((*pContext)._L50);
		case 529:
			return &((*pContext)._L55);
		case 530:
			return &((*pContext)._L62);
		case 531:
			return &((*pContext)._L61);
		case 532:
			return &((*pContext)._L60);
		case 533:
			return &((*pContext)._L63);
		case 534:
			return &((*pContext)._L64);
		case 535:
			return &((*pContext)._L68);
		case 536:
			return &((*pContext)._L67);
		case 537:
			return &((*pContext)._L69);
		case 538:
			return &((*pContext)._L70);
		case 539:
			return &((*pContext)._L71);
		case 540:
			return &((*pContext)._L72);
		case 541:
			return &((*pContext).previouslyPassedBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::genPassedBG_SeqNo/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_genPassedBG_SeqNo_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_genPassedBG_SeqNo_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_indexOfPassedBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfPassedBG_by_id", "1", 542, 0, 0);
	_SCSIM_Mapping_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg("CalculateTrainPosition_Pkg::gp_functions_Pkg::countUp", "1", 543, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "keepPassedBGSeqNo", &_SCSIM_kcg_bool_Utils, 544, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "incrPassedBGSeqNo", &_SCSIM_kcg_bool_Utils, 545, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 546, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 547, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 548, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 549, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_bool_Utils, 550, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 551, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 552, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 553, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 554, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 555, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 556, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 557, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_bool_Utils, 558, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_bool_Utils, 559, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_bool_Utils, 560, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_bool_Utils, 561, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 562, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_int_Utils, 563, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 564, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 565, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_bool_Utils, 566, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "seqNo", &_SCSIM_kcg_int_Utils, 567, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_genPassedBG_SeqNo_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg* pContext = (outC_genPassedBG_SeqNo_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 542:
			return &((*pContext).Context_1);
		case 543:
			return &((*pContext)._1_Context_1);
		case 544:
			return &((*pContext).keepPassedBGSeqNo);
		case 545:
			return &((*pContext).incrPassedBGSeqNo);
		case 546:
			return &((*pContext)._L1);
		case 547:
			return &((*pContext)._L2);
		case 548:
			return &((*pContext)._L3);
		case 549:
			return &((*pContext)._L6);
		case 550:
			return &((*pContext)._L5);
		case 551:
			return &((*pContext)._L4);
		case 552:
			return &((*pContext)._L8);
		case 553:
			return &((*pContext)._L9);
		case 554:
			return &((*pContext)._L10);
		case 555:
			return &((*pContext)._L11);
		case 556:
			return &((*pContext)._L12);
		case 557:
			return &((*pContext)._L13);
		case 558:
			return &((*pContext)._L14);
		case 559:
			return &((*pContext)._L15);
		case 560:
			return &((*pContext)._L16);
		case 561:
			return &((*pContext)._L17);
		case 562:
			return &((*pContext)._L18);
		case 563:
			return &((*pContext)._L19);
		case 564:
			return &((*pContext)._L20);
		case 565:
			return &((*pContext)._L21);
		case 566:
			return &((*pContext)._L22);
		case 567:
			return &((*pContext).seqNo);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::improve_BG_locations/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead", "1", 568, 0, 0);
	_SCSIM_Mapping_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern", "1", 569, 0, 0);
	_SCSIM_Mapping_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations", "1", 570, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 571, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 572, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 573, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L34", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 574, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L38", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 575, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L39", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 576, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 577, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_improve_BG_locations_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 568:
			return &((*pContext).Context_1);
		case 569:
			return &((*pContext)._1_Context_1);
		case 570:
			return &((*pContext)._2_Context_1);
		case 571:
			return &((*pContext)._L1);
		case 572:
			return &((*pContext)._L2);
		case 573:
			return &((*pContext)._L33);
		case 574:
			return &((*pContext)._L34);
		case 575:
			return &((*pContext)._L38);
		case 576:
			return &((*pContext)._L39);
		case 577:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** BasicLocationFunctions_Pkg::add_2_Distances/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_add_2_Distances_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 578, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 579, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 580, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 581, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 582, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 583, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 584, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 585, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 586, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 587, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 588, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 589, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 590, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 591, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 592, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 593, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "distance", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 594, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_add_2_Distances_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_add_2_Distances_BasicLocationFunctions_Pkg* pContext = (outC_add_2_Distances_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 578:
			return &((*pContext)._L1);
		case 579:
			return &((*pContext)._L2);
		case 580:
			return &((*pContext)._L3);
		case 581:
			return &((*pContext)._L4);
		case 582:
			return &((*pContext)._L5);
		case 583:
			return &((*pContext)._L17);
		case 584:
			return &((*pContext)._L16);
		case 585:
			return &((*pContext)._L15);
		case 586:
			return &((*pContext)._L14);
		case 587:
			return &((*pContext)._L13);
		case 588:
			return &((*pContext)._L22);
		case 589:
			return &((*pContext)._L21);
		case 590:
			return &((*pContext)._L20);
		case 591:
			return &((*pContext)._L19);
		case 592:
			return &((*pContext)._L18);
		case 593:
			return &((*pContext)._L23);
		case 594:
			return &((*pContext).distance);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidC_nidBG_2_NIDLRBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 595, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_NID_LRBG_Utils, 596, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 597, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 598, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 599, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_NID_BG_Utils, 600, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 601, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 602, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 603, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_NID_C_Utils, 604, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_NID_BG_Utils, 605, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "nidLRBG", &_SCSIM_NID_LRBG_Utils, 606, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 595:
			return &((*pContext)._L5);
		case 596:
			return &((*pContext)._L6);
		case 597:
			return &((*pContext)._L7);
		case 598:
			return &((*pContext)._L8);
		case 599:
			return &((*pContext)._L9);
		case 600:
			return &((*pContext)._L10);
		case 601:
			return &((*pContext)._L11);
		case 602:
			return &((*pContext)._L12);
		case 603:
			return &((*pContext)._L13);
		case 604:
			return &((*pContext)._L15);
		case 605:
			return &((*pContext)._L16);
		case 606:
			return &((*pContext).nidLRBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::Pos_Pkg::runningDirectionVsRef/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg("CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor", "1", 607, 0, 0);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock1");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_608_Utils, 608);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_609_Utils, 609);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 610, valid, 609, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_611_Utils, 611);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 612, valid, 611, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_613_Utils, 613);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 614, valid, 613, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock2");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_615_Utils, 615);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_616_Utils, 616);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_Q_DIRTRAIN_Utils, 617, valid, 616, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 618, valid, 616, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_Q_DIRTRAIN_Utils, 619, valid, 616, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_Q_DIRTRAIN_Utils, 620, valid, 616, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_Q_DIRTRAIN_Utils, 621, valid, 616, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_622_Utils, 622);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_Q_DIRTRAIN_Utils, 623, valid, 622, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_624_Utils, 624);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_Q_DIRTRAIN_Utils, 625, valid, 624, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "currentDir", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 626, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "refDir", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 627, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 628, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 629, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "trainRunningDirection", &_SCSIM_Q_DIRTRAIN_Utils, 630, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg* pContext = (outC_runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 607:
			return &((*pContext).Context_1);
		case 608:
			return &((*pContext).IfBlock1_clock);
		case 609:
			return &((*pContext).else_clock_IfBlock1);
		case 610:
			return &((*pContext)._L14_IfBlock1);
		case 611:
			return &((*pContext).else_clock_IfBlock1);
		case 612:
			return &((*pContext)._L13_IfBlock1);
		case 613:
			return &((*pContext).IfBlock1_clock);
		case 614:
			return &((*pContext)._L1_IfBlock1);
		case 615:
			return &((*pContext).IfBlock2_clock);
		case 616:
			return &((*pContext).else_clock_IfBlock2);
		case 617:
			return &((*pContext)._L12_IfBlock2);
		case 618:
			return &((*pContext)._L2_IfBlock2);
		case 619:
			return &((*pContext)._L3_IfBlock2);
		case 620:
			return &((*pContext)._L4_IfBlock2);
		case 621:
			return &((*pContext)._L6_IfBlock2);
		case 622:
			return &((*pContext).else_clock_IfBlock2);
		case 623:
			return &((*pContext)._L11_IfBlock2);
		case 624:
			return &((*pContext).IfBlock2_clock);
		case 625:
			return &((*pContext)._L1_IfBlock2);
		case 626:
			return &((*pContext).currentDir);
		case 627:
			return &((*pContext).refDir);
		case 628:
			return &((*pContext)._L4);
		case 629:
			return &((*pContext)._L5);
		case 630:
			return &((*pContext).trainRunningDirection);
		default:
			break;
	}
	return 0;
}

static int Is609Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_609_Utils = {Is609Active};

static int Is611Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_611_Utils = {Is611Active};

static int Is608Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_608_Utils = {Is608Active};

static int Is613Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_613_Utils = {Is613Active};

static int Is616Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_616_Utils = {Is616Active};

static int Is622Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_622_Utils = {Is622Active};

static int Is615Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_615_Utils = {Is615Active};

static int Is624Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_624_Utils = {Is624Active};

/****************************************************************
 ** CalculateTrainPosition_Pkg::Pos_Pkg::frontendToLRBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "1", 631, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "1", 632, 0, 0);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock1");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_633_Utils, 633);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_634_Utils, 634);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_Q_DLRBG_Utils, 635, valid, 634, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_636_Utils, 636);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 637, valid, 636, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_Q_DLRBG_Utils, 638, valid, 636, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_Q_DLRBG_Utils, 639, valid, 636, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_Q_DLRBG_Utils, 640, valid, 636, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 641, valid, 636, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 642, valid, 636, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_643_Utils, 643);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 644, valid, 643, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 645, valid, 643, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 646, valid, 643, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_Q_DLRBG_Utils, 647, valid, 643, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_Q_DLRBG_Utils, 648, valid, 643, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_Q_DLRBG_Utils, 649, valid, 643, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "estimated_d_LRBGToFrontend", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 650, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "trainOrientationToLRBG", &_SCSIM_Q_DIRLRBG_Utils, 651, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils, 652, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 653, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 654, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 655, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 656, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 657, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 658, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 659, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 660, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 661, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 662, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 663, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 664, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_Q_DIRLRBG_Utils, 665, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_Q_DIRLRBG_Utils, 666, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 667, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_Q_DIRLRBG_Utils, 668, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "nominalOrReverseToLRBG", &_SCSIM_Q_DLRBG_Utils, 669, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg* pContext = (outC_frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 631:
			return &((*pContext).Context_1);
		case 632:
			return &((*pContext)._1_Context_1);
		case 633:
			return &((*pContext).IfBlock1_clock);
		case 634:
			return &((*pContext).else_clock_IfBlock1);
		case 635:
			return &((*pContext)._L14_IfBlock1);
		case 636:
			return &((*pContext).else_clock_IfBlock1);
		case 637:
			return &((*pContext)._L10_IfBlock1);
		case 638:
			return &((*pContext)._L9_IfBlock1);
		case 639:
			return &((*pContext)._L8_IfBlock1);
		case 640:
			return &((*pContext)._L7_IfBlock1);
		case 641:
			return &((*pContext)._L63_IfBlock1);
		case 642:
			return &((*pContext)._L52_IfBlock1);
		case 643:
			return &((*pContext).IfBlock1_clock);
		case 644:
			return &((*pContext)._L1_IfBlock1);
		case 645:
			return &((*pContext)._L2_IfBlock1);
		case 646:
			return &((*pContext)._L3_IfBlock1);
		case 647:
			return &((*pContext)._L4_IfBlock1);
		case 648:
			return &((*pContext)._L5_IfBlock1);
		case 649:
			return &((*pContext)._L6_IfBlock1);
		case 650:
			return &((*pContext).estimated_d_LRBGToFrontend);
		case 651:
			return &((*pContext).trainOrientationToLRBG);
		case 652:
			return &((*pContext)._L1);
		case 653:
			return &((*pContext)._L2);
		case 654:
			return &((*pContext)._L3);
		case 655:
			return &((*pContext)._L4);
		case 656:
			return &((*pContext)._L5);
		case 657:
			return &((*pContext)._L6);
		case 658:
			return &((*pContext)._L7);
		case 659:
			return &((*pContext)._L8);
		case 660:
			return &((*pContext)._L9);
		case 661:
			return &((*pContext)._L10);
		case 662:
			return &((*pContext)._L11);
		case 663:
			return &((*pContext)._L12);
		case 664:
			return &((*pContext)._L13);
		case 665:
			return &((*pContext)._L14);
		case 666:
			return &((*pContext)._L17);
		case 667:
			return &((*pContext)._L18);
		case 668:
			return &((*pContext)._L19);
		case 669:
			return &((*pContext).nominalOrReverseToLRBG);
		default:
			break;
	}
	return 0;
}

static int Is634Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_634_Utils = {Is634Active};

static int Is636Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_636_Utils = {Is636Active};

static int Is633Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_633_Utils = {Is633Active};

static int Is643Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_643_Utils = {Is643Active};

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionDerivedFromPassedBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock1");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_670_Utils, 670);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "1", 671, 670, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 672, valid, 670, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 673, valid, 670, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 674, valid, 670, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_675_Utils, 675);
	_SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_odo_2_Location", "6", 676, 675, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 677, valid, 675, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 678, valid, 675, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 679, valid, 675, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 680, valid, 675, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 681, valid, 675, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddOutput(pSimulator, "position", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 682, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 670:
			return &((*pContext).IfBlock1_clock);
		case 671:
			return &((*pContext).Context_1);
		case 672:
			return &((*pContext)._L3_IfBlock1);
		case 673:
			return &((*pContext)._L4_IfBlock1);
		case 674:
			return &((*pContext)._L5_IfBlock1);
		case 675:
			return &((*pContext).IfBlock1_clock);
		case 676:
			return &((*pContext).Context_6);
		case 677:
			return &((*pContext)._L19_IfBlock1);
		case 678:
			return &((*pContext)._L18_IfBlock1);
		case 679:
			return &((*pContext)._L17_IfBlock1);
		case 680:
			return &((*pContext)._L16_IfBlock1);
		case 681:
			return &((*pContext)._L15_IfBlock1);
		case 682:
			return &((*pContext).position);
		default:
			break;
	}
	return 0;
}

static int Is670Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_670_Utils = {Is670Active};

static int Is675Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_675_Utils = {Is675Active};

/****************************************************************
 ** BasicLocationFunctions_Pkg::overlapOf_2_Locations/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_overlapOf_2_Locations_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	/*<< Inlined math::Min*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::Min", "1", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "Mi_Output", &_SCSIM_kcg_int_Utils, 683, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "I1", &_SCSIM_kcg_int_Utils, 684, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "I2", &_SCSIM_kcg_int_Utils, 685, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 686, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 687, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 688, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_bool_Utils, 689, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	/*<< Inlined math::Max*/
	pSimulator->m_pfnPushInstance(pSimulator, "math::Max", "1", 0, 0, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "Ma_Output", &_SCSIM_kcg_int_Utils, 690, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "I1", &_SCSIM_kcg_int_Utils, 691, valid, 0, 0);
	pSimulator->m_pfnAddInput(pSimulator, "I2", &_SCSIM_kcg_int_Utils, 692, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 693, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_int_Utils, 694, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 695, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 696, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
	/*>>*/
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 697, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 698, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 699, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 700, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 701, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 702, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 703, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 704, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 705, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_int_Utils, 706, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 707, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 708, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 709, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 710, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 711, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 712, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 713, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_int_Utils, 714, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_bool_Utils, 715, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 716, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 717, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 718, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 719, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 720, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_kcg_int_Utils, 721, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_kcg_int_Utils, 722, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "loc", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 723, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "overlap", &_SCSIM_kcg_bool_Utils, 724, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_overlapOf_2_Locations_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg* pContext = (outC_overlapOf_2_Locations_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 683:
			return &((*pContext).Mi_Output_1);
		case 684:
			return &((*pContext).I1_1);
		case 685:
			return &((*pContext).I2_1);
		case 686:
			return &((*pContext)._L21_1);
		case 687:
			return &((*pContext)._L22_1);
		case 688:
			return &((*pContext)._L24_1);
		case 689:
			return &((*pContext)._L25_1);
		case 690:
			return &((*pContext).Ma_Output_1);
		case 691:
			return &((*pContext).I1_12);
		case 692:
			return &((*pContext).I2_11);
		case 693:
			return &((*pContext)._L1_1);
		case 694:
			return &((*pContext)._L2_1);
		case 695:
			return &((*pContext)._L3_1);
		case 696:
			return &((*pContext)._L4_1);
		case 697:
			return &((*pContext)._L1);
		case 698:
			return &((*pContext)._L2);
		case 699:
			return &((*pContext)._L3);
		case 700:
			return &((*pContext)._L5);
		case 701:
			return &((*pContext)._L6);
		case 702:
			return &((*pContext)._L9);
		case 703:
			return &((*pContext)._L8);
		case 704:
			return &((*pContext)._L7);
		case 705:
			return &((*pContext)._L10);
		case 706:
			return &((*pContext)._L19);
		case 707:
			return &((*pContext)._L18);
		case 708:
			return &((*pContext)._L17);
		case 709:
			return &((*pContext)._L16);
		case 710:
			return &((*pContext)._L15);
		case 711:
			return &((*pContext)._L14);
		case 712:
			return &((*pContext)._L13);
		case 713:
			return &((*pContext)._L12);
		case 714:
			return &((*pContext)._L11);
		case 715:
			return &((*pContext)._L20);
		case 716:
			return &((*pContext)._L21);
		case 717:
			return &((*pContext)._L22);
		case 718:
			return &((*pContext)._L23);
		case 719:
			return &((*pContext)._L24);
		case 720:
			return &((*pContext)._L31);
		case 721:
			return &((*pContext)._L32);
		case 722:
			return &((*pContext)._L33);
		case 723:
			return &((*pContext).loc);
		case 724:
			return &((*pContext).overlap);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "foldwi", 8, 8);
	_SCSIM_Mapping_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG_itr", "1", 725, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 726, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 727, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 728, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 729, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 730, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_int_Utils, 731, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 732, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 733, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 734, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 735, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 736, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_array_bool_8_Utils, 737, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 738, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_found", &_SCSIM_kcg_bool_Utils, 739, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexValid", &_SCSIM_kcg_bool_Utils, 740, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 725:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 726:
			return &((*pContext)._L1);
		case 727:
			return &((*pContext)._L3);
		case 728:
			return &((*pContext)._L4);
		case 729:
			return &((*pContext)._L5);
		case 730:
			return &((*pContext)._L6);
		case 731:
			return &((*pContext)._L12);
		case 732:
			return &((*pContext)._L10);
		case 733:
			return &((*pContext)._L9);
		case 734:
			return &((*pContext)._L8);
		case 735:
			return &((*pContext)._L7);
		case 736:
			return &((*pContext)._L13);
		case 737:
			return &((*pContext)._L14);
		case 738:
			return &((*pContext).indexOfBG);
		case 739:
			return &((*pContext).BG_found);
		case 740:
			return &((*pContext).indexValid);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "foldw", 8, 8);
	_SCSIM_Mapping_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs_itr", "1", 741, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 742, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 743, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 744, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 745, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 746, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_bool_Utils, 747, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 748, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_bool_Utils, 749, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 750, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 751, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "empty", &_SCSIM_kcg_bool_Utils, 752, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "full", &_SCSIM_kcg_bool_Utils, 753, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "counters", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 754, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_countBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 741:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 742:
			return &((*pContext)._L1);
		case 743:
			return &((*pContext)._L3);
		case 744:
			return &((*pContext)._L4);
		case 745:
			return &((*pContext)._L5);
		case 746:
			return &((*pContext)._L12);
		case 747:
			return &((*pContext)._L14);
		case 748:
			return &((*pContext)._L15);
		case 749:
			return &((*pContext)._L16);
		case 750:
			return &((*pContext)._L17);
		case 751:
			return &((*pContext)._L24);
		case 752:
			return &((*pContext).empty);
		case 753:
			return &((*pContext).full);
		case 754:
			return &((*pContext).counters);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "foldwi", 8, 8);
	_SCSIM_Mapping_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG_itr", "1", 755, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 756, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 757, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 758, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 759, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 760, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_array_bool_8_Utils, 761, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 762, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 763, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_array_int_8_Utils, 764, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 765, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 766, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 767, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_bool_Utils, 768, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 769, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_bool_Utils, 770, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 771, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_found", &_SCSIM_kcg_bool_Utils, 772, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOf_nthPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 755:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 756:
			return &((*pContext)._L1);
		case 757:
			return &((*pContext)._L3);
		case 758:
			return &((*pContext)._L4);
		case 759:
			return &((*pContext)._L6);
		case 760:
			return &((*pContext)._L13);
		case 761:
			return &((*pContext)._L14);
		case 762:
			return &((*pContext)._L15);
		case 763:
			return &((*pContext)._L16);
		case 764:
			return &((*pContext)._L17);
		case 765:
			return &((*pContext)._L18);
		case 766:
			return &((*pContext)._L19);
		case 767:
			return &((*pContext)._L20);
		case 768:
			return &((*pContext)._L21);
		case 769:
			return &((*pContext)._L22);
		case 770:
			return &((*pContext)._L23);
		case 771:
			return &((*pContext).indexOfBG);
		case 772:
			return &((*pContext).BG_found);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapwi", 8, 8);
	_SCSIM_Mapping_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex_itr", "1", 773, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_bool_Utils, 774, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 775, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 776, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 777, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 778, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 779, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 780, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 781, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_array_int_8_Utils, 782, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_array__5687_Utils, 783, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 784, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_array__5687_Utils, 785, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 786, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_array__5780_Utils, 787, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 788, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_deleteBGs_beforeIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 773:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 774:
			return &((*pContext)._L1);
		case 775:
			return &((*pContext)._L2);
		case 776:
			return &((*pContext)._L3);
		case 777:
			return &((*pContext)._L4);
		case 778:
			return &((*pContext)._L5);
		case 779:
			return &((*pContext)._L6);
		case 780:
			return &((*pContext)._L7);
		case 781:
			return &((*pContext)._L8);
		case 782:
			return &((*pContext)._L9);
		case 783:
			return &((*pContext)._L17);
		case 784:
			return &((*pContext)._L18);
		case 785:
			return &((*pContext)._L20);
		case 786:
			return &((*pContext)._L21);
		case 787:
			return &((*pContext)._L22);
		case 788:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** ctp_t_pck::t_engine::genPassedBG_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_genPassedBG_itr_ctp_t_pck_t_engine(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_genPassedBG_itr_ctp_t_pck_t_engine_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 789, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 790, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 791, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 792, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 793, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 794, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_bool_Utils, 795, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 796, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 797, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils, 798, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 799, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 800, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 801, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "passedBG", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 802, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_genPassedBG_itr_ctp_t_pck_t_engine_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_genPassedBG_itr_ctp_t_pck_t_engine* pContext = (outC_genPassedBG_itr_ctp_t_pck_t_engine*)pInstance;
	switch (nHandleIdent) {
		case 789:
			return &((*pContext)._L1);
		case 790:
			return &((*pContext)._L2);
		case 791:
			return &((*pContext)._L3);
		case 792:
			return &((*pContext)._L4);
		case 793:
			return &((*pContext)._L5);
		case 794:
			return &((*pContext)._L6);
		case 795:
			return &((*pContext)._L7);
		case 796:
			return &((*pContext)._L8);
		case 797:
			return &((*pContext)._L9);
		case 798:
			return &((*pContext)._L10);
		case 799:
			return &((*pContext)._L11);
		case 800:
			return &((*pContext)._L12);
		case 801:
			return &((*pContext).cont);
		case 802:
			return &((*pContext).passedBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "foldwi", 8, 8);
	_SCSIM_Mapping_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id_itr", "1", 803, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 804, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 805, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 806, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 807, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 808, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 809, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_array__5687_Utils, 810, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 811, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_bool_Utils, 812, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 813, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 814, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 815, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 816, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_found", &_SCSIM_kcg_bool_Utils, 817, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexValid", &_SCSIM_kcg_bool_Utils, 818, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 803:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 804:
			return &((*pContext)._L1);
		case 805:
			return &((*pContext)._L2);
		case 806:
			return &((*pContext)._L3);
		case 807:
			return &((*pContext)._L6);
		case 808:
			return &((*pContext)._L8);
		case 809:
			return &((*pContext)._L9);
		case 810:
			return &((*pContext)._L11);
		case 811:
			return &((*pContext)._L12);
		case 812:
			return &((*pContext)._L16);
		case 813:
			return &((*pContext)._L17);
		case 814:
			return &((*pContext)._L18);
		case 815:
			return &((*pContext)._L19);
		case 816:
			return &((*pContext).indexOfBG);
		case 817:
			return &((*pContext).BG_found);
		case 818:
			return &((*pContext).indexValid);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::passedBG_2_positionedBG/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_passedBG_2_positionedBG_CalculateTrainPosition_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_passedBG_2_positionedBG_CalculateTrainPosition_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs", "1", 819, 0, 0);
	pSimulator->m_pfnPushActivateIf(pSimulator, "ifAnnouncedOrABGWasPreviouslyPassed");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_820_Utils, 820);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_821_Utils, 821);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_822_Utils, 822);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "14", 823, 822, &_SCSIM_ClockActive_kcg_false);
	_SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_odo_2_Location", "6", 824, 822, &_SCSIM_ClockActive_kcg_false);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "3", 825, 822, &_SCSIM_ClockActive_kcg_false);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "6", 826, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 827, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 828, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 829, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 830, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 831, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 832, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 833, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 834, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 835, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 836, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 837, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 838, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 839, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 840, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 841, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_bool_Utils, 842, valid, 822, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_843_Utils, 843);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 844, valid, 843, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 845, valid, 843, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_846_Utils, 846);
	_SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_odo_2_Location", "5", 847, 846, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "13", 848, 846, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "5", 849, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 850, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 851, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 852, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 853, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 854, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 855, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 856, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 857, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 858, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_bool_Utils, 859, valid, 846, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_860_Utils, 860);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "9", 861, 860, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "8", 862, 860, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "4", 863, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 864, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 865, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 866, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 867, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 868, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 869, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_bool_Utils, 870, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 871, valid, 860, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "BG_wasAnnounced", &_SCSIM_kcg_bool_Utils, 872, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "location", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 873, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "passedPositionedBG_loc", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 874, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "notFoundWhereAnnounced_loc", &_SCSIM_kcg_bool_Utils, 875, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_LinkedBGs_T_BG_Types_Pkg_Utils, 876, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_BG_Header_T_BG_Types_Pkg_Utils, 877, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 878, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 879, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils, 880, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 881, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 882, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 883, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 884, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L37", &_SCSIM_NID_C_Utils, 885, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L38", &_SCSIM_NID_BG_Utils, 886, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L39", &_SCSIM_Q_LINK_Utils, 887, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L40", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 888, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L41", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 889, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L56", &_SCSIM_kcg_bool_Utils, 890, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L57", &_SCSIM_NID_BG_Utils, 891, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L58", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 892, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L59", &_SCSIM_NID_BG_Utils, 893, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L60", &_SCSIM_kcg_bool_Utils, 894, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L61", &_SCSIM_NID_C_Utils, 895, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L62", &_SCSIM_NID_C_Utils, 896, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L63", &_SCSIM_kcg_bool_Utils, 897, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L64", &_SCSIM_Q_LINK_Utils, 898, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L65", &_SCSIM_Q_LINK_Utils, 899, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L66", &_SCSIM_kcg_bool_Utils, 900, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_kcg_bool_Utils, 901, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L68", &_SCSIM_kcg_bool_Utils, 902, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L181", &_SCSIM_kcg_bool_Utils, 903, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L182", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 904, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L183", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 905, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L184", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 906, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L185", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 907, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L262", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 908, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L264", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 909, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L263", &_SCSIM_LinkedBGs_T_BG_Types_Pkg_Utils, 910, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L265", &_SCSIM_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, 911, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L279", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 912, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L278", &_SCSIM_Q_DIRTRAIN_Utils, 913, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L277", &_SCSIM_Q_DIRLRBG_Utils, 914, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L276", &_SCSIM_kcg_bool_Utils, 915, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L281", &_SCSIM_kcg_int_Utils, 916, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L282", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 917, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L283", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 918, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L284", &_SCSIM_kcg_bool_Utils, 919, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L285", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 920, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "passedPositionedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 921, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "notFoundWhereAnnounced", &_SCSIM_kcg_bool_Utils, 922, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "linkedBGs", &_SCSIM_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, 923, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_passedBG_2_positionedBG_CalculateTrainPosition_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg* pContext = (outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 819:
			return &((*pContext).Context_1);
		case 820:
			return &((*pContext).ifAnnouncedOrABGWasPreviouslyPassed_clock);
		case 821:
			return &((*pContext)._3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed);
		case 822:
			return &((*pContext).else_clock_ifAnnouncedOrABGWasPreviouslyPassed);
		case 823:
			return &((*pContext).Context_14);
		case 824:
			return &((*pContext).Context_6);
		case 825:
			return &((*pContext).Context_3);
		case 826:
			return &((*pContext)._1_Context_6);
		case 827:
			return &((*pContext)._L1417_ifAnnouncedOrABGWasPreviouslyPassed);
		case 828:
			return &((*pContext)._L1316_ifAnnouncedOrABGWasPreviouslyPassed);
		case 829:
			return &((*pContext)._L1215_ifAnnouncedOrABGWasPreviouslyPassed);
		case 830:
			return &((*pContext)._L1114_ifAnnouncedOrABGWasPreviouslyPassed);
		case 831:
			return &((*pContext)._L913_ifAnnouncedOrABGWasPreviouslyPassed);
		case 832:
			return &((*pContext)._L1012_ifAnnouncedOrABGWasPreviouslyPassed);
		case 833:
			return &((*pContext)._L811_ifAnnouncedOrABGWasPreviouslyPassed);
		case 834:
			return &((*pContext)._L710_ifAnnouncedOrABGWasPreviouslyPassed);
		case 835:
			return &((*pContext)._L69_ifAnnouncedOrABGWasPreviouslyPassed);
		case 836:
			return &((*pContext)._L5_ifAnnouncedOrABGWasPreviouslyPassed);
		case 837:
			return &((*pContext)._L4_ifAnnouncedOrABGWasPreviouslyPassed);
		case 838:
			return &((*pContext)._L3_ifAnnouncedOrABGWasPreviouslyPassed);
		case 839:
			return &((*pContext)._L28_ifAnnouncedOrABGWasPreviouslyPassed);
		case 840:
			return &((*pContext)._L17_ifAnnouncedOrABGWasPreviouslyPassed);
		case 841:
			return &((*pContext)._L154_ifAnnouncedOrABGWasPreviouslyPassed);
		case 842:
			return &((*pContext)._L16_ifAnnouncedOrABGWasPreviouslyPassed);
		case 843:
			return &((*pContext).else_clock_ifAnnouncedOrABGWasPreviouslyPassed);
		case 844:
			return &((*pContext)._L2_ifAnnouncedOrABGWasPreviouslyPassed);
		case 845:
			return &((*pContext)._L1_ifAnnouncedOrABGWasPreviouslyPassed);
		case 846:
			return &((*pContext)._3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed);
		case 847:
			return &((*pContext).Context_5);
		case 848:
			return &((*pContext).Context_13);
		case 849:
			return &((*pContext)._2_Context_5);
		case 850:
			return &((*pContext)._L13_ifAnnouncedOrABGWasPreviouslyPassed);
		case 851:
			return &((*pContext)._L12_ifAnnouncedOrABGWasPreviouslyPassed);
		case 852:
			return &((*pContext)._L11_ifAnnouncedOrABGWasPreviouslyPassed);
		case 853:
			return &((*pContext)._L10_ifAnnouncedOrABGWasPreviouslyPassed);
		case 854:
			return &((*pContext)._L9_ifAnnouncedOrABGWasPreviouslyPassed);
		case 855:
			return &((*pContext)._L8_ifAnnouncedOrABGWasPreviouslyPassed);
		case 856:
			return &((*pContext)._L7_ifAnnouncedOrABGWasPreviouslyPassed);
		case 857:
			return &((*pContext)._L6_ifAnnouncedOrABGWasPreviouslyPassed);
		case 858:
			return &((*pContext)._L14_ifAnnouncedOrABGWasPreviouslyPassed);
		case 859:
			return &((*pContext)._L15_ifAnnouncedOrABGWasPreviouslyPassed);
		case 860:
			return &((*pContext).ifAnnouncedOrABGWasPreviouslyPassed_clock);
		case 861:
			return &((*pContext).Context_9);
		case 862:
			return &((*pContext).Context_8);
		case 863:
			return &((*pContext).Context_4);
		case 864:
			return &((*pContext)._L25_ifAnnouncedOrABGWasPreviouslyPassed);
		case 865:
			return &((*pContext)._L24_ifAnnouncedOrABGWasPreviouslyPassed);
		case 866:
			return &((*pContext)._L23_ifAnnouncedOrABGWasPreviouslyPassed);
		case 867:
			return &((*pContext)._L22_ifAnnouncedOrABGWasPreviouslyPassed);
		case 868:
			return &((*pContext)._L21_ifAnnouncedOrABGWasPreviouslyPassed);
		case 869:
			return &((*pContext)._L20_ifAnnouncedOrABGWasPreviouslyPassed);
		case 870:
			return &((*pContext)._L27_ifAnnouncedOrABGWasPreviouslyPassed);
		case 871:
			return &((*pContext)._L26_ifAnnouncedOrABGWasPreviouslyPassed);
		case 872:
			return &((*pContext).BG_wasAnnounced);
		case 873:
			return &((*pContext).location);
		case 874:
			return &((*pContext).passedPositionedBG_loc);
		case 875:
			return &((*pContext).notFoundWhereAnnounced_loc);
		case 876:
			return &((*pContext)._L13);
		case 877:
			return &((*pContext)._L12);
		case 878:
			return &((*pContext)._L11);
		case 879:
			return &((*pContext)._L10);
		case 880:
			return &((*pContext)._L9);
		case 881:
			return &((*pContext)._L8);
		case 882:
			return &((*pContext)._L14);
		case 883:
			return &((*pContext)._L15);
		case 884:
			return &((*pContext)._L16);
		case 885:
			return &((*pContext)._L37);
		case 886:
			return &((*pContext)._L38);
		case 887:
			return &((*pContext)._L39);
		case 888:
			return &((*pContext)._L40);
		case 889:
			return &((*pContext)._L41);
		case 890:
			return &((*pContext)._L56);
		case 891:
			return &((*pContext)._L57);
		case 892:
			return &((*pContext)._L58);
		case 893:
			return &((*pContext)._L59);
		case 894:
			return &((*pContext)._L60);
		case 895:
			return &((*pContext)._L61);
		case 896:
			return &((*pContext)._L62);
		case 897:
			return &((*pContext)._L63);
		case 898:
			return &((*pContext)._L64);
		case 899:
			return &((*pContext)._L65);
		case 900:
			return &((*pContext)._L66);
		case 901:
			return &((*pContext)._L67);
		case 902:
			return &((*pContext)._L68);
		case 903:
			return &((*pContext)._L181);
		case 904:
			return &((*pContext)._L182);
		case 905:
			return &((*pContext)._L183);
		case 906:
			return &((*pContext)._L184);
		case 907:
			return &((*pContext)._L185);
		case 908:
			return &((*pContext)._L262);
		case 909:
			return &((*pContext)._L264);
		case 910:
			return &((*pContext)._L263);
		case 911:
			return &((*pContext)._L265);
		case 912:
			return &((*pContext)._L279);
		case 913:
			return &((*pContext)._L278);
		case 914:
			return &((*pContext)._L277);
		case 915:
			return &((*pContext)._L276);
		case 916:
			return &((*pContext)._L281);
		case 917:
			return &((*pContext)._L282);
		case 918:
			return &((*pContext)._L283);
		case 919:
			return &((*pContext)._L284);
		case 920:
			return &((*pContext)._L285);
		case 921:
			return &((*pContext).passedPositionedBG);
		case 922:
			return &((*pContext).notFoundWhereAnnounced);
		case 923:
			return &((*pContext).linkedBGs);
		default:
			break;
	}
	return 0;
}

static int Is822Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_822_Utils = {Is822Active};

static int Is843Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_843_Utils = {Is843Active};

static int Is821Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_821_Utils = {Is821Active};

static int Is846Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_846_Utils = {Is846Active};

static int Is820Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_820_Utils = {Is820Active};

static int Is860Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_860_Utils = {Is860Active};

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_indexOfBG_by_id_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id", "2", 924, 0, 0);
	_SCSIM_Mapping_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack", "1", 925, 0, 0);
	_SCSIM_Mapping_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex", "1", 926, 0, 0);
	_SCSIM_Mapping_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex", "1", 927, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 928, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 929, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_int_Utils, 930, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 931, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_bool_Utils, 932, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 933, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 934, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 935, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 936, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 937, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 938, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 939, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 940, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 941, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 942, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 943, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 944, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 945, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_bool_Utils, 946, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 947, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_bool_Utils, 948, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 949, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "overrun", &_SCSIM_kcg_bool_Utils, 950, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 924:
			return &((*pContext).Context_2);
		case 925:
			return &((*pContext).Context_1);
		case 926:
			return &((*pContext)._1_Context_1);
		case 927:
			return &((*pContext)._2_Context_1);
		case 928:
			return &((*pContext)._L3);
		case 929:
			return &((*pContext)._L2);
		case 930:
			return &((*pContext)._L1);
		case 931:
			return &((*pContext)._L6);
		case 932:
			return &((*pContext)._L5);
		case 933:
			return &((*pContext)._L4);
		case 934:
			return &((*pContext)._L7);
		case 935:
			return &((*pContext)._L8);
		case 936:
			return &((*pContext)._L9);
		case 937:
			return &((*pContext)._L10);
		case 938:
			return &((*pContext)._L11);
		case 939:
			return &((*pContext)._L12);
		case 940:
			return &((*pContext)._L13);
		case 941:
			return &((*pContext)._L15);
		case 942:
			return &((*pContext)._L16);
		case 943:
			return &((*pContext)._L17);
		case 944:
			return &((*pContext)._L18);
		case 945:
			return &((*pContext)._L19);
		case 946:
			return &((*pContext)._L20);
		case 947:
			return &((*pContext)._L21);
		case 948:
			return &((*pContext)._L22);
		case 949:
			return &((*pContext).BGs_out);
		case 950:
			return &((*pContext).overrun);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "fold", 8, 8);
	_SCSIM_Mapping_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack_itr", "1", 951, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 952, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 953, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, 954, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, 955, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 956, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 957, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 958, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 959, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "overrun", &_SCSIM_kcg_bool_Utils, 960, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_mergeBGs_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 951:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 952:
			return &((*pContext)._L1);
		case 953:
			return &((*pContext)._L2);
		case 954:
			return &((*pContext)._L7);
		case 955:
			return &((*pContext)._L8);
		case 956:
			return &((*pContext)._L9);
		case 957:
			return &((*pContext)._L13);
		case 958:
			return &((*pContext)._L12);
		case 959:
			return &((*pContext).BGs_out);
		case 960:
			return &((*pContext).overrun);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapfold", 8, 8);
	_SCSIM_Mapping_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack_itr", "1", 961, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 962, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_array__5687_Utils, 963, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_int_Utils, 964, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 965, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 966, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_trimSeqNoOnTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 961:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 962:
			return &((*pContext)._L1);
		case 963:
			return &((*pContext)._L3);
		case 964:
			return &((*pContext)._L2);
		case 965:
			return &((*pContext)._L5);
		case 966:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_NID_C_Utils, 967, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_NID_C_Utils, 968, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_NID_BG_Utils, 969, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_NID_BG_Utils, 970, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_bool_Utils, 971, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 972, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_bool_Utils, 973, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "isEqual", &_SCSIM_kcg_bool_Utils, 974, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 967:
			return &((*pContext)._L1);
		case 968:
			return &((*pContext)._L2);
		case 969:
			return &((*pContext)._L3);
		case 970:
			return &((*pContext)._L4);
		case 971:
			return &((*pContext)._L5);
		case 972:
			return &((*pContext)._L6);
		case 973:
			return &((*pContext)._L7);
		case 974:
			return &((*pContext).isEqual);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::gp_functions_Pkg::countUp/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_int_Utils, 975, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_int_Utils, 976, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 977, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 978, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 979, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 980, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 981, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 982, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_int_Utils, 983, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "counter", &_SCSIM_kcg_int_Utils, 984, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg* pContext = (outC_countUp_CalculateTrainPosition_Pkg_gp_functions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 975:
			return &((*pContext)._L11);
		case 976:
			return &((*pContext)._L2);
		case 977:
			return &((*pContext)._L3);
		case 978:
			return &((*pContext)._L4);
		case 979:
			return &((*pContext)._L5);
		case 980:
			return &((*pContext)._L6);
		case 981:
			return &((*pContext)._L9);
		case 982:
			return &((*pContext)._L10);
		case 983:
			return &((*pContext)._L12);
		case 984:
			return &((*pContext).counter);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapfold", 8, 8);
	_SCSIM_Mapping_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead_itr", "1", 985, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 986, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 987, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 988, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_array__5687_Utils, 989, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 990, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 991, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 992, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_array__5777_Utils, 993, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 994, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_recalculate_BG_locations_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 985:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 986:
			return &((*pContext)._L1);
		case 987:
			return &((*pContext)._L2);
		case 988:
			return &((*pContext)._L3);
		case 989:
			return &((*pContext)._L4);
		case 990:
			return &((*pContext)._L7);
		case 991:
			return &((*pContext)._L8);
		case 992:
			return &((*pContext)._L9);
		case 993:
			return &((*pContext)._L10);
		case 994:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapfold", 8, 8);
	_SCSIM_Mapping_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern_itr", "1", 995, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 996, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 997, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 998, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_array__5687_Utils, 999, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1000, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1001, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1002, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_array__5687_Utils, 1003, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1004, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_array__5777_Utils, 1005, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1006, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_recalculate_BG_locations_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 995:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 996:
			return &((*pContext)._L1);
		case 997:
			return &((*pContext)._L2);
		case 998:
			return &((*pContext)._L3);
		case 999:
			return &((*pContext)._L4);
		case 1000:
			return &((*pContext)._L7);
		case 1001:
			return &((*pContext)._L8);
		case 1002:
			return &((*pContext)._L9);
		case 1003:
			return &((*pContext)._L10);
		case 1004:
			return &((*pContext)._L11);
		case 1005:
			return &((*pContext)._L12);
		case 1006:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapw", 8, 8);
	_SCSIM_Mapping_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations_itr", "1", 1007, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	_SCSIM_Mapping_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBGs", "1", 1008, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1009, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1010, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_array__5687_Utils, 1011, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 1012, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_array__5780_Utils, 1013, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_bool_Utils, 1014, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1015, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_improveUnlinkedBGLocations_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1007:
			if (nSize != 1)
				break;
			return &((*pContext)._1_Context_1[pIteratorFilter[0]]);
		case 1008:
			return &((*pContext).Context_1);
		case 1009:
			return &((*pContext)._L2);
		case 1010:
			return &((*pContext)._L3);
		case 1011:
			return &((*pContext)._L5);
		case 1012:
			return &((*pContext)._L6);
		case 1013:
			return &((*pContext)._L8);
		case 1014:
			return &((*pContext)._L12);
		case 1015:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "currentOdometry", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 1016, valid, 0, 0);
	pSimulator->m_pfnPushStateMachine(pSimulator, "SM1");
	pSimulator->m_pfnPushState(pSimulator, "Unknown", &_SCSIM_SSM_st_Unknown_SM1_Utils, 1017);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1018, valid, 1017, &_SCSIM_ClockActive_SSM_st_Unknown_SM1);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "1", &_SCSIM_SSM_TR_Unknown_1_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "2", &_SCSIM_SSM_TR_Unknown_2_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "3", &_SCSIM_SSM_TR_Unknown_3_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPopState(pSimulator);
	pSimulator->m_pfnPushState(pSimulator, "Decreasing", &_SCSIM_SSM_st_Decreasing_SM1_Utils, 1017);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1020, valid, 1017, &_SCSIM_ClockActive_SSM_st_Decreasing_SM1);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "1", &_SCSIM_SSM_TR_Decreasing_1_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "2", &_SCSIM_SSM_TR_Decreasing_2_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPopState(pSimulator);
	pSimulator->m_pfnPushState(pSimulator, "Increasing", &_SCSIM_SSM_st_Increasing_SM1_Utils, 1017);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1021, valid, 1017, &_SCSIM_ClockActive_SSM_st_Increasing_SM1);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "1", &_SCSIM_SSM_TR_Increasing_1_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "2", &_SCSIM_SSM_TR_Increasing_2_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPopState(pSimulator);
	pSimulator->m_pfnPushState(pSimulator, "Standstill", &_SCSIM_SSM_st_Standstill_SM1_Utils, 1017);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1022, valid, 1017, &_SCSIM_ClockActive_SSM_st_Standstill_SM1);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "1", &_SCSIM_SSM_TR_Standstill_1_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPushStrongTransition(pSimulator, "2", &_SCSIM_SSM_TR_Standstill_2_SM1_Utils, 1019);
	pSimulator->m_pfnPopStrongTransition(pSimulator);
	pSimulator->m_pfnPopState(pSimulator);
	pSimulator->m_pfnPopStateMachine(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "direction_loc", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1023, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "standstillDetected", &_SCSIM_kcg_bool_Utils, 1024, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 1025, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 1026, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 1027, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1028, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils, 1029, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 1030, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils, 1031, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 1032, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1033, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "direction", &_SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils, 1034, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg* pContext = (outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1016:
			return &((*pContext).rem_currentOdometry);
		case 1017:
			return &((*pContext).SM1_state_act);
		case 1018:
			return &((*pContext)._L1_SM1_Unknown);
		case 1019:
			return &((*pContext).SM1_fired_strong);
		case 1020:
			return &((*pContext)._L1_SM1_Decreasing);
		case 1021:
			return &((*pContext)._L1_SM1_Increasing);
		case 1022:
			return &((*pContext)._L1_SM1_Standstill);
		case 1023:
			return &((*pContext).direction_loc);
		case 1024:
			return &((*pContext).standstillDetected);
		case 1025:
			return &((*pContext)._L5);
		case 1026:
			return &((*pContext)._L6);
		case 1027:
			return &((*pContext)._L7);
		case 1028:
			return &((*pContext)._L8);
		case 1029:
			return &((*pContext)._L10);
		case 1030:
			return &((*pContext)._L11);
		case 1031:
			return &((*pContext)._L12);
		case 1032:
			return &((*pContext)._L13);
		case 1033:
			return &((*pContext)._L14);
		case 1034:
			return &((*pContext).direction);
		default:
			break;
	}
	return 0;
}

static int IsSSM_TR_Unknown_1_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Unknown_1_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Unknown_1_SM1_Utils = {IsSSM_TR_Unknown_1_SM1Active};

static int IsSSM_TR_Unknown_2_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Unknown_2_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Unknown_2_SM1_Utils = {IsSSM_TR_Unknown_2_SM1Active};

static int IsSSM_TR_Unknown_3_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Unknown_3_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Unknown_3_SM1_Utils = {IsSSM_TR_Unknown_3_SM1Active};

static int IsSSM_st_Unknown_SM1Active(void * pHandle) {
	return *((SSM_ST_SM1*)pHandle) == SSM_st_Unknown_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_st_Unknown_SM1_Utils = {IsSSM_st_Unknown_SM1Active};

static int IsSSM_TR_Decreasing_1_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Decreasing_1_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Decreasing_1_SM1_Utils = {IsSSM_TR_Decreasing_1_SM1Active};

static int IsSSM_TR_Decreasing_2_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Decreasing_2_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Decreasing_2_SM1_Utils = {IsSSM_TR_Decreasing_2_SM1Active};

static int IsSSM_st_Decreasing_SM1Active(void * pHandle) {
	return *((SSM_ST_SM1*)pHandle) == SSM_st_Decreasing_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_st_Decreasing_SM1_Utils = {IsSSM_st_Decreasing_SM1Active};

static int IsSSM_TR_Increasing_1_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Increasing_1_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Increasing_1_SM1_Utils = {IsSSM_TR_Increasing_1_SM1Active};

static int IsSSM_TR_Increasing_2_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Increasing_2_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Increasing_2_SM1_Utils = {IsSSM_TR_Increasing_2_SM1Active};

static int IsSSM_st_Increasing_SM1Active(void * pHandle) {
	return *((SSM_ST_SM1*)pHandle) == SSM_st_Increasing_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_st_Increasing_SM1_Utils = {IsSSM_st_Increasing_SM1Active};

static int IsSSM_TR_Standstill_1_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Standstill_1_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Standstill_1_SM1_Utils = {IsSSM_TR_Standstill_1_SM1Active};

static int IsSSM_TR_Standstill_2_SM1Active(void * pHandle) {
	return *((SSM_TR_SM1*)pHandle) == SSM_TR_Standstill_2_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_TR_Standstill_2_SM1_Utils = {IsSSM_TR_Standstill_2_SM1Active};

static int IsSSM_st_Standstill_SM1Active(void * pHandle) {
	return *((SSM_ST_SM1*)pHandle) == SSM_st_Standstill_SM1 ? 1 : 0;
}
ControlUtils _SCSIM_SSM_st_Standstill_SM1_Utils = {IsSSM_st_Standstill_SM1Active};

/****************************************************************
 ** BasicLocationFunctions_Pkg::sub_2_odoDistances/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_sub_2_odoDistances_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1035, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1036, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1037, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1038, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 1039, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1040, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1041, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 1042, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1043, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1044, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1045, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1046, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 1047, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1048, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1049, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 1050, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 1051, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1052, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "distance", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1053, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_sub_2_odoDistances_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_sub_2_odoDistances_BasicLocationFunctions_Pkg* pContext = (outC_sub_2_odoDistances_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1035:
			return &((*pContext)._L1);
		case 1036:
			return &((*pContext)._L2);
		case 1037:
			return &((*pContext)._L3);
		case 1038:
			return &((*pContext)._L4);
		case 1039:
			return &((*pContext)._L5);
		case 1040:
			return &((*pContext)._L17);
		case 1041:
			return &((*pContext)._L16);
		case 1042:
			return &((*pContext)._L15);
		case 1043:
			return &((*pContext)._L14);
		case 1044:
			return &((*pContext)._L13);
		case 1045:
			return &((*pContext)._L22);
		case 1046:
			return &((*pContext)._L21);
		case 1047:
			return &((*pContext)._L20);
		case 1048:
			return &((*pContext)._L19);
		case 1049:
			return &((*pContext)._L18);
		case 1050:
			return &((*pContext)._L23);
		case 1051:
			return &((*pContext)._L24);
		case 1052:
			return &((*pContext)._L31);
		case 1053:
			return &((*pContext).distance);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** BasicLocationFunctions_Pkg::add_odo_2_Location/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_add_odo_2_Location_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "1", 1054, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "1", 1055, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1056, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1057, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1058, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1059, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1060, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "location", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1061, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_add_odo_2_Location_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_add_odo_2_Location_BasicLocationFunctions_Pkg* pContext = (outC_add_odo_2_Location_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1054:
			return &((*pContext).Context_1);
		case 1055:
			return &((*pContext)._1_Context_1);
		case 1056:
			return &((*pContext)._L1);
		case 1057:
			return &((*pContext)._L2);
		case 1058:
			return &((*pContext)._L3);
		case 1059:
			return &((*pContext)._L4);
		case 1060:
			return &((*pContext)._L5);
		case 1061:
			return &((*pContext).location);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfLastPassedBG_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1062, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 1063, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_Q_LINK_Utils, 1064, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_Q_LINK_Utils, 1065, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_bool_Utils, 1066, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_bool_Utils, 1067, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_bool_Utils, 1068, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_bool_Utils, 1069, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_int_Utils, 1070, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_kcg_int_Utils, 1071, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_kcg_int_Utils, 1072, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_kcg_bool_Utils, 1073, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_Q_LINK_Utils, 1074, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_Q_LINK_Utils, 1075, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1076, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 1077, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfLastPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1062:
			return &((*pContext)._L4);
		case 1063:
			return &((*pContext)._L19);
		case 1064:
			return &((*pContext)._L20);
		case 1065:
			return &((*pContext)._L21);
		case 1066:
			return &((*pContext)._L22);
		case 1067:
			return &((*pContext)._L23);
		case 1068:
			return &((*pContext)._L25);
		case 1069:
			return &((*pContext)._L26);
		case 1070:
			return &((*pContext)._L27);
		case 1071:
			return &((*pContext)._L28);
		case 1072:
			return &((*pContext)._L29);
		case 1073:
			return &((*pContext)._L30);
		case 1074:
			return &((*pContext)._L31);
		case 1075:
			return &((*pContext)._L32);
		case 1076:
			return &((*pContext).cont);
		case 1077:
			return &((*pContext).indexOfBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::countBGs_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1078, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1079, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 1080, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 1081, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 1082, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 1083, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 1084, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_Q_LINK_Utils, 1085, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_Q_LINK_Utils, 1086, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 1087, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_bool_Utils, 1088, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_bool_Utils, 1089, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 1090, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 1091, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_int_Utils, 1092, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 1093, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 1094, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 1095, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_int_Utils, 1096, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_int_Utils, 1097, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 1098, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_kcg_int_Utils, 1099, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_kcg_int_Utils, 1100, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_kcg_int_Utils, 1101, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_kcg_int_Utils, 1102, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_kcg_int_Utils, 1103, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L35", &_SCSIM_kcg_int_Utils, 1104, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L34", &_SCSIM_kcg_int_Utils, 1105, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L37", &_SCSIM_kcg_int_Utils, 1106, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L36", &_SCSIM_kcg_int_Utils, 1107, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L40", &_SCSIM_kcg_int_Utils, 1108, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L41", &_SCSIM_kcg_int_Utils, 1109, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L42", &_SCSIM_kcg_int_Utils, 1110, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L44", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1111, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L43", &_SCSIM_kcg_bool_Utils, 1112, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L45", &_SCSIM_kcg_bool_Utils, 1113, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L46", &_SCSIM_kcg_bool_Utils, 1114, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L47", &_SCSIM_kcg_bool_Utils, 1115, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L48", &_SCSIM_kcg_bool_Utils, 1116, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1117, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "counters_out", &_SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 1118, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_countBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1078:
			return &((*pContext)._L1);
		case 1079:
			return &((*pContext)._L2);
		case 1080:
			return &((*pContext)._L8);
		case 1081:
			return &((*pContext)._L7);
		case 1082:
			return &((*pContext)._L6);
		case 1083:
			return &((*pContext)._L9);
		case 1084:
			return &((*pContext)._L10);
		case 1085:
			return &((*pContext)._L11);
		case 1086:
			return &((*pContext)._L12);
		case 1087:
			return &((*pContext)._L13);
		case 1088:
			return &((*pContext)._L14);
		case 1089:
			return &((*pContext)._L15);
		case 1090:
			return &((*pContext)._L17);
		case 1091:
			return &((*pContext)._L18);
		case 1092:
			return &((*pContext)._L19);
		case 1093:
			return &((*pContext)._L22);
		case 1094:
			return &((*pContext)._L21);
		case 1095:
			return &((*pContext)._L20);
		case 1096:
			return &((*pContext)._L25);
		case 1097:
			return &((*pContext)._L24);
		case 1098:
			return &((*pContext)._L23);
		case 1099:
			return &((*pContext)._L29);
		case 1100:
			return &((*pContext)._L30);
		case 1101:
			return &((*pContext)._L31);
		case 1102:
			return &((*pContext)._L33);
		case 1103:
			return &((*pContext)._L32);
		case 1104:
			return &((*pContext)._L35);
		case 1105:
			return &((*pContext)._L34);
		case 1106:
			return &((*pContext)._L37);
		case 1107:
			return &((*pContext)._L36);
		case 1108:
			return &((*pContext)._L40);
		case 1109:
			return &((*pContext)._L41);
		case 1110:
			return &((*pContext)._L42);
		case 1111:
			return &((*pContext)._L44);
		case 1112:
			return &((*pContext)._L43);
		case 1113:
			return &((*pContext)._L45);
		case 1114:
			return &((*pContext)._L46);
		case 1115:
			return &((*pContext)._L47);
		case 1116:
			return &((*pContext)._L48);
		case 1117:
			return &((*pContext).cont);
		case 1118:
			return &((*pContext).counters_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOf_nthPassedBG_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1119, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 1120, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_Q_LINK_Utils, 1121, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_Q_LINK_Utils, 1122, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_bool_Utils, 1123, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_bool_Utils, 1124, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_bool_Utils, 1125, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_bool_Utils, 1126, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_int_Utils, 1127, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_kcg_int_Utils, 1128, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_kcg_bool_Utils, 1129, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_Q_LINK_Utils, 1130, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_Q_LINK_Utils, 1131, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 1132, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L37", &_SCSIM_kcg_int_Utils, 1133, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L38", &_SCSIM_kcg_int_Utils, 1134, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L39", &_SCSIM_kcg_int_Utils, 1135, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L40", &_SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 1136, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L42", &_SCSIM_kcg_int_Utils, 1137, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L43", &_SCSIM_kcg_bool_Utils, 1138, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L44", &_SCSIM_kcg_bool_Utils, 1139, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L53", &_SCSIM_kcg_bool_Utils, 1140, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L52", &_SCSIM_kcg_int_Utils, 1141, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L51", &_SCSIM_kcg_int_Utils, 1142, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L54", &_SCSIM_kcg_bool_Utils, 1143, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L55", &_SCSIM_kcg_bool_Utils, 1144, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1145, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "acc_out", &_SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils, 1146, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOf_nthPassedBG_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1119:
			return &((*pContext)._L4);
		case 1120:
			return &((*pContext)._L19);
		case 1121:
			return &((*pContext)._L20);
		case 1122:
			return &((*pContext)._L21);
		case 1123:
			return &((*pContext)._L22);
		case 1124:
			return &((*pContext)._L23);
		case 1125:
			return &((*pContext)._L25);
		case 1126:
			return &((*pContext)._L26);
		case 1127:
			return &((*pContext)._L27);
		case 1128:
			return &((*pContext)._L28);
		case 1129:
			return &((*pContext)._L30);
		case 1130:
			return &((*pContext)._L31);
		case 1131:
			return &((*pContext)._L32);
		case 1132:
			return &((*pContext)._L33);
		case 1133:
			return &((*pContext)._L37);
		case 1134:
			return &((*pContext)._L38);
		case 1135:
			return &((*pContext)._L39);
		case 1136:
			return &((*pContext)._L40);
		case 1137:
			return &((*pContext)._L42);
		case 1138:
			return &((*pContext)._L43);
		case 1139:
			return &((*pContext)._L44);
		case 1140:
			return &((*pContext)._L53);
		case 1141:
			return &((*pContext)._L52);
		case 1142:
			return &((*pContext)._L51);
		case 1143:
			return &((*pContext)._L54);
		case 1144:
			return &((*pContext)._L55);
		case 1145:
			return &((*pContext).cont);
		case 1146:
			return &((*pContext).acc_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBGs_beforeIndex_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1147, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 1148, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 1149, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1150, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 1151, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1152, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_int_Utils, 1153, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 1154, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1155, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1156, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1157, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_deleteBGs_beforeIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1147:
			return &((*pContext)._L10);
		case 1148:
			return &((*pContext)._L9);
		case 1149:
			return &((*pContext)._L8);
		case 1150:
			return &((*pContext)._L7);
		case 1151:
			return &((*pContext)._L6);
		case 1152:
			return &((*pContext)._L5);
		case 1153:
			return &((*pContext)._L4);
		case 1154:
			return &((*pContext)._L3);
		case 1155:
			return &((*pContext)._L2);
		case 1156:
			return &((*pContext).cont);
		case 1157:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_by_id_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal", "1", 1158, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1159, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1160, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 1161, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1162, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_int_Utils, 1163, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 1164, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 1165, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1166, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 1167, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfBG_by_id_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1158:
			return &((*pContext).Context_1);
		case 1159:
			return &((*pContext)._L3);
		case 1160:
			return &((*pContext)._L4);
		case 1161:
			return &((*pContext)._L6);
		case 1162:
			return &((*pContext)._L8);
		case 1163:
			return &((*pContext)._L11);
		case 1164:
			return &((*pContext)._L16);
		case 1165:
			return &((*pContext)._L18);
		case 1166:
			return &((*pContext).cont);
		case 1167:
			return &((*pContext).indexOfBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapfold", 4, 4);
	_SCSIM_Mapping_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs_itr", "1", 1168, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1169, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LinkedBGs_T_BG_Types_Pkg_Utils, 1170, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_array__5740_Utils, 1171, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_array__5740_Utils, 1172, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1173, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1174, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1175, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_array__5762_Utils, 1176, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "linkedPositionedBGs", &_SCSIM_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils, 1177, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1168:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 1169:
			return &((*pContext)._L1);
		case 1170:
			return &((*pContext)._L2);
		case 1171:
			return &((*pContext)._L3);
		case 1172:
			return &((*pContext)._L4);
		case 1173:
			return &((*pContext)._L6);
		case 1174:
			return &((*pContext)._L7);
		case 1175:
			return &((*pContext)._L8);
		case 1176:
			return &((*pContext)._L9);
		case 1177:
			return &((*pContext).linkedPositionedBGs);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "foldwi", 8, 8);
	_SCSIM_Mapping_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack_itr", "1", 1178, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	_SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal", "1", 1179, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1180, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1181, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 1182, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_int_Utils, 1183, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 1184, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 1185, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_array__5687_Utils, 1186, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1187, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 1188, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 1189, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 1190, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_bool_Utils, 1191, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 1192, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_found", &_SCSIM_kcg_bool_Utils, 1193, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexValid", &_SCSIM_kcg_bool_Utils, 1194, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1178:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 1179:
			return &((*pContext)._1_Context_1);
		case 1180:
			return &((*pContext)._L1);
		case 1181:
			return &((*pContext)._L2);
		case 1182:
			return &((*pContext)._L3);
		case 1183:
			return &((*pContext)._L6);
		case 1184:
			return &((*pContext)._L8);
		case 1185:
			return &((*pContext)._L9);
		case 1186:
			return &((*pContext)._L11);
		case 1187:
			return &((*pContext)._L12);
		case 1188:
			return &((*pContext)._L17);
		case 1189:
			return &((*pContext)._L18);
		case 1190:
			return &((*pContext)._L19);
		case 1191:
			return &((*pContext)._L20);
		case 1192:
			return &((*pContext).indexOfBG);
		case 1193:
			return &((*pContext).BG_found);
		case 1194:
			return &((*pContext).indexValid);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapwi", 8, 8);
	_SCSIM_Mapping_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr", "1", 1195, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_bool_Utils, 1196, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1197, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 1198, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 1199, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 1200, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 1201, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 1202, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1203, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_array_int_8_Utils, 1204, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_array__5768_Utils, 1205, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1206, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_array__5771_Utils, 1207, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_array__5687_Utils, 1208, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_array__5687_Utils, 1209, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 1210, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_array__5687_Utils, 1211, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1212, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1213, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_deleteBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1195:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 1196:
			return &((*pContext)._L1);
		case 1197:
			return &((*pContext)._L2);
		case 1198:
			return &((*pContext)._L3);
		case 1199:
			return &((*pContext)._L4);
		case 1200:
			return &((*pContext)._L5);
		case 1201:
			return &((*pContext)._L6);
		case 1202:
			return &((*pContext)._L7);
		case 1203:
			return &((*pContext)._L8);
		case 1204:
			return &((*pContext)._L9);
		case 1205:
			return &((*pContext)._L10);
		case 1206:
			return &((*pContext)._L11);
		case 1207:
			return &((*pContext)._L12);
		case 1208:
			return &((*pContext)._L13);
		case 1209:
			return &((*pContext)._L15);
		case 1210:
			return &((*pContext)._L16);
		case 1211:
			return &((*pContext)._L17);
		case 1212:
			return &((*pContext)._L18);
		case 1213:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapwi", 8, 8);
	_SCSIM_Mapping_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr", "1", 1214, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	_SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal", "1", 1215, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_kcg_bool_Utils, 1216, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1217, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_int_Utils, 1218, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 1219, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 1220, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 1221, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 1222, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1223, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_array_int_8_Utils, 1224, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_array__5768_Utils, 1225, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1226, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_array__5771_Utils, 1227, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_array__5687_Utils, 1228, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_array__5687_Utils, 1229, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 1230, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_array__5687_Utils, 1231, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1232, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1233, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_array__5687_Utils, 1234, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1235, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1236, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_int_Utils, 1237, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_bool_Utils, 1238, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1239, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_bool_Utils, 1240, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1241, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1242, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_kcg_bool_Utils, 1243, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_kcg_bool_Utils, 1244, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_kcg_bool_Utils, 1245, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_kcg_bool_Utils, 1246, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L34", &_SCSIM_kcg_bool_Utils, 1247, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1248, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "overrun", &_SCSIM_kcg_bool_Utils, 1249, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_insertBG_atIndex_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1214:
			if (nSize != 1)
				break;
			return &((*pContext)._1_Context_1[pIteratorFilter[0]]);
		case 1215:
			return &((*pContext).Context_1);
		case 1216:
			return &((*pContext)._L1);
		case 1217:
			return &((*pContext)._L2);
		case 1218:
			return &((*pContext)._L3);
		case 1219:
			return &((*pContext)._L4);
		case 1220:
			return &((*pContext)._L5);
		case 1221:
			return &((*pContext)._L6);
		case 1222:
			return &((*pContext)._L7);
		case 1223:
			return &((*pContext)._L8);
		case 1224:
			return &((*pContext)._L9);
		case 1225:
			return &((*pContext)._L10);
		case 1226:
			return &((*pContext)._L11);
		case 1227:
			return &((*pContext)._L12);
		case 1228:
			return &((*pContext)._L13);
		case 1229:
			return &((*pContext)._L15);
		case 1230:
			return &((*pContext)._L16);
		case 1231:
			return &((*pContext)._L17);
		case 1232:
			return &((*pContext)._L18);
		case 1233:
			return &((*pContext)._L19);
		case 1234:
			return &((*pContext)._L20);
		case 1235:
			return &((*pContext)._L21);
		case 1236:
			return &((*pContext)._L22);
		case 1237:
			return &((*pContext)._L23);
		case 1238:
			return &((*pContext)._L25);
		case 1239:
			return &((*pContext)._L26);
		case 1240:
			return &((*pContext)._L27);
		case 1241:
			return &((*pContext)._L28);
		case 1242:
			return &((*pContext)._L29);
		case 1243:
			return &((*pContext)._L30);
		case 1244:
			return &((*pContext)._L31);
		case 1245:
			return &((*pContext)._L32);
		case 1246:
			return &((*pContext)._L33);
		case 1247:
			return &((*pContext)._L34);
		case 1248:
			return &((*pContext).BGs_out);
		case 1249:
			return &((*pContext).overrun);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBGs_onTrack_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_mergeBG_onTrack_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::mergeBG_onTrack", "1", 1250, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1251, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, 1252, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 1253, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1254, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, 1255, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_bool_Utils, 1256, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1257, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_kcg_bool_Utils, 1258, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_out", &_SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils, 1259, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_mergeBGs_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1250:
			return &((*pContext).Context_1);
		case 1251:
			return &((*pContext)._L1);
		case 1252:
			return &((*pContext)._L2);
		case 1253:
			return &((*pContext)._L13);
		case 1254:
			return &((*pContext)._L12);
		case 1255:
			return &((*pContext)._L14);
		case 1256:
			return &((*pContext)._L18);
		case 1257:
			return &((*pContext)._L17);
		case 1258:
			return &((*pContext)._L19);
		case 1259:
			return &((*pContext).BGs_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::trimSeqNoOnTrack_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1260, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 1261, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 1262, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 1263, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 1264, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 1265, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 1266, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_int_Utils, 1267, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 1268, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1269, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "seqNo", &_SCSIM_kcg_int_Utils, 1270, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1271, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_trimSeqNoOnTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1260:
			return &((*pContext)._L2);
		case 1261:
			return &((*pContext)._L3);
		case 1262:
			return &((*pContext)._L4);
		case 1263:
			return &((*pContext)._L6);
		case 1264:
			return &((*pContext)._L7);
		case 1265:
			return &((*pContext)._L8);
		case 1266:
			return &((*pContext)._L13);
		case 1267:
			return &((*pContext)._L14);
		case 1268:
			return &((*pContext)._L15);
		case 1269:
			return &((*pContext)._L16);
		case 1270:
			return &((*pContext).seqNo);
		case 1271:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_ahead_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal", "3", 1272, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "2", 1273, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "2", 1274, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "3", 1275, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "3", 1276, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "6", 1277, 0, 0);
	_SCSIM_Mapping_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies", "", 1278, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "7", 1279, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "4", 1280, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "8", 1281, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "4", 1282, 0, 0);
	_SCSIM_Mapping_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_ahead", "1", 1283, 1284, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "9", 1285, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "12", 1286, 0, 0);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "1", 1287, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "BGin_is_refBG", &_SCSIM_kcg_bool_Utils, 1288, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "recalculateSubsequentBGs", &_SCSIM_kcg_bool_Utils, 1289, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "refLocation", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1290, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "refBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1291, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "prevLinkedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1292, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "prevUnlinkedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1293, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "relocatedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1294, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "BG_loc_inacc", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1295, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "sumOfBestDistances", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1296, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "d_prevLinkedBG_refBG", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1297, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L36", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1298, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L59", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1299, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L52", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1300, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L51", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1301, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L61", &_SCSIM_kcg_bool_Utils, 1302, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L71", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1303, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L69", &_SCSIM_kcg_bool_Utils, 1304, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_kcg_bool_Utils, 1305, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L64", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1306, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L75", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1307, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L76", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1308, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L77", &_SCSIM_kcg_bool_Utils, 1309, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L78", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1310, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L80", &_SCSIM_kcg_bool_Utils, 1311, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L81", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1312, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L82", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1313, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L83", &_SCSIM_kcg_bool_Utils, 1314, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L84", &_SCSIM_kcg_bool_Utils, 1315, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L85", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1316, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L86", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1317, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L87", &_SCSIM_kcg_bool_Utils, 1318, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L88", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1319, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L89", &_SCSIM_kcg_bool_Utils, 1320, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L90", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1321, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L92", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1322, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L93", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1323, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L94", &_SCSIM_kcg_bool_Utils, 1324, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L95", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1325, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L96", &_SCSIM_kcg_bool_Utils, 1326, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L97", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1327, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L98", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1328, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L99", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1329, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L105", &_SCSIM_Q_LINK_Utils, 1330, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L106", &_SCSIM_kcg_bool_Utils, 1331, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L107", &_SCSIM_Q_LINK_Utils, 1332, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L108", &_SCSIM_Q_LINK_Utils, 1333, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L109", &_SCSIM_kcg_bool_Utils, 1334, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L110", &_SCSIM_Q_LINK_Utils, 1335, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L111", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1336, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L113", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1337, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L112", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1338, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L144", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1339, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L143", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1340, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L142", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1341, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L141", &_SCSIM_Q_LINK_Utils, 1342, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L140", &_SCSIM_kcg_bool_Utils, 1343, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L139", &_SCSIM_Q_LINK_Utils, 1344, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L138", &_SCSIM_Q_LINK_Utils, 1345, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L137", &_SCSIM_kcg_bool_Utils, 1346, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L136", &_SCSIM_Q_LINK_Utils, 1347, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L134", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1348, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L133", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1349, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L132", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1350, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L131", &_SCSIM_kcg_bool_Utils, 1351, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L130", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1352, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L129", &_SCSIM_kcg_bool_Utils, 1353, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L128", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1354, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L127", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1355, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L126", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1356, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L125", &_SCSIM_kcg_bool_Utils, 1357, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L124", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1358, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L123", &_SCSIM_kcg_bool_Utils, 1359, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L122", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1360, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L121", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1361, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L120", &_SCSIM_kcg_bool_Utils, 1362, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L119", &_SCSIM_kcg_bool_Utils, 1363, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L118", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1364, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L117", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1365, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L116", &_SCSIM_kcg_bool_Utils, 1366, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L115", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1367, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L114", &_SCSIM_kcg_bool_Utils, 1368, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L148", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1369, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L149", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1370, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L152", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1371, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L154", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1372, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L155", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1373, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L156", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1374, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L157", &_SCSIM_kcg_bool_Utils, 1375, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L158", &_SCSIM_kcg_bool_Utils, 1376, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L159", &_SCSIM_kcg_bool_Utils, 1377, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L160", &_SCSIM_kcg_bool_Utils, 1378, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L161", &_SCSIM_kcg_bool_Utils, 1379, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L162", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1380, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L163", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1381, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L164", &_SCSIM_kcg_bool_Utils, 1382, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L165", &_SCSIM_kcg_bool_Utils, 1383, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L167", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1384, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L168", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1385, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L169", &_SCSIM_kcg_bool_Utils, 1386, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L172", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1387, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L173", &_SCSIM_kcg_bool_Utils, 1388, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L174", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1389, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L175", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1390, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L62", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1391, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L74", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1392, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L147", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1393, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L188", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1394, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L197", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1395, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L216", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1396, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L217", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1397, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L218", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1398, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L219", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1399, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L220", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1400, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L229", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1401, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L230", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1402, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L236", &_SCSIM_kcg_bool_Utils, 1403, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L240", &_SCSIM_Q_LINK_Utils, 1404, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L239", &_SCSIM_kcg_bool_Utils, 1405, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L238", &_SCSIM_Q_LINK_Utils, 1406, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L237", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1407, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L243", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1408, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L244", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1409, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L253", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 1410, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L254", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1411, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L255", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1412, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L256", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1413, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L257", &_SCSIM_kcg_bool_Utils, 1414, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L258", &_SCSIM_kcg_bool_Utils, 1415, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L259", &_SCSIM_kcg_bool_Utils, 1416, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L260", &_SCSIM_kcg_bool_Utils, 1417, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L265", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1418, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L267", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1419, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L268", &_SCSIM_kcg_bool_Utils, 1420, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L269", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1421, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L270", &_SCSIM_kcg_bool_Utils, 1422, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L271", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1423, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L273", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1424, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L274", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1425, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L275", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1426, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L276", &_SCSIM_kcg_bool_Utils, 1427, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L277", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1428, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L278", &_SCSIM_kcg_bool_Utils, 1429, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L279", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1430, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L280", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1431, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L281", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1432, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L282", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1433, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L285", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1434, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L286", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1435, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L287", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1436, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L288", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1437, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L289", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1438, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L290", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1439, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L291", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1440, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L292", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1441, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L293", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1442, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L294", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1443, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L296", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1444, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L297", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1445, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L300", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1446, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L301", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1447, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L303", &_SCSIM_kcg_bool_Utils, 1448, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L302", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1449, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L304", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1450, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L305", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1451, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 1284, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "refBGs_out", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1452, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1453, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_recalculate_BG_locations_ahead_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1272:
			return &((*pContext).Context_3);
		case 1273:
			return &((*pContext).Context_2);
		case 1274:
			return &((*pContext)._5_Context_2);
		case 1275:
			return &((*pContext)._4_Context_3);
		case 1276:
			return &((*pContext)._2_Context_3);
		case 1277:
			return &((*pContext).Context_6);
		case 1278:
			return &((*pContext).Context_calculateLocalBGInaccuracies);
		case 1279:
			return &((*pContext).Context_7);
		case 1280:
			return &((*pContext)._1_Context_4);
		case 1281:
			return &((*pContext).Context_8);
		case 1282:
			return &((*pContext).Context_4);
		case 1283:
			return &((*pContext)._3_Context_1);
		case 1285:
			return &((*pContext).Context_9);
		case 1286:
			return &((*pContext).Context_12);
		case 1287:
			return &((*pContext).Context_1);
		case 1288:
			return &((*pContext).BGin_is_refBG);
		case 1289:
			return &((*pContext).recalculateSubsequentBGs);
		case 1290:
			return &((*pContext).refLocation);
		case 1291:
			return &((*pContext).refBG);
		case 1292:
			return &((*pContext).prevLinkedBG);
		case 1293:
			return &((*pContext).prevUnlinkedBG);
		case 1294:
			return &((*pContext).relocatedBG);
		case 1295:
			return &((*pContext).BG_loc_inacc);
		case 1296:
			return &((*pContext).sumOfBestDistances);
		case 1297:
			return &((*pContext).d_prevLinkedBG_refBG);
		case 1298:
			return &((*pContext)._L36);
		case 1299:
			return &((*pContext)._L59);
		case 1300:
			return &((*pContext)._L52);
		case 1301:
			return &((*pContext)._L51);
		case 1302:
			return &((*pContext)._L61);
		case 1303:
			return &((*pContext)._L71);
		case 1304:
			return &((*pContext)._L69);
		case 1305:
			return &((*pContext)._L67);
		case 1306:
			return &((*pContext)._L64);
		case 1307:
			return &((*pContext)._L75);
		case 1308:
			return &((*pContext)._L76);
		case 1309:
			return &((*pContext)._L77);
		case 1310:
			return &((*pContext)._L78);
		case 1311:
			return &((*pContext)._L80);
		case 1312:
			return &((*pContext)._L81);
		case 1313:
			return &((*pContext)._L82);
		case 1314:
			return &((*pContext)._L83);
		case 1315:
			return &((*pContext)._L84);
		case 1316:
			return &((*pContext)._L85);
		case 1317:
			return &((*pContext)._L86);
		case 1318:
			return &((*pContext)._L87);
		case 1319:
			return &((*pContext)._L88);
		case 1320:
			return &((*pContext)._L89);
		case 1321:
			return &((*pContext)._L90);
		case 1322:
			return &((*pContext)._L92);
		case 1323:
			return &((*pContext)._L93);
		case 1324:
			return &((*pContext)._L94);
		case 1325:
			return &((*pContext)._L95);
		case 1326:
			return &((*pContext)._L96);
		case 1327:
			return &((*pContext)._L97);
		case 1328:
			return &((*pContext)._L98);
		case 1329:
			return &((*pContext)._L99);
		case 1330:
			return &((*pContext)._L105);
		case 1331:
			return &((*pContext)._L106);
		case 1332:
			return &((*pContext)._L107);
		case 1333:
			return &((*pContext)._L108);
		case 1334:
			return &((*pContext)._L109);
		case 1335:
			return &((*pContext)._L110);
		case 1336:
			return &((*pContext)._L111);
		case 1337:
			return &((*pContext)._L113);
		case 1338:
			return &((*pContext)._L112);
		case 1339:
			return &((*pContext)._L144);
		case 1340:
			return &((*pContext)._L143);
		case 1341:
			return &((*pContext)._L142);
		case 1342:
			return &((*pContext)._L141);
		case 1343:
			return &((*pContext)._L140);
		case 1344:
			return &((*pContext)._L139);
		case 1345:
			return &((*pContext)._L138);
		case 1346:
			return &((*pContext)._L137);
		case 1347:
			return &((*pContext)._L136);
		case 1348:
			return &((*pContext)._L134);
		case 1349:
			return &((*pContext)._L133);
		case 1350:
			return &((*pContext)._L132);
		case 1351:
			return &((*pContext)._L131);
		case 1352:
			return &((*pContext)._L130);
		case 1353:
			return &((*pContext)._L129);
		case 1354:
			return &((*pContext)._L128);
		case 1355:
			return &((*pContext)._L127);
		case 1356:
			return &((*pContext)._L126);
		case 1357:
			return &((*pContext)._L125);
		case 1358:
			return &((*pContext)._L124);
		case 1359:
			return &((*pContext)._L123);
		case 1360:
			return &((*pContext)._L122);
		case 1361:
			return &((*pContext)._L121);
		case 1362:
			return &((*pContext)._L120);
		case 1363:
			return &((*pContext)._L119);
		case 1364:
			return &((*pContext)._L118);
		case 1365:
			return &((*pContext)._L117);
		case 1366:
			return &((*pContext)._L116);
		case 1367:
			return &((*pContext)._L115);
		case 1368:
			return &((*pContext)._L114);
		case 1369:
			return &((*pContext)._L148);
		case 1370:
			return &((*pContext)._L149);
		case 1371:
			return &((*pContext)._L152);
		case 1372:
			return &((*pContext)._L154);
		case 1373:
			return &((*pContext)._L155);
		case 1374:
			return &((*pContext)._L156);
		case 1375:
			return &((*pContext)._L157);
		case 1376:
			return &((*pContext)._L158);
		case 1377:
			return &((*pContext)._L159);
		case 1378:
			return &((*pContext)._L160);
		case 1379:
			return &((*pContext)._L161);
		case 1380:
			return &((*pContext)._L162);
		case 1381:
			return &((*pContext)._L163);
		case 1382:
			return &((*pContext)._L164);
		case 1383:
			return &((*pContext)._L165);
		case 1384:
			return &((*pContext)._L167);
		case 1385:
			return &((*pContext)._L168);
		case 1386:
			return &((*pContext)._L169);
		case 1387:
			return &((*pContext)._L172);
		case 1388:
			return &((*pContext)._L173);
		case 1389:
			return &((*pContext)._L174);
		case 1390:
			return &((*pContext)._L175);
		case 1391:
			return &((*pContext)._L62);
		case 1392:
			return &((*pContext)._L74);
		case 1393:
			return &((*pContext)._L147);
		case 1394:
			return &((*pContext)._L188);
		case 1395:
			return &((*pContext)._L197);
		case 1396:
			return &((*pContext)._L216);
		case 1397:
			return &((*pContext)._L217);
		case 1398:
			return &((*pContext)._L218);
		case 1399:
			return &((*pContext)._L219);
		case 1400:
			return &((*pContext)._L220);
		case 1401:
			return &((*pContext)._L229);
		case 1402:
			return &((*pContext)._L230);
		case 1403:
			return &((*pContext)._L236);
		case 1404:
			return &((*pContext)._L240);
		case 1405:
			return &((*pContext)._L239);
		case 1406:
			return &((*pContext)._L238);
		case 1407:
			return &((*pContext)._L237);
		case 1408:
			return &((*pContext)._L243);
		case 1409:
			return &((*pContext)._L244);
		case 1410:
			return &((*pContext)._L253);
		case 1411:
			return &((*pContext)._L254);
		case 1412:
			return &((*pContext)._L255);
		case 1413:
			return &((*pContext)._L256);
		case 1414:
			return &((*pContext)._L257);
		case 1415:
			return &((*pContext)._L258);
		case 1416:
			return &((*pContext)._L259);
		case 1417:
			return &((*pContext)._L260);
		case 1418:
			return &((*pContext)._L265);
		case 1419:
			return &((*pContext)._L267);
		case 1420:
			return &((*pContext)._L268);
		case 1421:
			return &((*pContext)._L269);
		case 1422:
			return &((*pContext)._L270);
		case 1423:
			return &((*pContext)._L271);
		case 1424:
			return &((*pContext)._L273);
		case 1425:
			return &((*pContext)._L274);
		case 1426:
			return &((*pContext)._L275);
		case 1427:
			return &((*pContext)._L276);
		case 1428:
			return &((*pContext)._L277);
		case 1429:
			return &((*pContext)._L278);
		case 1430:
			return &((*pContext)._L279);
		case 1431:
			return &((*pContext)._L280);
		case 1432:
			return &((*pContext)._L281);
		case 1433:
			return &((*pContext)._L282);
		case 1434:
			return &((*pContext)._L285);
		case 1435:
			return &((*pContext)._L286);
		case 1436:
			return &((*pContext)._L287);
		case 1437:
			return &((*pContext)._L288);
		case 1438:
			return &((*pContext)._L289);
		case 1439:
			return &((*pContext)._L290);
		case 1440:
			return &((*pContext)._L291);
		case 1441:
			return &((*pContext)._L292);
		case 1442:
			return &((*pContext)._L293);
		case 1443:
			return &((*pContext)._L294);
		case 1444:
			return &((*pContext)._L296);
		case 1445:
			return &((*pContext)._L297);
		case 1446:
			return &((*pContext)._L300);
		case 1447:
			return &((*pContext)._L301);
		case 1448:
			return &((*pContext)._L303);
		case 1449:
			return &((*pContext)._L302);
		case 1450:
			return &((*pContext)._L304);
		case 1451:
			return &((*pContext)._L305);
		case 1284:
			return &((*pContext).tmp);
		case 1452:
			return &((*pContext).refBGs_out);
		case 1453:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_locations_astern_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal", "1", 1454, 0, 0);
	_SCSIM_Mapping_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern", "1", 1455, 1456, &_SCSIM_ClockActive_kcg_true);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "1", 1457, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "1", 1458, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "2", 1459, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "2", 1460, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "3", 1461, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "BGin_is_refBG", &_SCSIM_kcg_bool_Utils, 1462, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "recalculateSubsequentBGs", &_SCSIM_kcg_bool_Utils, 1463, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "refBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1464, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "prevLinkedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1465, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "prevUnlinkedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1466, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "relocatedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1467, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "sumOfBestDistances", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1468, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L36", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1469, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L71", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1470, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L69", &_SCSIM_kcg_bool_Utils, 1471, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_kcg_bool_Utils, 1472, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L64", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1473, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L74", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1474, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L77", &_SCSIM_kcg_bool_Utils, 1475, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L78", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1476, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L80", &_SCSIM_kcg_bool_Utils, 1477, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L81", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1478, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L83", &_SCSIM_kcg_bool_Utils, 1479, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L84", &_SCSIM_kcg_bool_Utils, 1480, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L85", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1481, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L105", &_SCSIM_Q_LINK_Utils, 1482, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L106", &_SCSIM_kcg_bool_Utils, 1483, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L107", &_SCSIM_Q_LINK_Utils, 1484, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L108", &_SCSIM_Q_LINK_Utils, 1485, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L109", &_SCSIM_kcg_bool_Utils, 1486, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L110", &_SCSIM_Q_LINK_Utils, 1487, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L111", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1488, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L113", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1489, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L112", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1490, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L144", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1491, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L143", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1492, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L142", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1493, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L141", &_SCSIM_Q_LINK_Utils, 1494, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L140", &_SCSIM_kcg_bool_Utils, 1495, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L139", &_SCSIM_Q_LINK_Utils, 1496, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L138", &_SCSIM_Q_LINK_Utils, 1497, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L137", &_SCSIM_kcg_bool_Utils, 1498, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L136", &_SCSIM_Q_LINK_Utils, 1499, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L121", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1500, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L120", &_SCSIM_kcg_bool_Utils, 1501, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L119", &_SCSIM_kcg_bool_Utils, 1502, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L117", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1503, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L116", &_SCSIM_kcg_bool_Utils, 1504, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L115", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1505, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L114", &_SCSIM_kcg_bool_Utils, 1506, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L147", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1507, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L148", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1508, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L149", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1509, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L150", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1510, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L152", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1511, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L153", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1512, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L154", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1513, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L155", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1514, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L156", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1515, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L157", &_SCSIM_kcg_bool_Utils, 1516, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L158", &_SCSIM_kcg_bool_Utils, 1517, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L159", &_SCSIM_kcg_bool_Utils, 1518, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L160", &_SCSIM_kcg_bool_Utils, 1519, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L161", &_SCSIM_kcg_bool_Utils, 1520, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L162", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1521, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L172", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1522, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L173", &_SCSIM_kcg_bool_Utils, 1523, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L174", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1524, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L175", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1525, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L181", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1526, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L182", &_SCSIM_kcg_bool_Utils, 1527, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L183", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1528, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L184", &_SCSIM_kcg_bool_Utils, 1529, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L187", &_SCSIM_Q_LINK_Utils, 1530, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L186", &_SCSIM_kcg_bool_Utils, 1531, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L185", &_SCSIM_Q_LINK_Utils, 1532, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L190", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1533, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L193", &_SCSIM_kcg_bool_Utils, 1534, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L194", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 1535, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L195", &_SCSIM_kcg_bool_Utils, 1536, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L196", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1537, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L197", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1538, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L198", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1539, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L199", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1540, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L203", &_SCSIM_kcg_bool_Utils, 1541, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L204", &_SCSIM_kcg_bool_Utils, 1542, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L205", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1543, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L206", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1544, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L207", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1545, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L209", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1546, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L208", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1547, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L210", &_SCSIM_kcg_bool_Utils, 1548, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L213", &_SCSIM_kcg_bool_Utils, 1549, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L214", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1550, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L215", &_SCSIM_kcg_bool_Utils, 1551, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L216", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1552, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L217", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1553, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L218", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1554, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L220", &_SCSIM_kcg_bool_Utils, 1555, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L219", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1556, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L221", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1557, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L224", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1558, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L223", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1559, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L222", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1560, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L226", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1561, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L225", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1562, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L229", &_SCSIM_Q_LINK_Utils, 1563, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L228", &_SCSIM_Q_LINK_Utils, 1564, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L227", &_SCSIM_kcg_bool_Utils, 1565, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L230", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1566, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L231", &_SCSIM_kcg_bool_Utils, 1567, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L232", &_SCSIM_kcg_bool_Utils, 1568, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L233", &_SCSIM_kcg_bool_Utils, 1569, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L235", &_SCSIM_kcg_bool_Utils, 1570, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L234", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1571, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L236", &_SCSIM_kcg_bool_Utils, 1572, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L242", &_SCSIM_kcg_bool_Utils, 1573, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L241", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1574, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L240", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1575, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L243", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1576, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L244", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1577, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L245", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1578, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L246", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1579, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L247", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1580, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L248", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1581, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L249", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1582, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L250", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1583, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L251", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1584, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L_kcg_clock", &_SCSIM_kcg_bool_Utils, 1456, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "refBGs_out", &_SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1585, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1586, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_recalculate_BG_locations_astern_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1454:
			return &((*pContext).Context_1);
		case 1455:
			return &((*pContext)._4_Context_1);
		case 1457:
			return &((*pContext)._1_Context_1);
		case 1458:
			return &((*pContext)._2_Context_1);
		case 1459:
			return &((*pContext)._3_Context_2);
		case 1460:
			return &((*pContext).Context_2);
		case 1461:
			return &((*pContext).Context_3);
		case 1462:
			return &((*pContext).BGin_is_refBG);
		case 1463:
			return &((*pContext).recalculateSubsequentBGs);
		case 1464:
			return &((*pContext).refBG);
		case 1465:
			return &((*pContext).prevLinkedBG);
		case 1466:
			return &((*pContext).prevUnlinkedBG);
		case 1467:
			return &((*pContext).relocatedBG);
		case 1468:
			return &((*pContext).sumOfBestDistances);
		case 1469:
			return &((*pContext)._L36);
		case 1470:
			return &((*pContext)._L71);
		case 1471:
			return &((*pContext)._L69);
		case 1472:
			return &((*pContext)._L67);
		case 1473:
			return &((*pContext)._L64);
		case 1474:
			return &((*pContext)._L74);
		case 1475:
			return &((*pContext)._L77);
		case 1476:
			return &((*pContext)._L78);
		case 1477:
			return &((*pContext)._L80);
		case 1478:
			return &((*pContext)._L81);
		case 1479:
			return &((*pContext)._L83);
		case 1480:
			return &((*pContext)._L84);
		case 1481:
			return &((*pContext)._L85);
		case 1482:
			return &((*pContext)._L105);
		case 1483:
			return &((*pContext)._L106);
		case 1484:
			return &((*pContext)._L107);
		case 1485:
			return &((*pContext)._L108);
		case 1486:
			return &((*pContext)._L109);
		case 1487:
			return &((*pContext)._L110);
		case 1488:
			return &((*pContext)._L111);
		case 1489:
			return &((*pContext)._L113);
		case 1490:
			return &((*pContext)._L112);
		case 1491:
			return &((*pContext)._L144);
		case 1492:
			return &((*pContext)._L143);
		case 1493:
			return &((*pContext)._L142);
		case 1494:
			return &((*pContext)._L141);
		case 1495:
			return &((*pContext)._L140);
		case 1496:
			return &((*pContext)._L139);
		case 1497:
			return &((*pContext)._L138);
		case 1498:
			return &((*pContext)._L137);
		case 1499:
			return &((*pContext)._L136);
		case 1500:
			return &((*pContext)._L121);
		case 1501:
			return &((*pContext)._L120);
		case 1502:
			return &((*pContext)._L119);
		case 1503:
			return &((*pContext)._L117);
		case 1504:
			return &((*pContext)._L116);
		case 1505:
			return &((*pContext)._L115);
		case 1506:
			return &((*pContext)._L114);
		case 1507:
			return &((*pContext)._L147);
		case 1508:
			return &((*pContext)._L148);
		case 1509:
			return &((*pContext)._L149);
		case 1510:
			return &((*pContext)._L150);
		case 1511:
			return &((*pContext)._L152);
		case 1512:
			return &((*pContext)._L153);
		case 1513:
			return &((*pContext)._L154);
		case 1514:
			return &((*pContext)._L155);
		case 1515:
			return &((*pContext)._L156);
		case 1516:
			return &((*pContext)._L157);
		case 1517:
			return &((*pContext)._L158);
		case 1518:
			return &((*pContext)._L159);
		case 1519:
			return &((*pContext)._L160);
		case 1520:
			return &((*pContext)._L161);
		case 1521:
			return &((*pContext)._L162);
		case 1522:
			return &((*pContext)._L172);
		case 1523:
			return &((*pContext)._L173);
		case 1524:
			return &((*pContext)._L174);
		case 1525:
			return &((*pContext)._L175);
		case 1526:
			return &((*pContext)._L181);
		case 1527:
			return &((*pContext)._L182);
		case 1528:
			return &((*pContext)._L183);
		case 1529:
			return &((*pContext)._L184);
		case 1530:
			return &((*pContext)._L187);
		case 1531:
			return &((*pContext)._L186);
		case 1532:
			return &((*pContext)._L185);
		case 1533:
			return &((*pContext)._L190);
		case 1534:
			return &((*pContext)._L193);
		case 1535:
			return &((*pContext)._L194);
		case 1536:
			return &((*pContext)._L195);
		case 1537:
			return &((*pContext)._L196);
		case 1538:
			return &((*pContext)._L197);
		case 1539:
			return &((*pContext)._L198);
		case 1540:
			return &((*pContext)._L199);
		case 1541:
			return &((*pContext)._L203);
		case 1542:
			return &((*pContext)._L204);
		case 1543:
			return &((*pContext)._L205);
		case 1544:
			return &((*pContext)._L206);
		case 1545:
			return &((*pContext)._L207);
		case 1546:
			return &((*pContext)._L209);
		case 1547:
			return &((*pContext)._L208);
		case 1548:
			return &((*pContext)._L210);
		case 1549:
			return &((*pContext)._L213);
		case 1550:
			return &((*pContext)._L214);
		case 1551:
			return &((*pContext)._L215);
		case 1552:
			return &((*pContext)._L216);
		case 1553:
			return &((*pContext)._L217);
		case 1554:
			return &((*pContext)._L218);
		case 1555:
			return &((*pContext)._L220);
		case 1556:
			return &((*pContext)._L219);
		case 1557:
			return &((*pContext)._L221);
		case 1558:
			return &((*pContext)._L224);
		case 1559:
			return &((*pContext)._L223);
		case 1560:
			return &((*pContext)._L222);
		case 1561:
			return &((*pContext)._L226);
		case 1562:
			return &((*pContext)._L225);
		case 1563:
			return &((*pContext)._L229);
		case 1564:
			return &((*pContext)._L228);
		case 1565:
			return &((*pContext)._L227);
		case 1566:
			return &((*pContext)._L230);
		case 1567:
			return &((*pContext)._L231);
		case 1568:
			return &((*pContext)._L232);
		case 1569:
			return &((*pContext)._L233);
		case 1570:
			return &((*pContext)._L235);
		case 1571:
			return &((*pContext)._L234);
		case 1572:
			return &((*pContext)._L236);
		case 1573:
			return &((*pContext)._L242);
		case 1574:
			return &((*pContext)._L241);
		case 1575:
			return &((*pContext)._L240);
		case 1576:
			return &((*pContext)._L243);
		case 1577:
			return &((*pContext)._L244);
		case 1578:
			return &((*pContext)._L245);
		case 1579:
			return &((*pContext)._L246);
		case 1580:
			return &((*pContext)._L247);
		case 1581:
			return &((*pContext)._L248);
		case 1582:
			return &((*pContext)._L249);
		case 1583:
			return &((*pContext)._L250);
		case 1584:
			return &((*pContext)._L251);
		case 1456:
			return &((*pContext).tmp);
		case 1585:
			return &((*pContext).refBGs_out);
		case 1586:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocations_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocation", "1", 1587, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1588, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1589, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1590, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_int_Utils, 1591, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1592, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_int_Utils, 1593, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 1594, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1595, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1596, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1597, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1598, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1599, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_improveUnlinkedBGLocations_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1587:
			return &((*pContext).Context_1);
		case 1588:
			return &((*pContext)._L1);
		case 1589:
			return &((*pContext)._L2);
		case 1590:
			return &((*pContext)._L4);
		case 1591:
			return &((*pContext)._L5);
		case 1592:
			return &((*pContext)._L8);
		case 1593:
			return &((*pContext)._L9);
		case 1594:
			return &((*pContext)._L10);
		case 1595:
			return &((*pContext)._L15);
		case 1596:
			return &((*pContext)._L16);
		case 1597:
			return &((*pContext)._L17);
		case 1598:
			return &((*pContext).cont);
		case 1599:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBGs/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushIterator(pSimulator, "mapfold", 8, 8);
	_SCSIM_Mapping_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_fwd_itr", "1", 1600, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnPushIterator(pSimulator, "mapfold", 8, 8);
	_SCSIM_Mapping_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_bckwd_itr", "1", 1601, 0, 0);
	pSimulator->m_pfnPopIterator(pSimulator);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_array__5729_Utils, 1602, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1603, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1604, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1605, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_array__5729_Utils, 1606, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1607, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils, 1608, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_array__5729_Utils, 1609, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_array__5729_Utils, 1610, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BGs_indices", &_SCSIM_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1611, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_findLinkedBGs_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1600:
			if (nSize != 1)
				break;
			return &((*pContext).Context_1[pIteratorFilter[0]]);
		case 1601:
			if (nSize != 1)
				break;
			return &((*pContext)._1_Context_1[pIteratorFilter[0]]);
		case 1602:
			return &((*pContext)._L24);
		case 1603:
			return &((*pContext)._L23);
		case 1604:
			return &((*pContext)._L25);
		case 1605:
			return &((*pContext)._L26);
		case 1606:
			return &((*pContext)._L29);
		case 1607:
			return &((*pContext)._L28);
		case 1608:
			return &((*pContext)._L30);
		case 1609:
			return &((*pContext)._L31);
		case 1610:
			return &((*pContext)._L32);
		case 1611:
			return &((*pContext).BGs_indices);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionedBGs_ids_equal/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_nidBG_nidc_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg("CalculateTrainPosition_Pkg::BG_utilities_Pkg::nidBG_nidc_equal", "1", 1612, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1613, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1614, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_kcg_bool_Utils, 1615, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_NID_C_Utils, 1616, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_NID_BG_Utils, 1617, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_NID_C_Utils, 1618, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_NID_BG_Utils, 1619, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1620, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_kcg_bool_Utils, 1621, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 1622, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "idsEqual", &_SCSIM_kcg_bool_Utils, 1623, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_positionedBGs_ids_equal_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1612:
			return &((*pContext).Context_1);
		case 1613:
			return &((*pContext)._L1);
		case 1614:
			return &((*pContext)._L2);
		case 1615:
			return &((*pContext)._L3);
		case 1616:
			return &((*pContext)._L4);
		case 1617:
			return &((*pContext)._L5);
		case 1618:
			return &((*pContext)._L6);
		case 1619:
			return &((*pContext)._L7);
		case 1620:
			return &((*pContext)._L8);
		case 1621:
			return &((*pContext)._L9);
		case 1622:
			return &((*pContext)._L10);
		case 1623:
			return &((*pContext).idsEqual);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::positionLinkedBGs_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::scaledDLINK_2_dlink", "1", 1624, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "1", 1625, 0, 0);
	_SCSIM_Mapping_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::scaledDLINK_2_dlink", "2", 1626, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "2", 1627, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "3", 1628, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "4", 1629, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1630, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1631, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_LinkedBG_T_BG_Types_Pkg_Utils, 1632, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 1633, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 1634, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1635, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_Q_LINK_Utils, 1636, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_NID_BG_Utils, 1637, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_NID_C_Utils, 1638, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 1639, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1640, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L76", &_SCSIM_Q_LINKREACTION_Utils, 1641, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L75", &_SCSIM_Q_LINKORIENTATION_Utils, 1642, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L74", &_SCSIM_NID_BG_Utils, 1643, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L73", &_SCSIM_NID_C_Utils, 1644, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L72", &_SCSIM_Q_NEWCOUNTRY_Utils, 1645, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L71", &_SCSIM_D_LINK_Utils, 1646, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L70", &_SCSIM_Q_SCALE_Utils, 1647, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L69", &_SCSIM_L_PACKET_Utils, 1648, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L68", &_SCSIM_Q_DIR_Utils, 1649, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L67", &_SCSIM_NID_PACKET_Utils, 1650, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L66", &_SCSIM_NID_LRBG_Utils, 1651, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L65", &_SCSIM_kcg_bool_Utils, 1652, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L84", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 1653, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L85", &_SCSIM_kcg_bool_Utils, 1654, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L86", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1655, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L87", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1656, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L89", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1657, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L90", &_SCSIM_LinkedBG_T_BG_Types_Pkg_Utils, 1658, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L104", &_SCSIM_Q_LOCACC_Utils, 1659, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L113", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1660, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L114", &_SCSIM_kcg_int_Utils, 1661, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L117", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1662, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L119", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1663, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L120", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1664, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L121", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1665, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L122", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1666, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L123", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1667, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "sumOfLinkingDistances", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1668, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "linkedPositionedBG", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1669, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_positionLinkedBGs_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1624:
			return &((*pContext).Context_1);
		case 1625:
			return &((*pContext)._2_Context_1);
		case 1626:
			return &((*pContext).Context_2);
		case 1627:
			return &((*pContext)._1_Context_2);
		case 1628:
			return &((*pContext).Context_3);
		case 1629:
			return &((*pContext).Context_4);
		case 1630:
			return &((*pContext)._L1);
		case 1631:
			return &((*pContext)._L2);
		case 1632:
			return &((*pContext)._L3);
		case 1633:
			return &((*pContext)._L17);
		case 1634:
			return &((*pContext)._L16);
		case 1635:
			return &((*pContext)._L15);
		case 1636:
			return &((*pContext)._L14);
		case 1637:
			return &((*pContext)._L13);
		case 1638:
			return &((*pContext)._L12);
		case 1639:
			return &((*pContext)._L11);
		case 1640:
			return &((*pContext)._L32);
		case 1641:
			return &((*pContext)._L76);
		case 1642:
			return &((*pContext)._L75);
		case 1643:
			return &((*pContext)._L74);
		case 1644:
			return &((*pContext)._L73);
		case 1645:
			return &((*pContext)._L72);
		case 1646:
			return &((*pContext)._L71);
		case 1647:
			return &((*pContext)._L70);
		case 1648:
			return &((*pContext)._L69);
		case 1649:
			return &((*pContext)._L68);
		case 1650:
			return &((*pContext)._L67);
		case 1651:
			return &((*pContext)._L66);
		case 1652:
			return &((*pContext)._L65);
		case 1653:
			return &((*pContext)._L84);
		case 1654:
			return &((*pContext)._L85);
		case 1655:
			return &((*pContext)._L86);
		case 1656:
			return &((*pContext)._L87);
		case 1657:
			return &((*pContext)._L89);
		case 1658:
			return &((*pContext)._L90);
		case 1659:
			return &((*pContext)._L104);
		case 1660:
			return &((*pContext)._L113);
		case 1661:
			return &((*pContext)._L114);
		case 1662:
			return &((*pContext)._L117);
		case 1663:
			return &((*pContext)._L119);
		case 1664:
			return &((*pContext)._L120);
		case 1665:
			return &((*pContext)._L121);
		case 1666:
			return &((*pContext)._L122);
		case 1667:
			return &((*pContext)._L123);
		case 1668:
			return &((*pContext).sumOfLinkingDistances);
		case 1669:
			return &((*pContext).linkedPositionedBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::indexOfBG_onTrack_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "stopIteration", &_SCSIM_kcg_bool_Utils, 1670, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "invalidateIndex", &_SCSIM_kcg_bool_Utils, 1671, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 1672, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1673, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_int_Utils, 1674, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_int_Utils, 1675, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 1676, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 1677, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1678, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1679, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_kcg_bool_Utils, 1680, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_kcg_bool_Utils, 1681, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_bool_Utils, 1682, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_bool_Utils, 1683, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_bool_Utils, 1684, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1685, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_kcg_bool_Utils, 1686, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1687, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_kcg_bool_Utils, 1688, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_kcg_int_Utils, 1689, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L33", &_SCSIM_kcg_int_Utils, 1690, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L34", &_SCSIM_kcg_bool_Utils, 1691, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L35", &_SCSIM_kcg_bool_Utils, 1692, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L37", &_SCSIM_kcg_bool_Utils, 1693, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L38", &_SCSIM_kcg_bool_Utils, 1694, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L39", &_SCSIM_kcg_bool_Utils, 1695, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L40", &_SCSIM_kcg_bool_Utils, 1696, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L41", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1697, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L42", &_SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils, 1698, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L43", &_SCSIM_kcg_bool_Utils, 1699, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L44", &_SCSIM_kcg_bool_Utils, 1700, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L45", &_SCSIM_kcg_bool_Utils, 1701, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L46", &_SCSIM_kcg_int_Utils, 1702, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1703, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "indexOfBG", &_SCSIM_kcg_int_Utils, 1704, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_indexOfBG_onTrack_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1670:
			return &((*pContext).stopIteration);
		case 1671:
			return &((*pContext).invalidateIndex);
		case 1672:
			return &((*pContext)._L7);
		case 1673:
			return &((*pContext)._L8);
		case 1674:
			return &((*pContext)._L10);
		case 1675:
			return &((*pContext)._L11);
		case 1676:
			return &((*pContext)._L16);
		case 1677:
			return &((*pContext)._L18);
		case 1678:
			return &((*pContext)._L21);
		case 1679:
			return &((*pContext)._L19);
		case 1680:
			return &((*pContext)._L23);
		case 1681:
			return &((*pContext)._L24);
		case 1682:
			return &((*pContext)._L25);
		case 1683:
			return &((*pContext)._L26);
		case 1684:
			return &((*pContext)._L27);
		case 1685:
			return &((*pContext)._L28);
		case 1686:
			return &((*pContext)._L29);
		case 1687:
			return &((*pContext)._L30);
		case 1688:
			return &((*pContext)._L31);
		case 1689:
			return &((*pContext)._L32);
		case 1690:
			return &((*pContext)._L33);
		case 1691:
			return &((*pContext)._L34);
		case 1692:
			return &((*pContext)._L35);
		case 1693:
			return &((*pContext)._L37);
		case 1694:
			return &((*pContext)._L38);
		case 1695:
			return &((*pContext)._L39);
		case 1696:
			return &((*pContext)._L40);
		case 1697:
			return &((*pContext)._L41);
		case 1698:
			return &((*pContext)._L42);
		case 1699:
			return &((*pContext)._L43);
		case 1700:
			return &((*pContext)._L44);
		case 1701:
			return &((*pContext)._L45);
		case 1702:
			return &((*pContext)._L46);
		case 1703:
			return &((*pContext).cont);
		case 1704:
			return &((*pContext).indexOfBG);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::deleteBG_atIndex_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock1");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_1705_Utils, 1705);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_1706_Utils, 1706);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1707, valid, 1706, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1708, valid, 1706, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_1709_Utils, 1709);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1710, valid, 1709, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1711, valid, 1709, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_1712_Utils, 1712);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1713, valid, 1712, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1714, valid, 1712, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1715, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1716, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_deleteBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1705:
			return &((*pContext).IfBlock1_clock);
		case 1706:
			return &((*pContext).else_clock_IfBlock1);
		case 1707:
			return &((*pContext)._L14_IfBlock1);
		case 1708:
			return &((*pContext)._L23_IfBlock1);
		case 1709:
			return &((*pContext).else_clock_IfBlock1);
		case 1710:
			return &((*pContext)._L12_IfBlock1);
		case 1711:
			return &((*pContext)._L21_IfBlock1);
		case 1712:
			return &((*pContext).IfBlock1_clock);
		case 1713:
			return &((*pContext)._L1_IfBlock1);
		case 1714:
			return &((*pContext)._L2_IfBlock1);
		case 1715:
			return &((*pContext).cont);
		case 1716:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

static int Is1706Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_1706_Utils = {Is1706Active};

static int Is1709Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_1709_Utils = {Is1709Active};

static int Is1705Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_1705_Utils = {Is1705Active};

static int Is1712Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_1712_Utils = {Is1712Active};

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_utilities_Pkg::insertBG_atIndex_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnPushActivateIf(pSimulator, "IfBlock1");
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_1717_Utils, 1717);
	pSimulator->m_pfnPushBranch(pSimulator, "else", &_SCSIM_1718_Utils, 1718);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1719, valid, 1718, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1720, valid, 1718, &_SCSIM_ClockActive_kcg_false);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_1721_Utils, 1721);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1722, valid, 1721, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1723, valid, 1721, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPushBranch(pSimulator, "then", &_SCSIM_1724_Utils, 1724);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1725, valid, 1724, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1726, valid, 1724, &_SCSIM_ClockActive_kcg_true);
	pSimulator->m_pfnPopBranch(pSimulator);
	pSimulator->m_pfnPopActivateIf(pSimulator);
	pSimulator->m_pfnAddOutput(pSimulator, "cont", &_SCSIM_kcg_bool_Utils, 1727, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1728, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg* pContext = (outC_insertBG_atIndex_itr_CalculateTrainPosition_Pkg_BG_utilities_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1717:
			return &((*pContext).IfBlock1_clock);
		case 1718:
			return &((*pContext).else_clock_IfBlock1);
		case 1719:
			return &((*pContext)._L13_IfBlock1);
		case 1720:
			return &((*pContext)._L22_IfBlock1);
		case 1721:
			return &((*pContext).else_clock_IfBlock1);
		case 1722:
			return &((*pContext)._L21_IfBlock1);
		case 1723:
			return &((*pContext)._L3_IfBlock1);
		case 1724:
			return &((*pContext).IfBlock1_clock);
		case 1725:
			return &((*pContext)._L1_IfBlock1);
		case 1726:
			return &((*pContext)._L2_IfBlock1);
		case 1727:
			return &((*pContext).cont);
		case 1728:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

static int Is1718Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_1718_Utils = {Is1718Active};

static int Is1721Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_1721_Utils = {Is1721Active};

static int Is1717Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 0 : 1;
}
ControlUtils _SCSIM_1717_Utils = {Is1717Active};

static int Is1724Active(void * pHandle) {
	return *((kcg_bool*)pHandle) != kcg_false  ? 1 : 0;
}
ControlUtils _SCSIM_1724_Utils = {Is1724Active};

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::scaledDLINK_2_dlink", "3", 1729, 0, 0);
	_SCSIM_Mapping_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::scaledDLINK_2_dlink", "4", 1730, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "5", 1731, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1732, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1733, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils, 1734, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_kcg_bool_Utils, 1735, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_Q_SCALE_Utils, 1736, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_LinkedBG_T_BG_Types_Pkg_Utils, 1737, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_Q_LOCACC_Utils, 1738, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_int_Utils, 1739, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1740, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1741, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_Q_NVLOCACC_Utils, 1742, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1743, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 1744, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_Q_SCALE_Utils, 1745, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1746, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1747, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_bool_Utils, 1748, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 1749, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1750, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_bool_Utils, 1751, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1752, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1753, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1754, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1755, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1756, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "localInaccuracies", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1757, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1729:
			return &((*pContext).Context_3);
		case 1730:
			return &((*pContext).Context_4);
		case 1731:
			return &((*pContext).Context_5);
		case 1732:
			return &((*pContext)._L2);
		case 1733:
			return &((*pContext)._L1);
		case 1734:
			return &((*pContext)._L3);
		case 1735:
			return &((*pContext)._L4);
		case 1736:
			return &((*pContext)._L5);
		case 1737:
			return &((*pContext)._L6);
		case 1738:
			return &((*pContext)._L7);
		case 1739:
			return &((*pContext)._L8);
		case 1740:
			return &((*pContext)._L9);
		case 1741:
			return &((*pContext)._L10);
		case 1742:
			return &((*pContext)._L11);
		case 1743:
			return &((*pContext)._L12);
		case 1744:
			return &((*pContext)._L13);
		case 1745:
			return &((*pContext)._L14);
		case 1746:
			return &((*pContext)._L15);
		case 1747:
			return &((*pContext)._L16);
		case 1748:
			return &((*pContext)._L17);
		case 1749:
			return &((*pContext)._L18);
		case 1750:
			return &((*pContext)._L19);
		case 1751:
			return &((*pContext)._L20);
		case 1752:
			return &((*pContext)._L21);
		case 1753:
			return &((*pContext)._L23);
		case 1754:
			return &((*pContext)._L24);
		case 1755:
			return &((*pContext)._L25);
		case 1756:
			return &((*pContext)._L26);
		case 1757:
			return &((*pContext).localInaccuracies);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_ahead/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "3", 1758, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "4", 1759, 0, 0);
	_SCSIM_Mapping_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies", "1", 1760, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "2", 1761, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "5", 1762, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "6", 1763, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L162", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1764, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L163", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1765, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L164", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1766, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L165", &_SCSIM_kcg_bool_Utils, 1767, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L166", &_SCSIM_kcg_bool_Utils, 1768, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L167", &_SCSIM_kcg_bool_Utils, 1769, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L168", &_SCSIM_kcg_bool_Utils, 1770, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L171", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1771, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L172", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1772, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L176", &_SCSIM_Q_LINK_Utils, 1773, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L175", &_SCSIM_Q_LINK_Utils, 1774, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L174", &_SCSIM_kcg_bool_Utils, 1775, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L177", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1776, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L178", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1777, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L179", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1778, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L180", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1779, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L181", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1780, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L182", &_SCSIM_kcg_bool_Utils, 1781, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L183", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1782, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L184", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1783, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L185", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1784, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L186", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1785, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L187", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1786, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L188", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1787, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L189", &_SCSIM_kcg_bool_Utils, 1788, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L190", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1789, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L191", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1790, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L194", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1791, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L193", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1792, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L192", &_SCSIM_kcg_bool_Utils, 1793, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L195", &_SCSIM_kcg_bool_Utils, 1794, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L196", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1795, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L197", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1796, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L198", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1797, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L199", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1798, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L200", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1799, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L203", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1800, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L204", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1801, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L205", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1802, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1803, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_recalculate_BG_location_ahead_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1758:
			return &((*pContext).Context_3);
		case 1759:
			return &((*pContext).Context_4);
		case 1760:
			return &((*pContext).Context_1);
		case 1761:
			return &((*pContext).Context_2);
		case 1762:
			return &((*pContext).Context_5);
		case 1763:
			return &((*pContext).Context_6);
		case 1764:
			return &((*pContext)._L162);
		case 1765:
			return &((*pContext)._L163);
		case 1766:
			return &((*pContext)._L164);
		case 1767:
			return &((*pContext)._L165);
		case 1768:
			return &((*pContext)._L166);
		case 1769:
			return &((*pContext)._L167);
		case 1770:
			return &((*pContext)._L168);
		case 1771:
			return &((*pContext)._L171);
		case 1772:
			return &((*pContext)._L172);
		case 1773:
			return &((*pContext)._L176);
		case 1774:
			return &((*pContext)._L175);
		case 1775:
			return &((*pContext)._L174);
		case 1776:
			return &((*pContext)._L177);
		case 1777:
			return &((*pContext)._L178);
		case 1778:
			return &((*pContext)._L179);
		case 1779:
			return &((*pContext)._L180);
		case 1780:
			return &((*pContext)._L181);
		case 1781:
			return &((*pContext)._L182);
		case 1782:
			return &((*pContext)._L183);
		case 1783:
			return &((*pContext)._L184);
		case 1784:
			return &((*pContext)._L185);
		case 1785:
			return &((*pContext)._L186);
		case 1786:
			return &((*pContext)._L187);
		case 1787:
			return &((*pContext)._L188);
		case 1788:
			return &((*pContext)._L189);
		case 1789:
			return &((*pContext)._L190);
		case 1790:
			return &((*pContext)._L191);
		case 1791:
			return &((*pContext)._L194);
		case 1792:
			return &((*pContext)._L193);
		case 1793:
			return &((*pContext)._L192);
		case 1794:
			return &((*pContext)._L195);
		case 1795:
			return &((*pContext)._L196);
		case 1796:
			return &((*pContext)._L197);
		case 1797:
			return &((*pContext)._L198);
		case 1798:
			return &((*pContext)._L199);
		case 1799:
			return &((*pContext)._L200);
		case 1800:
			return &((*pContext)._L203);
		case 1801:
			return &((*pContext)._L204);
		case 1802:
			return &((*pContext)._L205);
		case 1803:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::recalculate_BG_location_astern/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "1", 1804, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "1", 1805, 0, 0);
	_SCSIM_Mapping_calculateLocalBGInaccuracies_CalculateTrainPosition_Pkg_BG_relocation_Pkg("CalculateTrainPosition_Pkg::BG_relocation_Pkg::calculateLocalBGInaccuracies", "1", 1806, 0, 0);
	_SCSIM_Mapping_sub_2_odoDistances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_odoDistances", "1", 1807, 0, 0);
	_SCSIM_Mapping_add_2_Distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_2_Distances", "3", 1808, 0, 0);
	_SCSIM_Mapping_sub_2_distances_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::sub_2_distances", "3", 1809, 0, 0);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "1", 1810, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L162", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1811, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L164", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1812, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L165", &_SCSIM_kcg_bool_Utils, 1813, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L166", &_SCSIM_kcg_bool_Utils, 1814, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L168", &_SCSIM_kcg_bool_Utils, 1815, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L171", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1816, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L172", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1817, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L176", &_SCSIM_Q_LINK_Utils, 1818, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L175", &_SCSIM_Q_LINK_Utils, 1819, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L174", &_SCSIM_kcg_bool_Utils, 1820, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L177", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1821, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L178", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1822, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L179", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1823, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L180", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1824, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L181", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1825, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L182", &_SCSIM_kcg_bool_Utils, 1826, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L183", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1827, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L184", &_SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils, 1828, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L185", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1829, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L186", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1830, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L187", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1831, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L188", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1832, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L189", &_SCSIM_kcg_bool_Utils, 1833, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L190", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1834, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L191", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1835, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L194", &_SCSIM_passedBG_T_BG_Types_Pkg_Utils, 1836, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L193", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1837, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L192", &_SCSIM_kcg_bool_Utils, 1838, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L195", &_SCSIM_kcg_bool_Utils, 1839, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L196", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1840, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L197", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1841, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L198", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1842, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L199", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1843, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L200", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1844, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L203", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1845, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L204", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1846, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L205", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1847, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L208", &_SCSIM_kcg_bool_Utils, 1848, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L210", &_SCSIM_kcg_bool_Utils, 1849, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L212", &_SCSIM_kcg_bool_Utils, 1850, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L211", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1851, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L213", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1852, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L214", &_SCSIM_kcg_bool_Utils, 1853, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "BG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1854, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_recalculate_BG_location_astern_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1804:
			return &((*pContext).Context_1);
		case 1805:
			return &((*pContext)._2_Context_1);
		case 1806:
			return &((*pContext)._1_Context_1);
		case 1807:
			return &((*pContext)._3_Context_1);
		case 1808:
			return &((*pContext).Context_3);
		case 1809:
			return &((*pContext)._4_Context_3);
		case 1810:
			return &((*pContext)._5_Context_1);
		case 1811:
			return &((*pContext)._L162);
		case 1812:
			return &((*pContext)._L164);
		case 1813:
			return &((*pContext)._L165);
		case 1814:
			return &((*pContext)._L166);
		case 1815:
			return &((*pContext)._L168);
		case 1816:
			return &((*pContext)._L171);
		case 1817:
			return &((*pContext)._L172);
		case 1818:
			return &((*pContext)._L176);
		case 1819:
			return &((*pContext)._L175);
		case 1820:
			return &((*pContext)._L174);
		case 1821:
			return &((*pContext)._L177);
		case 1822:
			return &((*pContext)._L178);
		case 1823:
			return &((*pContext)._L179);
		case 1824:
			return &((*pContext)._L180);
		case 1825:
			return &((*pContext)._L181);
		case 1826:
			return &((*pContext)._L182);
		case 1827:
			return &((*pContext)._L183);
		case 1828:
			return &((*pContext)._L184);
		case 1829:
			return &((*pContext)._L185);
		case 1830:
			return &((*pContext)._L186);
		case 1831:
			return &((*pContext)._L187);
		case 1832:
			return &((*pContext)._L188);
		case 1833:
			return &((*pContext)._L189);
		case 1834:
			return &((*pContext)._L190);
		case 1835:
			return &((*pContext)._L191);
		case 1836:
			return &((*pContext)._L194);
		case 1837:
			return &((*pContext)._L193);
		case 1838:
			return &((*pContext)._L192);
		case 1839:
			return &((*pContext)._L195);
		case 1840:
			return &((*pContext)._L196);
		case 1841:
			return &((*pContext)._L197);
		case 1842:
			return &((*pContext)._L198);
		case 1843:
			return &((*pContext)._L199);
		case 1844:
			return &((*pContext)._L200);
		case 1845:
			return &((*pContext)._L203);
		case 1846:
			return &((*pContext)._L204);
		case 1847:
			return &((*pContext)._L205);
		case 1848:
			return &((*pContext)._L208);
		case 1849:
			return &((*pContext)._L210);
		case 1850:
			return &((*pContext)._L212);
		case 1851:
			return &((*pContext)._L211);
		case 1852:
			return &((*pContext)._L213);
		case 1853:
			return &((*pContext)._L214);
		case 1854:
			return &((*pContext).BG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::improveUnlinkedBGLocation/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_odoLoc_2_refLocations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::odoLoc_2_refLocations", "1", 1855, 0, 0);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "1", 1856, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1857, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_kcg_bool_Utils, 1858, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_Q_LINK_Utils, 1859, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_Q_LINK_Utils, 1860, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_kcg_bool_Utils, 1861, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1862, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1863, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1864, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_kcg_bool_Utils, 1865, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_Q_LINK_Utils, 1866, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_Q_LINK_Utils, 1867, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_bool_Utils, 1868, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_bool_Utils, 1869, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1870, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1871, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1872, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L23", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1873, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L24", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1874, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1875, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1876, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1877, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L29", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1878, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L31", &_SCSIM_kcg_bool_Utils, 1879, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L30", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1880, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L32", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1881, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L34", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1882, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L35", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1883, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L36", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1884, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L37", &_SCSIM_kcg_bool_Utils, 1885, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L41", &_SCSIM_Q_LINK_Utils, 1886, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L40", &_SCSIM_kcg_bool_Utils, 1887, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L39", &_SCSIM_Q_LINK_Utils, 1888, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L38", &_SCSIM_kcg_bool_Utils, 1889, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L43", &_SCSIM_kcg_bool_Utils, 1890, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L44", &_SCSIM_kcg_bool_Utils, 1891, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L45", &_SCSIM_kcg_bool_Utils, 1892, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L47", &_SCSIM_kcg_bool_Utils, 1893, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "unlinkedBG_out", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1894, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_improveUnlinkedBGLocation_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1855:
			return &((*pContext).Context_1);
		case 1856:
			return &((*pContext)._1_Context_1);
		case 1857:
			return &((*pContext)._L1);
		case 1858:
			return &((*pContext)._L2);
		case 1859:
			return &((*pContext)._L3);
		case 1860:
			return &((*pContext)._L4);
		case 1861:
			return &((*pContext)._L5);
		case 1862:
			return &((*pContext)._L7);
		case 1863:
			return &((*pContext)._L8);
		case 1864:
			return &((*pContext)._L9);
		case 1865:
			return &((*pContext)._L10);
		case 1866:
			return &((*pContext)._L11);
		case 1867:
			return &((*pContext)._L12);
		case 1868:
			return &((*pContext)._L13);
		case 1869:
			return &((*pContext)._L14);
		case 1870:
			return &((*pContext)._L19);
		case 1871:
			return &((*pContext)._L20);
		case 1872:
			return &((*pContext)._L21);
		case 1873:
			return &((*pContext)._L23);
		case 1874:
			return &((*pContext)._L24);
		case 1875:
			return &((*pContext)._L25);
		case 1876:
			return &((*pContext)._L27);
		case 1877:
			return &((*pContext)._L28);
		case 1878:
			return &((*pContext)._L29);
		case 1879:
			return &((*pContext)._L31);
		case 1880:
			return &((*pContext)._L30);
		case 1881:
			return &((*pContext)._L32);
		case 1882:
			return &((*pContext)._L34);
		case 1883:
			return &((*pContext)._L35);
		case 1884:
			return &((*pContext)._L36);
		case 1885:
			return &((*pContext)._L37);
		case 1886:
			return &((*pContext)._L41);
		case 1887:
			return &((*pContext)._L40);
		case 1888:
			return &((*pContext)._L39);
		case 1889:
			return &((*pContext)._L38);
		case 1890:
			return &((*pContext)._L43);
		case 1891:
			return &((*pContext)._L44);
		case 1892:
			return &((*pContext)._L45);
		case 1893:
			return &((*pContext)._L47);
		case 1894:
			return &((*pContext).unlinkedBG_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_fwd_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1895, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 1896, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_Q_LINK_Utils, 1897, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1898, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_Q_LINK_Utils, 1899, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 1900, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1901, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L18", &_SCSIM_kcg_int_Utils, 1902, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L17", &_SCSIM_kcg_int_Utils, 1903, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L16", &_SCSIM_kcg_int_Utils, 1904, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1905, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 1906, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_kcg_int_Utils, 1907, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L21", &_SCSIM_kcg_int_Utils, 1908, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "index_acc", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1909, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "index_out", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1910, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_findLinkedBG_fwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1895:
			return &((*pContext)._L5);
		case 1896:
			return &((*pContext)._L6);
		case 1897:
			return &((*pContext)._L7);
		case 1898:
			return &((*pContext)._L8);
		case 1899:
			return &((*pContext)._L9);
		case 1900:
			return &((*pContext)._L11);
		case 1901:
			return &((*pContext)._L12);
		case 1902:
			return &((*pContext)._L18);
		case 1903:
			return &((*pContext)._L17);
		case 1904:
			return &((*pContext)._L16);
		case 1905:
			return &((*pContext)._L19);
		case 1906:
			return &((*pContext)._L20);
		case 1907:
			return &((*pContext)._L22);
		case 1908:
			return &((*pContext)._L21);
		case 1909:
			return &((*pContext).index_acc);
		case 1910:
			return &((*pContext).index_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** CalculateTrainPosition_Pkg::BG_relocation_Pkg::findLinkedBG_bckwd_itr/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L5", &_SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils, 1911, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_kcg_bool_Utils, 1912, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_Q_LINK_Utils, 1913, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_kcg_bool_Utils, 1914, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_Q_LINK_Utils, 1915, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 1916, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1917, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L19", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1918, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L20", &_SCSIM_kcg_int_Utils, 1919, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1920, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L26", &_SCSIM_kcg_int_Utils, 1921, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L27", &_SCSIM_kcg_int_Utils, 1922, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L28", &_SCSIM_kcg_int_Utils, 1923, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "index_acc_out", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1924, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "index_out", &_SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils, 1925, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg* pContext = (outC_findLinkedBG_bckwd_itr_CalculateTrainPosition_Pkg_BG_relocation_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1911:
			return &((*pContext)._L5);
		case 1912:
			return &((*pContext)._L6);
		case 1913:
			return &((*pContext)._L7);
		case 1914:
			return &((*pContext)._L8);
		case 1915:
			return &((*pContext)._L9);
		case 1916:
			return &((*pContext)._L11);
		case 1917:
			return &((*pContext)._L12);
		case 1918:
			return &((*pContext)._L19);
		case 1919:
			return &((*pContext)._L20);
		case 1920:
			return &((*pContext)._L25);
		case 1921:
			return &((*pContext)._L26);
		case 1922:
			return &((*pContext)._L27);
		case 1923:
			return &((*pContext)._L28);
		case 1924:
			return &((*pContext).index_acc_out);
		case 1925:
			return &((*pContext).index_out);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** BasicLocationFunctions_Pkg::scaledDLINK_2_dlink/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_Q_SCALE_Utils, 1926, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_D_LINK_Utils, 1927, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_Q_LOCACC_Utils, 1928, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_kcg_int_Utils, 1929, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 1930, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 1931, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 1932, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils, 1933, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_kcg_int_Utils, 1934, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L13", &_SCSIM_kcg_int_Utils, 1935, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L14", &_SCSIM_kcg_int_Utils, 1936, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L15", &_SCSIM_kcg_int_Utils, 1937, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L22", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1938, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L25", &_SCSIM_kcg_int_Utils, 1939, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "distance", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1940, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg* pContext = (outC_scaledDLINK_2_dlink_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1926:
			return &((*pContext)._L1);
		case 1927:
			return &((*pContext)._L2);
		case 1928:
			return &((*pContext)._L3);
		case 1929:
			return &((*pContext)._L7);
		case 1930:
			return &((*pContext)._L8);
		case 1931:
			return &((*pContext)._L9);
		case 1932:
			return &((*pContext)._L10);
		case 1933:
			return &((*pContext)._L11);
		case 1934:
			return &((*pContext)._L12);
		case 1935:
			return &((*pContext)._L13);
		case 1936:
			return &((*pContext)._L14);
		case 1937:
			return &((*pContext)._L15);
		case 1938:
			return &((*pContext)._L22);
		case 1939:
			return &((*pContext)._L25);
		case 1940:
			return &((*pContext).distance);
		default:
			break;
	}
	return 0;
}

/****************************************************************
 ** BasicLocationFunctions_Pkg::odoLoc_2_refLocations/ mapping function
 ****************************************************************/
void _SCSIM_Mapping_odoLoc_2_refLocations_BasicLocationFunctions_Pkg(const char* pszPath, const char* pszInstanceName, int nHandleIdent, int nClockHandleIdent, int (*pfnClockActive)(void*)) {
	pSimulator->m_pfnPushInstance(pSimulator, pszPath, pszInstanceName, nHandleIdent, _SCSIM_Get_odoLoc_2_refLocations_BasicLocationFunctions_Pkg_Handle, nClockHandleIdent, pfnClockActive);
	_SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_odo_2_Location", "1", 1941, 0, 0);
	_SCSIM_Mapping_add_odo_2_Location_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::add_odo_2_Location", "2", 1942, 0, 0);
	_SCSIM_Mapping_overlapOf_2_Locations_BasicLocationFunctions_Pkg("BasicLocationFunctions_Pkg::overlapOf_2_Locations", "1", 1943, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L1", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1944, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L2", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1945, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L3", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1946, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L4", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1947, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L6", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1948, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L7", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1949, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L8", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1950, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L9", &_SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils, 1951, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L11", &_SCSIM_kcg_bool_Utils, 1952, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L10", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1953, valid, 0, 0);
	pSimulator->m_pfnAddLocal(pSimulator, "_L12", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1954, valid, 0, 0);
	pSimulator->m_pfnAddOutput(pSimulator, "location", &_SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils, 1955, valid, 0, 0);
	pSimulator->m_pfnPopInstance(pSimulator);
}

void* _SCSIM_Get_odoLoc_2_refLocations_BasicLocationFunctions_Pkg_Handle(void* pInstance, int nHandleIdent, int* pIteratorFilter, int nSize) {
	outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg* pContext = (outC_odoLoc_2_refLocations_BasicLocationFunctions_Pkg*)pInstance;
	switch (nHandleIdent) {
		case 1941:
			return &((*pContext).Context_1);
		case 1942:
			return &((*pContext).Context_2);
		case 1943:
			return &((*pContext)._1_Context_1);
		case 1944:
			return &((*pContext)._L1);
		case 1945:
			return &((*pContext)._L2);
		case 1946:
			return &((*pContext)._L3);
		case 1947:
			return &((*pContext)._L4);
		case 1948:
			return &((*pContext)._L6);
		case 1949:
			return &((*pContext)._L7);
		case 1950:
			return &((*pContext)._L8);
		case 1951:
			return &((*pContext)._L9);
		case 1952:
			return &((*pContext)._L11);
		case 1953:
			return &((*pContext)._L10);
		case 1954:
			return &((*pContext)._L12);
		case 1955:
			return &((*pContext).location);
		default:
			break;
	}
	return 0;
}

static int _SCSIM_ClockActive_SSM_st_Standstill_SM1(void* clock) {
return *(kcg_bool*)clock == SSM_st_Standstill_SM1 ? 1 : 0;
}
static int _SCSIM_ClockActive_SSM_st_Increasing_SM1(void* clock) {
return *(kcg_bool*)clock == SSM_st_Increasing_SM1 ? 1 : 0;
}
static int _SCSIM_ClockActive_SSM_st_Decreasing_SM1(void* clock) {
return *(kcg_bool*)clock == SSM_st_Decreasing_SM1 ? 1 : 0;
}
static int _SCSIM_ClockActive_SSM_st_Unknown_SM1(void* clock) {
return *(kcg_bool*)clock == SSM_st_Unknown_SM1 ? 1 : 0;
}
static int _SCSIM_ClockActive_kcg_false(void* clock) {
return *(kcg_bool*)clock == kcg_false ? 1 : 0;
}
static int _SCSIM_ClockActive_kcg_true(void* clock) {
return *(kcg_bool*)clock == kcg_true ? 1 : 0;
}
