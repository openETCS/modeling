/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "passedBG_2_positionedBG_CalculateTrainPosition_Pkg.h"

void passedBG_2_positionedBG_reset_CalculateTrainPosition_Pkg(
  outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg *outC)
{
  /* 1 */
  positionLinkedBGs_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->Context_1);
  /* 4 */
  overlapOf_2_Locations_reset_BasicLocationFunctions_Pkg(&outC->Context_4);
  /* 9 */ add_2_Distances_reset_BasicLocationFunctions_Pkg(&outC->Context_9);
  /* 8 */ sub_2_odoDistances_reset_BasicLocationFunctions_Pkg(&outC->Context_8);
  /* 5 */
  overlapOf_2_Locations_reset_BasicLocationFunctions_Pkg(&outC->_2_Context_5);
  /* 13 */ add_2_Distances_reset_BasicLocationFunctions_Pkg(&outC->Context_13);
  /* 5 */ add_odo_2_Location_reset_BasicLocationFunctions_Pkg(&outC->Context_5);
  /* 6 */
  overlapOf_2_Locations_reset_BasicLocationFunctions_Pkg(&outC->_1_Context_6);
  /* 3 */
  overlapOf_2_Locations_reset_BasicLocationFunctions_Pkg(&outC->Context_3);
  /* 14 */ add_2_Distances_reset_BasicLocationFunctions_Pkg(&outC->Context_14);
  /* 6 */ add_odo_2_Location_reset_BasicLocationFunctions_Pkg(&outC->Context_6);
}

/* CalculateTrainPosition_Pkg::passedBG_2_positionedBG */
void passedBG_2_positionedBG_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::passedBG */passedBG_T_BG_Types_Pkg *passedBG,
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::passedBG_asAnnounced */positionedBG_T_TrainPosition_Types_Pck *passedBG_asAnnounced,
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::previouslyPassedLinkedBG */positionedBG_T_TrainPosition_Types_Pck *previouslyPassedLinkedBG,
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::passedBGSeqNo */kcg_int passedBGSeqNo,
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  outC_passedBG_2_positionedBG_CalculateTrainPosition_Pkg *outC)
{
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced */ kcg_bool _3_notFoundWhereAnnounced;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::location */ LocWithInAcc_T_Obu_BasicTypes_Pkg _2_location;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced_loc */ kcg_bool _1_notFoundWhereAnnounced_loc;
  kcg_bool _18_noname;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced */ kcg_bool notFoundWhereAnnounced;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::location */ LocWithInAcc_T_Obu_BasicTypes_Pkg location;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced_loc */ kcg_bool notFoundWhereAnnounced_loc;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced_loc */ kcg_bool _15_notFoundWhereAnnounced_loc;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::location */ LocWithInAcc_T_Obu_BasicTypes_Pkg _14_location;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced */ kcg_bool _13_notFoundWhereAnnounced;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced_loc */ kcg_bool _12_notFoundWhereAnnounced_loc;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::location */ LocWithInAcc_T_Obu_BasicTypes_Pkg _11_location;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced */ kcg_bool _10_notFoundWhereAnnounced;
  kcg_bool _16_noname;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced */ kcg_bool _4_notFoundWhereAnnounced;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::location */ LocWithInAcc_T_Obu_BasicTypes_Pkg _5_location;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced_loc */ kcg_bool _6_notFoundWhereAnnounced_loc;
  kcg_bool _17_noname;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced */ kcg_bool _7_notFoundWhereAnnounced;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::location */ LocWithInAcc_T_Obu_BasicTypes_Pkg _8_location;
  /* CalculateTrainPosition_Pkg::passedBG_2_positionedBG::notFoundWhereAnnounced_loc */ kcg_bool _9_notFoundWhereAnnounced_loc;
  T_internal_Type_Obu_BasicTypes_Pkg noname;
  OdometryLocations_T_Obu_BasicTypes_Pkg _19_noname;
  LocWithInAcc_T_Obu_BasicTypes_Pkg _20_noname;
  LinkedBGs_T_BG_Types_Pkg _21_noname;
  kcg_bool _22_noname;
  Q_DIRLRBG _23_noname;
  Q_DIRTRAIN _24_noname;
  Speed_T_Obu_BasicTypes_Pkg _25_noname;
  
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L15, passedBG);
  outC->_L279 = outC->_L15.passingSpeed;
  outC->_L278 = outC->_L15.trainRunningDirectionToBG;
  outC->_L277 = outC->_L15.trainOrientationToBG;
  outC->_L276 = outC->_L15.noCoordinateSystemHasBeenAssigned;
  kcg_copy_LinkedBGs_T_BG_Types_Pkg(&outC->_L13, &outC->_L15.linkedBGs);
  kcg_copy_BG_Header_T_BG_Types_Pkg(&outC->_L12, &outC->_L15.BG_Header);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L11,
    &outC->_L15.BG_centerDetectionInaccuraccuracies);
  kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
    &outC->_L10,
    &outC->_L15.odometrystamp);
  outC->_L9 = outC->_L15.timestamp;
  kcg_copy_passedBG_T_BG_Types_Pkg(
    &outC->_L285,
    (passedBG_T_BG_Types_Pkg *) &cNoPassedBG_CalculateTrainPosition_Pkg);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L41,
    passedBG_asAnnounced);
  outC->_L56 = outC->_L41.valid;
  outC->_L57 = outC->_L41.nid_bg;
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L58, passedBG);
  outC->_L59 = outC->_L58.BG_Header.nid_bg;
  outC->_L60 = outC->_L57 == outC->_L59;
  outC->_L61 = outC->_L41.nid_c;
  outC->_L62 = outC->_L58.BG_Header.nid_c;
  outC->_L63 = outC->_L61 == outC->_L62;
  outC->_L64 = outC->_L41.q_link;
  outC->_L65 = outC->_L58.BG_Header.q_link;
  outC->_L66 = outC->_L64 == outC->_L65;
  outC->_L181 = outC->_L41.infoFromLinking.valid;
  outC->_L67 = outC->_L56 & outC->_L60 & outC->_L63 & outC->_L66 & outC->_L181;
  outC->BG_wasAnnounced = outC->_L67;
  outC->ifAnnouncedOrABGWasPreviouslyPassed_clock = !outC->BG_wasAnnounced &
    !(*previouslyPassedLinkedBG).valid;
  if (outC->ifAnnouncedOrABGWasPreviouslyPassed_clock) {
    _1_notFoundWhereAnnounced_loc = kcg_false;
    outC->notFoundWhereAnnounced_loc = _1_notFoundWhereAnnounced_loc;
  }
  else {
    outC->_3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed =
      !outC->BG_wasAnnounced & (*previouslyPassedLinkedBG).valid;
    if (outC->_3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed) {
      _9_notFoundWhereAnnounced_loc = kcg_false;
      notFoundWhereAnnounced_loc = _9_notFoundWhereAnnounced_loc;
    }
    else {
      outC->else_clock_ifAnnouncedOrABGWasPreviouslyPassed =
        outC->BG_wasAnnounced & !(*previouslyPassedLinkedBG).valid;
      if (outC->else_clock_ifAnnouncedOrABGWasPreviouslyPassed) {
        _15_notFoundWhereAnnounced_loc = kcg_false;
        _6_notFoundWhereAnnounced_loc = _15_notFoundWhereAnnounced_loc;
      }
      else {
        kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
          &outC->_L1114_ifAnnouncedOrABGWasPreviouslyPassed,
          passedBG_asAnnounced);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L1417_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L1114_ifAnnouncedOrABGWasPreviouslyPassed.location);
        kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
          &outC->_L710_ifAnnouncedOrABGWasPreviouslyPassed,
          previouslyPassedLinkedBG);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L811_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L710_ifAnnouncedOrABGWasPreviouslyPassed.location);
        kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
          &outC->_L3_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L710_ifAnnouncedOrABGWasPreviouslyPassed.infoFromPassing.odometrystamp);
        kcg_copy_passedBG_T_BG_Types_Pkg(
          &outC->_L1316_ifAnnouncedOrABGWasPreviouslyPassed,
          passedBG);
        kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
          &outC->_L69_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L1316_ifAnnouncedOrABGWasPreviouslyPassed.odometrystamp);
        /* 6 */
        add_odo_2_Location_BasicLocationFunctions_Pkg(
          &outC->_L811_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L3_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L69_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->Context_6);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L28_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->Context_6.location);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L4_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L1316_ifAnnouncedOrABGWasPreviouslyPassed.BG_centerDetectionInaccuraccuracies);
        /* 14 */
        add_2_Distances_BasicLocationFunctions_Pkg(
          &outC->_L28_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L4_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->Context_14);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L17_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->Context_14.distance);
        /* 3 */
        overlapOf_2_Locations_BasicLocationFunctions_Pkg(
          &outC->_L1417_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L17_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->Context_3);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L913_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->Context_3.loc);
        outC->_L1012_ifAnnouncedOrABGWasPreviouslyPassed =
          outC->Context_3.overlap;
        outC->_L1215_ifAnnouncedOrABGWasPreviouslyPassed =
          !outC->_L1012_ifAnnouncedOrABGWasPreviouslyPassed;
        _12_notFoundWhereAnnounced_loc =
          outC->_L1215_ifAnnouncedOrABGWasPreviouslyPassed;
        _6_notFoundWhereAnnounced_loc = _12_notFoundWhereAnnounced_loc;
      }
      notFoundWhereAnnounced_loc = _6_notFoundWhereAnnounced_loc;
    }
    outC->notFoundWhereAnnounced_loc = notFoundWhereAnnounced_loc;
  }
  outC->_L284 = outC->notFoundWhereAnnounced_loc;
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L16, passedBG);
  if (outC->_L284) {
    kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L283, &outC->_L285);
  }
  else {
    kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L283, &outC->_L16);
  }
  kcg_copy_trainProperties_T_TrainPosition_Types_Pck(
    &outC->_L282,
    trainProperties);
  outC->_L281 = passedBGSeqNo;
  _25_noname = outC->_L279;
  _24_noname = outC->_L278;
  _23_noname = outC->_L277;
  _22_noname = outC->_L276;
  outC->_L8 = outC->_L15.valid;
  outC->_L37 = outC->_L12.nid_c;
  outC->_L38 = outC->_L12.nid_bg;
  outC->_L39 = outC->_L12.q_link;
  if (outC->ifAnnouncedOrABGWasPreviouslyPassed_clock) {
    kcg_copy_passedBG_T_BG_Types_Pkg(
      &outC->_L23_ifAnnouncedOrABGWasPreviouslyPassed,
      passedBG);
    kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
      &outC->_L21_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->_L23_ifAnnouncedOrABGWasPreviouslyPassed.odometrystamp);
    kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
      &outC->_L20_ifAnnouncedOrABGWasPreviouslyPassed,
      (OdometryLocations_T_Obu_BasicTypes_Pkg *)
        &cOdometryInitialValue_Obu_BasicTypes_Pkg);
    /* 8 */
    sub_2_odoDistances_BasicLocationFunctions_Pkg(
      &outC->_L21_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->_L20_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->Context_8);
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
      &outC->_L24_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->Context_8.distance);
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
      &outC->_L25_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->_L23_ifAnnouncedOrABGWasPreviouslyPassed.BG_centerDetectionInaccuraccuracies);
    /* 9 */
    add_2_Distances_BasicLocationFunctions_Pkg(
      &outC->_L24_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->_L25_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->Context_9);
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
      &outC->_L22_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->Context_9.distance);
    /* 4 */
    overlapOf_2_Locations_BasicLocationFunctions_Pkg(
      &outC->_L22_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->_L22_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->Context_4);
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
      &outC->_L26_ifAnnouncedOrABGWasPreviouslyPassed,
      &outC->Context_4.loc);
    outC->_L27_ifAnnouncedOrABGWasPreviouslyPassed = outC->Context_4.overlap;
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
      &_2_location,
      &outC->_L26_ifAnnouncedOrABGWasPreviouslyPassed);
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->location, &_2_location);
  }
  else {
    if (outC->_3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed) {
      kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
        &outC->_L12_ifAnnouncedOrABGWasPreviouslyPassed,
        previouslyPassedLinkedBG);
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
        &outC->_L7_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L12_ifAnnouncedOrABGWasPreviouslyPassed.location);
      kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
        &outC->_L11_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L12_ifAnnouncedOrABGWasPreviouslyPassed.infoFromPassing.odometrystamp);
      kcg_copy_passedBG_T_BG_Types_Pkg(
        &outC->_L10_ifAnnouncedOrABGWasPreviouslyPassed,
        passedBG);
      kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(
        &outC->_L9_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L10_ifAnnouncedOrABGWasPreviouslyPassed.odometrystamp);
      /* 5 */
      add_odo_2_Location_BasicLocationFunctions_Pkg(
        &outC->_L7_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L11_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L9_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->Context_5);
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
        &outC->_L6_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->Context_5.location);
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
        &outC->_L13_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L10_ifAnnouncedOrABGWasPreviouslyPassed.BG_centerDetectionInaccuraccuracies);
      /* 13 */
      add_2_Distances_BasicLocationFunctions_Pkg(
        &outC->_L6_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L13_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->Context_13);
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
        &outC->_L8_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->Context_13.distance);
      /* 5 */
      overlapOf_2_Locations_BasicLocationFunctions_Pkg(
        &outC->_L8_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_L8_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_2_Context_5);
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
        &outC->_L14_ifAnnouncedOrABGWasPreviouslyPassed,
        &outC->_2_Context_5.loc);
      outC->_L15_ifAnnouncedOrABGWasPreviouslyPassed =
        outC->_2_Context_5.overlap;
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
        &_8_location,
        &outC->_L14_ifAnnouncedOrABGWasPreviouslyPassed);
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&location, &_8_location);
    }
    else {
      if (outC->else_clock_ifAnnouncedOrABGWasPreviouslyPassed) {
        kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
          &outC->_L1_ifAnnouncedOrABGWasPreviouslyPassed,
          passedBG_asAnnounced);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L2_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L1_ifAnnouncedOrABGWasPreviouslyPassed.location);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &_14_location,
          &outC->_L2_ifAnnouncedOrABGWasPreviouslyPassed);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&_5_location, &_14_location);
      }
      else {
        /* 6 */
        overlapOf_2_Locations_BasicLocationFunctions_Pkg(
          &outC->_L1417_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_L1417_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_1_Context_6);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &outC->_L154_ifAnnouncedOrABGWasPreviouslyPassed,
          &outC->_1_Context_6.loc);
        outC->_L16_ifAnnouncedOrABGWasPreviouslyPassed =
          outC->_1_Context_6.overlap;
        if (outC->_L1012_ifAnnouncedOrABGWasPreviouslyPassed) {
          kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
            &outC->_L5_ifAnnouncedOrABGWasPreviouslyPassed,
            &outC->_L913_ifAnnouncedOrABGWasPreviouslyPassed);
        }
        else {
          kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
            &outC->_L5_ifAnnouncedOrABGWasPreviouslyPassed,
            &outC->_L154_ifAnnouncedOrABGWasPreviouslyPassed);
        }
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
          &_11_location,
          &outC->_L5_ifAnnouncedOrABGWasPreviouslyPassed);
        kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&_5_location, &_11_location);
      }
      kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&location, &_5_location);
    }
    kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->location, &location);
  }
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&outC->_L182, &outC->location);
  outC->_L68 = outC->BG_wasAnnounced;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L40,
    passedBG_asAnnounced);
  kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck(
    &outC->_L183,
    &outC->_L40.infoFromLinking);
  kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck(
    &outC->_L185,
    (infoFromLinking_T_TrainPosition_Types_Pck *)
      &cNoInfoFromLinking_CalculateTrainPosition_Pkg);
  if (outC->_L68) {
    kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck(
      &outC->_L184,
      &outC->_L183);
  }
  else {
    kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck(
      &outC->_L184,
      &outC->_L185);
  }
  outC->_L14.valid = outC->_L8;
  outC->_L14.nid_c = outC->_L37;
  outC->_L14.nid_bg = outC->_L38;
  outC->_L14.q_link = outC->_L39;
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L14.location,
    &outC->_L182);
  outC->_L14.seqNoOnTrack = outC->_L281;
  kcg_copy_infoFromLinking_T_TrainPosition_Types_Pck(
    &outC->_L14.infoFromLinking,
    &outC->_L184);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L14.infoFromPassing, &outC->_L283);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->passedPositionedBG_loc,
    &outC->_L14);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L262,
    &outC->passedPositionedBG_loc);
  kcg_copy_passedBG_T_BG_Types_Pkg(&outC->_L264, passedBG);
  kcg_copy_LinkedBGs_T_BG_Types_Pkg(&outC->_L263, &outC->_L264.linkedBGs);
  /* 1 */
  positionLinkedBGs_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_L262,
    &outC->_L263,
    &outC->_L282,
    &outC->Context_1);
  kcg_copy_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(
    &outC->_L265,
    &outC->Context_1.linkedPositionedBGs);
  kcg_copy_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(
    &outC->linkedBGs,
    &outC->_L265);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->passedPositionedBG,
    &outC->_L14);
  kcg_copy_LinkedBGs_T_BG_Types_Pkg(&_21_noname, &outC->_L13);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(&_20_noname, &outC->_L11);
  kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(&_19_noname, &outC->_L10);
  if (outC->ifAnnouncedOrABGWasPreviouslyPassed_clock) {
    _3_notFoundWhereAnnounced = kcg_false;
    _18_noname = outC->_L27_ifAnnouncedOrABGWasPreviouslyPassed;
    outC->notFoundWhereAnnounced = _3_notFoundWhereAnnounced;
  }
  else {
    if (outC->_3_else_clock_ifAnnouncedOrABGWasPreviouslyPassed) {
      _7_notFoundWhereAnnounced = kcg_false;
      _17_noname = outC->_L15_ifAnnouncedOrABGWasPreviouslyPassed;
      notFoundWhereAnnounced = _7_notFoundWhereAnnounced;
    }
    else {
      if (outC->else_clock_ifAnnouncedOrABGWasPreviouslyPassed) {
        _13_notFoundWhereAnnounced = kcg_false;
        _4_notFoundWhereAnnounced = _13_notFoundWhereAnnounced;
      }
      else {
        _16_noname = outC->_L16_ifAnnouncedOrABGWasPreviouslyPassed;
        _10_notFoundWhereAnnounced =
          outC->_L1215_ifAnnouncedOrABGWasPreviouslyPassed;
        _4_notFoundWhereAnnounced = _10_notFoundWhereAnnounced;
      }
      notFoundWhereAnnounced = _4_notFoundWhereAnnounced;
    }
    outC->notFoundWhereAnnounced = notFoundWhereAnnounced;
  }
  noname = outC->_L9;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** passedBG_2_positionedBG_CalculateTrainPosition_Pkg.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

