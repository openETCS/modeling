/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateTrainPositionInfo_CalculateTrainPosition_Pkg.h"

void calculateTrainPositionInfo_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg *outC)
{
  outC->init = kcg_true;
  /* 1 */
  overlapOf_2_Locations_reset_BasicLocationFunctions_Pkg(&outC->_3_Context_1);
  /* 2 */
  positionDerivedFromPassedBG_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_2_Context_2);
  /* 1 */
  positionDerivedFromPassedBG_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_1_Context_1);
  /* 2 */
  indexOfLastPassedBG_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->Context_2);
  /* 1 */
  indexOfLastPassedBG_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->Context_1);
}

/* CalculateTrainPosition_Pkg::calculateTrainPositionInfo */
void calculateTrainPositionInfo_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::BGs */positionedBGs_T_TrainPosition_Types_Pck *BGs,
  /* CalculateTrainPosition_Pkg::calculateTrainPositionInfo::recalculateBGs */kcg_bool recalculateBGs,
  outC_calculateTrainPositionInfo_CalculateTrainPosition_Pkg *outC)
{
  kcg_bool tmp5;
  kcg_bool tmp4;
  kcg_bool tmp3;
  kcg_bool tmp2;
  kcg_int tmp1;
  kcg_int tmp;
  kcg_bool tmp9;
  kcg_bool tmp10;
  kcg_int tmp11;
  kcg_bool tmp6;
  kcg_bool tmp7;
  kcg_int tmp8;
  kcg_bool noname;
  kcg_bool _12_noname;
  kcg_bool _13_noname;
  kcg_bool _14_noname;
  
  outC->_L32 = recalculateBGs;
  outC->tmp4 = outC->_L32;
  outC->_L26 = kcg_true;
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L30, BGs);
  if (outC->tmp4) {
    /* 1 */
    indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
      outC->_L26,
      &outC->_L30,
      outC->_L32,
      &outC->Context_1);
    tmp11 = outC->Context_1.indexOfBG;
    tmp10 = outC->Context_1.BG_found;
    tmp9 = outC->Context_1.indexValid;
  }
  outC->_L36 = kcg_false;
  if (outC->tmp4) {
    outC->_L19 = tmp9;
    outC->_L18 = tmp10;
  }
  else {
    if (outC->init) {
      tmp5 = outC->_L36;
    }
    else {
      tmp5 = outC->_L19;
    }
    outC->_L19 = tmp5;
    if (outC->init) {
      tmp4 = outC->_L36;
    }
    else {
      tmp4 = outC->_L18;
    }
    outC->_L18 = tmp4;
  }
  outC->_L33 = recalculateBGs;
  outC->tmp = outC->_L33;
  outC->_L27 = kcg_false;
  kcg_copy_positionedBGs_T_TrainPosition_Types_Pck(&outC->_L31, BGs);
  if (outC->tmp) {
    /* 2 */
    indexOfLastPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
      outC->_L27,
      &outC->_L31,
      outC->_L33,
      &outC->Context_2);
    tmp8 = outC->Context_2.indexOfBG;
    tmp7 = outC->Context_2.BG_found;
    tmp6 = outC->Context_2.indexValid;
  }
  outC->_L35 = kcg_false;
  if (outC->tmp) {
    outC->_L25 = tmp6;
    outC->_L24 = tmp7;
  }
  else {
    if (outC->init) {
      tmp3 = outC->_L35;
    }
    else {
      tmp3 = outC->_L25;
    }
    outC->_L25 = tmp3;
    if (outC->init) {
      tmp2 = outC->_L35;
    }
    else {
      tmp2 = outC->_L24;
    }
    outC->_L24 = tmp2;
  }
  outC->_L37 = cNoValidIndex_CalculateTrainPosition_Pkg;
  outC->_L34 = cNoValidIndex_CalculateTrainPosition_Pkg;
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L1, currentOdometry);
  kcg_copy_OdometryLocations_T_Obu_BasicTypes_Pkg(&outC->_L13, &outC->_L1.odo);
  if (outC->tmp4) {
    outC->_L17 = tmp11;
  }
  else {
    if (outC->init) {
      tmp1 = outC->_L37;
    }
    else {
      tmp1 = outC->_L17;
    }
    outC->_L17 = tmp1;
  }
  if ((0 <= outC->_L17) & (outC->_L17 < 8)) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &outC->_L20,
      &outC->_L30[outC->_L17]);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &outC->_L20,
      (positionedBG_T_TrainPosition_Types_Pck *)
        &cNoPositionedBG_CalculateTrainPosition_Pkg);
  }
  /* 1 */
  positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_L13,
    &outC->_L20,
    &outC->_1_Context_1);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L7,
    &outC->_1_Context_1.position);
  if (outC->tmp) {
    outC->_L23 = tmp8;
  }
  else {
    if (outC->init) {
      tmp = outC->_L34;
    }
    else {
      tmp = outC->_L23;
    }
    outC->_L23 = tmp;
  }
  if ((0 <= outC->_L23) & (outC->_L23 < 8)) {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &outC->_L22,
      &outC->_L31[outC->_L23]);
  }
  else {
    kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
      &outC->_L22,
      (positionedBG_T_TrainPosition_Types_Pck *)
        &cNoPositionedBG_CalculateTrainPosition_Pkg);
  }
  /* 2 */
  positionDerivedFromPassedBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_L13,
    &outC->_L22,
    &outC->_2_Context_2);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L8,
    &outC->_2_Context_2.position);
  /* 1 */
  overlapOf_2_Locations_BasicLocationFunctions_Pkg(
    &outC->_L7,
    &outC->_L8,
    &outC->_3_Context_1);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L10,
    &outC->_3_Context_1.loc);
  outC->_L11 = outC->_3_Context_1.overlap;
  outC->_L12 = !outC->_L11;
  outC->positionCalculationNotConsistent = outC->_L12;
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L28, currentOdometry);
  _14_noname = outC->_L25;
  _13_noname = outC->_L24;
  _12_noname = outC->_L19;
  noname = outC->_L18;
  outC->_L15 = outC->_L28.speed;
  outC->_L14 = outC->_L1.timestamp;
  outC->_L9.valid = outC->_L11;
  outC->_L9.timestamp = outC->_L14;
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L9.trainPosition,
    &outC->_L10);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L9.trainPositionDerivedFromLastLinkedBG,
    &outC->_L7);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L9.trainPositionDerivedFromLastUnlinkedBG,
    &outC->_L8);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L9.lastPassedLinkedBG,
    &outC->_L20);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(
    &outC->_L9.lastPassedUnlinkedBG,
    &outC->_L22);
  outC->_L9.speed = outC->_L15;
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->trainPositionInfo,
    &outC->_L9);
  outC->init = kcg_false;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainPositionInfo_CalculateTrainPosition_Pkg.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

