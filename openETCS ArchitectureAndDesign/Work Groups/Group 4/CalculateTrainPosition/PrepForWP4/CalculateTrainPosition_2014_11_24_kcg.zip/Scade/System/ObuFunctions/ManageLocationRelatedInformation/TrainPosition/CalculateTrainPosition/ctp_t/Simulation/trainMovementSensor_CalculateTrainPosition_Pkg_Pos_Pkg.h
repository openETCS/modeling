/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_H_
#define _trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction */ direction;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  SSM_ST_SM1 /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_state_nxt;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_reset_act;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_reset_nxt;
  odometry_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */ rem_currentOdometry;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Unknown::_L1 */ _L1_SM1_Unknown;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Decreasing::_L1 */ _L1_SM1_Decreasing;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Increasing::_L1 */ _L1_SM1_Increasing;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1::Standstill::_L1 */ _L1_SM1_Standstill;
  SSM_ST_SM1 /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_state_sel;
  SSM_ST_SM1 /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_state_act;
  SSM_TR_SM1 /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_fired_strong;
  SSM_TR_SM1 /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */ SM1_fired;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::direction_loc */ direction_loc;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::standstillDetected */ standstillDetected;
  odometry_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L5 */ _L5;
  Speed_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L6 */ _L6;
  Speed_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L7 */ _L7;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L8 */ _L8;
  odometry_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L10 */ _L10;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L11 */ _L11;
  Speed_T_Obu_BasicTypes_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L12 */ _L12;
  kcg_bool /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L13 */ _L13;
  trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::_L14 */ _L14;
} outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg;

/* ===========  node initialization and cycle functions  =========== */
/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor */
extern void trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

extern void trainMovementSensor_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC);

#endif /* _trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

