/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _genLocation_ctp_t_pck_t_engine_H_
#define _genLocation_ctp_t_pck_t_engine_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::location */ location;
  T_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::t_engine::genLocation::time */ time;
  /* -----------------------  no local probes  ----------------------- */
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* -----------------------  no local memory  ----------------------- */
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
} outC_genLocation_ctp_t_pck_t_engine;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::t_engine::genLocation */
extern void genLocation_ctp_t_pck_t_engine(
  outC_genLocation_ctp_t_pck_t_engine *outC);

extern void genLocation_reset_ctp_t_pck_t_engine(
  outC_genLocation_ctp_t_pck_t_engine *outC);

#endif /* _genLocation_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genLocation_ctp_t_pck_t_engine.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

