#ifndef VINCENT_SCENARIO_07_CTP_T_PCK_TYPES_CONVERTION
#define VINCENT_SCENARIO_07_CTP_T_PCK_TYPES_CONVERTION

/****************************************************************
 ** Boolean entity activation
 ****************************************************************/
extern int _SCSIM_BoolEntity_is_active(void* pValue);

/****************************************************************
 ** Type utils declarations
 ****************************************************************/
extern TypeUtils _SCSIM_kcg_real_Utils;
extern TypeUtils _SCSIM_kcg_bool_Utils;
extern TypeUtils _SCSIM_kcg_char_Utils;
extern TypeUtils _SCSIM_kcg_int_Utils;
extern TypeUtils _SCSIM_struct__5578_Utils;
extern TypeUtils _SCSIM_struct__5584_Utils;
extern TypeUtils _SCSIM_struct__5600_Utils;
extern TypeUtils _SCSIM_struct__5609_Utils;
extern TypeUtils _SCSIM_array__5615_Utils;
extern TypeUtils _SCSIM_struct__5618_Utils;
extern TypeUtils _SCSIM_struct__5629_Utils;
extern TypeUtils _SCSIM_struct__5642_Utils;
extern TypeUtils _SCSIM_struct__5653_Utils;
extern TypeUtils _SCSIM_struct__5664_Utils;
extern TypeUtils _SCSIM_struct__5681_Utils;
extern TypeUtils _SCSIM_array__5687_Utils;
extern TypeUtils _SCSIM_struct__5690_Utils;
extern TypeUtils _SCSIM_struct__5701_Utils;
extern TypeUtils _SCSIM_struct__5708_Utils;
extern TypeUtils _SCSIM_struct__5714_Utils;
extern TypeUtils _SCSIM_struct__5723_Utils;
extern TypeUtils _SCSIM_array__5729_Utils;
extern TypeUtils _SCSIM_struct__5732_Utils;
extern TypeUtils _SCSIM_array__5740_Utils;
extern TypeUtils _SCSIM_struct__5743_Utils;
extern TypeUtils _SCSIM_struct__5748_Utils;
extern TypeUtils _SCSIM_array__5753_Utils;
extern TypeUtils _SCSIM_struct__5756_Utils;
extern TypeUtils _SCSIM_array__5762_Utils;
extern TypeUtils _SCSIM_array_int_8_Utils;
extern TypeUtils _SCSIM_array__5768_Utils;
extern TypeUtils _SCSIM_array__5771_Utils;
extern TypeUtils _SCSIM_array_bool_8_Utils;
extern TypeUtils _SCSIM_array__5777_Utils;
extern TypeUtils _SCSIM_array__5780_Utils;
extern TypeUtils _SCSIM_array_int_10_Utils;
extern TypeUtils _SCSIM_Q_UPDOWN_Utils;
extern TypeUtils _SCSIM_M_VERSION_Utils;
extern TypeUtils _SCSIM_Q_MEDIA_Utils;
extern TypeUtils _SCSIM_N_TOTAL_Utils;
extern TypeUtils _SCSIM_M_MCOUNT_Utils;
extern TypeUtils _SCSIM_NID_C_Utils;
extern TypeUtils _SCSIM_NID_BG_Utils;
extern TypeUtils _SCSIM_Q_LINK_Utils;
extern TypeUtils _SCSIM_NID_LRBG_Utils;
extern TypeUtils _SCSIM_NID_PACKET_Utils;
extern TypeUtils _SCSIM_Q_DIR_Utils;
extern TypeUtils _SCSIM_L_PACKET_Utils;
extern TypeUtils _SCSIM_Q_SCALE_Utils;
extern TypeUtils _SCSIM_D_LINK_Utils;
extern TypeUtils _SCSIM_Q_NEWCOUNTRY_Utils;
extern TypeUtils _SCSIM_Q_LINKORIENTATION_Utils;
extern TypeUtils _SCSIM_Q_LINKREACTION_Utils;
extern TypeUtils _SCSIM_Q_LOCACC_Utils;
extern TypeUtils _SCSIM_Q_DIRLRBG_Utils;
extern TypeUtils _SCSIM_Q_DIRTRAIN_Utils;
extern TypeUtils _SCSIM_NID_ENGINE_Utils;
extern TypeUtils _SCSIM_NID_OPERATIONAL_Utils;
extern TypeUtils _SCSIM_L_TRAIN_Utils;
extern TypeUtils _SCSIM_Q_NVLOCACC_Utils;
extern TypeUtils _SCSIM_NID_PRVLRBG_Utils;
extern TypeUtils _SCSIM_Q_DLRBG_Utils;
extern TypeUtils _SCSIM_odometryFactors_T_ctp_t_pck_t_engine_Utils;
extern TypeUtils _SCSIM_genPassedBG_T_ctp_t_pck_t_engine_Utils;
extern TypeUtils _SCSIM_genPassedBGs_T_ctp_t_pck_t_engine_Utils;
extern TypeUtils _SCSIM_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_Utils;
extern TypeUtils _SCSIM_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils;
extern TypeUtils _SCSIM_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_Utils;
extern TypeUtils _SCSIM_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils;
extern TypeUtils _SCSIM_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils;
extern TypeUtils _SCSIM_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_Utils;
extern TypeUtils _SCSIM_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_Utils;
extern TypeUtils _SCSIM_passedBG_T_BG_Types_Pkg_Utils;
extern TypeUtils _SCSIM_BG_Header_T_BG_Types_Pkg_Utils;
extern TypeUtils _SCSIM_LinkedBGs_T_BG_Types_Pkg_Utils;
extern TypeUtils _SCSIM_LinkedBG_T_BG_Types_Pkg_Utils;
extern TypeUtils _SCSIM_T_internal_Type_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_OdometryLocations_T_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_L_internal_Type_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_LocWithInAcc_T_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_Speed_T_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_V_internal_Type_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_Location_T_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_odometry_T_Obu_BasicTypes_Pkg_Utils;
extern TypeUtils _SCSIM_positionedBG_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_infoFromLinking_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_trainProperties_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_positionedBGs_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_positionErrors_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_trainPosition_T_TrainPosition_Types_Pck_Utils;
extern TypeUtils _SCSIM_trainPositionInfo_T_TrainPosition_Types_Pck_Utils;

/****************************************************************
 ** kcg_real
 ****************************************************************/
extern const char * kcg_real_to_string(const void* pValue);
extern int check_kcg_real_string(const char* strValue);
extern int string_to_kcg_real(const char* strValue, void* pValue);
int is_kcg_real_allow_double_convertion();
extern int kcg_real_to_double(double * nValue, const void*);
extern const char * get_kcg_real_signature();
extern int compare_kcg_real_type(int*, const char*, const void*);
#define kcg_real_filter_size 0
#define get_kcg_real_filter_utils 0
#define kcg_real_filter_values 0
/****************************************************************
 ** kcg_bool
 ****************************************************************/
extern const char * kcg_bool_to_string(const void* pValue);
extern int check_kcg_bool_string(const char* strValue);
extern int string_to_kcg_bool(const char* strValue, void* pValue);
int is_kcg_bool_allow_double_convertion();
extern int kcg_bool_to_double(double * nValue, const void*);
extern const char * get_kcg_bool_signature();
extern int compare_kcg_bool_type(int*, const char*, const void*);
#define kcg_bool_filter_size 0
#define get_kcg_bool_filter_utils 0
#define kcg_bool_filter_values 0
/****************************************************************
 ** kcg_char
 ****************************************************************/
extern const char * kcg_char_to_string(const void* pValue);
extern int check_kcg_char_string(const char* strValue);
extern int string_to_kcg_char(const char* strValue, void* pValue);
int is_kcg_char_allow_double_convertion();
extern int kcg_char_to_double(double * nValue, const void*);
extern const char * get_kcg_char_signature();
extern int compare_kcg_char_type(int*, const char*, const void*);
#define kcg_char_filter_size 0
#define get_kcg_char_filter_utils 0
#define kcg_char_filter_values 0
/****************************************************************
 ** kcg_int
 ****************************************************************/
extern const char * kcg_int_to_string(const void* pValue);
extern int check_kcg_int_string(const char* strValue);
extern int string_to_kcg_int(const char* strValue, void* pValue);
int is_kcg_int_allow_double_convertion();
extern int kcg_int_to_double(double * nValue, const void*);
extern const char * get_kcg_int_signature();
extern int compare_kcg_int_type(int*, const char*, const void*);
#define kcg_int_filter_size 0
#define get_kcg_int_filter_utils 0
#define kcg_int_filter_values 0
/****************************************************************
 ** struct__5578
 ****************************************************************/
extern const char * struct__5578_to_string(const void* pValue);
extern int check_struct__5578_string(const char* strValue);
extern int string_to_struct__5578(const char* strValue, void* pValue);
int is_struct__5578_allow_double_convertion();
extern const char * get_struct__5578_signature();
extern int compare_struct__5578_type(int*, const char*, const void*);
#define struct__5578_filter_size 3
extern FilterUtils get_struct__5578_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5578_filter_values[3];
/****************************************************************
 ** struct__5584
 ****************************************************************/
extern const char * struct__5584_to_string(const void* pValue);
extern int check_struct__5584_string(const char* strValue);
extern int string_to_struct__5584(const char* strValue, void* pValue);
int is_struct__5584_allow_double_convertion();
extern const char * get_struct__5584_signature();
extern int compare_struct__5584_type(int*, const char*, const void*);
#define struct__5584_filter_size 13
extern FilterUtils get_struct__5584_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5584_filter_values[13];
/****************************************************************
 ** struct__5600
 ****************************************************************/
extern const char * struct__5600_to_string(const void* pValue);
extern int check_struct__5600_string(const char* strValue);
extern int string_to_struct__5600(const char* strValue, void* pValue);
int is_struct__5600_allow_double_convertion();
extern const char * get_struct__5600_signature();
extern int compare_struct__5600_type(int*, const char*, const void*);
#define struct__5600_filter_size 6
extern FilterUtils get_struct__5600_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5600_filter_values[6];
/****************************************************************
 ** struct__5609
 ****************************************************************/
extern const char * struct__5609_to_string(const void* pValue);
extern int check_struct__5609_string(const char* strValue);
extern int string_to_struct__5609(const char* strValue, void* pValue);
int is_struct__5609_allow_double_convertion();
extern const char * get_struct__5609_signature();
extern int compare_struct__5609_type(int*, const char*, const void*);
#define struct__5609_filter_size 3
extern FilterUtils get_struct__5609_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5609_filter_values[3];
/****************************************************************
 ** array__5615
 ****************************************************************/
extern const char * array__5615_to_string(const void* pValue);
extern int check_array__5615_string(const char* strValue);
extern int string_to_array__5615(const char* strValue, void* pValue);
int is_array__5615_allow_double_convertion();
extern const char * get_array__5615_signature();
extern int compare_array__5615_type(int*, const char*, const void*);
#define array__5615_filter_size 4
extern FilterUtils get_array__5615_filter_utils(const char* strFilter, void* pValue);
#define array__5615_filter_values 0
/****************************************************************
 ** struct__5618
 ****************************************************************/
extern const char * struct__5618_to_string(const void* pValue);
extern int check_struct__5618_string(const char* strValue);
extern int string_to_struct__5618(const char* strValue, void* pValue);
int is_struct__5618_allow_double_convertion();
extern const char * get_struct__5618_signature();
extern int compare_struct__5618_type(int*, const char*, const void*);
#define struct__5618_filter_size 8
extern FilterUtils get_struct__5618_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5618_filter_values[8];
/****************************************************************
 ** struct__5629
 ****************************************************************/
extern const char * struct__5629_to_string(const void* pValue);
extern int check_struct__5629_string(const char* strValue);
extern int string_to_struct__5629(const char* strValue, void* pValue);
int is_struct__5629_allow_double_convertion();
extern const char * get_struct__5629_signature();
extern int compare_struct__5629_type(int*, const char*, const void*);
#define struct__5629_filter_size 10
extern FilterUtils get_struct__5629_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5629_filter_values[10];
/****************************************************************
 ** struct__5642
 ****************************************************************/
extern const char * struct__5642_to_string(const void* pValue);
extern int check_struct__5642_string(const char* strValue);
extern int string_to_struct__5642(const char* strValue, void* pValue);
int is_struct__5642_allow_double_convertion();
extern const char * get_struct__5642_signature();
extern int compare_struct__5642_type(int*, const char*, const void*);
#define struct__5642_filter_size 8
extern FilterUtils get_struct__5642_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5642_filter_values[8];
/****************************************************************
 ** struct__5653
 ****************************************************************/
extern const char * struct__5653_to_string(const void* pValue);
extern int check_struct__5653_string(const char* strValue);
extern int string_to_struct__5653(const char* strValue, void* pValue);
int is_struct__5653_allow_double_convertion();
extern const char * get_struct__5653_signature();
extern int compare_struct__5653_type(int*, const char*, const void*);
#define struct__5653_filter_size 8
extern FilterUtils get_struct__5653_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5653_filter_values[8];
/****************************************************************
 ** struct__5664
 ****************************************************************/
extern const char * struct__5664_to_string(const void* pValue);
extern int check_struct__5664_string(const char* strValue);
extern int string_to_struct__5664(const char* strValue, void* pValue);
int is_struct__5664_allow_double_convertion();
extern const char * get_struct__5664_signature();
extern int compare_struct__5664_type(int*, const char*, const void*);
#define struct__5664_filter_size 14
extern FilterUtils get_struct__5664_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5664_filter_values[14];
/****************************************************************
 ** struct__5681
 ****************************************************************/
extern const char * struct__5681_to_string(const void* pValue);
extern int check_struct__5681_string(const char* strValue);
extern int string_to_struct__5681(const char* strValue, void* pValue);
int is_struct__5681_allow_double_convertion();
extern const char * get_struct__5681_signature();
extern int compare_struct__5681_type(int*, const char*, const void*);
#define struct__5681_filter_size 3
extern FilterUtils get_struct__5681_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5681_filter_values[3];
/****************************************************************
 ** array__5687
 ****************************************************************/
extern const char * array__5687_to_string(const void* pValue);
extern int check_array__5687_string(const char* strValue);
extern int string_to_array__5687(const char* strValue, void* pValue);
int is_array__5687_allow_double_convertion();
extern const char * get_array__5687_signature();
extern int compare_array__5687_type(int*, const char*, const void*);
#define array__5687_filter_size 8
extern FilterUtils get_array__5687_filter_utils(const char* strFilter, void* pValue);
#define array__5687_filter_values 0
/****************************************************************
 ** struct__5690
 ****************************************************************/
extern const char * struct__5690_to_string(const void* pValue);
extern int check_struct__5690_string(const char* strValue);
extern int string_to_struct__5690(const char* strValue, void* pValue);
int is_struct__5690_allow_double_convertion();
extern const char * get_struct__5690_signature();
extern int compare_struct__5690_type(int*, const char*, const void*);
#define struct__5690_filter_size 8
extern FilterUtils get_struct__5690_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5690_filter_values[8];
/****************************************************************
 ** struct__5701
 ****************************************************************/
extern const char * struct__5701_to_string(const void* pValue);
extern int check_struct__5701_string(const char* strValue);
extern int string_to_struct__5701(const char* strValue, void* pValue);
int is_struct__5701_allow_double_convertion();
extern const char * get_struct__5701_signature();
extern int compare_struct__5701_type(int*, const char*, const void*);
#define struct__5701_filter_size 4
extern FilterUtils get_struct__5701_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5701_filter_values[4];
/****************************************************************
 ** struct__5708
 ****************************************************************/
extern const char * struct__5708_to_string(const void* pValue);
extern int check_struct__5708_string(const char* strValue);
extern int string_to_struct__5708(const char* strValue, void* pValue);
int is_struct__5708_allow_double_convertion();
extern const char * get_struct__5708_signature();
extern int compare_struct__5708_type(int*, const char*, const void*);
#define struct__5708_filter_size 3
extern FilterUtils get_struct__5708_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5708_filter_values[3];
/****************************************************************
 ** struct__5714
 ****************************************************************/
extern const char * struct__5714_to_string(const void* pValue);
extern int check_struct__5714_string(const char* strValue);
extern int string_to_struct__5714(const char* strValue, void* pValue);
int is_struct__5714_allow_double_convertion();
extern const char * get_struct__5714_signature();
extern int compare_struct__5714_type(int*, const char*, const void*);
#define struct__5714_filter_size 6
extern FilterUtils get_struct__5714_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5714_filter_values[6];
/****************************************************************
 ** struct__5723
 ****************************************************************/
extern const char * struct__5723_to_string(const void* pValue);
extern int check_struct__5723_string(const char* strValue);
extern int string_to_struct__5723(const char* strValue, void* pValue);
int is_struct__5723_allow_double_convertion();
extern const char * get_struct__5723_signature();
extern int compare_struct__5723_type(int*, const char*, const void*);
#define struct__5723_filter_size 3
extern FilterUtils get_struct__5723_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5723_filter_values[3];
/****************************************************************
 ** array__5729
 ****************************************************************/
extern const char * array__5729_to_string(const void* pValue);
extern int check_array__5729_string(const char* strValue);
extern int string_to_array__5729(const char* strValue, void* pValue);
int is_array__5729_allow_double_convertion();
extern const char * get_array__5729_signature();
extern int compare_array__5729_type(int*, const char*, const void*);
#define array__5729_filter_size 8
extern FilterUtils get_array__5729_filter_utils(const char* strFilter, void* pValue);
#define array__5729_filter_values 0
/****************************************************************
 ** struct__5732
 ****************************************************************/
extern const char * struct__5732_to_string(const void* pValue);
extern int check_struct__5732_string(const char* strValue);
extern int string_to_struct__5732(const char* strValue, void* pValue);
int is_struct__5732_allow_double_convertion();
extern const char * get_struct__5732_signature();
extern int compare_struct__5732_type(int*, const char*, const void*);
#define struct__5732_filter_size 5
extern FilterUtils get_struct__5732_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5732_filter_values[5];
/****************************************************************
 ** array__5740
 ****************************************************************/
extern const char * array__5740_to_string(const void* pValue);
extern int check_array__5740_string(const char* strValue);
extern int string_to_array__5740(const char* strValue, void* pValue);
int is_array__5740_allow_double_convertion();
extern const char * get_array__5740_signature();
extern int compare_array__5740_type(int*, const char*, const void*);
#define array__5740_filter_size 4
extern FilterUtils get_array__5740_filter_utils(const char* strFilter, void* pValue);
#define array__5740_filter_values 0
/****************************************************************
 ** struct__5743
 ****************************************************************/
extern const char * struct__5743_to_string(const void* pValue);
extern int check_struct__5743_string(const char* strValue);
extern int string_to_struct__5743(const char* strValue, void* pValue);
int is_struct__5743_allow_double_convertion();
extern const char * get_struct__5743_signature();
extern int compare_struct__5743_type(int*, const char*, const void*);
#define struct__5743_filter_size 2
extern FilterUtils get_struct__5743_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5743_filter_values[2];
/****************************************************************
 ** struct__5748
 ****************************************************************/
extern const char * struct__5748_to_string(const void* pValue);
extern int check_struct__5748_string(const char* strValue);
extern int string_to_struct__5748(const char* strValue, void* pValue);
int is_struct__5748_allow_double_convertion();
extern const char * get_struct__5748_signature();
extern int compare_struct__5748_type(int*, const char*, const void*);
#define struct__5748_filter_size 2
extern FilterUtils get_struct__5748_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5748_filter_values[2];
/****************************************************************
 ** array__5753
 ****************************************************************/
extern const char * array__5753_to_string(const void* pValue);
extern int check_array__5753_string(const char* strValue);
extern int string_to_array__5753(const char* strValue, void* pValue);
int is_array__5753_allow_double_convertion();
extern const char * get_array__5753_signature();
extern int compare_array__5753_type(int*, const char*, const void*);
#define array__5753_filter_size 10
extern FilterUtils get_array__5753_filter_utils(const char* strFilter, void* pValue);
#define array__5753_filter_values 0
/****************************************************************
 ** struct__5756
 ****************************************************************/
extern const char * struct__5756_to_string(const void* pValue);
extern int check_struct__5756_string(const char* strValue);
extern int string_to_struct__5756(const char* strValue, void* pValue);
int is_struct__5756_allow_double_convertion();
extern const char * get_struct__5756_signature();
extern int compare_struct__5756_type(int*, const char*, const void*);
#define struct__5756_filter_size 3
extern FilterUtils get_struct__5756_filter_utils(const char* strFilter, void* pValue);
extern const char * struct__5756_filter_values[3];
/****************************************************************
 ** array__5762
 ****************************************************************/
extern const char * array__5762_to_string(const void* pValue);
extern int check_array__5762_string(const char* strValue);
extern int string_to_array__5762(const char* strValue, void* pValue);
int is_array__5762_allow_double_convertion();
extern const char * get_array__5762_signature();
extern int compare_array__5762_type(int*, const char*, const void*);
#define array__5762_filter_size 4
extern FilterUtils get_array__5762_filter_utils(const char* strFilter, void* pValue);
#define array__5762_filter_values 0
/****************************************************************
 ** array_int_8
 ****************************************************************/
extern const char * array_int_8_to_string(const void* pValue);
extern int check_array_int_8_string(const char* strValue);
extern int string_to_array_int_8(const char* strValue, void* pValue);
int is_array_int_8_allow_double_convertion();
extern const char * get_array_int_8_signature();
extern int compare_array_int_8_type(int*, const char*, const void*);
#define array_int_8_filter_size 8
extern FilterUtils get_array_int_8_filter_utils(const char* strFilter, void* pValue);
#define array_int_8_filter_values 0
/****************************************************************
 ** array__5768
 ****************************************************************/
extern const char * array__5768_to_string(const void* pValue);
extern int check_array__5768_string(const char* strValue);
extern int string_to_array__5768(const char* strValue, void* pValue);
int is_array__5768_allow_double_convertion();
extern const char * get_array__5768_signature();
extern int compare_array__5768_type(int*, const char*, const void*);
#define array__5768_filter_size 7
extern FilterUtils get_array__5768_filter_utils(const char* strFilter, void* pValue);
#define array__5768_filter_values 0
/****************************************************************
 ** array__5771
 ****************************************************************/
extern const char * array__5771_to_string(const void* pValue);
extern int check_array__5771_string(const char* strValue);
extern int string_to_array__5771(const char* strValue, void* pValue);
int is_array__5771_allow_double_convertion();
extern const char * get_array__5771_signature();
extern int compare_array__5771_type(int*, const char*, const void*);
#define array__5771_filter_size 1
extern FilterUtils get_array__5771_filter_utils(const char* strFilter, void* pValue);
#define array__5771_filter_values 0
/****************************************************************
 ** array_bool_8
 ****************************************************************/
extern const char * array_bool_8_to_string(const void* pValue);
extern int check_array_bool_8_string(const char* strValue);
extern int string_to_array_bool_8(const char* strValue, void* pValue);
int is_array_bool_8_allow_double_convertion();
extern const char * get_array_bool_8_signature();
extern int compare_array_bool_8_type(int*, const char*, const void*);
#define array_bool_8_filter_size 8
extern FilterUtils get_array_bool_8_filter_utils(const char* strFilter, void* pValue);
#define array_bool_8_filter_values 0
/****************************************************************
 ** array__5777
 ****************************************************************/
extern const char * array__5777_to_string(const void* pValue);
extern int check_array__5777_string(const char* strValue);
extern int string_to_array__5777(const char* strValue, void* pValue);
int is_array__5777_allow_double_convertion();
extern const char * get_array__5777_signature();
extern int compare_array__5777_type(int*, const char*, const void*);
#define array__5777_filter_size 8
extern FilterUtils get_array__5777_filter_utils(const char* strFilter, void* pValue);
#define array__5777_filter_values 0
/****************************************************************
 ** array__5780
 ****************************************************************/
extern const char * array__5780_to_string(const void* pValue);
extern int check_array__5780_string(const char* strValue);
extern int string_to_array__5780(const char* strValue, void* pValue);
int is_array__5780_allow_double_convertion();
extern const char * get_array__5780_signature();
extern int compare_array__5780_type(int*, const char*, const void*);
#define array__5780_filter_size 8
extern FilterUtils get_array__5780_filter_utils(const char* strFilter, void* pValue);
#define array__5780_filter_values 0
/****************************************************************
 ** array_int_10
 ****************************************************************/
extern const char * array_int_10_to_string(const void* pValue);
extern int check_array_int_10_string(const char* strValue);
extern int string_to_array_int_10(const char* strValue, void* pValue);
int is_array_int_10_allow_double_convertion();
extern const char * get_array_int_10_signature();
extern int compare_array_int_10_type(int*, const char*, const void*);
#define array_int_10_filter_size 10
extern FilterUtils get_array_int_10_filter_utils(const char* strFilter, void* pValue);
#define array_int_10_filter_values 0
/****************************************************************
 ** Q_UPDOWN
 ****************************************************************/
extern const char * Q_UPDOWN_to_string(const void* pValue);
extern int check_Q_UPDOWN_string(const char* strValue);
extern int string_to_Q_UPDOWN(const char* strValue, void* pValue);
int is_Q_UPDOWN_allow_double_convertion();
extern int Q_UPDOWN_to_double(double * nValue, const void*);
extern const char * get_Q_UPDOWN_signature();
extern int compare_Q_UPDOWN_type(int*, const char*, const void*);
#define Q_UPDOWN_filter_size 0
#define get_Q_UPDOWN_filter_utils 0
#define Q_UPDOWN_filter_values 0
/****************************************************************
 ** M_VERSION
 ****************************************************************/
extern const char * M_VERSION_to_string(const void* pValue);
extern int check_M_VERSION_string(const char* strValue);
extern int string_to_M_VERSION(const char* strValue, void* pValue);
int is_M_VERSION_allow_double_convertion();
extern int M_VERSION_to_double(double * nValue, const void*);
extern const char * get_M_VERSION_signature();
extern int compare_M_VERSION_type(int*, const char*, const void*);
#define M_VERSION_filter_size 0
#define get_M_VERSION_filter_utils 0
#define M_VERSION_filter_values 0
/****************************************************************
 ** Q_MEDIA
 ****************************************************************/
extern const char * Q_MEDIA_to_string(const void* pValue);
extern int check_Q_MEDIA_string(const char* strValue);
extern int string_to_Q_MEDIA(const char* strValue, void* pValue);
int is_Q_MEDIA_allow_double_convertion();
extern int Q_MEDIA_to_double(double * nValue, const void*);
extern const char * get_Q_MEDIA_signature();
extern int compare_Q_MEDIA_type(int*, const char*, const void*);
#define Q_MEDIA_filter_size 0
#define get_Q_MEDIA_filter_utils 0
#define Q_MEDIA_filter_values 0
/****************************************************************
 ** N_TOTAL
 ****************************************************************/
extern const char * N_TOTAL_to_string(const void* pValue);
extern int check_N_TOTAL_string(const char* strValue);
extern int string_to_N_TOTAL(const char* strValue, void* pValue);
int is_N_TOTAL_allow_double_convertion();
extern int N_TOTAL_to_double(double * nValue, const void*);
extern const char * get_N_TOTAL_signature();
extern int compare_N_TOTAL_type(int*, const char*, const void*);
#define N_TOTAL_filter_size 0
#define get_N_TOTAL_filter_utils 0
#define N_TOTAL_filter_values 0
/****************************************************************
 ** M_MCOUNT
 ****************************************************************/
extern const char * M_MCOUNT_to_string(const void* pValue);
extern int check_M_MCOUNT_string(const char* strValue);
extern int string_to_M_MCOUNT(const char* strValue, void* pValue);
int is_M_MCOUNT_allow_double_convertion();
extern int M_MCOUNT_to_double(double * nValue, const void*);
#define get_M_MCOUNT_signature get_kcg_int_signature
#define compare_M_MCOUNT_type compare_kcg_int_type
#define M_MCOUNT_filter_size kcg_int_filter_size
#define get_M_MCOUNT_filter_utils get_kcg_int_filter_utils
#define M_MCOUNT_filter_values kcg_int_filter_values
/****************************************************************
 ** NID_C
 ****************************************************************/
extern const char * NID_C_to_string(const void* pValue);
extern int check_NID_C_string(const char* strValue);
extern int string_to_NID_C(const char* strValue, void* pValue);
int is_NID_C_allow_double_convertion();
extern int NID_C_to_double(double * nValue, const void*);
#define get_NID_C_signature get_kcg_int_signature
#define compare_NID_C_type compare_kcg_int_type
#define NID_C_filter_size kcg_int_filter_size
#define get_NID_C_filter_utils get_kcg_int_filter_utils
#define NID_C_filter_values kcg_int_filter_values
/****************************************************************
 ** NID_BG
 ****************************************************************/
extern const char * NID_BG_to_string(const void* pValue);
extern int check_NID_BG_string(const char* strValue);
extern int string_to_NID_BG(const char* strValue, void* pValue);
int is_NID_BG_allow_double_convertion();
extern int NID_BG_to_double(double * nValue, const void*);
#define get_NID_BG_signature get_kcg_int_signature
#define compare_NID_BG_type compare_kcg_int_type
#define NID_BG_filter_size kcg_int_filter_size
#define get_NID_BG_filter_utils get_kcg_int_filter_utils
#define NID_BG_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_LINK
 ****************************************************************/
extern const char * Q_LINK_to_string(const void* pValue);
extern int check_Q_LINK_string(const char* strValue);
extern int string_to_Q_LINK(const char* strValue, void* pValue);
int is_Q_LINK_allow_double_convertion();
extern int Q_LINK_to_double(double * nValue, const void*);
extern const char * get_Q_LINK_signature();
extern int compare_Q_LINK_type(int*, const char*, const void*);
#define Q_LINK_filter_size 0
#define get_Q_LINK_filter_utils 0
#define Q_LINK_filter_values 0
/****************************************************************
 ** NID_LRBG
 ****************************************************************/
extern const char * NID_LRBG_to_string(const void* pValue);
extern int check_NID_LRBG_string(const char* strValue);
extern int string_to_NID_LRBG(const char* strValue, void* pValue);
int is_NID_LRBG_allow_double_convertion();
extern int NID_LRBG_to_double(double * nValue, const void*);
#define get_NID_LRBG_signature get_kcg_int_signature
#define compare_NID_LRBG_type compare_kcg_int_type
#define NID_LRBG_filter_size kcg_int_filter_size
#define get_NID_LRBG_filter_utils get_kcg_int_filter_utils
#define NID_LRBG_filter_values kcg_int_filter_values
/****************************************************************
 ** NID_PACKET
 ****************************************************************/
extern const char * NID_PACKET_to_string(const void* pValue);
extern int check_NID_PACKET_string(const char* strValue);
extern int string_to_NID_PACKET(const char* strValue, void* pValue);
int is_NID_PACKET_allow_double_convertion();
extern int NID_PACKET_to_double(double * nValue, const void*);
#define get_NID_PACKET_signature get_kcg_int_signature
#define compare_NID_PACKET_type compare_kcg_int_type
#define NID_PACKET_filter_size kcg_int_filter_size
#define get_NID_PACKET_filter_utils get_kcg_int_filter_utils
#define NID_PACKET_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_DIR
 ****************************************************************/
extern const char * Q_DIR_to_string(const void* pValue);
extern int check_Q_DIR_string(const char* strValue);
extern int string_to_Q_DIR(const char* strValue, void* pValue);
int is_Q_DIR_allow_double_convertion();
extern int Q_DIR_to_double(double * nValue, const void*);
extern const char * get_Q_DIR_signature();
extern int compare_Q_DIR_type(int*, const char*, const void*);
#define Q_DIR_filter_size 0
#define get_Q_DIR_filter_utils 0
#define Q_DIR_filter_values 0
/****************************************************************
 ** L_PACKET
 ****************************************************************/
extern const char * L_PACKET_to_string(const void* pValue);
extern int check_L_PACKET_string(const char* strValue);
extern int string_to_L_PACKET(const char* strValue, void* pValue);
int is_L_PACKET_allow_double_convertion();
extern int L_PACKET_to_double(double * nValue, const void*);
#define get_L_PACKET_signature get_kcg_int_signature
#define compare_L_PACKET_type compare_kcg_int_type
#define L_PACKET_filter_size kcg_int_filter_size
#define get_L_PACKET_filter_utils get_kcg_int_filter_utils
#define L_PACKET_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_SCALE
 ****************************************************************/
extern const char * Q_SCALE_to_string(const void* pValue);
extern int check_Q_SCALE_string(const char* strValue);
extern int string_to_Q_SCALE(const char* strValue, void* pValue);
int is_Q_SCALE_allow_double_convertion();
extern int Q_SCALE_to_double(double * nValue, const void*);
extern const char * get_Q_SCALE_signature();
extern int compare_Q_SCALE_type(int*, const char*, const void*);
#define Q_SCALE_filter_size 0
#define get_Q_SCALE_filter_utils 0
#define Q_SCALE_filter_values 0
/****************************************************************
 ** D_LINK
 ****************************************************************/
extern const char * D_LINK_to_string(const void* pValue);
extern int check_D_LINK_string(const char* strValue);
extern int string_to_D_LINK(const char* strValue, void* pValue);
int is_D_LINK_allow_double_convertion();
extern int D_LINK_to_double(double * nValue, const void*);
#define get_D_LINK_signature get_kcg_int_signature
#define compare_D_LINK_type compare_kcg_int_type
#define D_LINK_filter_size kcg_int_filter_size
#define get_D_LINK_filter_utils get_kcg_int_filter_utils
#define D_LINK_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_NEWCOUNTRY
 ****************************************************************/
extern const char * Q_NEWCOUNTRY_to_string(const void* pValue);
extern int check_Q_NEWCOUNTRY_string(const char* strValue);
extern int string_to_Q_NEWCOUNTRY(const char* strValue, void* pValue);
int is_Q_NEWCOUNTRY_allow_double_convertion();
extern int Q_NEWCOUNTRY_to_double(double * nValue, const void*);
extern const char * get_Q_NEWCOUNTRY_signature();
extern int compare_Q_NEWCOUNTRY_type(int*, const char*, const void*);
#define Q_NEWCOUNTRY_filter_size 0
#define get_Q_NEWCOUNTRY_filter_utils 0
#define Q_NEWCOUNTRY_filter_values 0
/****************************************************************
 ** Q_LINKORIENTATION
 ****************************************************************/
extern const char * Q_LINKORIENTATION_to_string(const void* pValue);
extern int check_Q_LINKORIENTATION_string(const char* strValue);
extern int string_to_Q_LINKORIENTATION(const char* strValue, void* pValue);
int is_Q_LINKORIENTATION_allow_double_convertion();
extern int Q_LINKORIENTATION_to_double(double * nValue, const void*);
extern const char * get_Q_LINKORIENTATION_signature();
extern int compare_Q_LINKORIENTATION_type(int*, const char*, const void*);
#define Q_LINKORIENTATION_filter_size 0
#define get_Q_LINKORIENTATION_filter_utils 0
#define Q_LINKORIENTATION_filter_values 0
/****************************************************************
 ** Q_LINKREACTION
 ****************************************************************/
extern const char * Q_LINKREACTION_to_string(const void* pValue);
extern int check_Q_LINKREACTION_string(const char* strValue);
extern int string_to_Q_LINKREACTION(const char* strValue, void* pValue);
int is_Q_LINKREACTION_allow_double_convertion();
extern int Q_LINKREACTION_to_double(double * nValue, const void*);
extern const char * get_Q_LINKREACTION_signature();
extern int compare_Q_LINKREACTION_type(int*, const char*, const void*);
#define Q_LINKREACTION_filter_size 0
#define get_Q_LINKREACTION_filter_utils 0
#define Q_LINKREACTION_filter_values 0
/****************************************************************
 ** Q_LOCACC
 ****************************************************************/
extern const char * Q_LOCACC_to_string(const void* pValue);
extern int check_Q_LOCACC_string(const char* strValue);
extern int string_to_Q_LOCACC(const char* strValue, void* pValue);
int is_Q_LOCACC_allow_double_convertion();
extern int Q_LOCACC_to_double(double * nValue, const void*);
#define get_Q_LOCACC_signature get_kcg_int_signature
#define compare_Q_LOCACC_type compare_kcg_int_type
#define Q_LOCACC_filter_size kcg_int_filter_size
#define get_Q_LOCACC_filter_utils get_kcg_int_filter_utils
#define Q_LOCACC_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_DIRLRBG
 ****************************************************************/
extern const char * Q_DIRLRBG_to_string(const void* pValue);
extern int check_Q_DIRLRBG_string(const char* strValue);
extern int string_to_Q_DIRLRBG(const char* strValue, void* pValue);
int is_Q_DIRLRBG_allow_double_convertion();
extern int Q_DIRLRBG_to_double(double * nValue, const void*);
extern const char * get_Q_DIRLRBG_signature();
extern int compare_Q_DIRLRBG_type(int*, const char*, const void*);
#define Q_DIRLRBG_filter_size 0
#define get_Q_DIRLRBG_filter_utils 0
#define Q_DIRLRBG_filter_values 0
/****************************************************************
 ** Q_DIRTRAIN
 ****************************************************************/
extern const char * Q_DIRTRAIN_to_string(const void* pValue);
extern int check_Q_DIRTRAIN_string(const char* strValue);
extern int string_to_Q_DIRTRAIN(const char* strValue, void* pValue);
int is_Q_DIRTRAIN_allow_double_convertion();
extern int Q_DIRTRAIN_to_double(double * nValue, const void*);
extern const char * get_Q_DIRTRAIN_signature();
extern int compare_Q_DIRTRAIN_type(int*, const char*, const void*);
#define Q_DIRTRAIN_filter_size 0
#define get_Q_DIRTRAIN_filter_utils 0
#define Q_DIRTRAIN_filter_values 0
/****************************************************************
 ** NID_ENGINE
 ****************************************************************/
extern const char * NID_ENGINE_to_string(const void* pValue);
extern int check_NID_ENGINE_string(const char* strValue);
extern int string_to_NID_ENGINE(const char* strValue, void* pValue);
int is_NID_ENGINE_allow_double_convertion();
extern int NID_ENGINE_to_double(double * nValue, const void*);
#define get_NID_ENGINE_signature get_kcg_int_signature
#define compare_NID_ENGINE_type compare_kcg_int_type
#define NID_ENGINE_filter_size kcg_int_filter_size
#define get_NID_ENGINE_filter_utils get_kcg_int_filter_utils
#define NID_ENGINE_filter_values kcg_int_filter_values
/****************************************************************
 ** NID_OPERATIONAL
 ****************************************************************/
extern const char * NID_OPERATIONAL_to_string(const void* pValue);
extern int check_NID_OPERATIONAL_string(const char* strValue);
extern int string_to_NID_OPERATIONAL(const char* strValue, void* pValue);
int is_NID_OPERATIONAL_allow_double_convertion();
extern int NID_OPERATIONAL_to_double(double * nValue, const void*);
#define get_NID_OPERATIONAL_signature get_kcg_int_signature
#define compare_NID_OPERATIONAL_type compare_kcg_int_type
#define NID_OPERATIONAL_filter_size kcg_int_filter_size
#define get_NID_OPERATIONAL_filter_utils get_kcg_int_filter_utils
#define NID_OPERATIONAL_filter_values kcg_int_filter_values
/****************************************************************
 ** L_TRAIN
 ****************************************************************/
extern const char * L_TRAIN_to_string(const void* pValue);
extern int check_L_TRAIN_string(const char* strValue);
extern int string_to_L_TRAIN(const char* strValue, void* pValue);
int is_L_TRAIN_allow_double_convertion();
extern int L_TRAIN_to_double(double * nValue, const void*);
#define get_L_TRAIN_signature get_kcg_int_signature
#define compare_L_TRAIN_type compare_kcg_int_type
#define L_TRAIN_filter_size kcg_int_filter_size
#define get_L_TRAIN_filter_utils get_kcg_int_filter_utils
#define L_TRAIN_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_NVLOCACC
 ****************************************************************/
extern const char * Q_NVLOCACC_to_string(const void* pValue);
extern int check_Q_NVLOCACC_string(const char* strValue);
extern int string_to_Q_NVLOCACC(const char* strValue, void* pValue);
int is_Q_NVLOCACC_allow_double_convertion();
extern int Q_NVLOCACC_to_double(double * nValue, const void*);
#define get_Q_NVLOCACC_signature get_kcg_int_signature
#define compare_Q_NVLOCACC_type compare_kcg_int_type
#define Q_NVLOCACC_filter_size kcg_int_filter_size
#define get_Q_NVLOCACC_filter_utils get_kcg_int_filter_utils
#define Q_NVLOCACC_filter_values kcg_int_filter_values
/****************************************************************
 ** NID_PRVLRBG
 ****************************************************************/
extern const char * NID_PRVLRBG_to_string(const void* pValue);
extern int check_NID_PRVLRBG_string(const char* strValue);
extern int string_to_NID_PRVLRBG(const char* strValue, void* pValue);
int is_NID_PRVLRBG_allow_double_convertion();
extern int NID_PRVLRBG_to_double(double * nValue, const void*);
#define get_NID_PRVLRBG_signature get_kcg_int_signature
#define compare_NID_PRVLRBG_type compare_kcg_int_type
#define NID_PRVLRBG_filter_size kcg_int_filter_size
#define get_NID_PRVLRBG_filter_utils get_kcg_int_filter_utils
#define NID_PRVLRBG_filter_values kcg_int_filter_values
/****************************************************************
 ** Q_DLRBG
 ****************************************************************/
extern const char * Q_DLRBG_to_string(const void* pValue);
extern int check_Q_DLRBG_string(const char* strValue);
extern int string_to_Q_DLRBG(const char* strValue, void* pValue);
int is_Q_DLRBG_allow_double_convertion();
extern int Q_DLRBG_to_double(double * nValue, const void*);
extern const char * get_Q_DLRBG_signature();
extern int compare_Q_DLRBG_type(int*, const char*, const void*);
#define Q_DLRBG_filter_size 0
#define get_Q_DLRBG_filter_utils 0
#define Q_DLRBG_filter_values 0
/****************************************************************
 ** odometryFactors_T_ctp_t_pck_t_engine
 ****************************************************************/
extern const char * odometryFactors_T_ctp_t_pck_t_engine_to_string(const void* pValue);
extern int check_odometryFactors_T_ctp_t_pck_t_engine_string(const char* strValue);
extern int string_to_odometryFactors_T_ctp_t_pck_t_engine(const char* strValue, void* pValue);
int is_odometryFactors_T_ctp_t_pck_t_engine_allow_double_convertion();
extern int odometryFactors_T_ctp_t_pck_t_engine_to_double(double * nValue, const void*);
#define get_odometryFactors_T_ctp_t_pck_t_engine_signature get_struct__5756_signature
#define compare_odometryFactors_T_ctp_t_pck_t_engine_type compare_struct__5756_type
#define odometryFactors_T_ctp_t_pck_t_engine_filter_size struct__5756_filter_size
#define get_odometryFactors_T_ctp_t_pck_t_engine_filter_utils get_struct__5756_filter_utils
#define odometryFactors_T_ctp_t_pck_t_engine_filter_values struct__5756_filter_values
/****************************************************************
 ** genPassedBG_T_ctp_t_pck_t_engine
 ****************************************************************/
extern const char * genPassedBG_T_ctp_t_pck_t_engine_to_string(const void* pValue);
extern int check_genPassedBG_T_ctp_t_pck_t_engine_string(const char* strValue);
extern int string_to_genPassedBG_T_ctp_t_pck_t_engine(const char* strValue, void* pValue);
int is_genPassedBG_T_ctp_t_pck_t_engine_allow_double_convertion();
extern int genPassedBG_T_ctp_t_pck_t_engine_to_double(double * nValue, const void*);
#define get_genPassedBG_T_ctp_t_pck_t_engine_signature get_struct__5748_signature
#define compare_genPassedBG_T_ctp_t_pck_t_engine_type compare_struct__5748_type
#define genPassedBG_T_ctp_t_pck_t_engine_filter_size struct__5748_filter_size
#define get_genPassedBG_T_ctp_t_pck_t_engine_filter_utils get_struct__5748_filter_utils
#define genPassedBG_T_ctp_t_pck_t_engine_filter_values struct__5748_filter_values
/****************************************************************
 ** genPassedBGs_T_ctp_t_pck_t_engine
 ****************************************************************/
extern const char * genPassedBGs_T_ctp_t_pck_t_engine_to_string(const void* pValue);
extern int check_genPassedBGs_T_ctp_t_pck_t_engine_string(const char* strValue);
extern int string_to_genPassedBGs_T_ctp_t_pck_t_engine(const char* strValue, void* pValue);
int is_genPassedBGs_T_ctp_t_pck_t_engine_allow_double_convertion();
extern int genPassedBGs_T_ctp_t_pck_t_engine_to_double(double * nValue, const void*);
#define get_genPassedBGs_T_ctp_t_pck_t_engine_signature get_array__5753_signature
#define compare_genPassedBGs_T_ctp_t_pck_t_engine_type compare_array__5753_type
#define genPassedBGs_T_ctp_t_pck_t_engine_filter_size array__5753_filter_size
#define get_genPassedBGs_T_ctp_t_pck_t_engine_filter_utils get_array__5753_filter_utils
#define genPassedBGs_T_ctp_t_pck_t_engine_filter_values array__5753_filter_values
/****************************************************************
 ** positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg
 ****************************************************************/
extern const char * positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_string(const void* pValue);
extern int check_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_string(const char* strValue);
extern int string_to_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg(const char* strValue, void* pValue);
int is_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_allow_double_convertion();
extern int positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_to_double(double * nValue, const void*);
#define get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_signature get_struct__5743_signature
#define compare_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_type compare_struct__5743_type
#define positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_filter_size struct__5743_filter_size
#define get_positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_filter_utils get_struct__5743_filter_utils
#define positionedBGs_w_overrun_T_CalculateTrainPosition_Pkg_filter_values struct__5743_filter_values
/****************************************************************
 ** BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg
 ****************************************************************/
extern const char * BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void* pValue);
extern int check_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char* strValue);
extern int string_to_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* strValue, void* pValue);
int is_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion();
extern int BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(double * nValue, const void*);
#define get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature get_struct__5714_signature
#define compare_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_type compare_struct__5714_type
#define BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_size struct__5714_filter_size
#define get_BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_utils get_struct__5714_filter_utils
#define BG_counters_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_values struct__5714_filter_values
/****************************************************************
 ** BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg
 ****************************************************************/
extern const char * BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_string(const void* pValue);
extern int check_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_string(const char* strValue);
extern int string_to_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg(const char* strValue, void* pValue);
int is_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_allow_double_convertion();
extern int BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_to_double(double * nValue, const void*);
#define get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_signature get_struct__5708_signature
#define compare_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_type compare_struct__5708_type
#define BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_size struct__5708_filter_size
#define get_BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_utils get_struct__5708_filter_utils
#define BG_find_T_CalculateTrainPosition_Pkg_BG_utilities_Pkg_filter_values struct__5708_filter_values
/****************************************************************
 ** refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg
 ****************************************************************/
extern const char * refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void* pValue);
extern int check_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char* strValue);
extern int string_to_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* strValue, void* pValue);
int is_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion();
extern int refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(double * nValue, const void*);
#define get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature get_struct__5732_signature
#define compare_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_type compare_struct__5732_type
#define refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_size struct__5732_filter_size
#define get_refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_utils get_struct__5732_filter_utils
#define refBGs_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_values struct__5732_filter_values
/****************************************************************
 ** linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg
 ****************************************************************/
extern const char * linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void* pValue);
extern int check_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char* strValue);
extern int string_to_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* strValue, void* pValue);
int is_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion();
extern int linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(double * nValue, const void*);
#define get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature get_struct__5723_signature
#define compare_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_type compare_struct__5723_type
#define linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_size struct__5723_filter_size
#define get_linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_utils get_struct__5723_filter_utils
#define linkedBG_index_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_values struct__5723_filter_values
/****************************************************************
 ** linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg
 ****************************************************************/
extern const char * linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_string(const void* pValue);
extern int check_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_string(const char* strValue);
extern int string_to_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg(const char* strValue, void* pValue);
int is_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_allow_double_convertion();
extern int linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_to_double(double * nValue, const void*);
#define get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_signature get_array__5729_signature
#define compare_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_type compare_array__5729_type
#define linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_size array__5729_filter_size
#define get_linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_utils get_array__5729_filter_utils
#define linkedBGs_indices_T_CalculateTrainPosition_Pkg_BG_relocation_Pkg_filter_values array__5729_filter_values
/****************************************************************
 ** trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg
 ****************************************************************/
extern const char * trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_string(const void* pValue);
extern int check_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_string(const char* strValue);
extern int string_to_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg(const char* strValue, void* pValue);
int is_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_allow_double_convertion();
extern int trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_to_double(double * nValue, const void*);
extern const char * get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_signature();
extern int compare_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_type(int*, const char*, const void*);
#define trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_filter_size 0
#define get_trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_filter_utils 0
#define trainMovementDir_T_CalculateTrainPosition_Pkg_Pos_Pkg_filter_values 0
/****************************************************************
 ** passedBG_T_BG_Types_Pkg
 ****************************************************************/
extern const char * passedBG_T_BG_Types_Pkg_to_string(const void* pValue);
extern int check_passedBG_T_BG_Types_Pkg_string(const char* strValue);
extern int string_to_passedBG_T_BG_Types_Pkg(const char* strValue, void* pValue);
int is_passedBG_T_BG_Types_Pkg_allow_double_convertion();
extern int passedBG_T_BG_Types_Pkg_to_double(double * nValue, const void*);
#define get_passedBG_T_BG_Types_Pkg_signature get_struct__5629_signature
#define compare_passedBG_T_BG_Types_Pkg_type compare_struct__5629_type
#define passedBG_T_BG_Types_Pkg_filter_size struct__5629_filter_size
#define get_passedBG_T_BG_Types_Pkg_filter_utils get_struct__5629_filter_utils
#define passedBG_T_BG_Types_Pkg_filter_values struct__5629_filter_values
/****************************************************************
 ** BG_Header_T_BG_Types_Pkg
 ****************************************************************/
extern const char * BG_Header_T_BG_Types_Pkg_to_string(const void* pValue);
extern int check_BG_Header_T_BG_Types_Pkg_string(const char* strValue);
extern int string_to_BG_Header_T_BG_Types_Pkg(const char* strValue, void* pValue);
int is_BG_Header_T_BG_Types_Pkg_allow_double_convertion();
extern int BG_Header_T_BG_Types_Pkg_to_double(double * nValue, const void*);
#define get_BG_Header_T_BG_Types_Pkg_signature get_struct__5618_signature
#define compare_BG_Header_T_BG_Types_Pkg_type compare_struct__5618_type
#define BG_Header_T_BG_Types_Pkg_filter_size struct__5618_filter_size
#define get_BG_Header_T_BG_Types_Pkg_filter_utils get_struct__5618_filter_utils
#define BG_Header_T_BG_Types_Pkg_filter_values struct__5618_filter_values
/****************************************************************
 ** LinkedBGs_T_BG_Types_Pkg
 ****************************************************************/
extern const char * LinkedBGs_T_BG_Types_Pkg_to_string(const void* pValue);
extern int check_LinkedBGs_T_BG_Types_Pkg_string(const char* strValue);
extern int string_to_LinkedBGs_T_BG_Types_Pkg(const char* strValue, void* pValue);
int is_LinkedBGs_T_BG_Types_Pkg_allow_double_convertion();
extern int LinkedBGs_T_BG_Types_Pkg_to_double(double * nValue, const void*);
#define get_LinkedBGs_T_BG_Types_Pkg_signature get_array__5615_signature
#define compare_LinkedBGs_T_BG_Types_Pkg_type compare_array__5615_type
#define LinkedBGs_T_BG_Types_Pkg_filter_size array__5615_filter_size
#define get_LinkedBGs_T_BG_Types_Pkg_filter_utils get_array__5615_filter_utils
#define LinkedBGs_T_BG_Types_Pkg_filter_values array__5615_filter_values
/****************************************************************
 ** LinkedBG_T_BG_Types_Pkg
 ****************************************************************/
extern const char * LinkedBG_T_BG_Types_Pkg_to_string(const void* pValue);
extern int check_LinkedBG_T_BG_Types_Pkg_string(const char* strValue);
extern int string_to_LinkedBG_T_BG_Types_Pkg(const char* strValue, void* pValue);
int is_LinkedBG_T_BG_Types_Pkg_allow_double_convertion();
extern int LinkedBG_T_BG_Types_Pkg_to_double(double * nValue, const void*);
#define get_LinkedBG_T_BG_Types_Pkg_signature get_struct__5584_signature
#define compare_LinkedBG_T_BG_Types_Pkg_type compare_struct__5584_type
#define LinkedBG_T_BG_Types_Pkg_filter_size struct__5584_filter_size
#define get_LinkedBG_T_BG_Types_Pkg_filter_utils get_struct__5584_filter_utils
#define LinkedBG_T_BG_Types_Pkg_filter_values struct__5584_filter_values
/****************************************************************
 ** T_internal_Type_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * T_internal_Type_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_T_internal_Type_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_T_internal_Type_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_T_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int T_internal_Type_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_T_internal_Type_Obu_BasicTypes_Pkg_signature get_kcg_int_signature
#define compare_T_internal_Type_Obu_BasicTypes_Pkg_type compare_kcg_int_type
#define T_internal_Type_Obu_BasicTypes_Pkg_filter_size kcg_int_filter_size
#define get_T_internal_Type_Obu_BasicTypes_Pkg_filter_utils get_kcg_int_filter_utils
#define T_internal_Type_Obu_BasicTypes_Pkg_filter_values kcg_int_filter_values
/****************************************************************
 ** OdometryLocations_T_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * OdometryLocations_T_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_OdometryLocations_T_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_OdometryLocations_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_OdometryLocations_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int OdometryLocations_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_OdometryLocations_T_Obu_BasicTypes_Pkg_signature get_struct__5609_signature
#define compare_OdometryLocations_T_Obu_BasicTypes_Pkg_type compare_struct__5609_type
#define OdometryLocations_T_Obu_BasicTypes_Pkg_filter_size struct__5609_filter_size
#define get_OdometryLocations_T_Obu_BasicTypes_Pkg_filter_utils get_struct__5609_filter_utils
#define OdometryLocations_T_Obu_BasicTypes_Pkg_filter_values struct__5609_filter_values
/****************************************************************
 ** L_internal_Type_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * L_internal_Type_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_L_internal_Type_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_L_internal_Type_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_L_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int L_internal_Type_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_L_internal_Type_Obu_BasicTypes_Pkg_signature get_kcg_int_signature
#define compare_L_internal_Type_Obu_BasicTypes_Pkg_type compare_kcg_int_type
#define L_internal_Type_Obu_BasicTypes_Pkg_filter_size kcg_int_filter_size
#define get_L_internal_Type_Obu_BasicTypes_Pkg_filter_utils get_kcg_int_filter_utils
#define L_internal_Type_Obu_BasicTypes_Pkg_filter_values kcg_int_filter_values
/****************************************************************
 ** LocWithInAcc_T_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * LocWithInAcc_T_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_LocWithInAcc_T_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_LocWithInAcc_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_LocWithInAcc_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int LocWithInAcc_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_LocWithInAcc_T_Obu_BasicTypes_Pkg_signature get_struct__5578_signature
#define compare_LocWithInAcc_T_Obu_BasicTypes_Pkg_type compare_struct__5578_type
#define LocWithInAcc_T_Obu_BasicTypes_Pkg_filter_size struct__5578_filter_size
#define get_LocWithInAcc_T_Obu_BasicTypes_Pkg_filter_utils get_struct__5578_filter_utils
#define LocWithInAcc_T_Obu_BasicTypes_Pkg_filter_values struct__5578_filter_values
/****************************************************************
 ** Speed_T_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * Speed_T_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_Speed_T_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_Speed_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_Speed_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int Speed_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_Speed_T_Obu_BasicTypes_Pkg_signature get_V_internal_Type_Obu_BasicTypes_Pkg_signature
#define compare_Speed_T_Obu_BasicTypes_Pkg_type compare_V_internal_Type_Obu_BasicTypes_Pkg_type
#define Speed_T_Obu_BasicTypes_Pkg_filter_size V_internal_Type_Obu_BasicTypes_Pkg_filter_size
#define get_Speed_T_Obu_BasicTypes_Pkg_filter_utils get_V_internal_Type_Obu_BasicTypes_Pkg_filter_utils
#define Speed_T_Obu_BasicTypes_Pkg_filter_values V_internal_Type_Obu_BasicTypes_Pkg_filter_values
/****************************************************************
 ** V_internal_Type_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * V_internal_Type_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_V_internal_Type_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_V_internal_Type_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_V_internal_Type_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int V_internal_Type_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_V_internal_Type_Obu_BasicTypes_Pkg_signature get_kcg_int_signature
#define compare_V_internal_Type_Obu_BasicTypes_Pkg_type compare_kcg_int_type
#define V_internal_Type_Obu_BasicTypes_Pkg_filter_size kcg_int_filter_size
#define get_V_internal_Type_Obu_BasicTypes_Pkg_filter_utils get_kcg_int_filter_utils
#define V_internal_Type_Obu_BasicTypes_Pkg_filter_values kcg_int_filter_values
/****************************************************************
 ** Location_T_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * Location_T_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_Location_T_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_Location_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_Location_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int Location_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_Location_T_Obu_BasicTypes_Pkg_signature get_L_internal_Type_Obu_BasicTypes_Pkg_signature
#define compare_Location_T_Obu_BasicTypes_Pkg_type compare_L_internal_Type_Obu_BasicTypes_Pkg_type
#define Location_T_Obu_BasicTypes_Pkg_filter_size L_internal_Type_Obu_BasicTypes_Pkg_filter_size
#define get_Location_T_Obu_BasicTypes_Pkg_filter_utils get_L_internal_Type_Obu_BasicTypes_Pkg_filter_utils
#define Location_T_Obu_BasicTypes_Pkg_filter_values L_internal_Type_Obu_BasicTypes_Pkg_filter_values
/****************************************************************
 ** odometry_T_Obu_BasicTypes_Pkg
 ****************************************************************/
extern const char * odometry_T_Obu_BasicTypes_Pkg_to_string(const void* pValue);
extern int check_odometry_T_Obu_BasicTypes_Pkg_string(const char* strValue);
extern int string_to_odometry_T_Obu_BasicTypes_Pkg(const char* strValue, void* pValue);
int is_odometry_T_Obu_BasicTypes_Pkg_allow_double_convertion();
extern int odometry_T_Obu_BasicTypes_Pkg_to_double(double * nValue, const void*);
#define get_odometry_T_Obu_BasicTypes_Pkg_signature get_struct__5701_signature
#define compare_odometry_T_Obu_BasicTypes_Pkg_type compare_struct__5701_type
#define odometry_T_Obu_BasicTypes_Pkg_filter_size struct__5701_filter_size
#define get_odometry_T_Obu_BasicTypes_Pkg_filter_utils get_struct__5701_filter_utils
#define odometry_T_Obu_BasicTypes_Pkg_filter_values struct__5701_filter_values
/****************************************************************
 ** positionedBG_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * positionedBG_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_positionedBG_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_positionedBG_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_positionedBG_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int positionedBG_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_positionedBG_T_TrainPosition_Types_Pck_signature get_struct__5642_signature
#define compare_positionedBG_T_TrainPosition_Types_Pck_type compare_struct__5642_type
#define positionedBG_T_TrainPosition_Types_Pck_filter_size struct__5642_filter_size
#define get_positionedBG_T_TrainPosition_Types_Pck_filter_utils get_struct__5642_filter_utils
#define positionedBG_T_TrainPosition_Types_Pck_filter_values struct__5642_filter_values
/****************************************************************
 ** infoFromLinking_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * infoFromLinking_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_infoFromLinking_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_infoFromLinking_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_infoFromLinking_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int infoFromLinking_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_infoFromLinking_T_TrainPosition_Types_Pck_signature get_struct__5600_signature
#define compare_infoFromLinking_T_TrainPosition_Types_Pck_type compare_struct__5600_type
#define infoFromLinking_T_TrainPosition_Types_Pck_filter_size struct__5600_filter_size
#define get_infoFromLinking_T_TrainPosition_Types_Pck_filter_utils get_struct__5600_filter_utils
#define infoFromLinking_T_TrainPosition_Types_Pck_filter_values struct__5600_filter_values
/****************************************************************
 ** trainProperties_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * trainProperties_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_trainProperties_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_trainProperties_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_trainProperties_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int trainProperties_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_trainProperties_T_TrainPosition_Types_Pck_signature get_struct__5690_signature
#define compare_trainProperties_T_TrainPosition_Types_Pck_type compare_struct__5690_type
#define trainProperties_T_TrainPosition_Types_Pck_filter_size struct__5690_filter_size
#define get_trainProperties_T_TrainPosition_Types_Pck_filter_utils get_struct__5690_filter_utils
#define trainProperties_T_TrainPosition_Types_Pck_filter_values struct__5690_filter_values
/****************************************************************
 ** linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_signature get_array__5740_signature
#define compare_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_type compare_array__5740_type
#define linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_filter_size array__5740_filter_size
#define get_linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_filter_utils get_array__5740_filter_utils
#define linkedBGs_asPositionedBGs_T_TrainPosition_Types_Pck_filter_values array__5740_filter_values
/****************************************************************
 ** positionedBGs_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * positionedBGs_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_positionedBGs_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_positionedBGs_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_positionedBGs_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int positionedBGs_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_positionedBGs_T_TrainPosition_Types_Pck_signature get_array__5687_signature
#define compare_positionedBGs_T_TrainPosition_Types_Pck_type compare_array__5687_type
#define positionedBGs_T_TrainPosition_Types_Pck_filter_size array__5687_filter_size
#define get_positionedBGs_T_TrainPosition_Types_Pck_filter_utils get_array__5687_filter_utils
#define positionedBGs_T_TrainPosition_Types_Pck_filter_values array__5687_filter_values
/****************************************************************
 ** positionErrors_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * positionErrors_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_positionErrors_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_positionErrors_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_positionErrors_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int positionErrors_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_positionErrors_T_TrainPosition_Types_Pck_signature get_struct__5681_signature
#define compare_positionErrors_T_TrainPosition_Types_Pck_type compare_struct__5681_type
#define positionErrors_T_TrainPosition_Types_Pck_filter_size struct__5681_filter_size
#define get_positionErrors_T_TrainPosition_Types_Pck_filter_utils get_struct__5681_filter_utils
#define positionErrors_T_TrainPosition_Types_Pck_filter_values struct__5681_filter_values
/****************************************************************
 ** trainPosition_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * trainPosition_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_trainPosition_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_trainPosition_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_trainPosition_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int trainPosition_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_trainPosition_T_TrainPosition_Types_Pck_signature get_struct__5664_signature
#define compare_trainPosition_T_TrainPosition_Types_Pck_type compare_struct__5664_type
#define trainPosition_T_TrainPosition_Types_Pck_filter_size struct__5664_filter_size
#define get_trainPosition_T_TrainPosition_Types_Pck_filter_utils get_struct__5664_filter_utils
#define trainPosition_T_TrainPosition_Types_Pck_filter_values struct__5664_filter_values
/****************************************************************
 ** trainPositionInfo_T_TrainPosition_Types_Pck
 ****************************************************************/
extern const char * trainPositionInfo_T_TrainPosition_Types_Pck_to_string(const void* pValue);
extern int check_trainPositionInfo_T_TrainPosition_Types_Pck_string(const char* strValue);
extern int string_to_trainPositionInfo_T_TrainPosition_Types_Pck(const char* strValue, void* pValue);
int is_trainPositionInfo_T_TrainPosition_Types_Pck_allow_double_convertion();
extern int trainPositionInfo_T_TrainPosition_Types_Pck_to_double(double * nValue, const void*);
#define get_trainPositionInfo_T_TrainPosition_Types_Pck_signature get_struct__5653_signature
#define compare_trainPositionInfo_T_TrainPosition_Types_Pck_type compare_struct__5653_type
#define trainPositionInfo_T_TrainPosition_Types_Pck_filter_size struct__5653_filter_size
#define get_trainPositionInfo_T_TrainPosition_Types_Pck_filter_utils get_struct__5653_filter_utils
#define trainPositionInfo_T_TrainPosition_Types_Pck_filter_values struct__5653_filter_values

#endif /*VINCENT_SCENARIO_07_CTP_T_PCK_TYPES_CONVERTION */
