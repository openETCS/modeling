/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.h"

void trainMovementSensor_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  outC->init = kcg_true;
}

/* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor */
void trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg(
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  outC_trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg *outC)
{
  static Speed_T_Obu_BasicTypes_Pkg tmp;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */
  static SSM_ST_SM1 SM1_state_sel;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::SM1 */
  static SSM_ST_SM1 SM1_state_act;
  /* CalculateTrainPosition_Pkg::Pos_Pkg::trainMovementSensor::standstillDetected */
  static kcg_bool standstillDetected;
  
  if (outC->init) {
    tmp = cOdometryStartVal_CalculateTrainPosition_Pkg_Pos_Pkg.speed;
    outC->init = kcg_false;
    SM1_state_sel = SSM_st_Unknown_SM1;
  }
  else {
    tmp = outC->rem_currentOdometry.speed;
    SM1_state_sel = outC->SM1_state_nxt;
  }
  standstillDetected = ((*currentOdometry).speed ==
      cSpeed_0_CalculateTrainPosition_Pkg_Pos_Pkg) &
    (cSpeed_0_CalculateTrainPosition_Pkg_Pos_Pkg == tmp);
  switch (SM1_state_sel) {
    case SSM_st_Unknown_SM1 :
      if ((*currentOdometry).speed < 0) {
        SM1_state_act = SSM_st_Decreasing_SM1;
      }
      else if ((*currentOdometry).speed > 0) {
        SM1_state_act = SSM_st_Increasing_SM1;
      }
      else if ((*currentOdometry).speed == 0) {
        SM1_state_act = SSM_st_Standstill_SM1;
      }
      else {
        SM1_state_act = SSM_st_Unknown_SM1;
      }
      break;
    case SSM_st_Decreasing_SM1 :
      if ((*currentOdometry).speed > 0) {
        SM1_state_act = SSM_st_Increasing_SM1;
      }
      else if (standstillDetected) {
        SM1_state_act = SSM_st_Standstill_SM1;
      }
      else {
        SM1_state_act = SSM_st_Decreasing_SM1;
      }
      break;
    case SSM_st_Increasing_SM1 :
      if ((*currentOdometry).speed < 0) {
        SM1_state_act = SSM_st_Decreasing_SM1;
      }
      else if (standstillDetected) {
        SM1_state_act = SSM_st_Standstill_SM1;
      }
      else {
        SM1_state_act = SSM_st_Increasing_SM1;
      }
      break;
    case SSM_st_Standstill_SM1 :
      if ((*currentOdometry).speed > 0) {
        SM1_state_act = SSM_st_Increasing_SM1;
      }
      else if ((*currentOdometry).speed < 0) {
        SM1_state_act = SSM_st_Decreasing_SM1;
      }
      else {
        SM1_state_act = SSM_st_Standstill_SM1;
      }
      break;
    
  }
  switch (SM1_state_act) {
    case SSM_st_Unknown_SM1 :
      outC->SM1_state_nxt = SSM_st_Unknown_SM1;
      outC->direction = trm_unknown_CalculateTrainPosition_Pkg_Pos_Pkg;
      break;
    case SSM_st_Decreasing_SM1 :
      outC->SM1_state_nxt = SSM_st_Decreasing_SM1;
      outC->direction = trm_decreasing_CalculateTrainPosition_Pkg_Pos_Pkg;
      break;
    case SSM_st_Increasing_SM1 :
      outC->SM1_state_nxt = SSM_st_Increasing_SM1;
      outC->direction = trm_increasing_CalculateTrainPosition_Pkg_Pos_Pkg;
      break;
    case SSM_st_Standstill_SM1 :
      outC->SM1_state_nxt = SSM_st_Standstill_SM1;
      outC->direction = trm_standstill_CalculateTrainPosition_Pkg_Pos_Pkg;
      break;
    
  }
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(
    &outC->rem_currentOdometry,
    currentOdometry);
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** trainMovementSensor_CalculateTrainPosition_Pkg_Pos_Pkg.c
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

