/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */
#ifndef _vincent_scenario_07_ctp_t_pck_H_
#define _vincent_scenario_07_ctp_t_pck_H_

#include "kcg_types.h"
#include "stimulator_ctp_t_pck_t_engine.h"
#include "observeBG_ctp_t_pck_t_engine.h"
#include "calculateTrainPosition_CalculateTrainPosition_Pkg.h"

/* =====================  no input structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  trainPosition_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::trainPosition */ trainPosition;
  trainPositionInfo_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::trainPositionInfo */ trainPositionInfo;
  positionedBGs_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::BGs */ BGs;
  positionErrors_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::errors */ errors;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::pos_true */ pos_true;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::pos_min */ pos_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::pos_nom */ pos_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::pos_max */ pos_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_001_min */ locBG_001_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_001_nom */ locBG_001_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_001_max */ locBG_001_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_002_min */ locBG_002_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_002_nom */ locBG_002_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_002_max */ locBG_002_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_003_min */ locBG_003_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_003_nom */ locBG_003_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_003_max */ locBG_003_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_004_min */ locBG_004_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_004_nom */ locBG_004_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_004_max */ locBG_004_max;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_005_min */ locBG_005_min;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_005_nom */ locBG_005_nom;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::locBG_005_max */ locBG_005_max;
  /* -----------------------   local probes  ------------------------- */
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::trainPos */ trainPos;
  /* -------------------- initialization variables  ------------------ */
  kcg_bool init;
  /* ----------------------- local memories  ------------------------- */
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::LRBG */ LRBG;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_observeBG_ctp_t_pck_t_engine /* 1 */ _2_Context_1;
  outC_observeBG_ctp_t_pck_t_engine /* 3 */ Context_3;
  outC_observeBG_ctp_t_pck_t_engine /* 4 */ Context_4;
  outC_observeBG_ctp_t_pck_t_engine /* 5 */ Context_5;
  outC_observeBG_ctp_t_pck_t_engine /* 2 */ Context_2;
  outC_calculateTrainPosition_CalculateTrainPosition_Pkg /* 1 */ _1_Context_1;
  outC_stimulator_ctp_t_pck_t_engine /* 1 */ Context_1;
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  positionErrors_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L5 */ _L5;
  positionedBGs_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L4 */ _L4;
  trainPositionInfo_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L3 */ _L3;
  trainPosition_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L2 */ _L2;
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L7 */ _L7;
  kcg_bool /* ctp_t_pck::vincent_scenario_07::_L8 */ _L8;
  trainProperties_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L9 */ _L9;
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L11 */ _L11;
  positionedBG_T_TrainPosition_Types_Pck /* ctp_t_pck::vincent_scenario_07::_L13 */ _L13;
  LocWithInAcc_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L14 */ _L14;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L20 */ _L20;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L19 */ _L19;
  L_internal_Type_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L18 */ _L18;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L21 */ _L21;
  passedBG_T_BG_Types_Pkg /* ctp_t_pck::vincent_scenario_07::_L10 */ _L10;
  odometry_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L1 */ _L1;
  kcg_int /* ctp_t_pck::vincent_scenario_07::_L22 */ _L22;
  kcg_int /* ctp_t_pck::vincent_scenario_07::_L23 */ _L23;
  kcg_int /* ctp_t_pck::vincent_scenario_07::_L24 */ _L24;
  kcg_int /* ctp_t_pck::vincent_scenario_07::_L25 */ _L25;
  kcg_int /* ctp_t_pck::vincent_scenario_07::_L26 */ _L26;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L31 */ _L31;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L30 */ _L30;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L29 */ _L29;
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L52 */ _L52;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L53 */ _L53;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L54 */ _L54;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L55 */ _L55;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L59 */ _L59;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L60 */ _L60;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L61 */ _L61;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L62 */ _L62;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L63 */ _L63;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L64 */ _L64;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L65 */ _L65;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L66 */ _L66;
  Location_T_Obu_BasicTypes_Pkg /* ctp_t_pck::vincent_scenario_07::_L67 */ _L67;
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L68 */ _L68;
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L69 */ _L69;
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L70 */ _L70;
  genPassedBG_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L71 */ _L71;
  genPassedBGs_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L73 */ _L73;
  odometryFactors_T_ctp_t_pck_t_engine /* ctp_t_pck::vincent_scenario_07::_L74 */ _L74;
} outC_vincent_scenario_07_ctp_t_pck;

/* ===========  node initialization and cycle functions  =========== */
/* ctp_t_pck::vincent_scenario_07 */
extern void vincent_scenario_07_ctp_t_pck(
  outC_vincent_scenario_07_ctp_t_pck *outC);

extern void vincent_scenario_07_reset_ctp_t_pck(
  outC_vincent_scenario_07_ctp_t_pck *outC);

#endif /* _vincent_scenario_07_ctp_t_pck_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** vincent_scenario_07_ctp_t_pck.h
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

