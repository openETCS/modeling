/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config D:/User/bw1stws0/text/z_OpenETCS/muell/muell_17/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/KCG\kcg_s2c_config.txt
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateTrainpositionAttributes_CalculateTrainPosition_Pkg.h"

void calculateTrainpositionAttributes_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg *outC)
{
  /* 1 */
  runningDirectionVsRef_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
    &outC->Context_1);
}

/** Figures out the attributes of the current train position with reference to a given LRBG. */
/** "Remark_1" {Description = "The main function calculating the actual train position. - Description: Calculates the actual train position based on passed balise groups - Copyright Siemens AG, 2014 - Licensed under the EUPL V.1.1 ( http://joinup.ec.europa.eu/software/page/eupl/licence-eupl ) - Gist URL: --- - Cryptography: No - Author(s): Uwe Steinke  The use of this software is limited to non-vital applications.  It has not been developed for vital operation purposes and must not be used for applications which may cause harm to people, physical accidents or financial loss.  THEREFORE, NO LIABILITY WILL BE GIVEN FOR SUCH AND ANY OTHER KIND OF USE.   "} */
/** "GdC_1" {Author = "Author : Uwe Steinke", DateC = "Created : 2014-15-22", DateM = "Modified : 2014-06-03", Version = "No 00.03.00"} */
/* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes */
void calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::LRBG */positionedBG_T_TrainPosition_Types_Pck *LRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::prevLRBG */positionedBG_T_TrainPosition_Types_Pck *prevLRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainPositionInfo */trainPositionInfo_T_TrainPosition_Types_Pck *trainPositionInfo,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg *outC)
{
  static Q_DIRTRAIN tmp;
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L243 */
  static LocWithInAcc_T_Obu_BasicTypes_Pkg _L243;
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L260 */
  static NID_LRBG _L260;
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::_L266 */
  static kcg_bool _L266;
  
  outC->trainPosition.valid = (*trainPositionInfo).valid;
  outC->trainPosition.timestamp = (*trainPositionInfo).timestamp;
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->trainPosition.trainPosition,
    &(*trainPositionInfo).trainPosition);
  outC->trainPosition.speed = (*trainPositionInfo).speed;
  _L266 = !(*LRBG).valid;
  outC->trainPosition.noCoordinateSystemHasBeenAssigned = _L266 |
    (*LRBG).infoFromPassing.noCoordinateSystemHasBeenAssigned;
  _L260 = /* nidC_nidBG_2_NIDLRBG */
    nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
      (*LRBG).valid,
      (*LRBG).nid_c,
      (*LRBG).nid_bg);
  outC->trainPosition.trainPositionIsUnknown = _L266 |
    (cNID_LRBG_unknown_BG_Types_Pkg == _L260);
  outC->trainPosition.nid_LRBG = _L260;
  /* 1 */
  add_2_Distances_BasicLocationFunctions_Pkg(
    &(*trainPositionInfo).trainPosition,
    &(*trainProperties).d_baliseAntenna_2_frontend,
    &_L243);
  outC->trainPosition.estimatedFrontEndPosition = _L243.nominal;
  outC->trainPosition.minSafeFrontEndPosition = _L243.nominal + _L243.d_min;
  outC->trainPosition.maxSafeFrontEndPostion = _L243.nominal + _L243.d_max;
  outC->trainPosition.nid_PrvLRB = /* 1 */
    nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
      (*prevLRBG).valid,
      (*prevLRBG).nid_c,
      (*prevLRBG).nid_bg);
  outC->trainPosition.nominalOrReverseToLRBG = /* 1 */
    frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg(
      LRBG,
      trainPositionInfo,
      trainProperties);
  if (_L266) {
    outC->trainPosition.trainOrientationToLRBG = Q_DIRLRBG_Unknown;
    tmp = Q_DIRTRAIN_Unknown;
  }
  else {
    outC->trainPosition.trainOrientationToLRBG =
      (*LRBG).infoFromPassing.trainOrientationToBG;
    tmp = (*LRBG).infoFromPassing.trainRunningDirectionToBG;
  }
  /* 1 */
  runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(
    tmp,
    (*LRBG).infoFromPassing.passingSpeed,
    currentOdometry,
    &outC->Context_1);
  outC->trainPosition.trainRunningDirectionToLRBG =
    outC->Context_1.trainRunningDirection;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainpositionAttributes_CalculateTrainPosition_Pkg.c
** Generation date: 2014-12-02T12:57:50
*************************************************************$ */

