/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/Simulation\kcg_s2c_config.txt
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "calculateTrainpositionAttributes_CalculateTrainPosition_Pkg.h"

void calculateTrainpositionAttributes_reset_CalculateTrainPosition_Pkg(
  outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg *outC)
{
  /* 1 */
  nidC_nidBG_2_NIDLRBG_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->_3_Context_1);
  /* nidC_nidBG_2_NIDLRBG */
  nidC_nidBG_2_NIDLRBG_reset_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    &outC->Context_nidC_nidBG_2_NIDLRBG);
  /* 1 */
  runningDirectionVsRef_reset_CalculateTrainPosition_Pkg_Pos_Pkg(
    &outC->_2_Context_1);
  /* 1 */
  frontendToLRBG_reset_CalculateTrainPosition_Pkg_Pos_Pkg(&outC->_1_Context_1);
  /* 1 */ add_2_Distances_reset_BasicLocationFunctions_Pkg(&outC->Context_1);
}

/* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes */
void calculateTrainpositionAttributes_CalculateTrainPosition_Pkg(
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::LRBG */positionedBG_T_TrainPosition_Types_Pck *LRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::prevLRBG */positionedBG_T_TrainPosition_Types_Pck *prevLRBG,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainPositionInfo */trainPositionInfo_T_TrainPosition_Types_Pck *trainPositionInfo,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::currentOdometry */odometry_T_Obu_BasicTypes_Pkg *currentOdometry,
  /* CalculateTrainPosition_Pkg::calculateTrainpositionAttributes::trainProperties */trainProperties_T_TrainPosition_Types_Pck *trainProperties,
  outC_calculateTrainpositionAttributes_CalculateTrainPosition_Pkg *outC)
{
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->_L224,
    trainPositionInfo);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L225,
    &outC->_L224.trainPosition);
  kcg_copy_trainProperties_T_TrainPosition_Types_Pck(
    &outC->_L237,
    trainProperties);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L242,
    &outC->_L237.d_baliseAntenna_2_frontend);
  /* 1 */
  add_2_Distances_BasicLocationFunctions_Pkg(
    &outC->_L225,
    &outC->_L242,
    &outC->Context_1);
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L243,
    &outC->Context_1.distance);
  outC->_L249 = outC->_L243.d_max;
  outC->_L248 = outC->_L243.d_min;
  outC->_L247 = outC->_L243.nominal;
  outC->_L316 = outC->_L247 + outC->_L249;
  outC->_L315 = outC->_L247 + outC->_L248;
  outC->_L314 = Q_DIRTRAIN_Unknown;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L221, LRBG);
  outC->_L220 = outC->_L221.valid;
  outC->_L266 = !outC->_L220;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L270, LRBG);
  outC->_L275 = outC->_L270.infoFromPassing.trainRunningDirectionToBG;
  if (outC->_L266) {
    outC->_L313 = outC->_L314;
  }
  else {
    outC->_L313 = outC->_L275;
  }
  outC->_L311 = Q_DIRLRBG_Unknown;
  outC->_L274 = outC->_L270.infoFromPassing.trainOrientationToBG;
  if (outC->_L266) {
    outC->_L312 = outC->_L311;
  }
  else {
    outC->_L312 = outC->_L274;
  }
  outC->_L223 = outC->_L221.infoFromPassing.noCoordinateSystemHasBeenAssigned;
  outC->_L310 = outC->_L266 | outC->_L223;
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->_L309,
    trainPositionInfo);
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L308, LRBG);
  kcg_copy_trainProperties_T_TrainPosition_Types_Pck(
    &outC->_L307,
    trainProperties);
  /* 1 */
  frontendToLRBG_CalculateTrainPosition_Pkg_Pos_Pkg(
    &outC->_L308,
    &outC->_L309,
    &outC->_L307,
    &outC->_1_Context_1);
  outC->_L306 = outC->_1_Context_1.nominalOrReverseToLRBG;
  kcg_copy_odometry_T_Obu_BasicTypes_Pkg(&outC->_L305, currentOdometry);
  outC->_L276 = outC->_L270.infoFromPassing.passingSpeed;
  /* 1 */
  runningDirectionVsRef_CalculateTrainPosition_Pkg_Pos_Pkg(
    outC->_L313,
    outC->_L276,
    &outC->_L305,
    &outC->_2_Context_1);
  outC->_L304 = outC->_2_Context_1.trainRunningDirection;
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->_L302,
    trainPositionInfo);
  outC->_L303 = outC->_L302.speed;
  kcg_copy_trainPositionInfo_T_TrainPosition_Types_Pck(
    &outC->_L218,
    trainPositionInfo);
  outC->_L301 = outC->_L218.timestamp;
  outC->_L268 = cNID_LRBG_unknown_BG_Types_Pkg;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L227, LRBG);
  outC->_L261 = outC->_L227.valid;
  outC->_L262 = outC->_L227.nid_c;
  outC->_L263 = outC->_L227.nid_bg;
  /* nidC_nidBG_2_NIDLRBG */
  nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    outC->_L261,
    outC->_L262,
    outC->_L263,
    &outC->Context_nidC_nidBG_2_NIDLRBG);
  outC->_L260 = outC->Context_nidC_nidBG_2_NIDLRBG.nidLRBG;
  outC->_L269 = outC->_L268 == outC->_L260;
  outC->_L267 = outC->_L266 | outC->_L269;
  kcg_copy_positionedBG_T_TrainPosition_Types_Pck(&outC->_L230, prevLRBG);
  outC->_L265 = outC->_L230.nid_c;
  outC->_L234 = outC->_L230.valid;
  outC->_L229 = outC->_L230.nid_bg;
  /* 1 */
  nidC_nidBG_2_NIDLRBG_CalculateTrainPosition_Pkg_BG_utilities_Pkg(
    outC->_L234,
    outC->_L265,
    outC->_L229,
    &outC->_3_Context_1);
  outC->_L264 = outC->_3_Context_1.nidLRBG;
  outC->_L219 = outC->_L218.valid;
  outC->_L205.valid = outC->_L219;
  outC->_L205.timestamp = outC->_L301;
  outC->_L205.trainPositionIsUnknown = outC->_L267;
  outC->_L205.noCoordinateSystemHasBeenAssigned = outC->_L310;
  kcg_copy_LocWithInAcc_T_Obu_BasicTypes_Pkg(
    &outC->_L205.trainPosition,
    &outC->_L225);
  outC->_L205.estimatedFrontEndPosition = outC->_L247;
  outC->_L205.minSafeFrontEndPosition = outC->_L315;
  outC->_L205.maxSafeFrontEndPostion = outC->_L316;
  outC->_L205.nid_LRBG = outC->_L260;
  outC->_L205.nid_PrvLRB = outC->_L264;
  outC->_L205.nominalOrReverseToLRBG = outC->_L306;
  outC->_L205.trainOrientationToLRBG = outC->_L312;
  outC->_L205.trainRunningDirectionToLRBG = outC->_L304;
  outC->_L205.speed = outC->_L303;
  kcg_copy_trainPosition_T_TrainPosition_Types_Pck(
    &outC->trainPosition,
    &outC->_L205);
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** calculateTrainpositionAttributes_CalculateTrainPosition_Pkg.c
** Generation date: 2014-10-27T12:56:02
*************************************************************$ */

