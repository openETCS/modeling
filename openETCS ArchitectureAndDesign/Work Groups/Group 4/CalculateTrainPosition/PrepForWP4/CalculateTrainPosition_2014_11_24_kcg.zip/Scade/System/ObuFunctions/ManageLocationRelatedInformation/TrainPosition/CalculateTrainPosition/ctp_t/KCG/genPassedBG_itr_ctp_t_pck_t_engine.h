/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config S:/SDVAL_RAMS/F�rderprojekte/openETCS/modeling/model/Scade/System/ObuFunctions/ManageLocationRelatedInformation/TrainPosition/CalculateTrainPosition/ctp_t/KCG\kcg_s2c_config.txt
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */
#ifndef _genPassedBG_itr_ctp_t_pck_t_engine_H_
#define _genPassedBG_itr_ctp_t_pck_t_engine_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */


/* ctp_t_pck::t_engine::genPassedBG_itr */
extern void genPassedBG_itr_ctp_t_pck_t_engine(
  /* ctp_t_pck::t_engine::genPassedBG_itr::accPassedBG */passedBG_T_BG_Types_Pkg *accPassedBG,
  /* ctp_t_pck::t_engine::genPassedBG_itr::location */L_internal_Type_Obu_BasicTypes_Pkg location,
  /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG_in */genPassedBG_T_ctp_t_pck_t_engine *passedBG_in,
  /* ctp_t_pck::t_engine::genPassedBG_itr::cont */kcg_bool *cont,
  /* ctp_t_pck::t_engine::genPassedBG_itr::passedBG */passedBG_T_BG_Types_Pkg *passedBG);

#endif /* _genPassedBG_itr_ctp_t_pck_t_engine_H_ */
/* $*************** KCG Version 6.1.3 (build i6) ****************
** genPassedBG_itr_ctp_t_pck_t_engine.h
** Generation date: 2014-10-21T17:48:28
*************************************************************$ */

